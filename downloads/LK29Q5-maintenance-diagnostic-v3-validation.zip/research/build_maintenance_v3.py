"""Diagnostic v3: original profile exemption, never a forced state getter.
Full printer boot and real device operations remain unverified.
"""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parents[1];BASE=0x433e0000
ORIGINAL_SHA='82c4c34f4ed5c1dd7118dd74839b499329d732d37b467df734ed5382a25dedac'

def build():
 original=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes()
 assert hashlib.sha256(original).hexdigest()==ORIGINAL_SHA
 assert original[0x43409724-BASE:0x4340972c-BASE]==bytes.fromhex('0100a0e31eff2fe1')
 code=bytearray(original);patches=[]
 def constant(a,value,reason):
  off=a-BASE;after=struct.pack('<II',0xe3a00000|value,0xe12fff1e)
  patches.append({'address':hex(a),'before':original[off:off+8].hex(),'after':after.hex(),'reason':reason})
  code[off:off+8]=after
 constant(0x4340ace0,1,'Select original per-box chip-exemption profile branches (compiled box count is one)')
 constant(0x43407ffc,100,'Remaining report always 100')
 for a,reason in [(0x43406890,'Primary consumption read reports zero'),(0x434068bc,'Secondary consumption read reports zero'),
                  (0x434068ac,'Do not add primary consumption'),(0x434068d8,'Do not add secondary consumption'),
                  (0x434068e8,'Do not add whole-unit or fractional consumption')]:constant(a,0,reason)
 preserved=[(0x43407f5c,0x24),(0x43407ec4,0x80),(0x43408308,0xb4),(0x43410748,0xe0),
            (0x43408468,0x6c),(0x433f3b7c,0x244),(0x43406330,0xb0)]
 for a,n in preserved:assert code[a-BASE:a-BASE+n]==original[a-BASE:a-BASE+n]
 changed=[i for i,(a,b) in enumerate(zip(original,code)) if a!=b]
 allowed={i for p in patches for i in range(int(p['address'],16)-BASE,int(p['address'],16)-BASE+8)}
 assert set(changed)<=allowed
 manifest={'artifact_type':'Uncompressed diagnostic ARM module; not a boot-validated firmware',
 'version':'LK29Q5','original_sha256':ORIGINAL_SHA,'module_sha256':hashlib.sha256(code).hexdigest(),
 'patches':patches,'changed_bytes':len(changed),'raw_state_getter_preserved':True,
 'notification_code_preserved':True,'status_output_code_preserved':True,'cover_interlock_preserved':True,
 'limitations':['Full startup is not emulated','Actual hardware CSIC driver and RTOS scheduling are not exercised',
 'Original profile-byte semantics beyond observed branches are not established','Preexisting stored consumption is preserved, not erased']}
 (ROOT/'experimental/maintenance-control.diagnostic-v3.bin').write_bytes(code)
 (ROOT/'experimental/maintenance-control.diagnostic-v3.json').write_text(json.dumps(manifest,indent=2)+'\n')
 return bytes(code),manifest
if __name__=='__main__':
 _,manifest=build();print(json.dumps(manifest,indent=2))
