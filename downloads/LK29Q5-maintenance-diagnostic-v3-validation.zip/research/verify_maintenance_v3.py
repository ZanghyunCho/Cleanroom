"""Native diagnostic-v3 regression suite. Not a complete firmware boot test."""
import hashlib,itertools,json,struct
from build_maintenance_v3 import build,ROOT,BASE
from maintenance_v3_fixture import Fixture
from probe_maintenance_notifications import capture_reports
from probe_startup_status import run as status_case

COUNTERS=(0x437cfebc,0x437cfecc,0x437cff9c,0x437ceba4)

def immutable(n,code,manifest):
 ranges=[(0x43407f5c,0x24),(0x43407ec4,0x80),(0x43408308,0xb4),(0x43410748,0xe0),
         (0x43408468,0x6c),(0x4340df98,0x1c4),(0x4340de44,0x154)]
 ranges += [(int(p['address'],16),8) for p in manifest['patches']]
 for a,size in ranges:assert bytes(n.u.mem_read(a,size))==code[a-BASE:a-BASE+size],hex(a)

def main():
 code,manifest=build();original=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes()
 # Negative control: the modeled absent device must actually cause original
 # workers to fail; it is not a fixture that accepts every input.
 baseline=Fixture(original,hardware_present=False);baseline.call(0x43407ec4)
 baseline_result=baseline.call(0x4340e15c,0x42001000)
 assert baseline_result==0 and len(baseline.hardware_calls)>0
 flows=[]
 for present,stored,mirror_fill,profile_flag in itertools.product((False,True),(0,123000000,0xffffffff),(0,255),(0,1)):
  n=Fixture(code,profile_flag,present)
  mirror=n.literal(0x43407740,-0x140);n.u.mem_write(mirror,bytes([mirror_fill])*192)
  for ptr in COUNTERS:n.u.mem_write(ptr,struct.pack('<I',stored))
  n.u.mem_write(n.state,b'\x07');n.u.mem_write(n.state+8,b'\0')
  n.call(0x434051b4) # original outer maintenance initializer, including mirror/cache setup
  n.call(0x43405798,0) # original capacity setup through its profile branch
  n.u.mem_write(mirror,bytes([mirror_fill])*192) # post-initialization mirror snapshot fixture
  assert n.call(0x43407f5c)==0
  n.call(0x4340e428,3) # unmodified initial presence cache population
  assert n.call(0x43407f5c)==0
  output=0x42001000;request=0x42002000
  n.u.mem_write(request,struct.pack('<II',500000000,0)+bytes(24))
  returns={}
  for fn,args in [(0x4340e15c,(output,)),(0x4340df98,(output,0)),
                  (0x4340de44,(0,0)),(0x43410144,(request,)),
                  (0x43410330,(request,)),(0x43410430,(request,)),
                  (0x4341027c,(request,0))]:
   value=n.call(fn,*args);returns[hex(fn)]=value
   assert value==1,(hex(fn),present,stored,mirror_fill,profile_flag,value)
   assert n.call(0x43407f5c)==0
  # A subsequent presence poll with its transition handler must keep state 0.
  mask=0x42003000;presence=mask+16
  n.u.mem_write(mask,struct.pack('<I',1)+bytes(12))
  n.call(0x43406214,mask,presence)
  assert struct.unpack('<I',n.u.mem_read(presence,4))[0]==1
  n.call(0x43406330,mask,presence)
  assert n.call(0x43407f5c)==0
  for fn in (0x434068ac,0x434068d8,0x434068e8):n.call(fn,0,0xffffffff)
  after=[struct.unpack('<I',n.u.mem_read(p,4))[0] for p in COUNTERS]
  assert after==[stored]*4
  assert n.call(0x43406890)==n.call(0x434068bc)==0
  assert n.call(0x43406928)==n.call(0x43407ffc)==100
  n.call(0x43410748,output)
  assert n.u.mem_read(output,1)[0]==1
  assert not n.hardware_calls,'Exempt box must not query electrical chip presence'
  immutable(n,code,manifest)
  flows.append({'modeled_physical_chip_present':present,'stored_consumption':stored,
    'mirror_fill':mirror_fill,'mirror_snapshot_applied_after_initializer':True,
    'capacity_after_setup':struct.unpack('<I',n.u.mem_read(n.literal(0x43406940,0x274),4))[0],
    'profile_header_byte2_fixture':profile_flag,'worker_returns':returns,
    'outer_initializer_executed':'0x434051b4','capacity_initializer_executed':'0x43405798',
    'final_raw_state':0,'status_flag':1,'reported_remaining':100,'reported_consumption':0,
    'stored_consumption_after':after,'physical_presence_callback_calls':len(n.hardware_calls),
    'os_calls':n.os_calls,'copy_fixture_calls':n.utility_calls})
 # Preserve the original state machine and rejection of unrelated error states.
 errors=[]
 for error in range(36):
  n=Fixture(code);ref=Fixture(original,profile_flag=1)
  for fixture in (n,ref):
   fixture.call(0x43407ec4)
   fixture.call(0x43408308,0,error)
  raw=n.call(0x43407f5c);assert raw==ref.call(0x43407f5c)
  if raw not in (0,7):assert n.call(0x43410144,0)==0
  errors.append({'error':error,'raw_state':raw,'matches_original_state_transition':True})
 cover_cases=[]
 for cover in (0,1,2):
  n=Fixture(code);n.call(0x43407ec4)
  n.u.mem_write(n.cover,bytes([cover])*3)
  n.call(0x43410748,0x42001000);flag=n.u.mem_read(0x42001000,1)[0]
  assert flag==int(cover==0)
  cover_cases.append({'cover_status_fixture':cover,'status_flag':flag})
 # Native report function is unmodified. Compare each state to the original
 # corresponding report, rather than suppressing arbitrary maintenance faults.
 original_reports=capture_reports(original,tuple(range(8)))
 candidate_reports=capture_reports(code,tuple(range(8)))
 for a,b in zip(original_reports,candidate_reports):
  assert a['events']==b['events'] and a['report_hex']==b['report_hex']
  assert a['posted_messages']==b['posted_messages']
 # Reproduce the v2 status regression and demonstrate its absence after init.
 v2=(ROOT/'experimental/maintenance-control.prototype.bin').read_bytes()
 v2_status=status_case(v2,0);assert v2_status['slot0_status_flag']==0
 v3_status=status_case(code,0);assert v3_status['slot0_status_flag']==1
 result={'module_sha256':manifest['module_sha256'],
 'scope':'Native maintenance subsystem functions with synthetic RAM, bus interface and OS/copy fixtures; not a full boot',
 'flow_cases':flows,'error_cases':errors,'cover_cases':cover_cases,
 'notification_cases':candidate_reports,'v2_regression':v2_status,'v3_regression':v3_status,
 'negative_control':{'original_absent_presence_return':baseline_result,'physical_callback_calls':len(baseline.hardware_calls)},
 'scenario_count':len(flows)+len(errors)+len(cover_cases)+len(candidate_reports)+3,
 'maintenance_verdict_hooks':0,'fixtures':['OS delay','OS signaling','ROM copy utility',
 'One enumerated bus with absent/present status callback; begin/end callbacks omitted',
 'Synthetic RAM clock/cache, profile header, capacity, nonvolatile cache and chip mirror'],
 'limitations':manifest['limitations']}
 out=ROOT/'validation/maintenance-v3-native-results.json'
 out.write_text(json.dumps(result,indent=2)+'\n')
 print(out);print('PASS',result['scenario_count'],'scenarios; subsystem flows',len(flows))
if __name__=='__main__':main()
