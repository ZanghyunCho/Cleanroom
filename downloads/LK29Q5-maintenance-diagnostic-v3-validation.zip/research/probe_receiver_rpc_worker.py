"""Run original library-header worker with matching and mismatching inputs."""
import json,struct
from probe_packaged_v3_receiver import FullReceiver,ROOT,ADDRESSES

def main():
 rcx=(ROOT/'FW7560TL.rcx').read_bytes();code=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
 bias=0x2d6c00-0x27ad53;initializers=[]
 for offset in (0xa44f,0xa45b):
  src,dst,size=struct.unpack_from('<III',rcx,offset);initializers.append((dst,rcx[src-bias:src-bias+size]))
 cases=[]
 for case,offset,expected in [('original_L_header',None,1),('wrong_magic',0,0),('wrong_format',9,0),('wrong_library_id',11,0)]:
  n=FullReceiver(b'',code=code,initializers=initializers,addresses=ADDRESSES,state_address=0x43fb9838)
  header=bytearray(rcx[0x7890153:0x7891153])
  if offset is not None:header[offset]^=1
  ptr=n.malloc(4096);n.u.mem_write(ptr,bytes(header));msg=n.malloc(128)
  n.u.mem_write(msg+4,struct.pack('<HHH',1,0x12a,0x3d));n.u.mem_write(msg+12,struct.pack('<I',ptr))
  n.execute(0x4442316c,msg)
  value=n.u.mem_read(msg+0x1c,1)[0];assert value==expected
  assert bytes(n.u.mem_read(0x4442316c,0x84))==code[0x4442316c-0x4409b000:0x444231f0-0x4409b000]
  cases.append({'case':case,'native_worker_result':value,'expected_library_id_RAM_fixture':'BA','code_unchanged':True})
 out=ROOT/'validation/receiver-rpc-worker-study.json';out.write_text(json.dumps({'worker':'0x4442316c','cases':cases,'verdict_hooks':0,'fixture':'OS queue transport; RAM library ID BA, derived from compiled BA01J2 identifier; actual printer RAM not observed'},indent=2)+'\n')
 print(out);print('PASS four native library-header controls')
if __name__=='__main__':main()
