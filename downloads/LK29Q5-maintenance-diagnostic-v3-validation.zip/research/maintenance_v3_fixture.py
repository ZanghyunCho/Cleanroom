"""Explicit single-box, single-bus fixture; no maintenance verdict hooks.
The real printer's electrical bus, interrupt scheduling and boot are not modeled.
"""
import struct
from probe_maintenance_state import Control
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_PC,UC_ARM_REG_LR

class Fixture(Control):
 def __init__(self,code,profile_flag=0,hardware_present=True):
  super().__init__(code);self.trace=[];self.os_calls=[];self.hardware_calls=[];self.utility_calls=[]
  self.u.mem_map(0xb9a00000,0x400000) # synthetic RAM clock/cache, initially zero
  self.state=self.literal(0x43408000,0xc4)
  profile=self.literal(0x4340aca8,-0x474)
  self.u.mem_write(profile-0x3c+1,b'\0')
  self.u.mem_write(profile,struct.pack('<I',0x42100000))
  self.u.mem_write(0x42100000,bytes([0,0,profile_flag])+bytes(509))
  self.u.mem_write(self.literal(0x433f6378,0x27c),bytes(8))
  self.u.mem_write(self.literal(0x43406940,0x274),struct.pack('<I',1000000))
  self.u.mem_write(self.literal(0x43406b60,0x5c),struct.pack('<I',900000))
  self.cover=self.literal(0x434084c4,0x1fc)
  self.u.mem_write(self.cover,bytes(3))
  # A real bus is enumerated. Configure one route and type-zero interface.
  selector=self.literal(0x4340aa80,0x31c)
  self.u.mem_write(selector+2,b'\0\1')
  routes=self.literal(0x4340aacc,0x2c0)
  self.u.mem_write(routes,b'\0')
  types=self.literal(0x4340ab00,0x2a0)
  self.u.mem_write(types,b'\0\0\0')
  interface=self.literal(0x433f7698,-0x830)
  self.u.mem_write(interface+0x50,bytes(8)) # no hardware begin/end callbacks in this bus model
  self.u.mem_write(interface+0x58,struct.pack('<I',0x48000004))
  self.u.mem_write(0x48000004,bytes.fromhex('1eff2fe1'))
  def ret(value=0):
   self.u.reg_write(UC_ARM_REG_R0,value)
   self.u.reg_write(UC_ARM_REG_PC,self.u.reg_read(UC_ARM_REG_LR))
  def hook(u,a,size,data):
   self.trace.append(a)
   if a in (0x4360f6bc,0x436152a4):
    self.os_calls.append(hex(a));ret()
   elif a==0x43644a40:
    dest=u.reg_read(UC_ARM_REG_R0);src=u.reg_read(UC_ARM_REG_R1);count=u.reg_read(UC_ARM_REG_R2)
    assert count <= 4096
    self.utility_calls.append({'utility':'copy','destination':hex(dest),'source':hex(src),'size':count})
    u.mem_write(dest,bytes(u.mem_read(src,count)));ret(dest)
   elif a==0x48000004:
    out=u.reg_read(UC_ARM_REG_R0)
    self.hardware_calls.append({'present':hardware_present,'output':hex(out)})
    u.mem_write(out,bytes([0 if hardware_present else 1]));ret()
  self.u.hook_add(UC_HOOK_CODE,hook)
