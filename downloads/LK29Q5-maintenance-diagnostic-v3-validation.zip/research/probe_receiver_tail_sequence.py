"""Exercise unchanged complex section handlers with a four-section sequence.
The fourth section repeats ARG to satisfy the original receiver's four slots.
This is an isolated transport fixture, not the actual full EFU test.
"""
import hashlib,json,struct
from probe_packaged_v3_receiver import FullReceiver,ROOT,ADDRESSES

def main():
 rcx=(ROOT/'FW7560TL.rcx').read_bytes();code=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
 sign=rcx.index(b'EPSONSIGN');bias=0x2d6c00-0x27ad53;initializers=[]
 for offset in (0xa44f,0xa45b):
  src,dst,size=struct.unpack_from('<III',rcx,offset);initializers.append((dst,rcx[src-bias:src-bias+size]))
 wire=rcx[sign:sign+4096]+rcx[0x6fa4153:]+rcx[0x6fa4153:0x741a153]
 n=FullReceiver(wire,code=code,initializers=initializers,addresses=ADDRESSES,state_address=0x43fb9838)
 try:result,seconds=n.execute(0x4419ee30,0x430f0000,0)
 except Exception as e:
  from unicorn.arm_const import UC_ARM_REG_PC,UC_ARM_REG_LR,UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3
  print('EXCEPTION',repr(e),{str(r):hex(n.u.reg_read(r)) for r in (UC_ARM_REG_PC,UC_ARM_REG_LR,UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3)},'position',n.pos,'fixtures',n.fixture_calls,flush=True)
  raise
 record={'scope':'Four-section synthetic sequence: original ARG, rARG, L and a repeated ARG; official signature header; native metadata setters; corrected buffer capacity fixture',
 'return':result,'state':n.state(),'ecdsa_calls':n.verifications,'native_checks':n.native_check_calls,
 'raw_drain_elided_bytes':n.raw_drain_elided_bytes,'input_bytes':len(wire),'consumed_bytes':n.pos,
 'fixtures':n.fixture_calls,'seconds':seconds}
 (ROOT/'validation/receiver-tail-sequence-study.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2),flush=True)
 assert result==1 and n.raw_drain_elided_bytes==0 and n.pos==len(wire)
if __name__=='__main__':main()
