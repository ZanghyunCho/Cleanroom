"""Run the actual packaged RCX signature body through the latest ARM receiver.
RCX host preamble, physical flash writes, USB and updater are outside this test.
"""
import hashlib,json,struct,time,zipfile,pickle,argparse
from probe_lk29q5_native import ROOT,ADDRESSES
from probe_efu_native import Receiver,ORIGINAL_KEY
from native_fixture import UC_ARM_REG_PC
from unicorn.arm_const import UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3,UC_ARM_REG_CPSR,UC_ARM_REG_SP,UC_ARM_REG_LR

class FullReceiver(Receiver):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  self.raw_drain_elided_bytes=0
  self.checkpoint_saved=False
  self.u.mem_map(0x50000000,0xa000000)
  self.u.mem_map(0xb0003000,0x3ffd000) # actual RCX has a 32 MiB metadata section; model a 64 MiB workspace
  from receiver_rpc_fixture import RpcFixture
  self.rpc=RpcFixture(self)
 def read(self,u,a,n,x):
  dst,count,_,_=self.args()
  if u.reg_read(UC_ARM_REG_LR)==0x4419f1c4 and count==1 and self.pos<len(self.stream):
   # Error cleanup only: no byte values are used by this raw drain loop.
   # A positive full-body test MUST prove this optimization skipped zero bytes.
   self.raw_drain_elided_bytes+=len(self.stream)-self.pos
   self.pos=len(self.stream);self.ret(0);return
  if self.pos==0x6fa4153-0x153 and not self.checkpoint_saved:
   self.checkpoint_saved=True
   self.save_checkpoint()
  super().read(u,a,n,x)
 def bookkeeping(self,u,a,n,x):
  # Observe actual descriptor setters; preserve their RAM writes for later readers.
  self.fixture_calls.append({'kind':'native_metadata_setter','pc':hex(a)})
 def save_checkpoint(self):
  directory=ROOT/'checkpoints';directory.mkdir(exist_ok=True)
  path=directory/'v3-first-section.zip'
  state={k:getattr(self,k) for k in ('heap','pos','verifications','digests','record','fixture_calls','native_check_calls','raw_drain_elided_bytes')}
  state['context']=self.u.context_save()
  state['stream_sha256']=hashlib.sha256(self.stream).hexdigest()
  with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
   z.writestr('state.pickle',pickle.dumps(state))
   for start,end,perm in self.u.mem_regions():
    for address in range(start,end+1,0x100000):
     size=min(0x100000,end+1-address)
     z.writestr(f'memory/{address:08x}.bin',bytes(self.u.mem_read(address,size)))
  print('Saved native prefix checkpoint',path,flush=True)
 def load_checkpoint(self,path):
  # Only load a checkpoint produced by this local tool, never an uploaded pickle.
  with zipfile.ZipFile(path) as z:
   state=pickle.loads(z.read('state.pickle'))
   assert state.pop('stream_sha256')==hashlib.sha256(self.stream).hexdigest()
   context=state.pop('context')
   for name in z.namelist():
    if name.startswith('memory/'):
     address=int(name.split('/')[1].split('.')[0],16);self.u.mem_write(address,z.read(name))
   for key,value in state.items():setattr(self,key,value)
   self.u.context_restore(context);self.checkpoint_saved=True
   self.rpc.configure_id()
 def section_buffer(self,u,a,n,x):
  self.fixture_calls.append({'kind':'section_buffer','type':self.args()[1]})
  u.mem_write(self.args()[0],struct.pack('<I',0xa000000));self.ret(0x50000000)
 def execute(self,pc,*args):
  u=self.u
  if args:
   u.reg_write(UC_ARM_REG_CPSR,19);u.reg_write(UC_ARM_REG_SP,0x421ff000);u.reg_write(UC_ARM_REG_LR,0x48000000)
   for r,v in zip((UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3),args):u.reg_write(r,v)
  started=time.monotonic()
  for chunk in range(1500):
   u.emu_start(pc,0x48000000,count=100000000);pc=u.reg_read(UC_ARM_REG_PC)
   if pc==0x48000000:return u.reg_read(UC_ARM_REG_R0),time.monotonic()-started
   if chunk%5==0:print('receiver progress',self.pos,'/',len(self.stream),'bytes; pc',hex(pc),'instruction_budget_chunks',chunk+1,flush=True)
  raise RuntimeError('Native instruction budget exhausted')

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--resume-prefix',action='store_true');args=parser.parse_args()
 path=ROOT/'experimental/FW7560TL_LK29Q5-maintenance-diagnostic-v3.efu'
 with zipfile.ZipFile(path) as z:rcx=z.read('FW7560TL.rcx')
 original=(ROOT/'FW7560TL.rcx').read_bytes();sign=rcx.index(b'EPSONSIGN')
 code=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
 initializers=[];bias=0x2d6c00-0x27ad53
 for offset in (0xa44f,0xa45b):
  src,dst,size=struct.unpack_from('<III',original,offset)
  initializers.append((dst,original[src-bias:src-bias+size]))
 assert initializers[0][1][:64]==ORIGINAL_KEY
 native=FullReceiver(rcx[sign:],code=code,initializers=initializers,addresses=ADDRESSES,state_address=0x43fb9838)
 if args.resume_prefix:
  native.load_checkpoint(ROOT/'checkpoints/v3-first-section.zip')
  result,seconds=native.execute(native.u.reg_read(UC_ARM_REG_PC))
 else:result,seconds=native.execute(0x4419ee30,0x430f0000,0)
 record={'efu_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rcx_sha256':hashlib.sha256(rcx).hexdigest(),
 'native_prefix_checkpoint_used':args.resume_prefix,
 'timing_scope':'Resumed suffix only; native prefix was executed and saved separately' if args.resume_prefix else 'Complete execution',
 'scope':'Actual RCX bytes from EPSONSIGN onward, latest unmodified upper receiver, mode input 0; OS/storage/memory fixtures',
 'return':result,'ecdsa_calls':native.verifications,'state':native.state(),'bytes_consumed':native.pos,
 'wire_bytes':len(native.stream),'raw_drain_elided_bytes':native.raw_drain_elided_bytes,'native_checks':native.native_check_calls,'fixtures':native.fixture_calls,'rpc_fixture_calls':native.rpc.calls,'elapsed_seconds':seconds,
 'code_unchanged':bytes(native.u.mem_read(0x4409b000,len(code)))==code,
 'original_key_preserved':bytes(native.u.mem_read(0x43f91800,64))==ORIGINAL_KEY,
 'limitations':['No flash workers, physical boot, USB, host preamble or PC updater execution','Mode input 0 is an emulator input, not a measured printer configuration']}
 out=ROOT/'validation/maintenance-v3-full-receiver.json'
 out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2),flush=True)
 assert result==1 and native.verifications==0 and native.state()==[1,1]
 assert native.raw_drain_elided_bytes==0
 assert record['code_unchanged'] and record['original_key_preserved']
 assert native.pos == len(native.stream)
if __name__=='__main__':main()
