"""Audit the actual packaged v3 EFU with original ARM helpers."""
import hashlib,json,zipfile
from audit_recovery_failure import ROOT,checksum_audit,loader_audit

def main():
 path=ROOT/'experimental/FW7560TL_LK29Q5-maintenance-diagnostic-v3.efu'
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None;rcx=z.read('FW7560TL.rcx')
 original=(ROOT/'FW7560TL.rcx').read_bytes()
 module=(ROOT/'experimental/maintenance-control.diagnostic-v3.bin').read_bytes()
 main=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
 routine=main[0x4419e2e0-0x4409b000:0x4419e324-0x4409b000]
 checksum=checksum_audit('diagnostic_v3',rcx,routine)
 assert checksum['native_checksum_return']==1
 print('PASS full payload native sum16 and inner SHA1',flush=True)
 start=0x14153;end=start+4+int.from_bytes(rcx[start+6:start+10],'big')
 loader=loader_audit('diagnostic_v3',rcx[start:end],original[0x25bb23:0x25bb23+0xae8],module)
 assert loader['native_dma_mod48']==loader['padded_count_mod16']==0
 print('PASS native loader metadata, DMA configuration and LZ reconstruction',flush=True)
 report={'efu_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'checksum':checksum,'loader':loader,
 'limitations':['Hardware Huffman completion is modeled, not executed','Full printer boot is not exercised']}
 out=ROOT/'validation/maintenance-v3-package-audit.json'
 out.write_text(json.dumps(report,indent=2)+'\n');print(out)
if __name__=='__main__':main()
