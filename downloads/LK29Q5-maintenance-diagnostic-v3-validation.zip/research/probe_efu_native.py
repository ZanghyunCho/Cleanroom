"""Execute original P7500 ARM verifier/receiver against synthetic inputs only.

Uses the supplied Native fixture for OS and memory operations. Neither native
cryptographic verdicts nor section parser/checksum/SHA1 results are replaced.
No installable EFU is written and no physical device is accessed.
"""
from pathlib import Path
import hashlib
import json
import struct
import time
from native_fixture import Native, ROM, CODE, PUB, envelope, sign
from unicorn import UC_HOOK_CODE

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL_KEY = ROM[0x6d000:0x6d040]
ZERO_SIGNATURE = bytes(64)


def check_originals(native):
    assert hashlib.sha256(ROM).hexdigest() == 'ae9b0cd5f15f1f2edcfd671c9131d9383243e1fbf9c59b0bf31dcaa04968c551'
    assert hashlib.sha256(CODE).hexdigest() == '52bff0422d872906047c36ed8abfca899934acdf3a7ec7b7edb3ab76a6003d94'
    assert bytes(native.u.mem_read(0x4409b000, len(CODE))) == CODE


def stream_probe(name, body, wire, key, expected_return, expected_calls, expected_state):
    native = Native(wire, key)
    check_originals(native)
    output = native.malloc(len(body))
    result = native.call(0x4419eadc, 0x430f0000, output, len(body))
    check_originals(native)
    state = native.state()
    assert bytes(native.u.mem_read(0x43f91800, 64)) == key
    assert (result, native.verifications, state) == (expected_return, expected_calls, expected_state), (name, result, native.verifications, state)
    return {'name': name, 'return': result, 'ecdsa_calls': native.verifications,
            'state': state, 'bytes_consumed': native.pos,
            'original_key': key == ORIGINAL_KEY, 'code_unchanged': True}


def synthetic_section(payload, metadata=None, corrupt_checksum=False, stale_digest=None):
    metadata = bytes(range(32)) if metadata is None else metadata
    header = bytearray(4096)
    header[:14] = b'EPSON IPLu\x06LK\xff'
    struct.pack_into('<H', header, 14, 108)
    checksum = (sum(metadata) + int(corrupt_checksum)) & 0xffff
    struct.pack_into('<HHHHII', header, 16, 1, checksum, 0, 0, 0, len(metadata))
    struct.pack_into('<HHHHII', header, 52, 2, 0, 0, 0, 0, len(payload))
    digest = hashlib.sha1(payload + hashlib.sha1(header[:14]).digest()).digest()
    header[68:88] = digest if stale_digest is None else stale_digest
    return bytes(header) + metadata + payload, digest


class Receiver(Native):
    def __init__(self, wire, **native_options):
        super().__init__(wire, ORIGINAL_KEY, **native_options)
        self.fixture_calls = []
        for pc, fn in [(0x443f3f30, self.config_read),
                       (0x443f3e30, self.config_write),
                       (0x4413f920, self.section_buffer),
                       *[(pc, self.bookkeeping) for pc in
                         (0x4413fc70, 0x4413fca8, 0x4413fce0, 0x4413fd18)]]:
            pc = self.addresses.get(pc, pc)
            self.u.hook_add(UC_HOOK_CODE, fn, begin=pc, end=pc)
        self.native_check_calls = {'parser': 0, 'checksum': 0, 'sha1': 0}
        for pc, label in [(0x4419e294, 'parser'), (0x4419e130, 'checksum'),
                          (0x4419f7e0, 'sha1')]:
            def observe(u, a, n, x, label=label):
                self.native_check_calls[label] += 1
            pc = self.addresses.get(pc, pc)
            self.u.hook_add(UC_HOOK_CODE, observe, begin=pc, end=pc)

    def config_read(self, u, a, n, x):
        name, dst, size, _ = self.args()
        self.fixture_calls.append({'kind': 'config_read', 'id': hex(name), 'size': size})
        u.mem_write(dst, (b'\xff\x7f' + bytes(size))[:size])
        self.ret(0)

    def config_write(self, u, a, n, x):
        self.fixture_calls.append({'kind': 'config_write', 'id': hex(self.args()[0])})
        self.ret(0)

    def section_buffer(self, u, a, n, x):
        self.fixture_calls.append({'kind': 'section_buffer', 'type': self.args()[1]})
        u.mem_write(self.args()[0], struct.pack('<I', 0))
        self.ret(0x46000000)

    def bookkeeping(self, u, a, n, x):
        self.fixture_calls.append({'kind': 'metadata_record', 'pc': hex(a)})
        self.ret(0)


def receiver_probe(name, body, mode, expected_return, expected_calls,
                   declared=None, remove_header=False):
    wire = body if remove_header else envelope(body, declared=declared, signature=ZERO_SIGNATURE)
    native = Receiver(wire)
    check_originals(native)
    result = native.call(0x4419ec80, 0x430f0000, mode)
    check_originals(native)
    assert bytes(native.u.mem_read(0x43f91800, 64)) == ORIGINAL_KEY
    assert (result, native.verifications) == (expected_return, expected_calls), (name, mode, result, native.verifications, native.state())
    return {'name': name, 'mode_input': mode, 'return': result,
            'ecdsa_calls': native.verifications, 'state': native.state(),
            'bytes_consumed': native.pos, 'native_checks': native.native_check_calls,
            'fixtures': native.fixture_calls, 'original_key': True,
            'code_unchanged': True}


def main():
    started = time.time()
    body = b'Synthetic P7500 receiver research input.\n' * 3
    valid = envelope(body)
    bad_body = body[:-1] + bytes([body[-1] ^ 1])
    bad_sig = bytearray(valid)
    bad_sig[32] ^= 1
    bad_magic = bytearray(valid)
    bad_magic[0] ^= 1
    cases = [
        ('test_key_valid_signature', body, valid, PUB, 1, 1, [2, 0]),
        ('original_key_rejects_test_signature', body, valid, ORIGINAL_KEY, 0, 1, [1, 0]),
        ('changed_body', bad_body, valid[:4096] + bad_body, PUB, 0, 1, [1, 0]),
        ('changed_signature', body, bytes(bad_sig), PUB, 0, 1, [1, 0]),
        ('original_key_zero_signature_exact', body, envelope(body, signature=ZERO_SIGNATURE), ORIGINAL_KEY, 0, 1, [1, 0]),
        ('original_key_zero_signature_overdeclared', body, envelope(body, len(body) + 1, ZERO_SIGNATURE), ORIGINAL_KEY, 1, 0, [1, 1]),
        ('original_key_zero_signature_underdeclared', body, envelope(body, len(body) - 1, ZERO_SIGNATURE), ORIGINAL_KEY, 0, 0, [1, len(body) - 1]),
        ('zero_declared_length', body, envelope(body, 0, ZERO_SIGNATURE), ORIGINAL_KEY, 0, 0, [0, 0]),
        ('invalid_magic', body, bytes(bad_magic), ORIGINAL_KEY, 0, 0, [0, 0]),
        ('missing_signature_header', body, body, ORIGINAL_KEY, 0, 0, [0, 0]),
    ]
    streams = []
    for case in cases:
        record = stream_probe(*case)
        streams.append(record)
        print('PASS stream', record['name'], flush=True)
    payload = bytes(range(64))
    section, digest = synthetic_section(payload)
    changed_payload = bytes([payload[0] ^ 1]) + payload[1:]
    stale, _ = synthetic_section(changed_payload, stale_digest=digest)
    refreshed, _ = synthetic_section(changed_payload)
    bad_checksum, _ = synthetic_section(payload, corrupt_checksum=True)
    invalid_section = bytearray(section)
    invalid_section[0] ^= 1
    receiver_cases = [
        ('exact_zero_signature', section, 0, 1, len(section), False),
        ('overdeclared_valid_inner_checks', section, 1, 0, len(section) + 1, False),
        ('changed_body_stale_sha1', stale, 0, 0, len(stale) + 1, False),
        ('changed_body_refreshed_sha1', refreshed, 1, 0, len(refreshed) + 1, False),
        ('bad_metadata_checksum', bad_checksum, 0, 0, len(bad_checksum) + 1, False),
        ('missing_signature_header', section, 0, 0, None, True),
        ('bad_section_magic', bytes(invalid_section), 0, 0, len(section) + 1, False),
        ('underdeclared_body', section, 0, 0, len(section) - 1, False),
    ]
    receivers = []
    for mode in (0, 6):
        for name, data, ret, calls, declared, removed in receiver_cases:
            record = receiver_probe(name, data, mode, ret, calls, declared, removed)
            receivers.append(record)
            print('PASS receiver', mode, name, flush=True)
    # Verify the differential changes only the LE32 declaration in synthetic RAM input.
    exact = envelope(section, len(section), ZERO_SIGNATURE)
    over = envelope(section, len(section) + 1, ZERO_SIGNATURE)
    differences = [i for i, (a, b) in enumerate(zip(exact, over)) if a != b]
    assert differences and all(16 <= i < 20 for i in differences)
    result = {'stream_cases': streams, 'receiver_cases': receivers,
              'length_differential_offsets': differences,
              'elapsed_seconds': time.time() - started,
              'scope': 'Original LK09O2 ARM module, synthetic data and OS/storage fixtures; no physical flash, USB, updater or full boot',
              'installable_firmware_generated': False}
    out = ROOT / 'validation/efu-envelope-native-results.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    print('Saved', out)


if __name__ == '__main__':
    main()
