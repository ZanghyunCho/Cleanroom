"""Isolate the unchanged ARG section and its buffer-capacity fixture.
Raw tail drain is elided ONLY at 0x4419f1b8: the loop ignores bytes and consumes
until EOF. Cryptographic and parser verdict functions are never hooked.
"""
import hashlib,json,struct,zipfile
from probe_packaged_v3_receiver import FullReceiver,ROOT,ADDRESSES
from unicorn.arm_const import UC_ARM_REG_LR

class CapacityReceiver(FullReceiver):
 def __init__(self,*args,capacity=0,**kwargs):
  self.capacity=capacity;self.elided_drain_bytes=0
  super().__init__(*args,**kwargs)
 def section_buffer(self,u,a,n,x):
  self.fixture_calls.append({'kind':'section_buffer','type':self.args()[1],'capacity':self.capacity})
  u.mem_write(self.args()[0],struct.pack('<I',self.capacity));self.ret(0x50000000)
 def read(self,u,a,n,x):
  dst,count,_,_=self.args()
  if u.reg_read(UC_ARM_REG_LR)==0x4419f1c4:
   assert count==1
   self.elided_drain_bytes+=len(self.stream)-self.pos
   self.pos=len(self.stream);self.ret(0);return
  super().read(u,a,n,x)

def main():
 original=(ROOT/'FW7560TL.rcx').read_bytes();code=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
 sign=original.index(b'EPSONSIGN');initializers=[];bias=0x2d6c00-0x27ad53
 for offset in (0xa44f,0xa45b):
  src,dst,size=struct.unpack_from('<III',original,offset);initializers.append((dst,original[src-bias:src-bias+size]))
 wire=original[sign:sign+4096]+original[0x6fa4153:0x741a153]
 cases=[]
 for capacity,final_flag in ((0,0),(0xa000000,0),(0xa000000,255)):
  case_wire=bytearray(wire);case_wire[4096+13]=final_flag
  n=CapacityReceiver(bytes(case_wire),capacity=capacity,code=code,initializers=initializers,addresses=ADDRESSES,state_address=0x43fb9838)
  try:
   value,seconds=n.execute(0x4419ee30,0x430f0000,0)
   case={'capacity':capacity,'section_final_flag_fixture':final_flag,'return':value,'seconds':seconds,'state':n.state(),
         'native_checks':n.native_check_calls,'ecdsa_calls':n.verifications,'raw_drain_elided_bytes':n.elided_drain_bytes,'fixtures':n.fixture_calls}
  except Exception as e:case={'capacity':capacity,'section_final_flag_fixture':final_flag,'error':repr(e),'position':n.pos,'state':n.state()}
  print(json.dumps(case,indent=2),flush=True);cases.append(case)
 (ROOT/'validation/receiver-buffer-capacity-study.json').write_text(json.dumps({'scope':'Unmodified official second ARG section in isolation; original key and code; synthetic OS/buffer/transport fixtures','cases':cases},indent=2)+'\n')
if __name__=='__main__':main()
