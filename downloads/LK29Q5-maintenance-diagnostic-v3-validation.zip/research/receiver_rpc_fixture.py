"""Synchronous OS transport for queue 0x12a / method 0x3d.
The original worker 0x4442316c computes the reply. No parser/crypto verdict is
substituted. Library ID BA is a recorded RAM fixture, not a device observation.
"""
import struct
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_PC,UC_ARM_REG_LR

class RpcFixture:
 def __init__(self,native):
  self.n=native;self.pending=None;self.reply=None;self.calls=[]
  self.configure_id()
  for address in (0x44402504,0x444021f8,0x44401c9c,0x44401cc0,0x48000008):
   native.u.hook_add(UC_HOOK_CODE,self.dispatch,begin=address,end=address)
  native.u.mem_write(0x48000008,bytes.fromhex('1eff2fe1'))
 def configure_id(self):
  # Independent compiled identifier in both original LK09O2 and latest LK29Q5.
  assert bytes(self.n.u.mem_read(0x4442211c,6))==b'BA01J2'
  self.n.u.mem_write(0x44ff0227,b'BA')
 def dispatch(self,u,address,size,user):
  n=self.n;r0,r1,r2,_=n.args()
  if address==0x44402504:
   assert r0==0
   ptr=n.malloc(128);u.mem_write(r1,struct.pack('<I',ptr));n.ret(0)
   self.calls.append({'kind':'message_allocate','bytes':128})
  elif address==0x444021f8:
   u.mem_write(r0,struct.pack('<H',1));n.ret(0)
  elif address==0x44401c9c:
   if r0==0x12a:
    method=struct.unpack('<H',u.mem_read(r1+8,2))[0]
    assert method==0x3d and self.pending is None
    self.calls.append({'kind':'dispatch_original_worker','queue':hex(r0),'method':hex(method),'worker':'0x4442316c'})
    self.pending=u.context_save()
    u.reg_write(UC_ARM_REG_R0,r1);u.reg_write(UC_ARM_REG_LR,0x48000008)
    u.reg_write(UC_ARM_REG_PC,0x4442316c)
   else:
    assert r0==1
    self.reply=r1;self.calls.append({'kind':'worker_reply','result':u.mem_read(r1+0x1c,1)[0]});n.ret(0)
  elif address==0x48000008:
   assert self.pending is not None and self.reply is not None
   context=self.pending;self.pending=None;u.context_restore(context);n.ret(0)
  else:
   assert r0==1 and self.reply is not None
   u.mem_write(r2,struct.pack('<I',self.reply));self.reply=None;n.ret(0)
