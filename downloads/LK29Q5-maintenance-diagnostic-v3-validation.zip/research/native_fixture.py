"""Native P7500 EPSONSIGN envelope and receiver probes.

Replays original loader data/key descriptors in emulator memory. Native SHA and
ECDSA verdicts are NEVER replaced. OS allocation/stream/config/storage bookkeeping
and memory utility dispatches are explicit fixtures. Synthetic input only; no
installable firmware is generated and no physical device is accessed.

Scalar 1 is a PUBLIC TEST FIXTURE, not the owner's signing key. Production private
keys are neither read nor emitted by this script.
"""
from pathlib import Path
import sys, struct, hashlib, json, time
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from unicorn import *
from unicorn.arm_const import *
from cryptography.hazmat.primitives.asymmetric import ec, utils
from cryptography.hazmat.primitives import hashes
ROM = (ROOT / 'original/merged.bin').read_bytes()
CODE = (ROOT / 'decoded/crom-002d6c00-0.bin').read_bytes()
KEY = ec.derive_private_key(1, ec.SECP256R1())
pn = KEY.public_key().public_numbers()
PUB = pn.x.to_bytes(32, 'big') + pn.y.to_bytes(32, 'big')

def sign(body):
    r, s = utils.decode_dss_signature(KEY.sign(body, ec.ECDSA(hashes.SHA256())))
    return r.to_bytes(32, 'big') + s.to_bytes(32, 'big')

def envelope(body, declared=None, signature=None):
    h = bytearray(0x1000)
    h[:9] = b'EPSONSIGN'
    h[9:13] = b'LK19'
    struct.pack_into('<H', h, 13, 100)
    struct.pack_into('<I', h, 16, len(body) if declared is None else declared)
    h[32:96] = sign(body) if signature is None else signature
    return bytes(h) + body

class Native:

    def __init__(self, stream, pub=PUB, *, code=CODE, initializers=None,
                 addresses=None, state_address=0x43fb9358):
        self.addresses = {} if addresses is None else addresses
        self.state_address = state_address
        self.u = u = Uc(UC_ARCH_ARM, UC_MODE_ARM)
        u.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_A9)
        for a, n in [(0x44000000, 0x1000000), (0x46000000, 0x1000000), (0x43000000, 0x100000), (0x43f00000, 0x100000), (0x42000000, 0x200000), (0x45000000, 0x800000), (0x48000000, 0x1000), (0xb0002000, 0x1000)]:
            u.mem_map(a, n)
        u.mem_write(0x4409b000, code)
        if initializers is None:
            initializers = []
            for o in [0x662fc, 0x66308]:
                src, dst, n = struct.unpack_from('<III', ROM, o)
                initializers.append((dst, ROM[src:src + n]))
        for dst, data in initializers:
            u.mem_write(dst, data)
        u.mem_write(0x43f91800, pub)
        u.reg_write(UC_ARM_REG_C1_C0_2, 0xf00000)
        u.reg_write(UC_ARM_REG_FPEXC, 0x40000000)
        self.heap = 0x45000000
        self.stream = stream
        self.pos = 0
        self.verifications = 0
        self.digests = []
        self.record = []
        for pc, fn in [(0x44393080, self.alloc), (0x44393348, self.free), (0x4419d4d0, self.zero), (0x44390d00, self.free), (0x443f3238, self.free), (0x443f39b0, self.compare), (0x443f69c8, self.copy), (0x443f3d0c, self.copy), (0x443f6400, self.compare), (0x443f5a70, self.os_alloc), (0x430f0000, self.read), (0x4419d504, self.observe_verify), (0x4419f9d8, self.observe_digest)]:
            pc = self.addresses.get(pc, pc)
            u.hook_add(UC_HOOK_CODE, fn, begin=pc, end=pc)

    def ret(self, v):
        self.u.reg_write(UC_ARM_REG_R0, v & 0xffffffff)
        self.u.reg_write(UC_ARM_REG_PC, self.u.reg_read(UC_ARM_REG_LR))

    def args(self):
        return [self.u.reg_read(r) for r in [UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3]]

    def malloc(self, n):
        assert n < 0x1000000, n
        p = self.heap
        self.heap += n + 15 & ~15
        assert self.heap < 0x45800000
        self.u.mem_write(p, bytes(n))
        return p

    def alloc(self, u, a, n, x):
        self.ret(self.malloc(self.args()[0]))

    def free(self, u, a, n, x):
        self.ret(0)

    def zero(self, u, a, n, x):
        p, n, _, _ = self.args()
        u.mem_write(p, bytes(n))
        self.ret(p)

    def copy(self, u, a, n, x):
        dst, src, n, _ = self.args()
        u.mem_write(dst, bytes(u.mem_read(src, n)))
        self.ret(dst)

    def compare(self, u, a, n, x):
        p, q, n, _ = self.args()
        left, right = bytes(u.mem_read(p, n)), bytes(u.mem_read(q, n))
        self.ret(next((a - b for a, b in zip(left, right) if a != b), 0))

    def os_alloc(self, u, a, n, x):
        _, _, n, out = self.args()
        u.mem_write(out, struct.pack('<I', self.malloc(n)))
        self.ret(0)

    def read(self, u, a, n, x):
        dst, n, _, _ = self.args()
        chunk = self.stream[self.pos:self.pos + n]
        self.pos += len(chunk)
        if chunk:
            u.mem_write(dst, chunk)
        self.ret(len(chunk))

    def observe_verify(self, u, a, n, x):
        self.verifications += 1

    def observe_digest(self, u, a, n, x):
        self.digests.append(bytes(u.mem_read(self.args()[0], 32)).hex())

    def call(self, pc, *args):
        u = self.u
        u.reg_write(UC_ARM_REG_CPSR, 19)
        u.reg_write(UC_ARM_REG_SP, 0x421ff000)
        u.reg_write(UC_ARM_REG_LR, 0x48000000)
        for r, v in zip([UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3], args):
            u.reg_write(r, v)
        u.emu_start(pc, 0x48000000, count=50000000)
        assert u.reg_read(UC_ARM_REG_PC) == 0x48000000, hex(u.reg_read(UC_ARM_REG_PC))
        return u.reg_read(UC_ARM_REG_R0)

    def state(self):
        return list(struct.unpack('<II', self.u.mem_read(self.state_address, 8)))
