"""Require matching evidence for v3; emit an explicitly diagnostic handoff."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]

def main():
 def read(path):return json.loads((ROOT/path).read_text())
 module=read('experimental/maintenance-control.diagnostic-v3.json')
 package=read('experimental/maintenance-efu.diagnostic-v3.json')
 native=read('validation/maintenance-v3-native-results.json')
 audit=read('validation/maintenance-v3-package-audit.json')
 receiver=read('validation/maintenance-v3-full-receiver.json')
 sections=read('validation/maintenance-v3-host-sections.json')
 path=ROOT/'experimental'/package['artifact'];digest=hashlib.sha256(path.read_bytes()).hexdigest()
 assert digest==package['efu_sha256']==audit['efu_sha256']==receiver['efu_sha256']
 assert module['module_sha256']==package['prototype_module_sha256']==native['module_sha256']
 assert native['scenario_count']==74 and len(native['flow_cases'])==24 and native['maintenance_verdict_hooks']==0
 assert receiver['return']==1 and receiver['state']==[1,1] and receiver['ecdsa_calls']==0
 assert receiver['native_checks']['parser']==4 and receiver['native_checks']['sha1']>=1
 assert receiver['raw_drain_elided_bytes']==0
 rpc=read('validation/receiver-rpc-worker-study.json')
 assert [c['native_worker_result'] for c in rpc['cases']]==[1,0,0,0] and rpc['verdict_hooks']==0
 assert receiver['bytes_consumed']==receiver['wire_bytes']
 assert receiver['code_unchanged'] and receiver['original_key_preserved']
 assert len(sections['sections'])==4 and sections['tail_bytes']==0
 assert all(r['metadata_sum_valid'] and r['payload_sum_valid'] and r['sha1_valid'] for r in sections['sections'])
 assert audit['checksum']['native_checksum_return']==1 and audit['loader']['native_lz_output_exact']
 assert audit['loader']['native_dma_mod48']==0
 package['limitations']=[s for s in package['limitations'] if s!='Full packaged EFU has not been run through the ARM receiver']
 package['actual_packaged_receiver_test']={k:receiver[k] for k in ('return','state','ecdsa_calls','bytes_consumed','wire_bytes','native_checks','elapsed_seconds','timing_scope','native_prefix_checkpoint_used','raw_drain_elided_bytes')}
 package['status']='Diagnostic candidate: matched software/native checks passed; physical boot unverified'
 (ROOT/'experimental/maintenance-efu.diagnostic-v3.json').write_text(json.dumps(package,indent=2)+'\n')
 (path.parent/(path.name+'.sha256')).write_text(digest+'  '+path.name+'\n')
 summary={'status':'Diagnostic EFU generated and software checks passed; NOT a physical-boot validation',
 'artifact':package['artifact'],'efu_sha256':digest,'module_sha256':module['module_sha256'],
 'native_maintenance_scenarios':native['scenario_count'],'native_subsystem_flows':len(native['flow_cases']),
 'container_receiver':package['actual_packaged_receiver_test'],'host_sections_verified':len(sections['sections']),
 'native_payload_sum_bytes':audit['checksum']['payload_bytes'],
 'changed_control_bytes':module['changed_bytes'],
 'actual_body_size':package['actual_signed_body_length'],'declared_body_size':package['declared_signed_body_length'],
 'original_key_and_receiver_preserved':True,'ordinary_ecdsa_signature_valid':False,
 'receiver_RAM_library_id_fixture':'BA; derived from compiled BA01J2 identifier, not measured printer RAM',
 'original_library_header_worker_controls':4,
 'remaining_checks':['Physical startup with attached cartridge','Physical startup without cartridge',
 'Actual printing/cleaning and waste collection','RTOS concurrency and actual flash/USB/updater/Huffman hardware'],
 'fixtures':native['fixtures']}
 (ROOT/'validation/maintenance-v3-validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 readme=ROOT/'experimental/LK29Q5-maintenance-diagnostic-v3.README.ko.md'
 text=readme.read_text()
 text+='''
## 실제 포장 본문의 원본 ARM 수신 검사

`python research/probe_packaged_v3_receiver.py`

EFU에서 재추출한 RCX의 EPSONSIGN부터 끝까지 원본 최신 ARM 상위 수신 함수에
입력했습니다. 모드 입력은 0이며, 실제 프린터에서 읽은 설정값이 아닙니다.
네 섹션의 원본 파서 호출, 전체 입력 소비, 상위 수신 반환 1, 서명 상태 1·남은 길이 1,
ECDSA 호출 0을 확인했습니다. 이는 서명 검증 완료를 의미하지 않습니다.

변경된 첫 섹션의 원본 SHA-1 검사가 실행됩니다. 다른 세 섹션은 원본과 바이트 단위로
동일하며, 형식별 원본 처리 경로와 호스트 합계·내부 SHA-1 검사도 확인했습니다.
원래 키와 수신 모듈 바이트가 유지됩니다.

메타데이터 작업 공간과 설치용 버퍼는 바이트 메모리로 모델링했습니다. 버퍼 용량은
실제 할당한 160 MiB로 보고하고 원본 메타데이터 기록 함수를 실행합니다.
OS 입력·메모리 유틸리티·설정 I/O·메시지 할당과 전달은 fixture입니다.
큐 0x12a의 메서드 0x3d는 원본 작업자 0x4442316c를 동기 실행하며,
작업자의 판정값을 대체하지 않습니다. 정상 헤더 1건과 잘못된 헤더 3건을 대조했습니다.
라이브러리 ID RAM 값 BA는 컴파일된 BA01J2 식별자를 근거로 둔 시험값이며,
실제 프린터 RAM에서 측정한 값은 아닙니다. RTOS 동시 실행은 재현하지 않습니다.

큰 첫 섹션을 원본 ARM 코드로 처리한 뒤 CPU/RAM 체크포인트를 저장하고
나머지 섹션을 이어 실행했습니다. 입력 해시로 체크포인트를 대조하고, 암호 상태나
서명 결과를 대체하지 않았습니다. 결과의 시간 값은 재개 구간만 나타냅니다.
기본 명령은 전체 입력을 처음부터 실행합니다.

이 결과는 플래시 설치 완료나 정상 부팅을 의미하지 않습니다.
'''
 if '## 실제 포장 본문의 원본 ARM 수신 검사' not in readme.read_text():readme.write_text(text)
 scripts=['build_maintenance_v3.py','maintenance_v3_fixture.py','verify_maintenance_v3.py',
 'probe_startup_status.py','probe_maintenance_state.py','probe_maintenance_notifications.py',
 'package_maintenance_prototype.py','encode_crom.py','decode_crom.py','probe_efu_envelope.py',
 'audit_maintenance_v3_package.py','audit_recovery_failure.py','probe_packaged_v3_receiver.py',
 'probe_lk29q5_native.py','probe_efu_native.py','native_fixture.py','finalize_maintenance_v3.py',
 'receiver_rpc_fixture.py','probe_receiver_rpc_worker.py','probe_receiver_tail_sequence.py','probe_receiver_buffer_capacity.py']
 records=['maintenance-v3-native-results.json','maintenance-v3-package-audit.json',
 'maintenance-v3-full-receiver.json','maintenance-v3-host-sections.json','maintenance-v3-validation-summary.json',
 'lk29q5-native-results.json','startup-status-regression.json','receiver-rpc-worker-study.json',
 'receiver-tail-sequence-study.json','receiver-buffer-capacity-study.json','maintenance-v3-full-receiver-capacity0.json']
 bundle=ROOT/'experimental/LK29Q5-maintenance-diagnostic-v3-validation.zip'
 with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
  for name in scripts:z.write(ROOT/'research'/name,'research/'+name)
  for name in records:z.write(ROOT/'validation'/name,'validation/'+name)
  for name in ['maintenance-control.diagnostic-v3.json','maintenance-efu.diagnostic-v3.json',readme.name]:
   z.write(ROOT/'experimental'/name,'experimental/'+name)
  z.writestr('INPUTS.ko.txt','재현에는 사용자가 제공한 원본 SPI/EFU 및 decoded 모듈과 Unicorn/Capstone/cryptography가 필요합니다. 원본 펌웨어·덤프와 개인키는 이 검증 묶음에 포함하지 않았습니다.\n')
 print(json.dumps(summary,indent=2));print(bundle)
if __name__=='__main__':main()
