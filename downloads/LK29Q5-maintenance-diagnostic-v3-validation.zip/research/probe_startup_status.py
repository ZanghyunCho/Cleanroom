"""Compare original and v2 status output, executing every function unhooked.
RAM fixtures model normal mode, a valid profile, closed cover and raw state 0.
This is a status-function regression test, not a complete boot simulation.
"""
from pathlib import Path
import hashlib,json,struct,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from probe_maintenance_state import Control,ROOT

def run(code,raw,cover_status=0):
 c=Control(code)
 state=c.literal(0x43408000,0xc4)
 profile=c.literal(0x4340aca8,-0x474)
 mode=c.literal(0x433f6378,0x27c)
 cover=c.literal(0x434084c4,0x1fc)
 c.u.mem_write(state,bytes([raw]))
 c.u.mem_write(state+8,b'\x64')
 c.u.mem_write(mode,b'\0'*8)
 c.u.mem_write(profile-0x3c+1,b'\0')
 c.u.mem_write(profile,struct.pack('<I',0x42100000))
 c.u.mem_write(0x42100000,b'\0'*16)
 c.u.mem_write(cover,bytes([cover_status])*3)
 output=0x42100100
 c.u.mem_write(output,b'\0'*48)
 c.call(0x43410748,output)
 result=bytes(c.u.mem_read(output,48))
 return {'raw_state':raw,'cover_status_fixture':cover_status,'getter_return':c.call(0x43407f5c),
         'slot0_status_flag':result[0],'output_hex':result.hex(),
         'code_unchanged':all(bytes(c.u.mem_read(a,n))==code[a-0x433e0000:a-0x433e0000+n] for a,n in [(0x43410748,0xe0),(0x43407f5c,0x24),(0x43408468,0x6c),(0x4340aca8,0x1c),(0x433f6378,0x1c)])}

def main():
 original=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes()
 patched=(ROOT/'experimental/maintenance-control.prototype.bin').read_bytes()
 # Isolate the global getter modification from all other changes.
 restored=bytearray(patched);off=0x43407f5c-0x433e0000
 restored[off:off+8]=original[off:off+8]
 report={'scope':'Unhooked ARM execution of status function 0x43410748; not full boot',
 'original_sha256':hashlib.sha256(original).hexdigest(),
 'v2_sha256':hashlib.sha256(patched).hexdigest(),
 'cases':{name:[run(code,s) for s in (0,1,2,7)] for name,code in
          [('original',original),('v2',patched),('v2_getter_restored_only',bytes(restored))]}}
 assert report['cases']['original'][0]['slot0_status_flag']==1
 assert report['cases']['v2'][0]['slot0_status_flag']==0
 assert report['cases']['v2_getter_restored_only'][0]['slot0_status_flag']==1
 assert all(case['code_unchanged'] for cases in report['cases'].values() for case in cases)
 path=ROOT/'validation/startup-status-regression.json'
 path.write_text(json.dumps(report,indent=2)+'\n')
 print(path)
 for name,cases in report['cases'].items():print(name,[(c['raw_state'],c['getter_return'],c['slot0_status_flag']) for c in cases])
if __name__=='__main__':main()
