"""Run receiver controls on the unmodified module extracted from LK29Q5 EFU."""
from pathlib import Path
import hashlib
import json
import struct
from native_fixture import Native, PUB, envelope, UC_ARM_REG_PC
from probe_efu_native import Receiver, ORIGINAL_KEY, ZERO_SIGNATURE, synthetic_section

ROOT = Path(__file__).resolve().parents[1]
# Entries resolved using unique code-prefix matches and original/new BL targets.
ADDRESSES = {
    0x44393080: 0x443a0978, 0x44393348: 0x443a0c40,
    0x4419d4d0: 0x4419d680, 0x44390d00: 0x4439e5f8,
    0x443f3238: 0x443ffbbc, 0x443f39b0: 0x44400334,
    0x443f69c8: 0x44403340, 0x443f3d0c: 0x4440068c,
    0x443f6400: 0x44402d78, 0x443f5a70: 0x444023e4,
    0x4419d504: 0x4419d6b4, 0x4419f9d8: 0x4419fb88,
    0x443f3f30: 0x444008b0, 0x443f3e30: 0x444007b0,
    0x4413f920: 0x4413fa4c, 0x4413fc70: 0x4413fd9c,
    0x4413fca8: 0x4413fdd4, 0x4413fce0: 0x4413fe0c,
    0x4413fd18: 0x4413fe44, 0x4419e294: 0x4419e444,
    0x4419e130: 0x4419e2e0, 0x4419f7e0: 0x4419f990,
}


def main():
    code = (ROOT / 'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
    rcx = (ROOT / 'FW7560TL.rcx').read_bytes()
    assert hashlib.sha256(code).hexdigest() == 'a58dc0eb44390e524fd6debda23cfa5eb952c28a843b1db1cc39f75efa956726'
    assert hashlib.sha256(rcx).hexdigest() == '5a8c9ff4c942e436e7ab9da60237dd7d60587715071d748a58c90fe20ca557b1'
    initializers = []
    descriptors = []
    # The source-to-RCX relationship is inferred from the loader descriptor table
    # and matching original/new initialized-data prefixes, not a flashing layout.
    bias = 0x2d6c00 - 0x27ad53
    for off, expected in [(0xa44f, (0x6d000, 0x43f91800, 0x1000)),
                          (0xa45b, (0x27b404, 0x43f99000, 0x3c5cc))]:
        src, dst, n = struct.unpack_from('<III', rcx, off)
        assert (src, dst, n) == expected
        data = rcx[src - bias:src - bias + n]
        assert len(data) == n
        initializers.append((dst, data))
        descriptors.append({'source': hex(src), 'rcx_offset': hex(src - bias),
                            'destination': hex(dst), 'size': n,
                            'sha256': hashlib.sha256(data).hexdigest()})
    assert initializers[0][1][:64] == ORIGINAL_KEY
    options = dict(code=code, initializers=initializers, addresses=ADDRESSES,
                   state_address=0x43fb9838)

    def invariant(native, key=ORIGINAL_KEY):
        assert bytes(native.u.mem_read(0x4409b000, len(code))) == code
        assert bytes(native.u.mem_read(0x43f91800, 64)) == key

    body = b'LK29Q5 synthetic receiver control\n' * 3
    stream_cases = []
    for name, key, signature, declared, expected in [
        ('test_key_valid_signature', PUB, None, len(body), (1, 1, [2, 0])),
        ('original_key_rejects_test_signature', ORIGINAL_KEY, None, len(body), (0, 1, [1, 0])),
        ('original_key_zero_signature_exact', ORIGINAL_KEY, ZERO_SIGNATURE, len(body), (0, 1, [1, 0])),
        ('original_key_zero_signature_overdeclared', ORIGINAL_KEY, ZERO_SIGNATURE, len(body) + 1, (1, 0, [1, 1])),
    ]:
        native = Native(envelope(body, declared, signature), key, **options)
        invariant(native, key)
        dst = native.malloc(len(body))
        ret = native.call(0x4419ec8c, 0x430f0000, dst, len(body))
        invariant(native, key)
        result = (ret, native.verifications, native.state())
        assert result == expected, (name, result)
        stream_cases.append({'name': name, 'return': ret, 'ecdsa_calls': native.verifications,
                             'state': native.state(), 'original_key': key == ORIGINAL_KEY})
        print('PASS LK29Q5 stream', name, flush=True)
    payload = bytes(range(64))
    section, digest = synthetic_section(payload)
    changed = bytes([payload[0] ^ 1]) + payload[1:]
    stale, _ = synthetic_section(changed, stale_digest=digest)
    refreshed, _ = synthetic_section(changed)
    bad_checksum, _ = synthetic_section(payload, corrupt_checksum=True)
    receivers = []
    for mode in (0, 6):
        for name, data, over, expected in [
            ('exact_zero_signature', section, 0, (0, 1)),
            ('overdeclared_valid_inner_checks', section, 1, (1, 0)),
            ('changed_body_stale_sha1', stale, 1, (0, 0)),
            ('changed_body_refreshed_sha1', refreshed, 1, (1, 0)),
            ('bad_metadata_checksum', bad_checksum, 1, (0, 0)),
        ]:
            native = Receiver(envelope(data, len(data) + over, ZERO_SIGNATURE), **options)
            invariant(native)
            ret = native.call(0x4419ee30, 0x430f0000, mode)
            invariant(native)
            assert (ret, native.verifications) == expected, (name, mode, ret, native.verifications, native.state())
            receivers.append({'name': name, 'mode_input': mode, 'return': ret,
                              'ecdsa_calls': native.verifications, 'state': native.state(),
                              'native_checks': native.native_check_calls,
                              'code_unchanged': True, 'original_key': True})
            print('PASS LK29Q5 receiver', mode, name, flush=True)
    result = {'version': 'LK29Q5', 'module_sha256': hashlib.sha256(code).hexdigest(),
              'initializers': descriptors, 'fixture_address_map': {hex(k): hex(v) for k, v in ADDRESSES.items()},
              'stream_cases': stream_cases, 'receiver_cases': receivers,
              'scope': 'Unmodified latest ARM module; synthetic section and OS/storage fixtures. No full boot, USB or physical flash.',
              'installable_firmware_generated': False}
    out = ROOT / 'validation/lk29q5-native-results.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    print('Saved', out)


if __name__ == '__main__':
    main()
