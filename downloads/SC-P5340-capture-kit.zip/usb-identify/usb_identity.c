/* Windows x64 discovery only. No print data, service command, reset, or write IOCTL. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winioctl.h>
#include <setupapi.h>
#include <usbprint.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

static const GUID printer_interface = {
    0x28d78fad, 0x5a12, 0x11d1, {0xae,0x5b,0,0,0xf8,3,0xa8,0xc2}
};

static void hex(const unsigned char *data, size_t size) {
    for (size_t i = 0; i < size; ++i) printf("%02x", data[i]);
}
static void wide_hex(const wchar_t *text) {
    hex((const unsigned char *)text, wcslen(text) * sizeof(wchar_t));
}

static DWORD identity(HANDLE device, unsigned char *buffer, DWORD capacity, DWORD *received) {
    OVERLAPPED operation = {0};
    operation.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (!operation.hEvent) return GetLastError();
    DWORD error = ERROR_SUCCESS;
    if (!DeviceIoControl(device, IOCTL_USBPRINT_GET_1284_ID, NULL, 0,
                         buffer, capacity, received, &operation)) {
        error = GetLastError();
        if (error == ERROR_IO_PENDING) {
            DWORD wait = WaitForSingleObject(operation.hEvent, 3000);
            if (wait == WAIT_OBJECT_0) {
                error = GetOverlappedResult(device, &operation, received, FALSE) ? 0 : GetLastError();
            } else {
                CancelIoEx(device, &operation);
                /* Keep the output buffer alive until cancellation completes.
                 * The launcher also imposes a process-wide time limit. */
                GetOverlappedResult(device, &operation, received, TRUE);
                error = ERROR_TIMEOUT;
            }
        }
    }
    CloseHandle(operation.hEvent);
    return error;
}

int wmain(int argc, wchar_t **argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    setvbuf(stdout, NULL, _IONBF, 0);
    if (sizeof(void *) != 8 || IOCTL_USBPRINT_GET_1284_ID != 0x220034) return 2;
    if (argc == 2 && wcscmp(argv[1], L"--self-test") == 0) {
        puts("{\"event\":\"self_test\",\"architecture\":\"x64\",\"identity_ioctl\":\"0x220034\",\"hardware_tested\":false}");
        return 0;
    }
    if (argc != 1) return 2;
    HDEVINFO devices = SetupDiGetClassDevsW(&printer_interface, NULL, NULL,
                                           DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
    if (devices == INVALID_HANDLE_VALUE) {
        printf("{\"event\":\"error\",\"stage\":\"enumerate\",\"code\":%lu}\n", GetLastError());
        return 1;
    }
    unsigned count = 0;
    int result = 0;
    for (DWORD index = 0; index < 256; ++index) {
        SP_DEVICE_INTERFACE_DATA iface = {0};
        iface.cbSize = sizeof(iface);
        if (!SetupDiEnumDeviceInterfaces(devices, NULL, &printer_interface, index, &iface)) {
            DWORD error = GetLastError();
            if (error != ERROR_NO_MORE_ITEMS) {
                printf("{\"event\":\"error\",\"stage\":\"interface\",\"code\":%lu}\n", error);
                result = 1;
            }
            break;
        }
        DWORD required = 0;
        SetupDiGetDeviceInterfaceDetailW(devices, &iface, NULL, 0, &required, NULL);
        if (required < sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA_W) || required > 65536) {
            result = 1;
            continue;
        }
        PSP_DEVICE_INTERFACE_DETAIL_DATA_W detail = calloc(1, required);
        if (!detail) { result = 1; break; }
        detail->cbSize = sizeof(*detail);
        SP_DEVINFO_DATA info = {0};
        info.cbSize = sizeof(info);
        if (!SetupDiGetDeviceInterfaceDetailW(devices, &iface, detail, required, NULL, &info)) {
            printf("{\"event\":\"error\",\"stage\":\"detail\",\"code\":%lu}\n", GetLastError());
            free(detail); result = 1; continue;
        }
        wchar_t name[512] = {0}, instance[512] = {0}, service[256] = {0};
        SetupDiGetDeviceRegistryPropertyW(devices, &info, SPDRP_FRIENDLYNAME,
                                         NULL, (BYTE *)name, sizeof(name), NULL);
        if (!name[0]) SetupDiGetDeviceRegistryPropertyW(devices, &info, SPDRP_DEVICEDESC,
                                                       NULL, (BYTE *)name, sizeof(name), NULL);
        SetupDiGetDeviceRegistryPropertyW(devices, &info, SPDRP_SERVICE,
                                         NULL, (BYTE *)service, sizeof(service), NULL);
        SetupDiGetDeviceInstanceIdW(devices, &info, instance, 512, NULL);
        name[511] = instance[511] = service[255] = 0;
        DWORD received = 0;
        unsigned char buffer[8192] = {0};
        HANDLE device = CreateFileW(detail->DevicePath, 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                    NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
        if (device == INVALID_HANDLE_VALUE)
            device = CreateFileW(detail->DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                 NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
        DWORD error;
        if (device == INVALID_HANDLE_VALUE) error = GetLastError();
        else { error = identity(device, buffer, sizeof(buffer), &received); CloseHandle(device); }
        if (received > sizeof(buffer) || error) received = 0;
        printf("{\"event\":\"device\",\"index\":%lu,\"name_utf16\":\"", index); wide_hex(name);
        printf("\",\"instance_utf16\":\""); wide_hex(instance);
        printf("\",\"service_utf16\":\""); wide_hex(service);
        printf("\",\"path_utf16\":\""); wide_hex(detail->DevicePath);
        printf("\",\"identity_error\":%lu,\"ieee1284_hex\":\"", error); hex(buffer, received);
        puts("\"}");
        free(detail);
        ++count;
        if (index == 255) result = 1; /* Do not label a capped enumeration complete. */
    }
    SetupDiDestroyDeviceInfoList(devices);
    printf("{\"event\":\"scan_done\",\"device_count\":%u,\"complete\":%s}\n", count, result ? "false" : "true");
    return result;
}
