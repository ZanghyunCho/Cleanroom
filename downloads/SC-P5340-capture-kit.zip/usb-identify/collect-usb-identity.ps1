$ErrorActionPreference = 'Stop'
$helper = Join-Path $PSScriptRoot 'scp5340_usb_identity.exe'
$digestFile = Join-Path $PSScriptRoot 'scp5340_usb_identity.exe.sha256'
if (!(Test-Path -LiteralPath $helper)) { throw "Missing helper: $helper" }
$expected = (Get-Content -LiteralPath $digestFile -Raw).Trim().ToLowerInvariant()
$actual = (Get-FileHash -LiteralPath $helper -Algorithm SHA256).Hash.ToLowerInvariant()
if ($expected -ne $actual) { throw 'Helper checksum mismatch. Extract the complete kit again.' }
$output = Join-Path (Split-Path $PSScriptRoot -Parent) ('usb-identity-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
if (Test-Path -LiteralPath $output) { throw "Output directory already exists: $output" }
New-Item -ItemType Directory -Path $output | Out-Null

$info = New-Object System.Diagnostics.ProcessStartInfo
$info.FileName = $helper
$info.UseShellExecute = $false
$info.CreateNoWindow = $true
$info.RedirectStandardOutput = $true
$info.RedirectStandardError = $true
$process = New-Object System.Diagnostics.Process
$process.StartInfo = $info
if (!$process.Start()) { throw 'Could not start the USB discovery helper.' }
$stdoutTask = $process.StandardOutput.ReadToEndAsync()
$stderrTask = $process.StandardError.ReadToEndAsync()
$timedOut = !$process.WaitForExit(30000)
if ($timedOut) { $process.Kill(); $process.WaitForExit() }
$stdout = $stdoutTask.GetAwaiter().GetResult()
$stderr = $stderrTask.GetAwaiter().GetResult()
$exitCode = $process.ExitCode
$process.Dispose()
[IO.File]::WriteAllText((Join-Path $output 'helper.jsonl'), $stdout, [Text.Encoding]::UTF8)
[IO.File]::WriteAllText((Join-Path $output 'helper-stderr.txt'), $stderr, [Text.Encoding]::UTF8)

function Decode-WideHex([string]$HexText) {
    if (!$HexText) { return '' }
    if ($HexText.Length % 4 -ne 0) { throw 'Invalid UTF-16 hex field' }
    $bytes = New-Object byte[] ($HexText.Length / 2)
    for ($i = 0; $i -lt $bytes.Length; $i++) { $bytes[$i] = [Convert]::ToByte($HexText.Substring($i * 2, 2), 16) }
    return [Text.Encoding]::Unicode.GetString($bytes)
}
$devices = @()
$parseErrors = @()
$scanComplete = $false
foreach ($line in ($stdout -split '\r?\n')) {
    if (!$line.Trim()) { continue }
    try {
        $record = $line | ConvertFrom-Json
        if ($record.event -eq 'device') {
            $devices += [pscustomobject]@{
                name = Decode-WideHex $record.name_utf16
                instance = Decode-WideHex $record.instance_utf16
                service = Decode-WideHex $record.service_utf16
                device_path = Decode-WideHex $record.path_utf16
                identity_error = $record.identity_error
                ieee1284_hex = $record.ieee1284_hex
            }
        }
        if ($record.event -eq 'scan_done') { $scanComplete = [bool]$record.complete }
    } catch { $parseErrors += $_.Exception.Message }
}
$queues = @()
$drivers = @()
$epsonUsb = @()
$systemErrors = @()
try {
    $queues = @(Get-CimInstance Win32_Printer -OperationTimeoutSec 10 | Where-Object {
        $_.Name -match 'SC-?P53|P5340' -or $_.DriverName -match 'SC-?P53|P5340'
    } | Select-Object Name, DriverName, PortName, PrintProcessor, PrintJobDataType, EnableBIDI, WorkOffline, PrinterStatus)
} catch { $systemErrors += $_.Exception.Message }
try {
    $epsonUsb = @(Get-CimInstance Win32_PnPEntity -OperationTimeoutSec 10 -Filter "PNPDeviceID LIKE 'USB%VID_04B8%'" |
        Select-Object Name, PNPDeviceID, Service, Status, ConfigManagerErrorCode)
} catch { $systemErrors += $_.Exception.Message }
try {
    $drivers = @(Get-CimInstance Win32_PrinterDriver -OperationTimeoutSec 10 | Where-Object {
        $_.Name -match 'SC-?P53|P5340'
    } | Select-Object Name, ConfigFile, DataFile, DriverPath, InfName, SupportedPlatform, Version)
} catch { $systemErrors += $_.Exception.Message }
[pscustomobject]@{
    schema_version = 1
    helper_sha256 = $actual
    helper_exit_code = $exitCode
    helper_timed_out = $timedOut
    enumeration_complete = ($scanComplete -and !$timedOut -and $exitCode -eq 0 -and $parseErrors.Count -eq 0)
    devices = $devices
    printer_queues = $queues
    printer_drivers = $drivers
    epson_usb_devices = $epsonUsb
    parse_errors = $parseErrors
    system_query_errors = $systemErrors
    scope = 'USB enumeration and standard IEEE-1284 identity read only; no raster or Epson service query sent.'
} | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 (Join-Path $output 'usb-identity.json')
$zip = $output + '.zip'
if (Test-Path -LiteralPath $zip) { throw "Refusing to overwrite: $zip" }
Compress-Archive -Path (Join-Path $output '*') -DestinationPath $zip
Write-Host "Result: $zip"
Write-Host "USB printer interfaces found: $($devices.Count)"
if ($timedOut -or !$scanComplete -or $exitCode -ne 0) {
    Write-Warning 'Discovery was incomplete. Keep the result ZIP and report it.'
}
