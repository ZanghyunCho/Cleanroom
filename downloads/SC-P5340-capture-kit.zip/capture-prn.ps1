param(
    [Parameter(Mandatory=$true)][string]$PrinterName,
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'captures')
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$installed = @([System.Drawing.Printing.PrinterSettings]::InstalledPrinters)
if ($installed -notcontains $PrinterName) {
    throw "Printer not installed: $PrinterName. Installed: $($installed -join ', ')"
}
New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null
$OutputDirectory = (Resolve-Path $OutputDirectory).Path
$colors = [ordered]@{
    white = @(255,255,255); black = @(0,0,0)
    gray25 = @(192,192,192); gray50 = @(128,128,128); gray75 = @(64,64,64)
    cyan = @(0,255,255); magenta = @(255,0,255); yellow = @(255,255,0)
    red = @(255,0,0); green = @(0,255,0); blue = @(0,0,255)
    violet = @(128,0,255)
}
$metadata = @()
foreach ($item in $colors.GetEnumerator()) {
    $path = Join-Path $OutputDirectory ($item.Key + '.prn')
    if (Test-Path $path) { throw "Refusing to overwrite $path; choose a new output directory." }
    $rgb = $item.Value
    $doc = New-Object System.Drawing.Printing.PrintDocument
    $brush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb($rgb[0],$rgb[1],$rgb[2]))
    try {
        $doc.PrinterSettings.PrinterName = $PrinterName
        $doc.PrinterSettings.PrintToFile = $true
        $doc.PrinterSettings.PrintFileName = $path
        $doc.PrintController = New-Object System.Drawing.Printing.StandardPrintController
        $doc.DocumentName = 'SC-P5340 observation ' + $item.Key
        $handler = [System.Drawing.Printing.PrintPageEventHandler]{
            param($sender, $event)
            # A 1-inch square in the printable area. RGB is input, not an ink ID.
            $event.Graphics.PageUnit = [System.Drawing.GraphicsUnit]::Inch
            $event.Graphics.FillRectangle($brush, [single]1, [single]1, [single]1, [single]1)
            $event.HasMorePages = $false
        }
        $doc.add_PrintPage($handler)
        $doc.Print()
        if (!(Test-Path $path) -or (Get-Item $path).Length -eq 0) {
            throw "No nonempty print-to-file output for $($item.Key)."
        }
        $metadata += [pscustomobject]@{
            sample = $item.Key; input_rgb = $rgb; file = [IO.Path]::GetFileName($path)
            bytes = (Get-Item $path).Length
            sha256 = (Get-FileHash -Algorithm SHA256 $path).Hash.ToLowerInvariant()
            paper = $doc.DefaultPageSettings.PaperSize.PaperName
            resolution_x = $doc.DefaultPageSettings.PrinterResolution.X
            resolution_y = $doc.DefaultPageSettings.PrinterResolution.Y
            color = $doc.DefaultPageSettings.Color
        }
    } finally {
        $brush.Dispose()
        $doc.Dispose()
    }
}
[pscustomobject]@{
    printer = $PrinterName
    note = 'Original driver output. RGB patch names do not identify physical ink channels. Record private driver settings separately.'
    samples = $metadata
} | ConvertTo-Json -Depth 6 | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory 'capture-metadata.json')
Write-Host "Captured $($metadata.Count) jobs to $OutputDirectory"
