param(
    [string]$PrinterName = 'EPSON SC-P5300 Series',
    [string]$OutputDirectory = (Join-Path $PSScriptRoot ('renderer-diagnostics-' + (Get-Date -Format 'yyyyMMdd-HHmmss')))
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$installed = @([System.Drawing.Printing.PrinterSettings]::InstalledPrinters)
if ($installed -notcontains $PrinterName) {
    throw "Printer not installed: $PrinterName. Installed: $($installed -join ', ')"
}
if (Test-Path $OutputDirectory) { throw "Choose a new output directory: $OutputDirectory" }

# The original Epson output DLL checks this fixed diagnostics location.
# The collector preserves existing files and does not change driver files or registry.
$logDirectory = 'C:\tmp\ephrlog'
New-Item -ItemType Directory -Force -Path $logDirectory | Out-Null
$before = @{}
Get-ChildItem -LiteralPath $logDirectory -File -Filter '*.log' | ForEach-Object {
    $before[$_.FullName] = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
}
New-Item -ItemType Directory -Path $OutputDirectory | Out-Null
$OutputDirectory = (Resolve-Path $OutputDirectory).Path
$path = Join-Path $OutputDirectory 'diagnostic.prn'
$doc = New-Object System.Drawing.Printing.PrintDocument
$black = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::Black)
$gray = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(128,128,128))
$violet = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(128,0,255))
try {
    $doc.PrinterSettings.PrinterName = $PrinterName
    $doc.PrinterSettings.PrintToFile = $true
    $doc.PrinterSettings.PrintFileName = $path
    $doc.PrintController = New-Object System.Drawing.Printing.StandardPrintController
    $doc.DocumentName = 'SC-P5340 renderer observation'
    $handler = [System.Drawing.Printing.PrintPageEventHandler]{
        param($sender, $event)
        $event.Graphics.PageUnit = [System.Drawing.GraphicsUnit]::Inch
        $event.Graphics.FillRectangle($black, [single]1, [single]1, [single]1, [single]1)
        $event.Graphics.FillRectangle($gray, [single]2.2, [single]1, [single]1, [single]1)
        $event.Graphics.FillRectangle($violet, [single]3.4, [single]1, [single]1, [single]1)
        $event.HasMorePages = $false
    }
    $doc.add_PrintPage($handler)
    $doc.Print()
} finally {
    $black.Dispose(); $gray.Dispose(); $violet.Dispose(); $doc.Dispose()
}
if (!(Test-Path -LiteralPath $path) -or (Get-Item -LiteralPath $path).Length -eq 0) {
    throw 'No nonempty PRN output was produced.'
}

# Allow the driver to flush its log. This polls for changes for at most 10 seconds.
$changed = @()
for ($attempt = 0; $attempt -lt 10; $attempt++) {
    $changed = @(Get-ChildItem -LiteralPath $logDirectory -File -Filter '*.log' | Where-Object {
        (-not $before.ContainsKey($_.FullName)) -or
        ((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash -ne $before[$_.FullName])
    })
    if ($changed.Count -gt 0) { break }
    Start-Sleep -Seconds 1
}
$logsOut = Join-Path $OutputDirectory 'logs'
New-Item -ItemType Directory -Path $logsOut | Out-Null
foreach ($log in $changed) {
    Copy-Item -LiteralPath $log.FullName -Destination (Join-Path $logsOut $log.Name)
}
[pscustomobject]@{
    printer = $PrinterName
    collected_log_count = $changed.Count
    prn_bytes = (Get-Item -LiteralPath $path).Length
    prn_sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    note = 'Original driver diagnostics; no ink disabling has been applied. Logs and PRN may contain personal identifiers.'
} | ConvertTo-Json | Set-Content -Encoding UTF8 (Join-Path $OutputDirectory 'diagnostic-metadata.json')
$zipPath = $OutputDirectory + '.zip'
if (Test-Path -LiteralPath $zipPath) { throw "Refusing to overwrite: $zipPath" }
Compress-Archive -Path (Join-Path $OutputDirectory '*') -DestinationPath $zipPath
Write-Host "Output: $zipPath"
Write-Host "Collected logs: $($changed.Count)"
Write-Host 'The diagnostics directory remains in C:\tmp\ephrlog. Remove it when diagnostics are no longer needed; existing logs have not been deleted.'
if ($changed.Count -eq 0) {
    Write-Warning 'The Windows driver did not produce a new log. Keep the ZIP and report this result; do not replace any driver DLL.'
}
