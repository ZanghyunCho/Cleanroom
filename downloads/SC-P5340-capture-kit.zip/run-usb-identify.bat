@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0usb-identify\collect-usb-identity.ps1"
set "probe_exit=%errorlevel%"
if not "%probe_exit%"=="0" echo Collection failed. Please send the error text shown above.
pause
exit /b %probe_exit%
