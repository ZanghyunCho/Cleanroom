"""Execute original and patched P704 helpers; OS setting store is a RAM fixture."""
from pathlib import Path
import hashlib,itertools,json,struct
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm_const import *
from build_stage1 import patch_module,ROOT,INPUT,BASE
STOP=0x48000000
BUF=0x42001000
class Machine:
    def __init__(self,code):
        self.code=code;self.u=Uc(UC_ARCH_ARM,UC_MODE_ARM)
        self.u.reg_write(UC_ARM_REG_C1_C0_2,0xf<<20);self.u.reg_write(UC_ARM_REG_FPEXC,0x40000000)
        for a,n in ((0x43800000,0x1000000),(0x42000000,0x200000),(STOP,0x1000)):self.u.mem_map(a,n)
        self.u.mem_write(BASE,code);self.settings={0x103d:1234,0x103f:5678};self.events=[]
        self.table=self.literal(0xb0f90);self.cache=self.literal(0xb0f7c);self.dirty=self.literal(0xb1104)
        # Initialized CSIC field descriptors are represented as RAM data, not hooks.
        for ident in range(0x60):self.u.mem_write(self.table+ident*4,struct.pack('<BBH',ident,ident+1,0xffff))
        self.u.mem_write(self.table+0x60*4,struct.pack('<BBH',0x64,0,0))
        self.u.hook_add(UC_HOOK_CODE,self.service)
    def literal(self,p):
        w=struct.unpack_from('<I',self.code,p)[0]
        off=p+8+(w&4095)*(1 if w&(1<<23) else -1)
        return struct.unpack_from('<I',self.code,off)[0]
    def service(self,u,a,size,user):
        if a not in (BASE+0x130,BASE+0x224):return
        ident=u.reg_read(UC_ARM_REG_R0);ptr=u.reg_read(UC_ARM_REG_R1);n=u.reg_read(UC_ARM_REG_R2)
        if ident not in (0x103d,0x103f):
            assert a==BASE+0x130
            self.events.append(('publication',ident,bytes(u.mem_read(ptr,n)).hex()))
            u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
        assert n==2,(hex(ident),n)
        if a==BASE+0x224:
            value=self.settings[ident];u.mem_write(ptr,struct.pack('<H',value));kind='read'
        else:
            value=struct.unpack('<H',u.mem_read(ptr,2))[0];self.settings[ident]=value;kind='write'
        self.events.append((kind,ident,value));u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
    def call(self,off,a=0,b=0):
        u=self.u;u.reg_write(UC_ARM_REG_CPSR,0x13);u.reg_write(UC_ARM_REG_SP,0x421ff000);u.reg_write(UC_ARM_REG_LR,STOP)
        u.reg_write(UC_ARM_REG_R0,a);u.reg_write(UC_ARM_REG_R1,b)
        u.emu_start(BASE+off,STOP,count=1000000)
        assert u.reg_read(UC_ARM_REG_PC)==STOP,hex(u.reg_read(UC_ARM_REG_PC))
        return u.reg_read(UC_ARM_REG_R0)
    def read_counter(self,off):
        self.u.mem_write(BUF,b'\xaa'*4);self.call(off,BUF);return struct.unpack('<I',self.u.mem_read(BUF,4))[0]
    def block(self,start,end,registers):
        self.u.reg_write(UC_ARM_REG_CPSR,0x13);self.u.reg_write(UC_ARM_REG_SP,0x421ff000)
        for reg,val in registers.items():self.u.reg_write(reg,val)
        self.u.emu_start(BASE+start,BASE+end,count=1000000)
        assert self.u.reg_read(UC_ARM_REG_PC)==BASE+end,hex(self.u.reg_read(UC_ARM_REG_PC))

def main():
    code,manifest=patch_module();original=(INPUT/'decoded/0x4f0a12e.bin').read_bytes();cases=[]
    for setter,getter,identity in ((0xaf33c,0xaf310,0x103d),(0xaf388,0xaf35c,0x103f)):
        for stored,request in itertools.product((0,1,32768,65535),(0,1,1234,65535,0xffffffff)):
            old,new=Machine(original),Machine(code)
            for m in (old,new):m.settings[identity]=stored
            assert old.read_counter(getter)==stored
            assert new.read_counter(getter)==0
            old.call(setter,request);new.call(setter,request)
            assert old.settings[identity]==request&65535 and new.settings[identity]==0
            other=0x103f if identity==0x103d else 0x103d
            assert old.settings[other]==new.settings[other]
            assert old.events[-1][0:2]==new.events[-1][0:2]==('write',identity)
            cases.append(dict(kind='config',id=hex(identity),stored=stored,request=request,patched_write=0))
    for setter,getter,first in ((0xb1128,0xb1040,0),(0xb128c,0xb1230,7)):
        for value in (0,1,7,8,65535,0x12345678,0xffffffff):
            old,new=Machine(original),Machine(code)
            for m in (old,new):
                m.u.mem_write(m.cache,b'\x5a'*192);m.u.mem_write(m.dirty,bytes(96))
            assert new.read_counter(getter)==0
            for m in (old,new):m.call(setter,value)
            assert old.read_counter(getter)==value and new.read_counter(getter)==0
            for index in range(96):
                actual=struct.unpack('<H',new.u.mem_read(new.cache+index*2,2))[0]
                assert actual==(0 if first<=index<=first+2 else 0x5a5a)
            assert bytes(old.u.mem_read(old.dirty,96))==bytes(new.u.mem_read(new.dirty,96))
            for _ in range(20):new.call(setter,value)
            assert new.read_counter(getter)==0
            cases.append(dict(kind='chip_cache',setter=hex(setter),request=value,repeated=20,unrelated_fields_unchanged=True))
    for setter,getters,ids in ((0xb1c88,(0xb1c48,0xb1c68),(0x49,0x4b)),(0xb1cf4,(0xb1cb4,0xb1cd4),(0x4a,0x4c))):
        for requested in (0,1,255):
            old,new=Machine(original),Machine(code)
            old.call(setter,requested);new.call(setter,requested)
            for getter in getters:
                old.call(getter,BUF);new.call(getter,BUF+8)
                assert old.u.mem_read(BUF,1)[0]==requested and new.u.mem_read(BUF+8,1)[0]==0
            cases.append(dict(kind='usage_flags',setter=hex(setter),requested=requested))
    for stored in (0,1,32768,0xffffffff):
        for getter,delta in ((0xaf468,0xc),(0xaf484,0x10)):
            old,new=Machine(original),Machine(code)
            for m in (old,new):m.u.mem_write(m.literal(getter)+delta,struct.pack('<I',stored))
            assert old.read_counter(getter)==stored and new.read_counter(getter)==0
            cases.append(dict(kind='reconciliation',getter=hex(getter),stored=stored))
    for incoming in (0,1,25,50,99,100,255):
        for data,expected in ((original,incoming),(code,100)):
            m=Machine(data);m.u.mem_write(BUF,bytes([incoming]));m.block(0xf55e0,0xf55e8,{UC_ARM_REG_R4:BUF,UC_ARM_REG_R3:BUF+0x100})
            assert m.u.mem_read(BUF+0x100+0x1d5,1)[0]==expected
        cases.append(dict(kind='remaining_publication',input=incoming,patched=100))
    for off,field in ((0xf55f0,0xd6),(0xf55fc,0xd8)):
        for incoming in (0,1,1234,65535):
            for data,expected in ((original,incoming),(code,0)):
                m=Machine(data);m.u.mem_write(BUF,struct.pack('<H',incoming));m.block(off,off+8,{UC_ARM_REG_R4:BUF,UC_ARM_REG_IP:BUF+0x100})
                assert struct.unpack('<H',m.u.mem_read(BUF+0x100+field,2))[0]==expected
            cases.append(dict(kind='usage_publication',offset=hex(off),input=incoming,patched=0))
    for capacity,used in itertools.product((1,100,1000,65535),(0,1,50,999,65535)):
        m=Machine(code);m.u.mem_write(BUF+4,struct.pack('<HH',capacity,capacity));m.u.mem_write(0x421ff008,struct.pack('<H',used))
        m.block(0x1a580,0x1a650,{UC_ARM_REG_R4:BUF,UC_ARM_REG_R6:BUF+0x100,UC_ARM_REG_R7:0x80,UC_ARM_REG_R5:0})
        assert m.u.mem_read(BUF+0x101,1)[0]==100
        cases.append(dict(kind='IKS_capacity',capacity=capacity,input_usage=used,remaining=100))
    for present,activity in itertools.product(range(4),range(4)):
        observations=[]
        for data in (original,code):
            m=Machine(data)
            state=m.literal(0xaf52c)
            m.u.mem_write(state+6,bytes([present,activity]))
            ret=m.call(0xb0868,BUF)
            observations.append((ret,m.u.mem_read(BUF,1)[0]))
        assert observations[0]==observations[1]
        cases.append(dict(kind='presence_preserved',presence_field=present,activity_field=activity,result=observations[1]))
    for state in range(6):
        results=[]
        for data in (original,code):
            m=Machine(data)
            status=m.literal(0xf6168);enabled=m.literal(0xf6180)
            m.u.mem_write(enabled,b'\x01');m.u.mem_write(status+0x1da,bytes([state]));m.u.mem_write(status+0x1d5,b'\x64')
            m.call(0xf6168)
            pub=[e for e in m.events if e[0]=='publication'];assert len(pub)==1
            results.append(pub)
        assert results[0]==results[1]
        cases.append(dict(kind='report_status_preserved',state=state,publication=results[1]))
    # Non-usage chip identity, presence, low-level transport, and state/error code
    # regions remain byte-identical. This is preservation evidence, not physical I/O.
    preserved=[]
    for lo,hi in ((0xae448,0xaf2f8),(0xaf4a0,0xaf558),(0xb05fc,0xb08cc),(0xb1994,0xb1c48),(0xb1d20,0xb2428),(0xf55d4,0xf55e0),(0xf6168,0xf6230)):
        assert code[lo:hi]==original[lo:hi];preserved.append([hex(lo),hex(hi)])
    result={'passed':len(cases),'failed':0,'cases':cases,'preserved_regions':preserved,
        'module_sha256':hashlib.sha256(code).hexdigest(),'verdict_replacement_hooks':0,
        'fixtures':'Initialized RAM CSIC field descriptors; two-byte OS setting read/write boundary for IDs 0x103d/0x103f. No chip-state or counter-function verdict is replaced.',
        'limitations':['Physical chip/NVRAM writes untested','Whole boot, RTOS scheduling and printing untested','Only identified usage paths tested; no-cartridge operation not implemented']}
    (ROOT/'native-stage1-results.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',len(cases),'native scenarios',flush=True)

if __name__=='__main__':main()
