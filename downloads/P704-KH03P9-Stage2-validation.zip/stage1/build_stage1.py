"""P704 KH03P9 maintenance-box Stage 1 software counter controls."""
from pathlib import Path
import hashlib,json,struct,sys,zipfile
ROOT=Path(__file__).resolve().parent
INPUT=ROOT.parent
BASE=0x43808000
sys.path.insert(0,str(INPUT/'prior'))
from encode_crom import encode
from decode_crom import decode
sys.path.insert(0,str(INPUT))
from build_controls import sections

def sha(b):return hashlib.sha256(b).hexdigest()

def patch_module():
    original=(INPUT/'decoded/0x4f0a12e.bin').read_bytes()
    assert sha(original)=='f5236e51018930c24945ef53fd760871c4d293d3939b35b9dbc5efc0efe7f080'
    code=bytearray(original);patches=[]
    def patch(off,before,after,reason):
        assert code[off:off+4]==bytes.fromhex(before),(hex(off),code[off:off+4].hex())
        new=struct.pack('<I',after);code[off:off+4]=new
        patches.append(dict(offset=hex(off),address=hex(BASE+off),before=before,after=new.hex(),reason=reason))
    for off in (0xaf330,0xaf37c):patch(off,'b010dde1',0xe3a01000,'Software ZA/YA read returns zero after original backing read')
    for a,b,c,disp in ((0xaf340,0xaf344,0xaf348,0x10c),(0xaf38c,0xaf390,0xaf394,0xc4)):
        patch(a,'b000cde1',0xe3a03000,'Zero software usage value')
        old=struct.pack('<I',0xe59f0000|(disp+4)).hex()
        patch(b,old,0xe1cd30b0,'Store zero into the original two-byte write buffer')
        patch(c,'0030a0e3',0xe59f0000|disp,'Preserve original setting ID and normal write dispatch')
    for off,before in ((0xaf46c,'0c1091e5'),(0xaf488,'101091e5')):
        patch(off,before,0xe3a01000,'Chip-counter reconciliation mirrors return zero')
    for off in (0xb108c,0xb127c):patch(off,'010080e1',0xe3a00000,'Chip usage read returns zero after original cache reads')
    for a,b,c in ((0xb112c,0xb1134,0xb1138),(0xb1290,0xb1298,0xb129c)):
        patch(a,'0037a0e1',0xe3a03000,'Zero high/middle usage component before original chip cache setter')
        patch(b,'2019a0e1',0xe3a01000,'Zero high usage component')
        patch(c,'075000e2',0xe3a05000,'Zero low usage component')
    for off in (0xb1c5c,0xb1c7c,0xb1cc8,0xb1ce8):
        patch(off,'b000dde1',0xe3a00000,'Read near/full usage flags as clear; original cache access remains')
    for off in (0xb1c8c,0xb1cf8):patch(off,'0050a0e1',0xe3a05000,'Write clear near/full usage flags through original setter')
    patch(0xf55e0,'0000d4e5',0xe3a00064,'Publish maintenance available space as 100 percent')
    for off in (0xf55f0,0xf55fc):patch(off,'b000d4e1',0xe3a00000,'Publish maintenance ZA/YA usage as zero')
    patch(0x1a584,'b800dde1',0xe3a00000,'Use zero consumption in IKS maintenance capacity comparison')
    patch(0x1a648,'640060e2',0xe3a00064,'IKS normal maintenance available-space report is 100 percent')
    allowed={i for p in patches for i in range(int(p['offset'],16),int(p['offset'],16)+4)}
    diff=[i for i,(a,b) in enumerate(zip(original,code)) if a!=b]
    assert set(diff)<=allowed
    manifest={'base':'KH03P9.FY19','module_base':hex(BASE),'module_source_rcx_offset':'0x4f0a12e',
        'original_module_sha256':sha(original),'patched_module_sha256':sha(code),'instruction_sites':len(patches),'changed_bytes':len(diff),
        'patches':patches,'physical_update_tested':False,'physical_boot_tested':False,
        'scope':'Software-visible ZA/YA counters, known cache/config writers, reconciliation and reporting; no claim that existing physical chip/NVRAM cells are erased.',
        'not_implemented':['No-cartridge operation','Bypass unrelated chip or cover errors','Physical EEPROM/chip transaction validation']}
    (ROOT/'stage1-module.bin').write_bytes(code)
    (ROOT/'patches.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return bytes(code),manifest

def package():
    code,manifest=patch_module()
    original=(INPUT/'FW4838TL.rcx').read_bytes();sign=original.index(b'EPSONSIGN');body=sign+4096
    start=0x4f0a12e;end=start+4+int.from_bytes(original[start+6:start+10],'big')
    n=int.from_bytes(original[end+2:end+6],'big');second=original[end:end+n]
    assert second.startswith(b'\xff\xd8') and original[end+n:]==b'\xff'*(len(original)-end-n)
    encoded,compression=encode(code,original[start:end]);assert compression['padding_tokens']>0
    assert compression['dma_output_bytes']%48==0
    assert len(encoded)+n<=len(original)-start
    changed=bytearray(original);changed[start:]=encoded+second+b'\xff'*(len(original)-start-len(encoded)-n)
    section=0x4ef712e;m=struct.unpack_from('<I',changed,section+28)[0];length=struct.unpack_from('<I',changed,section+64)[0]
    p=section+4096+m;payload=changed[p:p+length]
    struct.pack_into('<H',changed,section+54,sum(payload)&65535)
    changed[section+68:section+88]=hashlib.sha1(payload+hashlib.sha1(changed[section:section+14]).digest()).digest()
    actual=len(changed)-body;struct.pack_into('<I',changed,sign+16,actual+1)
    assert len(changed)==len(original)
    allowed=[(sign+16,sign+20),(section+54,section+56),(section+68,section+88),(start,len(original))]
    prev=0
    for lo,hi in allowed:assert changed[prev:lo]==original[prev:lo];prev=hi
    assert changed[sign+32:sign+96]==original[sign+32:sign+96]
    assert changed[0xb13e:0xb17e]==original[0xb13e:0xb17e]
    out=ROOT/'FW4838TL_KH03P9-P704-Stage1-maintenance-zero.efu'
    with zipfile.ZipFile(INPUT/'FW4838TL.efu') as z:info=z.getinfo('FW4838TL.rcx')
    with zipfile.ZipFile(out,'w') as z:z.writestr(info,changed)
    with zipfile.ZipFile(out) as z:assert z.testzip() is None;final=z.read('FW4838TL.rcx');assert final==changed
    restored,decoded=decode(final,start);assert restored==code
    newend=start+len(encoded);assert final[newend:newend+n]==second
    original_second,_=decode(b'CROM'+second,0);final_second,_=decode(b'CROM'+final[newend:newend+n],0)
    assert final_second==original_second
    manifest.update(file=out.name,bytes=out.stat().st_size,sha256=sha(out.read_bytes()),rcx_sha256=sha(final),
        actual_body_bytes=actual,declared_body_bytes=actual+1,compression=compression,sections=sections(final),
        final_crc_ok=True,final_module_exact=True,second_frame_identical=True,second_frame_new_offset=hex(newend),
        public_key_and_signature_preserved=True,unexpected_changes=False,normal_body_signature_valid=False)
    (ROOT/'validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ROOT/(out.name+'.sha256')).write_text(manifest['sha256']+'  '+out.name+'\n')
    print(json.dumps({k:manifest[k] for k in ('file','sha256','instruction_sites','changed_bytes','compression')},indent=2),flush=True)

if __name__=='__main__':package()
