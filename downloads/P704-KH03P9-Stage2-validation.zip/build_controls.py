"""Build P704 A/B controls from official KH03P9; never flash a device."""
from pathlib import Path
import hashlib,json,struct,sys,zipfile
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'prior'))
from decode_crom import decode
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec,utils
from cryptography.exceptions import InvalidSignature

def sha(x):return hashlib.sha256(x).hexdigest()

def sections(d):
    p=d.index(b'EPSONSIGN')+4096;out=[]
    while p<len(d):
        h=d[p:p+4096];assert len(h)==4096 and h.startswith(b'EPSON IP')
        m=struct.unpack_from('<I',h,28)[0];n=struct.unpack_from('<I',h,64)[0]
        a=p+4096;begin=a+m;end=begin+n;assert end<=len(d)
        assert sum(d[a:begin])&65535==struct.unpack_from('<H',h,18)[0]
        assert sum(d[begin:end])&65535==struct.unpack_from('<H',h,54)[0]
        assert hashlib.sha1(d[begin:end]+hashlib.sha1(h[:14]).digest()).digest()==h[68:88]
        out.append({'offset':hex(p),'metadata_bytes':m,'body_bytes':n,'checks_passed':True});p=end
    assert p==len(d) and len(out)==3
    return out

def main():
    original=(ROOT/'FW4838TL.rcx').read_bytes()
    assert sha(original)=='ee0d3dfcfa9869f0585ad249648f40d22e4cb08ed1fee228f26c11b1eb451d47'
    sign=original.index(b'EPSONSIGN');body=sign+4096;actual=len(original)-body
    assert struct.unpack_from('<I',original,sign+16)[0]==actual
    key=original[0x7010+0x412e:0x7050+0x412e]
    assert key==Path('/workspace/p5300-analysis/IC102.BIN').read_bytes()[0x7010:0x7050]
    pub=ec.EllipticCurvePublicNumbers(int.from_bytes(key[:32],'big'),int.from_bytes(key[32:],'big'),ec.SECP256R1()).public_key()
    sig=original[sign+32:sign+96];der=utils.encode_dss_signature(int.from_bytes(sig[:32],'big'),int.from_bytes(sig[32:],'big'))
    out=ROOT/'controls';out.mkdir(exist_ok=True)
    start=0xe412e;end=start+4+int.from_bytes(original[start+6:start+10],'big')
    second_size=int.from_bytes(original[end+2:end+6],'big');second=original[end:end+second_size]
    assert second.startswith(b'\xff\xd8')
    second_decoded,_=decode(b'CROM'+second,0)
    allocation_end=end+second_size
    while original[allocation_end]==255:allocation_end+=1
    assert allocation_end==0x46e12e
    decoded_original=(ROOT/'decoded/0xe412e.bin').read_bytes()
    with zipfile.ZipFile(ROOT/'FW4838TL.efu') as z:info=z.getinfo('FW4838TL.rcx')
    manifests=[]
    for label in ('A-envelope-only','B-original-code-reencoded'):
        d=bytearray(original);struct.pack_into('<I',d,sign+16,actual+1)
        compression=None;new_end=end
        if label.startswith('B'):
            encoded=(ROOT/'reencoded-original.crom').read_bytes();compression=json.loads((ROOT/'reencoded-original.json').read_text())
            replacement=encoded+second
            assert len(replacement)<=allocation_end-start,('allocation exceeded',len(replacement),allocation_end-start)
            d[start:allocation_end]=replacement+b'\xff'*(allocation_end-start-len(replacement));new_end=start+len(encoded)
            m=struct.unpack_from('<I',d,body+28)[0];n=struct.unpack_from('<I',d,body+64)[0];a=body+4096+m
            struct.pack_into('<H',d,body+54,sum(d[a:a+n])&65535)
            d[body+68:body+88]=hashlib.sha1(d[a:a+n]+hashlib.sha1(d[body:body+14]).digest()).digest()
        assert len(d)==len(original)
        assert d[sign+32:sign+96]==sig
        assert d[0xb13e:0xb17e]==key
        allowed=[(sign+16,sign+20)]
        if compression:allowed += [(body+54,body+56),(body+68,body+88),(start,allocation_end)]
        previous=0
        for lo,hi in sorted(allowed):assert d[previous:lo]==original[previous:lo];previous=hi
        assert d[previous:]==original[previous:]
        assert d[new_end:new_end+second_size]==second
        check_sections=sections(d)
        file=out/f'FW4838TL_KH03P9-startup-{label}.efu'
        with zipfile.ZipFile(file,'w') as z:z.writestr(info,d)
        with zipfile.ZipFile(file) as z:
            assert z.testzip() is None;final=z.read('FW4838TL.rcx');assert final==d
        # Validate decoded code from the final delivered container.
        recovered,decoded_report=decode(final,start);assert recovered==decoded_original
        recovered_second,_=decode(b'CROM'+final[new_end:new_end+second_size],0)
        assert recovered_second==second_decoded
        assert final[body:]==original[body:] if label.startswith('A') else final[body:]!=original[body:]
        verdict='valid'
        try:pub.verify(der,hashlib.sha256(final[body:]).digest(),ec.ECDSA(utils.Prehashed(hashes.SHA256())))
        except InvalidSignature:verdict='invalid'
        assert verdict==('valid' if label.startswith('A') else 'invalid')
        manifest={'label':label,'file':file.name,'bytes':file.stat().st_size,'sha256':sha(file.read_bytes()),'rcx_sha256':sha(final),
          'base_version':'KH03P9.FY19','dump_version':'KH04M4','original_signature_bytes_preserved':True,'original_public_key_bytes_preserved':True,
          'actual_body_bytes':actual,'declared_body_bytes':actual+1,'body_identical_to_official':label.startswith('A'),
          'normal_body_signature_host_check':verdict,'sections':check_sections,'compression':compression,'decoded_code_identical_to_official':True,
          'decoded_code_sha256':sha(recovered),'second_frame_identical':True,'second_frame_original_offset':hex(end),'second_frame_new_offset':hex(new_end),
          'allocation_end':hex(allocation_end),'unexpected_changes':False,'final_zip_crc_ok':True,'final_reextract_identical':True,
          'physical_update_tested':False,'physical_boot_tested':False,'full_upper_receiver_tested':False,'native_loader_dma_tested':False,
          'purpose':'Packaging controls only; original maintenance-cartridge behavior remains.'}
        (out/(label+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
        (out/(file.name+'.sha256')).write_text(manifest['sha256']+'  '+file.name+'\n')
        manifests.append(manifest);print(label,manifest['sha256'],flush=True)
    (out/'validation.json').write_text(json.dumps(manifests,indent=2)+'\n')

if __name__=='__main__':main()
