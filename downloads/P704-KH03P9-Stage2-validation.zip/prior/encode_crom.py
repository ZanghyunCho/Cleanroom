"""Encode a CROM frame with original canonical Huffman tables and LZ tokens."""
from array import array
import struct
from decode_crom import decode


def encode(data, template_container):
    if template_container[:6] != b'CROM\xff\xd8':
        raise ValueError('Expected original CROM frame template')
    p = 10
    table_end = p + 2 + int.from_bytes(template_container[p + 2:p + 4], 'big')
    dht = template_container[p:table_end]
    tables = []
    q = p + 4
    for ident in (0xf0, 0xf1, 0xf2):
        if template_container[q] != ident:
            raise ValueError('Unexpected Huffman table')
        counts = template_container[q + 1:q + 17]
        symbols = template_container[q + 17:q + 17 + sum(counts)]
        table, code, k = {}, 0, 0
        for bits, count in enumerate(counts, 1):
            for _ in range(count):
                table[symbols[k]] = (code, bits)
                code += 1
                k += 1
            code <<= 1
        tables.append(table)
        q += 17 + len(symbols)
    if q != table_end or template_container[q:q + 2] != b'\xff\xb1':
        raise ValueError('Invalid original token-block header')
    block_len = int.from_bytes(template_container[q + 2:q + 4], 'big') + 2
    if not 17 <= block_len <= 64:
        raise ValueError('Unsupported token header size')
    block = bytearray(template_container[q:q + block_len])
    tokens, literals = bytearray(), bytearray()
    heads = [-1] * 65536
    previous = array('i', [-1]) * len(data)
    pos = 0
    literal_start = None

    def insert(index):
        if index + 2 < len(data):
            key = ((data[index] * 251 + data[index + 1]) * 251 + data[index + 2]) & 65535
            previous[index] = heads[key]
            heads[key] = index

    def flush_literals(end):
        nonlocal literal_start
        if literal_start is None:
            return
        start = literal_start
        while start < end:
            count = min(253, end - start)
            while count - 1 not in tables[0]:
                count -= 1
            tokens.extend((count - 1, 0, 0))
            literals.extend(data[start:start + count])
            start += count
        literal_start = None

    while pos < len(data):
        best_length = best_distance = 0
        if pos + 2 < len(data):
            key = ((data[pos] * 251 + data[pos + 1]) * 251 + data[pos + 2]) & 65535
            candidate = heads[key]
            limit = min(254, len(data) - pos)
            depth = 0
            while candidate >= max(0, pos - 65535) and depth < 32:
                if data[candidate:candidate + 3] == data[pos:pos + 3]:
                    length = 3
                    while length < limit and data[candidate + length] == data[pos + length]:
                        length += 1
                    while length >= 3 and length - 2 not in tables[0]:
                        length -= 1
                    if length > best_length:
                        best_length, best_distance = length, pos - candidate
                        if length == limit:
                            break
                candidate = previous[candidate]
                depth += 1
        if best_length >= 3:
            flush_literals(pos)
            tokens.extend((best_length - 2, best_distance & 255, best_distance >> 8))
            for index in range(pos, pos + best_length):
                insert(index)
            pos += best_length
        else:
            if literal_start is None:
                literal_start = pos
            insert(pos)
            pos += 1
            if pos - literal_start >= 253:
                flush_literals(pos)
    flush_literals(pos)
    packed = bytearray()
    bit_buffer = bit_count = 0
    token_count = len(tokens) // 3
    # Keep positive padding, as in the official frame, by adding a no-output
    # token when the unpadded count is a multiple of sixteen.
    if token_count % 16 == 0:
        if 255 not in tables[0] or 0 not in tables[1] or 0 not in tables[2]:
            raise ValueError('No-output token unavailable in original tables')
        tokens.extend((255, 0, 0))
        token_count += 1
    padding_tokens = (-token_count) % 16
    # The hardware descriptor requests three output bytes per padded token.
    # Reusing the original frame's padding count breaks this DMA granularity.
    block[13] = padding_tokens
    padded_tokens = tokens + bytes(padding_tokens * 3)
    for index, value in enumerate(padded_tokens):
        code, bits = tables[index % 3][value]
        bit_buffer = (bit_buffer << bits) | code
        bit_count += bits
        while bit_count >= 8:
            bit_count -= 8
            packed.append((bit_buffer >> bit_count) & 255)
        bit_buffer &= (1 << bit_count) - 1
    if bit_count:
        packed.append((bit_buffer << (8 - bit_count)) & 255)
    packed.extend(bytes(16))
    packed.extend(bytes((-len(packed)) % 16))
    struct.pack_into('>II', block, 5, len(packed), token_count)
    frame = (b'\xff\xd8' + bytes(4) + dht + bytes(block) + bytes(packed)
             + b'\xff\xb2\x00\x06' + struct.pack('>I', len(literals)) + bytes(literals))
    frame = frame[:2] + struct.pack('>I', len(frame)) + frame[6:]
    container = b'CROM' + frame
    restored, info = decode(container, 0)
    if restored != data or info['literal_bytes_used'] != len(literals):
        raise ValueError('CROM encode/decode roundtrip failed')
    return container, {'encoded_frame_size': len(frame),
                       'tokens': token_count, 'padding_tokens': padding_tokens,
                       'padded_token_count': token_count + padding_tokens,
                       'dma_output_bytes': (token_count + padding_tokens) * 3,
                       'packed_size': len(packed),
                       'literal_size': len(literals), 'decoded_sha256': info['sha256'],
                       'roundtrip_exact': True}
