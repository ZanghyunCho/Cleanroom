"""P704 ink native comparisons; OS transport delivers to original setting RAM handlers."""
import sys,json,struct,itertools,hashlib,importlib.util
from pathlib import Path
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import *
from build_stage2 import patch_module,ROOT,INPUT,BASE
sys.path.insert(0,str(INPUT/'stage1'))
from verify_stage1 import Machine as BaselineMachine,BUF,STOP
from build_stage1 import patch_module as stage1

class Machine(BaselineMachine):
    def __init__(self,code):
        super().__init__(code)
        self.array32=self.literal(0x22cc);self.array16=self.literal(0x22ec)
        self.chip_fixture=False;self.raw_value=123;self.slot=0;self.mode=0;self.chip_events=[]
    def service(self,u,a,size,user):
        if a in (BASE+0x130,BASE+0x224):
            self.events.append(('write' if a==BASE+0x130 else 'read',u.reg_read(UC_ARM_REG_R0)))
            # Model only message delivery: the unmodified native setting handler,
            # including its patched selective access path, actually executes.
            u.reg_write(UC_ARM_REG_PC,BASE+(0x2330 if a==BASE+0x130 else 0x2500));return
        if not self.chip_fixture:return
        if a==BASE+0x9b308:
            u.mem_write(u.reg_read(UC_ARM_REG_R1),bytes([self.slot]));u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
        elif a==BASE+0x9a4d0:
            u.mem_write(u.reg_read(UC_ARM_REG_R0),bytes([self.mode]));u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
        elif a==BASE+0xabe18:
            self.chip_events.append(('read',u.reg_read(UC_ARM_REG_R0),u.reg_read(UC_ARM_REG_R1)))
            u.mem_write(u.reg_read(UC_ARM_REG_R2),struct.pack('<H',self.raw_value));u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
        elif a==BASE+0xac0e0:
            self.chip_events.append(('write',u.reg_read(UC_ARM_REG_R0),u.reg_read(UC_ARM_REG_R1),u.reg_read(UC_ARM_REG_R2)))
            u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
    def invoke(self,off,*args):
        u=self.u;u.reg_write(UC_ARM_REG_CPSR,0x13);u.reg_write(UC_ARM_REG_SP,0x421ff000);u.reg_write(UC_ARM_REG_LR,STOP)
        for reg,value in zip((UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3),args):u.reg_write(reg,value)
        u.emu_start(BASE+off,STOP,count=1000000)
        assert u.reg_read(UC_ARM_REG_PC)==STOP,hex(u.reg_read(UC_ARM_REG_PC))
        return u.reg_read(UC_ARM_REG_R0)
    def pointer(self,ident):return (self.array32+(ident-0x1240)*4,4) if ident>=0x1240 else (self.array16+(ident-0xfa3)*2,2)
    def seed(self,ident,value):
        p,n=self.pointer(ident);self.u.mem_write(p,int(value&((1<<(8*n))-1)).to_bytes(n,'little'))
    def value(self,ident):
        p,n=self.pointer(ident);return int.from_bytes(self.u.mem_read(p,n),'little')

def main():
    code,manifest=patch_module();baseline,_=stage1();ids=[int(x,16) for x in manifest['ink_usage_ids_by_slot']]
    ids16=[int(x,16) for x in manifest['secondary_usage_ids']];cases=[]
    for slot,stored,request in itertools.product(range(10),(0,1,0x12345678,0xffffffff),(0,1,0x87654321,0xffffffff)):
        old,new=Machine(baseline),Machine(code)
        for m in (old,new):
            for index,ident in enumerate(ids):m.seed(ident,stored if index==slot else 0x43210000+index)
        ident=ids[slot]
        old.invoke(0x99664,slot,BUF);new.invoke(0x99664,slot,BUF)
        assert int.from_bytes(old.u.mem_read(BUF,4),'little')==stored
        assert new.u.mem_read(BUF,4)==bytes(4) and new.value(ident)==0
        old.invoke(0x99754,slot,request);new.invoke(0x99754,slot,request)
        assert old.value(ident)==request and new.value(ident)==0
        for index,other in enumerate(ids):
            if index!=slot:assert new.value(other)==old.value(other)==0x43210000+index
        cases.append(dict(kind='slot_accounting',slot=slot,id=hex(ident),stored=stored,request=request))
    # Common storage entry points also cover writes that bypass the slot wrapper.
    for ident,stored,requested in itertools.product(ids+ids16,(0,1,65535),(0,1,0xffffffff)):
        old,new=Machine(baseline),Machine(code);p,n=new.pointer(ident)
        for m in (old,new):m.seed(ident,stored);m.u.mem_write(BUF,requested.to_bytes(4,'little'))
        old_ret=old.invoke(0x2330,ident,BUF,n);new_ret=new.invoke(0x2330,ident,BUF,n)
        mask=(1<<(n*8))-1
        assert old.value(ident)==requested&mask and new.value(ident)==0
        assert old_ret==int((stored&mask)!=(requested&mask)) and new_ret==int((stored&mask)!=0)
        assert new.u.mem_read(BUF,4)==requested.to_bytes(4,'little')
        new.seed(ident,stored);ret=new.invoke(0x2500,ident,BUF+8,n)
        assert ret==n and new.value(ident)==0 and bytes(new.u.mem_read(BUF+8,n))==bytes(n)
        cases.append(dict(kind='common_setting_access',id=hex(ident),width=n,stored=stored,request=request))
    selected=set(ids+ids16)
    neighbors=sorted({x+d for x in selected for d in (-1,1)}-selected)
    neighbors += [0xfa3,0x103d,0x103f,0x1200,0x1240,0x1439]
    for ident,requested in itertools.product(sorted(set(neighbors)),(0,1,0xffffffff)):
        observations=[]
        for data in (baseline,code):
            m=Machine(data);p,n=m.pointer(ident);m.seed(ident,99);m.u.mem_write(BUF,requested.to_bytes(4,'little'))
            write=m.invoke(0x2330,ident,BUF,n);read=m.invoke(0x2500,ident,BUF+8,n)
            observations.append((write,read,m.value(ident),bytes(m.u.mem_read(BUF,12))))
        assert observations[0]==observations[1],hex(ident)
        cases.append(dict(kind='unrelated_setting_preserved',id=hex(ident),request=requested))
    for index in (10,11,255,0xffffffff):
        for data in (baseline,code):
            m=Machine(data);m.invoke(0x99664,index,BUF);assert m.u.mem_read(BUF,4)==b'\xff'*4
            m.invoke(0x99754,index,1234);assert not m.events
        cases.append(dict(kind='invalid_slot_preserved',slot=index))
    for slot,stored,request in itertools.product(range(10),(0,1234,0xffffffff),(0,1,0xffffffff)):
        m=Machine(code);ptr=m.literal(0x9bd90)
        for i in range(10):m.u.mem_write(ptr+i*4,struct.pack('<I',stored if i==slot else 0x12340000+i))
        m.invoke(0x9bdbc,slot,BUF);assert m.u.mem_read(BUF,4)==bytes(4) and m.u.mem_read(ptr+slot*4,4)==bytes(4)
        for _ in range(10):m.invoke(0x9bd90,slot,request);m.invoke(0x9bdb0,slot,request)
        assert m.u.mem_read(ptr+slot*4,4)==bytes(4)
        for i in range(10):
            if i!=slot:assert int.from_bytes(m.u.mem_read(ptr+i*4,4),'little')==0x12340000+i
        cases.append(dict(kind='pulse_total',slot=slot,stored=stored,request=request))
    for slot,value in itertools.product(range(10),(0,1,65535)):
        m=Machine(code);ptr=m.literal(0x9bd00)
        for i in range(10):m.u.mem_write(ptr+i*2,struct.pack('<H',value if i==slot else 100+i))
        m.invoke(0x9bd00,slot,BUF);assert m.u.mem_read(BUF,2)==bytes(2) and m.u.mem_read(ptr+slot*2,2)==bytes(2)
        m.invoke(0x9bd14,slot,value);assert m.u.mem_read(ptr+slot*2,2)==bytes(2)
        for i in range(10):
            if i!=slot:assert int.from_bytes(m.u.mem_read(ptr+i*2,2),'little')==100+i
        cases.append(dict(kind='normalized_cache',slot=slot,input=value))
    for slot,raw,mode in itertools.product(range(10),(0,1,65535),(0,1)):
        for getter in (0xabe5c,0xac160,0xac71c):
            observations=[]
            for data in (baseline,code):
                m=Machine(data);m.chip_fixture=True;m.slot=slot;m.mode=mode;m.raw_value=raw
                m.invoke(getter,slot,BUF);observations.append((int.from_bytes(m.u.mem_read(BUF,2),'little'),m.chip_events))
            assert observations[0][0]==raw and observations[1][0]==0 and observations[0][1]==observations[1][1]
            cases.append(dict(kind='chip_usage_read',slot=slot,mode=mode,getter=hex(getter),raw=raw))
        for setter,fields in ((0xac124,(0,2)),(0xac1a8,(1,3))):
            old,new=Machine(baseline),Machine(code)
            for m in (old,new):m.chip_fixture=True;m.slot=slot;m.invoke(setter,slot,raw)
            assert old.chip_events==[('write',slot,f,raw) for f in fields]
            assert new.chip_events==[('write',slot,f,0) for f in fields]
            cases.append(dict(kind='chip_usage_write',slot=slot,setter=hex(setter),request=raw))
    # The actual numeric report preserves every nonnumeric state encoding.
    for slot,state,percent in itertools.product(range(10),range(8),(0,1,50,100)):
        observations=[]
        for data in (baseline,code):
            m=Machine(data);table=m.literal(0xf62d8);shared=m.literal(0xf6340);flags=m.literal(0xf6350)
            state_ptr=BUF+0x100+slot*16;percent_ptr=state_ptr+4
            m.u.mem_write(table+slot*64+8,struct.pack('<II',state_ptr,percent_ptr));m.u.mem_write(state_ptr,bytes([state]));m.u.mem_write(percent_ptr,bytes([percent]));m.u.mem_write(shared+0x1db,b'\x01')
            observations.append(m.invoke(0xf62d8,slot))
        assert observations[1]==(100 if state==0 else observations[0])
        cases.append(dict(kind='remaining_and_error_report',slot=slot,state=state,stored_percent=percent,output=observations[1]))
    for percent,state,branding in itertools.product((0,1,50,100),(0,1,3,5),(0,1)):
        m=Machine(code);record=BUF+0x100;source=BUF+0x200;stateptr=BUF+0x300;brandptr=BUF+0x301;remainingptr=BUF+0x302
        m.u.mem_write(record+8,struct.pack('<III',stateptr,remainingptr,brandptr));m.u.mem_write(record+0x18,struct.pack('<I',source));m.u.mem_write(source,bytes([state,percent,branding]))
        m.block(0xf54bc,0xf54ec,{UC_ARM_REG_R0:record})
        assert bytes(m.u.mem_read(stateptr,3))==bytes([state,branding,100])
        cases.append(dict(kind='canonical_remaining_event',percent=percent,state=state,branding=branding))
    # All Stage 1 behavior is re-run on the Stage 2 binary.
    import verify_stage1 as v1
    v1.patch_module=lambda:(code,manifest);v1.ROOT=ROOT;v1.main()
    regression=json.loads((ROOT/'native-stage1-results.json').read_text());assert regression['passed']==125
    result={'passed':len(cases)+125,'ink_scenarios':len(cases),'stage1_regression_scenarios':125,'failed':0,
        'module_sha256':hashlib.sha256(code).hexdigest(),'cases':cases,
        'fixtures':'OS message delivery aliases native 0x2330/0x2500 RAM handlers; cached chip field input and field write capture only in raw chip tests. No verdict replacement or authentication stubs.',
        'limitations':['Physical chip/EEPROM write acceptance untested','Full boot, RTOS concurrency and printing untested','Presence/authentication/other error states preserved; this is not a no-cartridge or approval bypass']}
    (ROOT/'native-stage2-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS',result['passed'],'native scenarios including 125 Stage 1 regressions',flush=True)

if __name__=='__main__':main()
