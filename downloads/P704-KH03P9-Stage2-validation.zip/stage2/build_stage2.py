"""P704 Stage 2: retain Stage 1; clamp only identified ink accounting fields."""
from pathlib import Path
import hashlib,json,struct,sys,zipfile
from keystone import Ks,KS_ARCH_ARM,KS_MODE_ARM
ROOT=Path(__file__).resolve().parent;INPUT=ROOT.parent;BASE=0x43808000
sys.path.insert(0,str(INPUT/'stage1'))
from build_stage1 import patch_module as stage1
sys.path.insert(0,str(INPUT/'prior'))
from encode_crom import encode
from decode_crom import decode
sys.path.insert(0,str(INPUT))
from build_controls import sections
def sha(b):return hashlib.sha256(b).hexdigest()
def branch(p,t):return struct.pack('<I',0xea000000|(((t-p-8)//4)&0xffffff))

def patch_module():
    baseline,s1=stage1();code=bytearray(baseline);patches=[]
    original=(INPUT/'decoded/0x4f0a12e.bin').read_bytes()
    ids=[]
    for i in range(10):
        p=struct.unpack_from('<I',original,0x99680+i*4)[0]-BASE
        w=struct.unpack_from('<I',original,p)[0]
        ids.append(struct.unpack_from('<I',original,p+8+(w&4095))[0])
    assert set(ids)=={0x1296,0x1297,0x1299,0x129b,*range(0x1309,0x130f)}
    def replace(off,data,reason):
        before=bytes(code[off:off+len(data)]);code[off:off+len(data)]=data
        patches.append(dict(offset=hex(off),address=hex(BASE+off),before=before.hex(),after=data.hex(),reason=reason))
    def word(off,expected,value,reason):
        assert struct.unpack_from('<I',code,off)[0]==expected,hex(off)
        replace(off,struct.pack('<I',value),reason)
    ks=Ks(KS_ARCH_ARM,KS_MODE_ARM)
    def asm(off,limit,text,reason):
        data=bytes(ks.asm(text,addr=BASE+off)[0]);assert len(data)<=limit,(hex(off),len(data),limit)
        replace(off,data,reason)
    # The old 10-way setter/getter are replaced in their own function ranges.
    # No other entry points reference their retired internal basic blocks.
    for p in range(0,len(original)-4,4):
        if 0x99664<=p<0x9985c:continue
        w=struct.unpack_from('<I',original,p)[0]
        assert not BASE+0x99664<w<BASE+0x99754
        assert not BASE+0x99754<w<BASE+0x9985c
        if w&0x0e000000==0x0a000000:
            x=w&0xffffff;x=x-0x1000000 if x&0x800000 else x;t=p+8+x*4
            assert not 0x99664<t<0x99754 and not 0x99754<t<0x9985c
    asm(0x99664,0x3c,f'''
        cmp r0,#10; mvn r3,#0; strhs r3,[r1]; bxhs lr
        push {{r4,lr}}; mov r4,r1
        movw r3,#{(BASE+0x99720)&65535}; movt r3,#{(BASE+0x99720)>>16}
        ldr r0,[r3,r0,lsl #2]; mov r2,#4
        bl {BASE+0x99658}; ldr r0,[r4]; pop {{r4,pc}}
    ''','Compact original-ID ink getter; invalid indices retain 0xffffffff')
    asm(0x996a0,0x40,f'''
        cmp r4,#0x56; cmpne r4,#0x57; cmpne r4,#0x59; cmpne r4,#0x5b; beq zero
        sub ip,r4,#0xc9; cmp ip,#5; bhi original
        zero: mov r0,#0; str r0,[r2,r4,lsl #2]
        original: ldr r0,[r2,r4,lsl #2]; b {BASE+0x2498}
    ''','32-bit ink usage read clears actual RAM and returns zero; other IDs original')
    asm(0x996e0,0x40,f'''
        cmp r4,#0x61; cmpne r4,#0x62; cmpne r4,#0x67; beq zero
        sub ip,r4,#0xf5; cmp ip,#6; bhi original
        zero: mov ip,#0; strh ip,[r0]
        original: ldrh r0,[r0]; b {BASE+0x24c8}
    ''','16-bit ink reconciliation usage read clears actual RAM; other IDs original')
    replace(0x99720,struct.pack('<10I',*ids),'Exact original physical-slot to usage-ID mapping')
    asm(0x99754,0x4c,f'''
        cmp r0,#10; bxhs lr; push {{r4,lr}}; sub sp,sp,#8
        mov r3,#0; str r3,[sp]
        movw ip,#{(BASE+0x99720)&65535}; movt ip,#{(BASE+0x99720)>>16}
        ldr r0,[ip,r0,lsl #2]; mov r1,sp; mov r2,#4
        bl {BASE+0x9965c}; add sp,sp,#8; pop {{r4,pc}}
    ''','All ten ink usage writers submit zero via original setting dispatch')
    asm(0x997a0,0x40,f'''
        cmp r0,#0x56; cmpne r0,#0x57; cmpne r0,#0x59; cmpne r0,#0x5b; beq zero
        sub ip,r0,#0xc9; cmp ip,#5; bhi original
        zero: mov r1,#0; b {BASE+0x22d4}
        original: ldr r1,[r1]; b {BASE+0x22d4}
    ''','Every common 32-bit write to selected ink IDs is zero; input buffer unchanged')
    asm(0x997e0,0x40,f'''
        cmp r0,#0x61; cmpne r0,#0x62; cmpne r0,#0x67; beq zero
        sub ip,r0,#0xf5; cmp ip,#6; bhi original
        zero: mov r1,#0; b {BASE+0x22f4}
        original: ldrh r1,[r1]; b {BASE+0x22f4}
    ''','Every common 16-bit write to selected ink usage IDs is zero')
    asm(0x99820,0x10,'add r0,r2,r0,lsl #1; mov r1,#0; strh r1,[r0]; bx lr',
        'Normalized current usage-cache setter preserves per-slot address calculation')
    asm(0x99830,0x10,f'mov r3,#0; strh r3,[r0]; mov r0,#0; b {BASE+0x9bd0c}',
        'Normalized current usage-cache read clears only the addressed slot')
    asm(0x99840,0x10,f'mov r3,#0; str r3,[r2,r0,lsl #2]; mov r0,#0; b {BASE+0x9bdc4}',
        'Pulse-total read clears the existing RAM value of only the addressed slot')
    for off,target,expected,reason in (
        (0x22d0,0x997a0,0xe5911000,'Intercept common 32-bit usage write'),
        (0x2494,0x996a0,0xe7920104,'Intercept common 32-bit usage read'),
        (0x22f0,0x997e0,0xe1d110b0,'Intercept common 16-bit usage write'),
        (0x24c4,0x996e0,0xe1d000b0,'Intercept common 16-bit usage read'),
        (0x9bd18,0x99820,0xe0820080,'Zero normalized usage cache writes'),
        (0x9bd08,0x99830,0xe1d000b0,'Zero normalized usage cache reads')):
        assert struct.unpack_from('<I',code,off)[0]==expected,(hex(off),code[off:off+4].hex())
        replace(off,branch(off,target),reason)
    # Raw chip usage access keeps identity selection and native field I/O.
    for off in (0xabe94,0xac198,0xac744):
        word(off,0xe1dd00b0,0xe3a00000,'Chip usage read reports zero after original field read')
    for off in (0xac128,0xac1ac):word(off,0xe1a04001,0xe3a04000,'Write zero into both original copies of this chip usage field')
    word(0x9c9b8,0xe1dd10b8,0xe3a01000,'Reconciliation pending usage snapshot is zero')
    # Volatile pulse accumulator: zero any existing count on a positive add/set.
    a=0x9bd90;data=bytes(ks.asm(f'mov r1,#0; str r1,[r3,r0,lsl #2]; bx lr',addr=BASE+a+4)[0])
    replace(a+4,data,'Pulse accumulation normalizes existing total to zero instead of adding')
    replace(0x9bdb0,branch(0x9bdb0,0x9bd90),'Direct pulse-total setter uses the same zero-normalizing path')
    assert struct.unpack_from('<I',code,0x9bdc0)[0]==0xe7920100
    replace(0x9bdc0,branch(0x9bdc0,0x99840),'Pulse total read normalizes actual RAM to zero')
    word(0xf6378,0xe5d00000,0xe3a00064,'Normal numeric ink remaining report is 100 percent; error dispatch unchanged')
    word(0xf54e4,0xe5d33001,0xe3a03064,'Canonical ink remaining event stores 100; adjacent state/branding events unchanged')
    # Check each inherited Stage 1 edit survived exactly.
    for p in s1['patches']:
        off=int(p['offset'],16);assert code[off:off+4]==baseline[off:off+4]
    allowed={i for p in patches for i in range(int(p['offset'],16),int(p['offset'],16)+len(bytes.fromhex(p['after'])))}
    diffs=[i for i,(a,b) in enumerate(zip(baseline,code)) if a!=b];assert set(diffs)<=allowed
    manifest={'label':'P704-Stage2-all-ink-zero','base':'KH03P9.FY19','stage1_user_report':'User reported Stage 1 passed on device',
        'module_base':hex(BASE),'stage1_module_sha256':sha(baseline),'patched_module_sha256':sha(code),
        'slot_count':10,'ink_usage_ids_by_slot':[hex(x) for x in ids],
        'secondary_usage_ids':[hex(x) for x in (0x1004,0x1005,0x100a,*range(0x1098,0x109f))],
        'patches':patches,'changed_bytes_vs_stage1':len(diffs),'all_stage1_patches_preserved':True,
        'physical_update_tested':False,'physical_boot_tested':False,
        'scope':'Identified ink software accounting, chip usage cache access, normal numeric reporting; no physical ink or authentication claim.'}
    (ROOT/'stage2-module.bin').write_bytes(code);(ROOT/'patches.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return bytes(code),manifest

def package():
    code,m=patch_module();original=(INPUT/'FW4838TL.rcx').read_bytes();sign=original.index(b'EPSONSIGN');body=sign+4096
    start=0x4f0a12e;end=start+4+int.from_bytes(original[start+6:start+10],'big');n=int.from_bytes(original[end+2:end+6],'big');second=original[end:end+n]
    assert original[end+n:]==b'\xff'*(len(original)-end-n)
    encoded,compression=encode(code,original[start:end]);assert compression['padding_tokens']>0 and compression['dma_output_bytes']%48==0
    assert len(encoded)+n<=len(original)-start
    d=bytearray(original);d[start:]=encoded+second+b'\xff'*(len(original)-start-len(encoded)-n)
    sec=0x4ef712e;meta=struct.unpack_from('<I',d,sec+28)[0];length=struct.unpack_from('<I',d,sec+64)[0];begin=sec+4096+meta
    struct.pack_into('<H',d,sec+54,sum(d[begin:begin+length])&65535)
    d[sec+68:sec+88]=hashlib.sha1(d[begin:begin+length]+hashlib.sha1(d[sec:sec+14]).digest()).digest()
    actual=len(d)-body;struct.pack_into('<I',d,sign+16,actual+1)
    previous=0
    for lo,hi in ((sign+16,sign+20),(sec+54,sec+56),(sec+68,sec+88),(start,len(d))):
        assert d[previous:lo]==original[previous:lo];previous=hi
    assert len(d)==len(original) and d[sign+32:sign+96]==original[sign+32:sign+96] and d[0xb13e:0xb17e]==original[0xb13e:0xb17e]
    file=ROOT/'FW4838TL_KH03P9-P704-Stage2-all-ink-zero.efu'
    with zipfile.ZipFile(INPUT/'FW4838TL.efu') as z:info=z.getinfo('FW4838TL.rcx')
    with zipfile.ZipFile(file,'w') as z:z.writestr(info,d)
    with zipfile.ZipFile(file) as z:assert z.testzip() is None;final=z.read('FW4838TL.rcx');assert final==d
    restored,rep=decode(final,start);assert restored==code
    newend=start+len(encoded);assert final[newend:newend+n]==second
    x,_=decode(b'CROM'+second,0);y,_=decode(b'CROM'+final[newend:newend+n],0);assert x==y
    m.update(file=file.name,bytes=file.stat().st_size,sha256=sha(file.read_bytes()),rcx_sha256=sha(final),
        actual_body_bytes=actual,declared_body_bytes=actual+1,compression=compression,sections=sections(final),
        final_crc_ok=True,final_module_exact=True,second_frame_identical=True,second_frame_new_offset=hex(newend),public_key_and_signature_preserved=True,unexpected_changes=False)
    (ROOT/'validation.json').write_text(json.dumps(m,indent=2)+'\n');(ROOT/(file.name+'.sha256')).write_text(m['sha256']+'  '+file.name+'\n')
    print(file.name,m['sha256'],flush=True)

if __name__=='__main__':package()
