/* User-operated Windows x64 cyan-only USB print experiment.
 * Default/--inspect performs identification only. --send-cyan writes exactly
 * one embedded 622-byte print candidate; no arbitrary file/command input.
 * No firmware, cleaning, registry, queue or driver configuration writes. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winioctl.h>
#include <setupapi.h>
#include <usbprint.h>
#include <cfgmgr32.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <wctype.h>
#include "native_cyan_packet.h"

static const GUID printer_interface = {0x28d78fad,0x5a12,0x11d1,{0xae,0x5b,0,0,0xf8,3,0xa8,0xc2}};

static int target_path(const wchar_t *path) {
    size_t length = wcslen(path);
    if (length > 32767) return 0;
    wchar_t *lower = calloc(length + 1, sizeof(wchar_t));
    if (!lower) return 0;
    for (size_t i = 0; i < length; ++i) lower[i] = towlower(path[i]);
    const wchar_t *hit = wcsstr(lower, L"vid_04b8&pid_1334&mi_00");
    int match = hit && (hit[23] == L'#' || hit[23] == 0);
    free(lower); return match;
}
static int field_equals(const unsigned char *data, size_t size, const char *key, const char *value) {
    size_t k = strlen(key), v = strlen(value);
    for (size_t i = 0; i + k + v <= size; ++i) {
        if (i != 0 && i != 2 && data[i - 1] != ';') continue;
        if (memcmp(data + i, key, k) || memcmp(data + i + k, value, v)) continue;
        if (i + k + v == size || data[i + k + v] == ';') return 1;
    }
    return 0;
}
static int target_identity(const unsigned char *data, size_t size) {
    return field_equals(data, size, "MFG:", "EPSON") &&
        (field_equals(data, size, "MDL:", "SC-P5300 Series") ||
         field_equals(data, size, "MDL:", "SC-P5340") ||
         field_equals(data, size, "MDL:", "SC-P5340 Series"));
}

typedef struct {
    int path_ok, model_ok, service_ok, node_started, model_conflict;
    ULONG devnode_status, problem, cm_result;
    wchar_t name[512], description[512];
} PnpEvidence;

static int allowed_pnp_name(const wchar_t *name) {
    static const wchar_t *names[] = {
        L"EPSON SC-P5300 Series", L"SC-P5300 Series", L"EPSON SC-P5340",
        L"SC-P5340", L"EPSON SC-P5340 Series", L"SC-P5340 Series"
    };
    for (size_t i = 0; i < sizeof(names) / sizeof(names[0]); ++i)
        if (!_wcsicmp(name, names[i])) return 1;
    return 0;
}
static int conflicting_pnp_name(const wchar_t *name) {
    if (allowed_pnp_name(name)) return 0;
    for (const wchar_t *p = name; *p; ++p)
        if (!_wcsnicmp(p, L"SC-P", 4)) return 1;
    return 0;
}
static void read_pnp(HDEVINFO devices, SP_DEVINFO_DATA *info,
                     const wchar_t *path, PnpEvidence *out) {
    memset(out, 0, sizeof(*out));
    wchar_t service[256] = {0};
    out->path_ok = target_path(path);
    SetupDiGetDeviceRegistryPropertyW(devices, info, SPDRP_FRIENDLYNAME, NULL,
                                     (BYTE *)out->name, sizeof(out->name), NULL);
    SetupDiGetDeviceRegistryPropertyW(devices, info, SPDRP_DEVICEDESC, NULL,
                                     (BYTE *)out->description, sizeof(out->description), NULL);
    SetupDiGetDeviceRegistryPropertyW(devices, info, SPDRP_SERVICE, NULL,
                                     (BYTE *)service, sizeof(service), NULL);
    out->name[511] = out->description[511] = service[255] = 0;
    out->model_ok = allowed_pnp_name(out->name) || allowed_pnp_name(out->description);
    out->model_conflict = conflicting_pnp_name(out->name) || conflicting_pnp_name(out->description);
    out->service_ok = !_wcsicmp(service, L"usbprint");
    out->cm_result = CM_Get_DevNode_Status(&out->devnode_status, &out->problem, info->DevInst, 0);
    out->node_started = out->cm_result == CR_SUCCESS &&
                        (out->devnode_status & DN_STARTED) && !out->problem &&
                        !(out->devnode_status & DN_HAS_PROBLEM);
}
static int evidence_allowed(DWORD wire_error, int wire_model_ok, const PnpEvidence *pnp) {
    if (!pnp->path_ok || !pnp->service_ok || !pnp->node_started || pnp->model_conflict) return 0;
    if (!wire_error) return wire_model_ok; /* A successful mismatching ID is never overridden. */
    /* Only the observed USBPRINT CRC failure has this independent fallback. */
    return wire_error == ERROR_CRC && pnp->model_ok;
}
static void wide_hex(const wchar_t *text) {
    const unsigned char *bytes = (const unsigned char *)text;
    for (size_t i = 0; i < wcslen(text) * sizeof(wchar_t); ++i) printf("%02x", bytes[i]);
}
static void report_check(const char *stage, DWORD wire_error, int wire_model_ok,
                         const PnpEvidence *pnp, int allowed) {
    const char *method = !allowed ? "none" : (!wire_error ? "ieee1284" : "pnp_crc_fallback");
    printf("{\"event\":\"target_check\",\"revision\":2,\"stage\":\"%s\",\"vid\":\"04b8\",\"pid\":\"1334\",\"interface\":\"00\","
           "\"identity_error\":%lu,\"wire_model_allowed\":%s,\"pnp_model_allowed\":%s,\"pnp_service_usbprint\":%s,"
           "\"node_started\":%s,\"cm_result\":%lu,\"problem_code\":%lu,\"model_conflict\":%s,\"model_allowed\":%s,\"verification_method\":\"%s\",\"pnp_name_utf16\":\"",
           stage, wire_error, wire_model_ok ? "true" : "false", pnp->model_ok ? "true" : "false",
           pnp->service_ok ? "true" : "false", pnp->node_started ? "true" : "false",
           pnp->cm_result, pnp->problem, pnp->model_conflict ? "true" : "false", allowed ? "true" : "false", method);
    wide_hex(pnp->name); printf("\",\"pnp_description_utf16\":\""); wide_hex(pnp->description); puts("\"}");
}
static int refresh_pnp(const wchar_t *path, PnpEvidence *evidence) {
    int found = 0;
    HDEVINFO devices = SetupDiGetClassDevsW(&printer_interface, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
    if (devices == INVALID_HANDLE_VALUE) return 0;
    for (DWORD index = 0; index < 256; ++index) {
        SP_DEVICE_INTERFACE_DATA iface = {0}; iface.cbSize = sizeof(iface);
        if (!SetupDiEnumDeviceInterfaces(devices, NULL, &printer_interface, index, &iface)) break;
        DWORD needed = 0;
        SetupDiGetDeviceInterfaceDetailW(devices, &iface, NULL, 0, &needed, NULL);
        if (needed < sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA_W) || needed > 65536) continue;
        PSP_DEVICE_INTERFACE_DETAIL_DATA_W detail = calloc(1, needed);
        if (!detail) break;
        detail->cbSize = sizeof(*detail);
        SP_DEVINFO_DATA info = {0}; info.cbSize = sizeof(info);
        if (SetupDiGetDeviceInterfaceDetailW(devices, &iface, detail, needed, NULL, &info) &&
            !_wcsicmp(detail->DevicePath, path)) {
            read_pnp(devices, &info, path, evidence); found = 1;
        }
        free(detail);
        if (found) break;
    }
    SetupDiDestroyDeviceInfoList(devices); return found;
}

static DWORD identity(HANDLE device, unsigned char *data, DWORD capacity, DWORD *received) {
    OVERLAPPED operation = {0};
    operation.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (!operation.hEvent) return GetLastError();
    BOOL ok = DeviceIoControl(device, IOCTL_USBPRINT_GET_1284_ID, NULL, 0,
                              data, capacity, received, &operation);
    DWORD error = ok ? 0 : GetLastError();
    if (!ok && error == ERROR_IO_PENDING) {
        if (WaitForSingleObject(operation.hEvent, 3000) == WAIT_OBJECT_0)
            error = GetOverlappedResult(device, &operation, received, FALSE) ? 0 : GetLastError();
        else {
            CancelIoEx(device, &operation);
            GetOverlappedResult(device, &operation, received, TRUE);
            error = ERROR_TIMEOUT;
        }
    }
    CloseHandle(operation.hEvent); return error;
}
static int self_test(void) {
    static const unsigned char good[] = "xxMFG:EPSON;MDL:SC-P5300 Series;";
    static const unsigned char wrong[] = "xxMFG:EPSON;MDL:SC-P5000 Series;";
    static const unsigned char prefix[] = "xxMFG:EPSON;MDL:SC-P5300 SeriesX;";
    static const unsigned char spoof[] = "xxXMFG:EPSON;MDL:SC-P5300 Series;";
    static const unsigned char header[] = {
        0x1b,0x40,0x1b,0x28,0x47,0x01,0,0x01,
        0x1b,0x28,0x44,0x04,0,0x80,0x16,0x08,0x08,
        0x1b,0x28,0x76,0x02,0,0x40,0,0x0d,
        0x1b,0x28,0x24,0x04,0,0x0c,0,0,0,
        0x1b,0x69,0x02,0,0x01,0x24,0,0x10,0
    };
    if (sizeof(cyan_packet) != 622 || sizeof(header) != 43 ||
        memcmp(cyan_packet, header, sizeof(header)) ||
        memcmp(cyan_packet + 619, "\x0c\x1b@", 3)) return 1;
    for (size_t row = 0; row < 16; ++row)
        for (size_t col = 0; col < 36; ++col)
            if (cyan_packet[43 + row * 36 + col] != (row % 2 ? 0x55 : 0xaa)) return 1;
    if (!target_identity(good, sizeof(good) - 1) ||
        target_identity(wrong, sizeof(wrong) - 1) ||
        target_identity(prefix, sizeof(prefix) - 1) || target_identity(spoof, sizeof(spoof) - 1)) return 1;
    if (!target_path(L"usb#VID_04B8&PID_1334&MI_00#test") ||
         target_path(L"usb#vid_04b8&pid_008c#test") ||
         target_path(L"usb#vid_04b8&pid_1334&mi_01#test") ||
         target_path(L"usb#vid_04b8&pid_1334&mi_000#test")) return 1;
    PnpEvidence e = {0};
    e.path_ok = e.model_ok = e.service_ok = e.node_started = 1;
    if (!allowed_pnp_name(L"EPSON SC-P5300 Series") || allowed_pnp_name(L"EPSON SC-P5000 Series") ||
        allowed_pnp_name(L"EPSON SC-P5300 SeriesX") || !conflicting_pnp_name(L"EPSON SC-P5000 Series") ||
        conflicting_pnp_name(L"USB Printing Support")) return 1;
    if (!evidence_allowed(0, 1, &e) || !evidence_allowed(ERROR_CRC, 0, &e) ||
        evidence_allowed(0, 0, &e) || evidence_allowed(ERROR_ACCESS_DENIED, 0, &e) ||
        evidence_allowed(ERROR_TIMEOUT, 0, &e)) return 1;
    e.model_ok = 0;
    if (evidence_allowed(ERROR_CRC, 0, &e)) return 1;
    e.model_ok = 1; e.node_started = 0;
    if (evidence_allowed(ERROR_CRC, 0, &e)) return 1;
    e.node_started = 1; e.service_ok = 0;
    if (evidence_allowed(ERROR_CRC, 0, &e)) return 1;
    e.service_ok = 1; e.model_conflict = 1;
    if (evidence_allowed(ERROR_CRC, 0, &e) || evidence_allowed(0, 1, &e)) return 1;
    e.model_conflict = 0; e.path_ok = 0;
    if (evidence_allowed(ERROR_CRC, 0, &e)) return 1;
    puts("{\"event\":\"self_test\",\"revision\":2,\"passed\":true,\"hardware_tested\":false}"); return 0;
}
static int send_once(const wchar_t *path) {
    HANDLE device = CreateFileW(path, GENERIC_READ | GENERIC_WRITE, 0, NULL,
                               OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
    if (device == INVALID_HANDLE_VALUE) {
        printf("{\"event\":\"error\",\"stage\":\"exclusive_open\",\"code\":%lu}\n", GetLastError()); return 1;
    }
    PnpEvidence pnp;
    if (!refresh_pnp(path, &pnp)) {
        puts("{\"event\":\"error\",\"stage\":\"refresh_pnp_before_write\",\"data_written\":false}");
        CloseHandle(device); return 1;
    }
    unsigned char data[8192] = {0}; DWORD received = 0;
    DWORD error = identity(device, data, sizeof(data), &received);
    if (received > sizeof(data)) error = ERROR_INVALID_DATA;
    int wire_ok = !error && target_identity(data, received);
    int allowed = evidence_allowed(error, wire_ok, &pnp);
    report_check("exclusive_recheck", error, wire_ok, &pnp, allowed);
    if (!allowed) {
        printf("{\"event\":\"error\",\"stage\":\"recheck_identity\",\"code\":%lu}\n", error);
        CloseHandle(device); return 1;
    }
    OVERLAPPED operation = {0}; DWORD written = 0;
    operation.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (!operation.hEvent) { CloseHandle(device); return 1; }
    printf("{\"event\":\"print_attempt\",\"ink\":\"C\",\"bytes\":%zu,\"packet_sha256\":\"%s\",\"attempt\":1}\n", sizeof(cyan_packet), packet_sha256);
    BOOL ok = WriteFile(device, cyan_packet, (DWORD)sizeof(cyan_packet), &written, &operation);
    error = ok ? 0 : GetLastError();
    if (!ok && error == ERROR_IO_PENDING) {
        if (WaitForSingleObject(operation.hEvent, 3000) == WAIT_OBJECT_0)
            error = GetOverlappedResult(device, &operation, &written, FALSE) ? 0 : GetLastError();
        else {
            CancelIoEx(device, &operation);
            GetOverlappedResult(device, &operation, &written, TRUE);
            error = ERROR_TIMEOUT;
        }
    }
    CloseHandle(operation.hEvent); CloseHandle(device);
    int accepted = !error && written == sizeof(cyan_packet);
    printf("{\"event\":\"write_result\",\"bytes\":%lu,\"error\":%lu,\"transport_accepted\":%s,\"physical_print_verified\":false,\"automatic_retry\":false}\n",
           written, error, accepted ? "true" : "false");
    return accepted ? 0 : 1;
}
int wmain(int argc, wchar_t **argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    setvbuf(stdout, NULL, _IONBF, 0);
    if (sizeof(void *) != 8 || IOCTL_USBPRINT_GET_1284_ID != 0x220034) return 2;
    if (argc == 2 && !wcscmp(argv[1], L"--self-test")) return self_test();
    if (argc == 2 && !wcscmp(argv[1], L"--packet")) {
        for (size_t i = 0; i < sizeof(cyan_packet); ++i) printf("%02x", cyan_packet[i]);
        putchar('\n'); return 0;
    }
    int sending = argc == 2 && !wcscmp(argv[1], L"--send-cyan");
    if (argc != 1 && !sending && !(argc == 2 && !wcscmp(argv[1], L"--inspect"))) return 2;
    if (self_test()) return 2;
    HDEVINFO devices = SetupDiGetClassDevsW(&printer_interface, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
    if (devices == INVALID_HANDLE_VALUE) {
        printf("{\"event\":\"error\",\"stage\":\"enumeration\",\"code\":%lu}\n", GetLastError()); return 1;
    }
    unsigned matches = 0; int complete = 1; wchar_t *selected = NULL;
    for (DWORD index = 0; index < 256; ++index) {
        SP_DEVICE_INTERFACE_DATA iface = {0}; iface.cbSize = sizeof(iface);
        if (!SetupDiEnumDeviceInterfaces(devices, NULL, &printer_interface, index, &iface)) {
            if (GetLastError() != ERROR_NO_MORE_ITEMS) complete = 0;
            break;
        }
        DWORD needed = 0;
        SetupDiGetDeviceInterfaceDetailW(devices, &iface, NULL, 0, &needed, NULL);
        if (needed < sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA_W) || needed > 65536) { complete = 0; continue; }
        PSP_DEVICE_INTERFACE_DETAIL_DATA_W detail = calloc(1, needed);
        if (!detail) { complete = 0; break; }
        detail->cbSize = sizeof(*detail);
        SP_DEVINFO_DATA info = {0}; info.cbSize = sizeof(info);
        if (!SetupDiGetDeviceInterfaceDetailW(devices, &iface, detail, needed, NULL, &info)) {
            free(detail); complete = 0; continue;
        }
        if (target_path(detail->DevicePath)) {
            unsigned char data[8192] = {0}; DWORD size = 0;
            HANDLE device = CreateFileW(detail->DevicePath, 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                       NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
            if (device == INVALID_HANDLE_VALUE)
                device = CreateFileW(detail->DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                    NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
            DWORD error = device == INVALID_HANDLE_VALUE ? GetLastError() : identity(device, data, sizeof(data), &size);
            if (device != INVALID_HANDLE_VALUE) CloseHandle(device);
            if (size > sizeof(data)) error = ERROR_INVALID_DATA;
            PnpEvidence pnp;
            read_pnp(devices, &info, detail->DevicePath, &pnp);
            int wire_ok = !error && target_identity(data, size);
            int valid = evidence_allowed(error, wire_ok, &pnp);
            report_check("enumeration", error, wire_ok, &pnp, valid);
            if (!valid) complete = 0;
            else {
                ++matches;
                if (matches == 1) {
                    size_t length = (wcslen(detail->DevicePath) + 1) * sizeof(wchar_t);
                    selected = malloc(length);
                    if (selected) memcpy(selected, detail->DevicePath, length);
                }
            }
        }
        free(detail);
        if (index == 255) complete = 0;
    }
    SetupDiDestroyDeviceInfoList(devices);
    printf("{\"event\":\"selection\",\"matching_targets\":%u,\"complete\":%s,\"send_requested\":%s}\n", matches, complete ? "true" : "false", sending ? "true" : "false");
    int result = 1;
    if (complete && matches == 1 && selected) result = sending ? send_once(selected) : 0;
    else puts("{\"event\":\"refused\",\"reason\":\"exactly_one_verified_target_required\",\"data_written\":false}");
    free(selected); return result;
}
