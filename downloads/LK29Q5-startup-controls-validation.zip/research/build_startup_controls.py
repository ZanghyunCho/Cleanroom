"""Make two controlled EFUs to distinguish envelope/codec from code changes.
A changes only EPSONSIGN length. B re-encodes the original unmodified control
module. Neither implements virtual maintenance-box behavior. No device is used.
"""
from pathlib import Path
import hashlib,json,struct,zipfile
from decode_crom import decode
from encode_crom import encode
from probe_efu_envelope import verify_signature
from audit_recovery_failure import loader_audit,checksum_audit
ROOT=Path(__file__).resolve().parents[1]
ORIGINAL_RCX='5a8c9ff4c942e436e7ab9da60237dd7d60587715071d748a58c90fe20ca557b1'
ORIGINAL_CONTROL='82c4c34f4ed5c1dd7118dd74839b499329d732d37b467df734ed5382a25dedac'
def sha(data):return hashlib.sha256(data).hexdigest()

def main():
 rcx=(ROOT/'FW7560TL.rcx').read_bytes();assert sha(rcx)==ORIGINAL_RCX
 control=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes();assert sha(control)==ORIGINAL_CONTROL
 sign=rcx.index(b'EPSONSIGN');body=sign+4096;actual=len(rcx)-body
 assert struct.unpack_from('<I',rcx,sign+16)[0]==actual
 start,next_container=0x14153,0x21b553
 frame_end=start+4+int.from_bytes(rcx[start+6:start+10],'big')
 frame1_size=int.from_bytes(rcx[frame_end+2:frame_end+6],'big')
 frame1=rcx[frame_end:frame_end+frame1_size]
 assert frame1[:2]==b'\xff\xd8'
 assert rcx[frame_end+frame1_size:next_container]==b'\xff'*(next_container-frame_end-frame1_size)
 restored,_=decode(rcx,start);assert restored==control
 out=ROOT/'experimental/startup-controls';out.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(ROOT/'FW7560TL_LK29Q5.efu') as z:info=z.getinfo('FW7560TL.rcx')
 images=[]
 for label in ('A-envelope-only','B-original-code-reencoded'):
  changed=bytearray(rcx);struct.pack_into('<I',changed,sign+16,actual+1)
  compression=None;new_frame_end=frame_end
  if label.startswith('B'):
   encoded,compression=encode(control,rcx[start:frame_end])
   replacement=encoded+frame1
   assert len(replacement)<=next_container-start
   changed[start:next_container]=replacement+b'\xff'*(next_container-start-len(replacement))
   new_frame_end=start+len(encoded)
   meta=struct.unpack_from('<I',changed,body+28)[0]
   length=struct.unpack_from('<I',changed,body+64)[0]
   begin=body+4096+meta;end=begin+length
   struct.pack_into('<H',changed,body+54,sum(changed[begin:end])&65535)
   changed[body+68:body+88]=hashlib.sha1(changed[begin:end]+hashlib.sha1(changed[body:body+14]).digest()).digest()
  decoded,_=decode(changed,start);assert decoded==control
  assert changed[new_frame_end:new_frame_end+frame1_size]==frame1
  assert changed[0x11153:0x11193]==rcx[0x11153:0x11193]
  assert changed[sign+32:sign+96]==rcx[sign+32:sign+96]
  assert len(changed)==len(rcx)
  if label.startswith('A'):
   assert changed[:sign+16]==rcx[:sign+16] and changed[sign+20:]==rcx[sign+20:]
  else:
   allowed=sorted([(sign+16,sign+20),(body+54,body+56),(body+68,body+88),(start,next_container)])
   prev=0
   for lo,hi in allowed:assert changed[prev:lo]==rcx[prev:lo];prev=hi
   assert changed[prev:]==rcx[prev:]
  # Every section's metadata, sum and SHA1. No native crypto verdict replacement.
  pos=body;sections=[]
  while pos<len(changed):
   header=changed[pos:pos+4096];assert header.startswith(b'EPSON')
   meta=struct.unpack_from('<I',header,28)[0];length=struct.unpack_from('<I',header,64)[0]
   begin=pos+4096+meta;end=begin+length;assert end<=len(changed)
   assert sum(changed[pos+4096:begin])&65535==struct.unpack_from('<H',header,18)[0]
   assert sum(changed[begin:end])&65535==struct.unpack_from('<H',header,54)[0]
   assert hashlib.sha1(changed[begin:end]+hashlib.sha1(header[:14]).digest()).digest()==header[68:88]
   sections.append({'offset':hex(pos),'metadata_bytes':meta,'payload_bytes':length});pos=end
  assert pos==len(changed) and len(sections)==4
  signature=verify_signature(bytes(changed[0x11153:0x11193]),bytes(changed[sign+32:sign+96]),hashlib.sha256(memoryview(changed)[body:]).digest())
  assert signature['status']==('valid' if label.startswith('A') else 'invalid')
  file=out/f'FW7560TL_LK29Q5-startup-{label}.efu'
  with zipfile.ZipFile(file,'w') as z:z.writestr(info,changed)
  with zipfile.ZipFile(file) as z:assert z.testzip() is None and z.read('FW7560TL.rcx')==changed
  manifest={'label':label,'filename':file.name,'efu_sha256':sha(file.read_bytes()),'bytes':file.stat().st_size,
    'original_rcx_sha256':ORIGINAL_RCX,'rcx_sha256':sha(changed),'decoded_control_sha256':sha(decoded),
    'decoded_control_byte_differences':0,'maintenance_behavior':'Unmodified original behavior; no 100-percent/absent-box patches',
    'actual_signed_body_bytes':actual,'declared_signed_body_bytes':actual+1,
    'body_identical_to_official':changed[body:]==rcx[body:],'original_epson_key_and_signature_bytes_preserved':True,
    'ordinary_body_signature':signature,'compression':compression,'second_frame_bytes_preserved':True,
    'second_frame_original_offset':hex(frame_end),'second_frame_new_offset':hex(new_frame_end),
    'second_frame_relocation_bytes':new_frame_end-frame_end,'all_four_host_section_checks_passed':True,'sections':sections,
    'hardware_startup_tested':False,'purpose':'Isolate startup hang, not a functional fix'}
  main=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
  routine=main[0x4419e2e0-0x4409b000:0x4419e324-0x4409b000]
  manifest['native_payload_checksum']=checksum_audit(label,bytes(changed),routine)
  assert manifest['native_payload_checksum']['native_checksum_return']==1
  if label.startswith('B'):
   manifest['native_loader']=loader_audit(label,bytes(changed[start:new_frame_end]),rcx[0x25bb23:0x25bb23+0xae8],control)
   assert manifest['native_loader']['native_lz_output_exact'] and manifest['native_loader']['native_dma_mod48']==0
  (out/(file.name+'.sha256')).write_text(manifest['efu_sha256']+'  '+file.name+'\n')
  (out/(label+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
  images.append(manifest);print(label,manifest['efu_sha256'],'original body',manifest['body_identical_to_official'],'original decoded code',manifest['decoded_control_byte_differences'],flush=True)
 (ROOT/'validation/startup-control-build-results.json').write_text(json.dumps({'controls':images,
 'reported_v3_behavior':'Maintenance box installed; initialization screen persists; UI touches and ink-door prompt react; no observed motor/pump movement or sound',
 'official_post_v3_normal_boot_user_confirmed':True,
 'not_proven':['A or B physical boot','Hardware Huffman correctness','Drive-control task/module liveness','Boot-time authentication or checksum acceptance',
 'Maintenance logic as actual cause of hang'],'huffman_in_loader_audit':'Completion boundary modeled, actual hardware not executed'},indent=2)+'\n')
if __name__=='__main__':main()
