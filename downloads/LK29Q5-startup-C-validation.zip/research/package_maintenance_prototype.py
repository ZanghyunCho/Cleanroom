"""Package the ARM-tested module as an explicitly experimental EFU copy.

This does not flash a device or establish updater acceptance or successful boot.
The original Epson key and the original receiver module remain unchanged.
"""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import zipfile
from decode_crom import decode
from encode_crom import encode
from probe_efu_envelope import verify_signature

ROOT = Path(__file__).resolve().parents[1]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def check_modified_signature(rcx, sign_offset):
    body_offset = sign_offset + 4096
    result = verify_signature(bytes(rcx[0x11153:0x11193]),
                              bytes(rcx[sign_offset + 32:sign_offset + 96]),
                              hashlib.sha256(memoryview(rcx)[body_offset:]).digest())
    if result['status'] != 'invalid':
        raise ValueError('Expected changed body to fail ordinary ECDSA verification')
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--variant', choices=('v2', 'v3', 'c-report'), default='v2')
    variant = parser.parse_args().variant
    rcx = (ROOT / 'FW7560TL.rcx').read_bytes()
    if sha(rcx) != '5a8c9ff4c942e436e7ab9da60237dd7d60587715071d748a58c90fe20ca557b1':
        raise ValueError('Unexpected original RCX')
    if variant == 'v2':
        prototype_path = ROOT / 'experimental/maintenance-control.prototype.bin'
        tests = json.loads((ROOT / 'validation/maintenance-prototype-native-results.json').read_text())
        test_hash, test_count = tests['prototype_sha256'], tests['executed_scenarios']
        required_count = 80
    elif variant == 'v3':
        prototype_path = ROOT / 'experimental/maintenance-control.diagnostic-v3.bin'
        tests = json.loads((ROOT / 'validation/maintenance-v3-native-results.json').read_text())
        test_hash, test_count = tests['module_sha256'], tests['scenario_count']
        required_count = 74
        if len(tests['flow_cases']) != 24 or tests['maintenance_verdict_hooks'] != 0:
            raise ValueError('Expected v3 subsystem flow checks without verdict hooks')
    else:
        prototype_path = ROOT / 'experimental/maintenance-control.report-C.bin'
        tests = json.loads((ROOT / 'validation/remaining-report-C-native-results.json').read_text())
        test_hash, test_count = tests['module_sha256'], tests['scenario_count']
        required_count = 87
        if tests['maintenance_verdict_hooks'] != 0:
            raise ValueError('Expected C checks without maintenance verdict hooks')
    prototype = prototype_path.read_bytes()
    if test_hash != sha(prototype) or test_count != required_count:
        raise ValueError('Matching completed ARM prototype tests required')
    start, next_container = 0x14153, 0x21b553
    frame0_end = start + 4 + int.from_bytes(rcx[start + 6:start + 10], 'big')
    if rcx[frame0_end:frame0_end + 2] != b'\xff\xd8':
        raise ValueError('Original second CROM frame missing')
    frame1_size = int.from_bytes(rcx[frame0_end + 2:frame0_end + 6], 'big')
    original_end = frame0_end + frame1_size
    frame1 = rcx[frame0_end:original_end]
    padding = rcx[original_end:next_container]
    if padding != b'\xff' * len(padding):
        raise ValueError('CROM growth would overwrite non-padding data')
    encoded, compression = encode(prototype, rcx[start:frame0_end], positive_padding=(variant == 'c-report'))
    replacement = encoded + frame1
    if len(replacement) > next_container - start:
        raise ValueError('Recompressed prototype exceeds original container allocation')
    modified = bytearray(rcx)
    modified[start:next_container] = replacement + b'\xff' * (next_container - start - len(replacement))
    restored, _ = decode(modified, start)
    if restored != prototype:
        raise ValueError('Embedded control module differs from tested prototype')
    relocated_frame1 = start + len(encoded)
    if modified[relocated_frame1:relocated_frame1 + frame1_size] != frame1:
        raise ValueError('Second CROM frame changed')
    sign_offset = rcx.index(b'EPSONSIGN')
    body_offset = sign_offset + 4096
    section_header = bytes(modified[body_offset:body_offset + 4096])
    metadata_size = struct.unpack_from('<I', section_header, 28)[0]
    payload_size = struct.unpack_from('<I', section_header, 64)[0]
    metadata_start = body_offset + 4096
    payload_start = metadata_start + metadata_size
    payload_end = payload_start + payload_size
    old_metadata = rcx[metadata_start:payload_start]
    if old_metadata != modified[metadata_start:payload_start]:
        raise ValueError('Unexpected section metadata change')
    if sum(old_metadata) & 0xffff != struct.unpack_from('<H', section_header, 18)[0]:
        raise ValueError('Original metadata checksum mismatch')
    header_hash = hashlib.sha1(section_header[:14]).digest()
    original_inner = hashlib.sha1(rcx[payload_start:payload_end] + header_hash).digest()
    if original_inner != section_header[68:88]:
        raise ValueError('Original section SHA1 hypothesis does not validate')
    original_payload_sum = sum(rcx[payload_start:payload_end]) & 0xffff
    if original_payload_sum != struct.unpack_from('<H', section_header, 54)[0]:
        raise ValueError('Original payload sum mismatch')
    new_payload_sum = sum(modified[payload_start:payload_end]) & 0xffff
    struct.pack_into('<H', modified, body_offset + 54, new_payload_sum)
    new_inner = hashlib.sha1(modified[payload_start:payload_end] + header_hash).digest()
    modified[body_offset + 68:body_offset + 88] = new_inner
    actual_body_size = len(modified) - body_offset
    original_declared = struct.unpack_from('<I', rcx, sign_offset + 16)[0]
    if original_declared != actual_body_size:
        raise ValueError('Original envelope length does not match actual body')
    struct.pack_into('<I', modified, sign_offset + 16, actual_body_size + 1)
    if modified[sign_offset + 32:sign_offset + 96] != rcx[sign_offset + 32:sign_offset + 96]:
        raise ValueError('Original Epson signature bytes changed')
    if modified[0x11153:0x11193] != rcx[0x11153:0x11193]:
        raise ValueError('Original Epson public key changed')
    # Verify the original latest receiver module is byte-identical after packaging.
    latest, _ = decode(modified, 0x27ad53)
    if sha(latest) != 'a58dc0eb44390e524fd6debda23cfa5eb952c28a843b1db1cc39f75efa956726':
        raise ValueError('Original receiver module changed')
    allowed = [(start, next_container), (body_offset + 54, body_offset + 56),
               (body_offset + 68, body_offset + 88),
               (sign_offset + 16, sign_offset + 20)]
    previous = 0
    for low, high in sorted(allowed):
        if modified[previous:low] != rcx[previous:low]:
            raise ValueError('Unexpected modification outside declared ranges')
        previous = high
    if modified[previous:] != rcx[previous:] or len(modified) != len(rcx):
        raise ValueError('RCX size or unaffected suffix changed')
    signature_check = check_modified_signature(modified, sign_offset)
    # Preserve the failed, distributed artifact for diagnosis. Never silently
    # overwrite its filename or manifest with a corrected diagnostic build.
    output = ROOT / (
        'experimental/FW7560TL_LK29Q5-startup-C-remaining-report-only.efu' if variant == 'c-report'
        else f'experimental/FW7560TL_LK29Q5-maintenance-diagnostic-{variant}.efu')
    with zipfile.ZipFile(ROOT / 'FW7560TL_LK29Q5.efu') as original_archive:
        info = original_archive.getinfo('FW7560TL.rcx')
    with zipfile.ZipFile(output, 'w') as archive:
        archive.writestr(info, modified)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError('Packaged EFU CRC failure')
        reloaded = archive.read('FW7560TL.rcx')
        if sha(reloaded) != sha(modified):
            raise ValueError('Packaged RCX mismatch')
    report = {
        'artifact': output.name, 'status': 'experimental; not hardware/updater validated',
        'efu_sha256': sha(output.read_bytes()), 'rcx_sha256': sha(modified),
        'original_rcx_sha256': sha(rcx), 'rcx_size': len(modified),
        'prototype_module_sha256': sha(prototype), 'arm_prototype_scenarios': test_count,
        'variant': variant,
        'compression': compression, 'second_crom_frame_preserved': True,
        'original_metadata_sum': sum(old_metadata) & 0xffff,
        'original_payload_sum': original_payload_sum,
        'new_payload_sum': new_payload_sum,
        'declared_payload_sum_matches': True,
        'original_section_sha1': original_inner.hex(), 'new_section_sha1': new_inner.hex(),
        'actual_signed_body_length': actual_body_size,
        'declared_signed_body_length': actual_body_size + 1,
        'original_epson_key_preserved': True,
        'original_signature_bytes_preserved': True,
        'ecdsa_signature_valid_after_modification': False,
        'host_signature_check': signature_check,
        'original_latest_receiver_module_preserved': True,
        'zip_crc_and_roundtrip_passed': True,
        'limitations': ['No physical printer, USB or PC updater validation',
                        'No full startup or reboot test',
                        'No native hardware CROM decompressor validation',
                        'Full packaged EFU has not been run through the ARM receiver',
                        'Existing stored consumption is not erased',
                        'No device flashing performed'],
    }
    (ROOT / f'experimental/maintenance-efu.diagnostic-{variant}.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
