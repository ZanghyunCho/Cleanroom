"""Native D predicate/transition/readiness comparisons; no verdict hooks."""
import json,struct
from build_lifetime_control import build,ROOT
from build_remaining_report_control import build as build_c
from verify_remaining_report_control import verify as base_verify
from probe_maintenance_state import Control
from unicorn import UC_HOOK_CODE

def setup(code,count=0,state_value=0):
 n=Control(code);state=n.literal(0x43408000,0xc4);n.u.mem_write(state,bytes([state_value]));n.u.mem_write(state+8,b'\x64')
 n.u.mem_write(n.literal(0x43408368,-0x2b4),b'\x20')
 n.u.mem_write(n.literal(0x433f6378,0x27c),bytes(8))
 n.u.mem_write(n.literal(0x43406940,0x274),struct.pack('<I',1000000))
 n.u.mem_write(n.literal(0x43406b60,0x5c),struct.pack('<I',900000))
 n.u.mem_write(0x437cfebc,struct.pack('<I',count));return n,state

def main():
 code,manifest=build();c,_=build_c();base=base_verify(code,manifest);assert base['scenario_count']==87
 life=[]
 for profile in (0,1):
  for cached in (0,1):
   for mirror in (0,1):
    observations=[]
    for data in (c,code):
     n,state=setup(data)
     profiles=n.literal(0x4340aca8,-0x474);n.u.mem_write(profiles-0x3c+1,b'\0')
     n.u.mem_write(profiles,struct.pack('<I',0x42002000));n.u.mem_write(0x42002000,bytes([0,0,profile])+bytes(13))
     buf=n.literal(0x43407740,-0x140);snapshot=bytes([255 if mirror else 0])*192;n.u.mem_write(buf,snapshot)
     bindings=n.literal(0x4340ae08,0x1c);flag,size=struct.unpack('<II',n.u.mem_read(bindings+0x46*8,8));assert size==1
     n.u.mem_write(flag,bytes([cached]));result=n.call(0x434059a4)
     assert bytes(n.u.mem_read(buf,192))==snapshot and n.u.mem_read(flag,1)[0]==cached
     observations.append({'return':result,'raw_state':n.call(0x43407f5c),'stored_remaining':n.u.mem_read(state+8,1)[0]})
    old_expected=int(profile==0 and cached==0 and mirror==1)
    assert observations[0]['return']==old_expected
    assert observations[1]=={'return':0,'raw_state':0,'stored_remaining':100}
    life.append({'profile':profile,'cached_record46':cached,'mirror_fieldA':mirror,'C':observations[0],'D':observations[1],'mirror_and_cached_records_unchanged':True})
 counts=(0,899999999,900000000,999999999,1000000000,1000000001,0xffffffff)
 limits=[]
 for count in counts:
  observations=[]
  for data in (c,code):
   n,state=setup(data,count);out=0x42001000;n.u.mem_write(out,b'\xaa')
   result=n.call(0x43406b24,0,out)
   assert n.call(0x43406890)==count
   observations.append({'return':result,'near_flag':n.u.mem_read(out,1)[0]})
  full=count//1000>=1000000
  assert observations[0]['return']==int(full) and observations[1]['return']==0
  assert observations[0]['near_flag']==observations[1]['near_flag']
  limits.append({'count':count,'C':observations[0],'D':observations[1],'counter_unchanged':True})
 readiness=[]
 for state_value in range(8):
  for count in (1000000000,0xffffffff):
   n,state=setup(code,count,state_value);full_handlers=[]
   n.u.hook_add(UC_HOOK_CODE,lambda *args:full_handlers.append(True),begin=0x4341009c,end=0x4341009c)
   result=n.call(0x43410144,0)
   assert result==(1 if state_value in (0,7) else 0)
   assert n.call(0x43407f5c)==state_value and n.call(0x43406890)==count and not full_handlers
   readiness.append({'state':state_value,'count':count,'return':result,'full_handler_calls':0,'counter_and_state_unchanged':True})
 report={'module_sha256':manifest['module_sha256'],'scenario_count':87+len(life)+len(limits)+len(readiness),
 'C_regression_cases':base,'life_bit_cases':life,'limit_cases':limits,'readiness_cases':readiness,
 'maintenance_verdict_hooks':0,'observation_hooks':'Full-handler entry count only; no return or PC modification',
 'limitations':['No full printer startup or real chip transactions','No physical expired-cartridge test','Direct other errors remain, including error 35 from any unmodeled source']}
 assert report['scenario_count']==118
 (ROOT/'validation/lifetime-D-native-results.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS',report['scenario_count'],'native cases; five changed code bytes; counters/profile/state intact')
if __name__=='__main__':main()
