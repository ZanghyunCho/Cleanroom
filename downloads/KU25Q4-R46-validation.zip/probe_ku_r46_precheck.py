import struct,itertools,hashlib,json
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import *
from build_ku_r46 import build,P
from build_ku_r45 import build as build_r45
from verify_ku_stage1 import Machine
from verify_ku_stage2 import seedpair
B=0x44604000
class PrecheckMachine(Machine):
 def __init__(self,code,raw):
  super().__init__(code);self.raw=raw;self.events=[];self.u.hook_add(UC_HOOK_CODE,self.hook)
 def hook(self,u,address,size,user):
  off=address-B;ret=None
  if off==0x20f44:ret=0 # global operating-mode fixture
  elif off==0x2ba84:ret=1 # existing acceptance/selection context fixture
  elif off==0x29754:ret=0 # configured INK slot
  elif off==0x2ad3c:ret=self.raw # raw chip/device state, still interpreted by original consumer
  elif off==0x2122c:ret=0
  elif off==0x32984:ret=10
  elif off==0x2b61c:self.events.append((u.reg_read(UC_ARM_REG_R0),u.reg_read(UC_ARM_REG_R1)));ret=0 # status notification transport
  if ret is not None:u.reg_write(UC_ARM_REG_R0,ret);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
def verify(code):
 baseline,_=build_r45();out=[]
 # Original capacity helpers use their own native scaling (10000 and 1000).
 for mode,raw,request,used in itertools.product(range(5),(0,1,2,12),(1,1000,200000,2000000),(0,150000)):
  results=[]
  for label,data in (('R45',baseline),('R46',code)):
   m=PrecheckMachine(data,raw)
   capacity=m.literal(0x2b494,0x294);alternative=m.literal(0x29e6c,0x454)
   for slot in range(10):
    m.setval(capacity+slot*4,200);m.setval(alternative+slot*4,200)
   low,n=m.descriptor(0x30);high,hn=m.descriptor(0x31);m.write(low,struct.pack("<"+"I"*(n//4),*([used]*(n//4))));m.write(high,bytes(hn))
   req=0x42001000;m.write(req,b''.join(struct.pack('<II',request,0xcc) for _ in range(12))+struct.pack('<I',mode))
   before=m.read(0x44900000,0x100000);ret=m.call(0x190cc,req)
   assert m.read(0x44900000,0x100000)==before
   statuses=[m.read(req+8*s+4,1)[0] for s in range(10)]
   if raw==0:assert statuses==[int(request+(0 if label=='R46' else used)<=(200000 if mode in (2,3) else 2000000))]*10,(mode,raw,request,used,label,statuses)
   if raw==1:assert statuses==[1]*10 and ret==0 # native raw error still causes overall failure
   results.append({'candidate':label,'return':ret,'slot_statuses':statuses,'events':m.events})
  if raw!=0:assert results[0]['return']==results[1]['return'] and results[0]['slot_statuses']==results[1]['slot_statuses']
  out.append({'mode':mode,'raw_state':raw,'requested':request,'stored_used':used,'results':results})
 assert any(x['results'][0]['slot_statuses']!=x['results'][1]['slot_statuses'] for x in out)
 report={'module_sha256':hashlib.sha256(code).hexdigest(),'native_precheck_scenarios_passed':len(out),'fixtures':['global mode and context','INK slot configuration','raw chip state','status notification transport'],'native_capacity_arithmetic_and_comparison_hooks':0,'chip_wire_responses_emulated_as_full':False,'job_name_to_mode_mapping_verified':False,'cases':out}
 (P/'KU25Q4-R46-precheck-results.json').write_text(json.dumps(report,indent=2)+'\n');return report
if __name__=='__main__':print(verify(build()[0])['native_precheck_scenarios_passed'])
