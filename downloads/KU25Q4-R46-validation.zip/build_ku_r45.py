"""R4.5 candidate: R4, two ink lids, EPSON manufacturer and non-Epson report flag."""
import hashlib,struct
from build_ku_r45_cover_prep import build as build_cover
from build_ku_stage1 import P,branch,word,BASE
from build_ku_stage2 import Asm
START=0x2af00;FIELD=0x2d0bc;FLAGGET=0x2b184;FLAGSET=0x2b198

def build():
 base,cover=build_cover();a=Asm(START)
 a.label('manufacturer');a.w(0xe3510002);a.b('field_native',cond=1);literal_index=len(a.words);a.w(0)
 a.w(0xe3a0c000);a.label('loop');a.w(0xe15c0003);a.b('done',cond=2);a.w(0xe3a00000);a.w(0xe35c0005);a.w(0x37d1000c);a.w(0xe7c2000c);a.w(0xe28cc001);a.b('loop');a.label('done');a.w(0xe12fff1e)
 a.label('field_native');a.w(struct.unpack_from('<I',base,FIELD)[0]);a.b(FIELD+4)
 a.label('flagget');a.w(0xe92d4010);a.w(0xe3a01000);a.b(FLAGSET,link=True);a.w(0xe3a00000);a.w(0xe8bd8010)
 a.label('flagset');a.w(0xe3a01000);a.w(struct.unpack_from('<I',base,FLAGSET)[0]);a.b(FLAGSET+4)
 a.label('epson_pointer');a.w(BASE+0x298f8)
 disp=a.labels['epson_pointer']-(START+literal_index*4+8);assert 0<=disp<4096;a.words[literal_index]=word(0xe59f1000|disp)
 helper=a.finish();end=START+len(helper);assert end<=0x2afb8
 for off in range(0,len(base)-4,4):
  w=struct.unpack_from('<I',base,off)[0]
  if w>>25&7==5:
   d=w&0xffffff;d-=1<<24 if d&0x800000 else 0;t=off+8+d*4
   assert not START<=t<end or 0x2ae88<=off<0x2afb8,(hex(off),hex(t))
  assert not BASE+START<=w<BASE+end
 code=bytearray(base);code[START:end]=helper
 for off,label in ((FIELD,'manufacturer'),(FLAGGET,'flagget'),(FLAGSET,'flagset')):code[off:off+4]=branch(off,a.labels[label])
 report={'label':'KU25Q4-R45-identity-cover-candidate','base_cover':cover,'module_sha256':hashlib.sha256(code).hexdigest(),'identity_change_ranges':[[hex(START),hex(end)]]+[[hex(x),hex(x+4)] for x in (FIELD,FLAGGET,FLAGSET)],'manufacturer_field_index':2,'manufacturer':'EPSON','non_Epson_cached_flag_get_set':'zero through native setter','country_SKU_lookup':'Original main-module lookup and NVRAM key 0x261 unchanged; UI/PC propagation remains to be verified','chip_crypto_functions_modified':False,'all_UI_PC_web_paths_verified':False,'hardware_tested':False}
 (P/'KU25Q4-R45-control.bin').write_bytes(code);(P/'KU25Q4-R45-patches.json').write_text(__import__('json').dumps(report,indent=2)+'\n');return bytes(code),report
