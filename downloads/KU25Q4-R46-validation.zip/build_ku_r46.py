"""R4.6: zero the chip-accounted usage query used by native consume prechecks."""
import hashlib
from build_ku_r45 import build as build_r45
from build_ku_stage1 import P,word,BASE
OFFSET=0x29ba0

def build():
 base,_=build_r45();code=bytearray(base)
 assert base[OFFSET:OFFSET+12]==bytes.fromhex('0020a0e13110a0e33000a0e3')
 code[OFFSET:OFFSET+12]=word(0xe3a00000)+word(0xe3a01000)+word(0xe12fff1e)
 assert code[:OFFSET]==base[:OFFSET] and code[OFFSET+12:]==base[OFFSET+12:]
 report={'label':'KU25Q4-R46-preconsume-zero-usage','baseline':'R4.5 candidate; no R4.5 physical result supplied','module_sha256':hashlib.sha256(code).hexdigest(),'baseline_module_sha256':hashlib.sha256(base).hexdigest(),'only_change_vs_R45':[hex(OFFSET),hex(OFFSET+12)],'semantics':'Usage getter for pair 30/31 returns uint64 zero; native capacity/request comparisons and raw-state checks unchanged','stored_chip_usage_changed':False,'chip_wire_response_replaced':False,'InitialCharge_CL1_CL2_CL3_individual_hardware_tests':False,'all_job_to_precheck_mappings_verified':False}
 (P/'KU25Q4-R46-control.bin').write_bytes(code);return bytes(code),report
