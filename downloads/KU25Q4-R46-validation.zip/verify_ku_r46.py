"""Native ink-cover tests; other-cover/interlock paths retain their own results."""
import hashlib,itertools,json,struct
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import *
from build_ku_r46 import build,P,BASE
from build_ku_r45_cover_prep import QUERY,INK_IDS
from verify_ku_stage1 import Machine
from verify_ku_r46_core import verify as verify_s2
class ServiceMachine(Machine):
 def __init__(self,code,states=None):
  super().__init__(code);self.states=dict(states or {});self.pending=None;self.events=[];self.writes=[];self.requests=[];self.u.hook_add(UC_HOOK_CODE,self.hook)
 def hook(self,u,address,size,data):
  off=address-BASE;ret=None
  r0=u.reg_read(UC_ARM_REG_R0);r1=u.reg_read(UC_ARM_REG_R1);r2=u.reg_read(UC_ARM_REG_R2)
  if off==0x1f3bb4:ret=0 # Logging sink.
  elif off==0x21a39c:self.write(r0,bytes(r1));ret=r0 # Zero-initialization utility.
  elif off==0x21be40:self.write(r0,bytes([r2&255])*r1);ret=r0 # ROM memory-fill utility (target ROM is absent).
  elif off==0x109f5c:ret=0x1234 # IPC context fixture.
  elif off==0x1098d0:
   message=self.val(u.reg_read(UC_ARM_REG_SP));self.pending=struct.unpack('<H',self.read(message+8,2))[0];self.requests.append(self.pending);ret=0
  elif off==0x109c68:
   response=0x42100000;self.setval(response+0x30,self.states.get(self.pending,0));self.setval(r0,response);ret=0
  elif off==0x109ff0:ret=0
  elif off==0x107188:
   assert r1==4;value=self.val(r2);self.states[r0]=value;self.writes.append({'id':hex(r0),'value':value});ret=0 # Typed DSM write/IPC boundary.
  elif off==0x1f9430:
   self.setval(u.reg_read(UC_ARM_REG_R3),0x42018000);ret=0 # Message allocation.
  elif off==0x828c4:
   self.events.append({'type':self.read(r0+0x1c,1)[0],'kind':r1,'action':r2});ret=0 # Message delivery, after native construction.
  elif off in (0x13b514,0x13b6f0):ret=0 # RPC submission/collection boundary.
  if ret is not None:u.reg_write(UC_ARM_REG_R0,ret);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))

def verify_covers(code):
 old=(P/'KU25Q4-R4-control.bin').read_bytes();counts={};cases={}
 regression=verify_s2(code);counts['R4_accounting_regressions']=regression['executed_scenarios']
 a=Machine(old);b=Machine(code);ptr=b.literal(0x2ba18,-0x2f8);cached=[]
 for left,right in itertools.product((0,1,2,255),repeat=2):
  for m in (a,b):m.write(ptr,bytes((left,right)))
  for slot in range(2):assert b.call(0x2b97c,slot)==0
  assert b.call(0x2ba28)==1
  assert a.call(0x2ba28)==int(left!=1 and right!=1)
  cached.append({'left':left,'right':right,'candidate_aggregate_closed':True})
 counts['cached_ink_cover_combinations']=len(cached);cases['cached']=cached
 setters=[]
 for slot,value in itertools.product(range(2),range(256)):
  b.write(ptr,bytes((99,88)));before=b.read(ptr,2);b.call(0x2b9d0,slot,value);expected=bytearray(before);expected[slot]=0;assert b.read(ptr,2)==expected
  setters.append({'slot':slot,'input':value,'stored':0,'other_slot_preserved':True})
 counts['two_ink_cover_setter_cases']=len(setters);cases['setters']=setters
 # Native DSM boolean query: exact ink IDs return zero, all other IDs retain fixture results.
 queries=[]
 for ident,value in itertools.product((*INK_IDS,0x6027,0x6000,0x602e,0x6008,0x6035,0x6036,0x6033,0x6010),range(4)):
  x=ServiceMachine(old,{ident:value});y=ServiceMachine(code,{ident:value});before=x.call(QUERY,ident);after=y.call(QUERY,ident)
  assert before==value and after==(0 if ident in INK_IDS else value)
  assert bool(y.requests)==(ident not in INK_IDS)
  queries.append({'id':hex(ident),'input':value,'original':before,'candidate':after,'IPC_requested':bool(y.requests)})
 counts['exact_ink_ID_and_other_query_cases']=len(queries);cases['queries']=queries
 # The real interlock checker and all-cover query execute with transport fixtures.
 table=0x278668;records=[struct.unpack_from('<6I',old,table+i*24) for i in range(6)];allcovers=[]
 for bits in itertools.product((0,1),repeat=6):
  states={row[3]&65535:v for row,v in zip(records,bits)};states[0x6033]=0
  x=ServiceMachine(old,states);y=ServiceMachine(code,states)
  original_interlock=x.call(0x101c28);candidate_interlock=y.call(0x101c28)
  assert original_interlock==candidate_interlock==bits[0]
  orig_any=x.call(0x101dc4);candidate_any=y.call(0x101dc4)
  assert orig_any==int(any(bits)) and candidate_any==int(any(v for i,v in enumerate(bits) if i not in (2,3)))
  allcovers.append({'cover_bits':bits,'original_interlock':original_interlock,'candidate_interlock':candidate_interlock,'original_any':orig_any,'candidate_any':candidate_any})
 counts['actual_interlock_and_other_cover_combinations']=len(allcovers);cases['all_covers']=allcovers
 # Ink-open callbacks now execute their own existing close callback; unrelated cover metadata is untouched.
 callbacks=[]
 for index,entry,state_id in ((2,0x101828,0x6009),(3,0x1018dc,0x600a)):
  observations=[]
  for label,data in (('original',old),('candidate',code)):
   m=ServiceMachine(data,{0x6027:1});mode=m.literal(0xde784,-0x770);m.write(mode,b'\x01')
   result=m.call(entry,BASE+table+index*24)
   observations.append({'image':label,'return':result,'writes':m.writes,'events':m.events})
   if label=='candidate':assert m.writes==[{'id':hex(state_id),'value':0}] and m.events==[{'type':index,'kind':32,'action':2}] and m.states[0x6027]==1
   else:assert m.events==[{'type':index,'kind':32,'action':0}]
  callbacks.append({'cover_type':index,'observations':observations})
 counts['ink_open_to_corresponding_close_callback_cases']=len(callbacks);cases['callbacks']=callbacks
 maintenance=[];maintenance_ptr=b.literal(0x31c24,8)
 for values in itertools.product((0,1,2),repeat=3):
  for m in (a,b):m.write(maintenance_ptr,bytes(values))
  before=a.call(0x31c54);after=b.call(0x31c54);assert before==after
  maintenance.append({'values':values,'original':before,'candidate':after})
 counts['maintenance_cover_regressions']=len(maintenance);cases['maintenance_covers']=maintenance
 return {'module_sha256':hashlib.sha256(code).hexdigest(),'executed_scenarios':sum(counts.values()),'case_counts':counts,'cases':cases,'S2_regressions':regression,'cover_state_logic_verdict_hooks':0,'fixtures':['DSM IPC context/send/receive/release','Typed DSM write IPC boundary','Logging and zero-initialization utility','Message allocation/delivery and RPC transport'],'interlock_classification_evidence':'Types 2 and 3 have flag 0; original ms_Cover_IsInterlockCoverOpen tests only flag 1. Type 0 has flag 1 and original results remain unchanged.','physical_tested':False,'scope':'Native ink-cover/status/interlock logic plus S2 regressions using initialized RAM and explicit message/IPC fixtures; no physical switch, full UI, print scheduling or vibration test.'}
if __name__=='__main__':
 code,_=build();r=verify(code);(P/'KU25Q4-cover-native-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ('cases','S2_regressions')},indent=2))


def verify_base(code):
 report=verify_covers(code)
 count=0
 b=Machine(code)
 for slot in range(10):
  for length in (0,1,4,5,6,16,64):
   out=0x42001000;b.write(out,b'\xcc'*80);b.call(0x2d0bc,slot,2,out,length)
   assert b.read(out,length)==(b'EPSON'+bytes(64))[:length]
   assert b.read(out+length,80-length)==b'\xcc'*(80-length);count+=1
 for slot in range(10):
  for value in (0,1,2,0xffffffff):
   b.call(0x2b198,slot,value);assert b.call(0x2b184,slot)==0;count+=1
 report['case_counts']['manufacturer_and_non_Epson_flag']=count;report['executed_scenarios']+=count
 report['all_UI_PC_web_paths_verified']=False
 return report


def verify(code):
 report=verify_base(code)
 from probe_ku_r46_precheck import verify as check_preconsume
 extra=check_preconsume(code)
 report['case_counts']['native_preconsume_comparisons']=extra['native_precheck_scenarios_passed'];report['executed_scenarios']+=extra['native_precheck_scenarios_passed']
 report['preconsume_scope']={k:v for k,v in extra.items() if k!='cases'}
 return report
