import hashlib,itertools,struct
from build_ku_r3 import build
from build_ku_r2 import build as build_r2,GET40
from verify_ku_stage1 import Machine,DIRTY,verify as verify_s1
from verify_ku_stage2 import seedpair,call40,SET40,ADD40

def verify(code):
 expected,manifest=build();assert code==expected;r2,_=build_r2();report=verify_s1(code)
 counts={'S1_regressions':report['executed_scenarios'],'percentage':10}
 for slot in range(10):assert Machine(code).call(0x2ae88,slot)==100
 a,b=Machine(r2),Machine(code);cases=[]
 pairs=((0x22,0x23),(0x24,0x25),(0x30,0x31),(0x22,0x25),(0x24,0x23))
 for pair,slot,low,high,amount,fn in itertools.product(pairs,range(10),(0,123,0xffffffff),(0,255),(0,17,0xffffffff),(GET40,SET40,ADD40)):
  # Each independent case begins with identical RAM; prior targeted writes differ by design.
  b.write(0x44900000,a.read(0x44900000,0x100000))
  for m in (a,b):desc,lows,highs=seedpair(m,pair,slot,low,high)
  before=b.read(0x44900000,0x100000)
  ra=call40(a,fn,pair,slot,amount,1);rb=call40(b,fn,pair,slot,amount,1)
  after=b.read(0x44900000,0x100000)
  if pair==(0x22,0x23) and fn in (SET40,ADD40):
   target=bytearray(before);ptr,n,hptr,hn=desc
   target[ptr-0x44900000+4*slot:ptr-0x44900000+4*slot+4]=bytes(4)
   target[hptr-0x44900000+slot]=0
   for idx,value in zip(pair,(low,high)):struct.pack_into('<I',target,DIRTY-0x44900000+idx*4,int(value!=0))
   assert after==target,(pair,slot,fn)
  else:
   assert rb==ra and after==a.read(0x44900000,0x100000)
   if fn==GET40:assert after==before
  assert a.read(0x421ff000,8)==b.read(0x421ff000,8)==struct.pack('<II',amount,1)
  cases.append({'pair':pair,'slot':slot,'stored':[low,high],'amount_low':amount,'fn':hex(fn),'RAM_and_stack_checked':True})
 counts['ledger_boundary_and_regression_cases']=len(cases)
 return {'module_sha256':hashlib.sha256(code).hexdigest(),'executed_scenarios':sum(counts.values()),'case_counts':counts,'cases':cases,'scope':manifest,'native_verdict_hooks':0,'hardware_boot_print_tested':False}
