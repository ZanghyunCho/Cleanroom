"""Package and validate KU25Q4 stage 1 from the supplied official EFU."""
from pathlib import Path
import hashlib,json,struct,zipfile
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec,utils
from build_ku_r46 import build,P
from build_ku_controls import sections
from decode_crom import decode
from encode_crom import encode
from verify_ku_r46 import verify
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 src=P/'FWCL14TL_KU25Q4.efu';assert sha(src.read_bytes())=='fb8bc19af5a13bb6dba43f8971aafeb062425e030be0c761eeccbf6000c99a56'
 with zipfile.ZipFile(src) as z:assert z.testzip() is None;info=z.getinfo('FWCL14TL.rcx');orig=z.read(info)
 sign=orig.index(b'EPSONSIGN');body=sign+4096;actual=len(orig)-body
 assert orig[sign+9:sign+13]==b'KU23' and struct.unpack_from('<I',orig,sign+16)[0]==actual
 sections(orig)
 start,slot_end=0x11412e,0x41412e;end=start+4+int.from_bytes(orig[start+6:start+10],'big');second_size=int.from_bytes(orig[end+2:end+6],'big');second=orig[end:end+second_size]
 assert second[:2]==b'\xff\xd8' and orig[end+second_size:slot_end]==b'\xff'*(slot_end-end-second_size)
 original_module,original_frame=decode(orig,start)
 (P/'FWCL14TL.rcx-0011412e.decoded.bin').write_bytes(original_module)
 module,patches=build();encoded,compression=encode(module,orig[start:end],positive_padding=True,restrict_to_template_symbols=True)
 assert len(encoded)+second_size<=slot_end-start and compression['dma_output_bytes']%48==0
 d=bytearray(orig);struct.pack_into('<I',d,sign+16,actual+1);replacement=encoded+second;d[start:slot_end]=replacement+b'\xff'*(slot_end-start-len(replacement))
 m=struct.unpack_from('<I',d,body+28)[0];n=struct.unpack_from('<I',d,body+64)[0];begin=body+4096+m;finish=begin+n
 struct.pack_into('<H',d,body+54,sum(d[begin:finish])&65535);d[body+68:body+88]=hashlib.sha1(d[begin:finish]+hashlib.sha1(d[body:body+14]).digest()).digest()
 ranges=sorted([(sign+16,sign+20),(body+54,body+56),(body+68,body+88),(start,slot_end)])
 prev=0
 for lo,hi in ranges:assert d[prev:lo]==orig[prev:lo];prev=hi
 assert d[prev:]==orig[prev:] and len(d)==len(orig)
 key=orig[0x1112e:0x1116e];sig=orig[sign+32:sign+96];assert d[0x1112e:0x1116e]==key and d[sign+32:sign+96]==sig
 pub=ec.EllipticCurvePublicNumbers(int.from_bytes(key[:32],'big'),int.from_bytes(key[32:],'big'),ec.SECP256R1()).public_key();der=utils.encode_dss_signature(int.from_bytes(sig[:32],'big'),int.from_bytes(sig[32:],'big'));pub.verify(der,orig[body:],ec.ECDSA(hashes.SHA256()))
 out=P/'FWCL14TL_KU25Q4-R46-preconsume-zero-usage.efu'
 with zipfile.ZipFile(out,'w') as z:z.writestr(info,d)
 with zipfile.ZipFile(out) as z:assert z.testzip() is None;final=z.read('FWCL14TL.rcx');assert final==d
 verified_sections=sections(final)
 final_module,final_frame=decode(final,start);assert final_module==module
 new_end=start+len(encoded);assert final[new_end:new_end+second_size]==second
 second_orig,_=decode(b'CROM'+second,0);second_final,_=decode(b'CROM'+final[new_end:new_end+second_size],0);assert second_orig==second_final
 try:pub.verify(der,final[body:],ec.ECDSA(hashes.SHA256()))
 except InvalidSignature:verdict='invalid'
 else:raise AssertionError('Unexpected valid modified-body signature')
 native=verify(final_module);assert native['module_sha256']==sha(final_module)
 (P/'KU25Q4-R46-native-results.json').write_text(json.dumps(native,indent=2)+'\n')
 report={'label':'KU25Q4-R46-preconsume-zero-usage','filename':out.name,'bytes':out.stat().st_size,'efu_sha256':sha(out.read_bytes()),'source_efu_sha256':sha(src.read_bytes()),'original_rcx_sha256':sha(orig),'rcx_sha256':sha(final),'actual_body_bytes':actual,'declared_body_bytes':actual+1,'original_key_and_signature_bytes_preserved':True,'ordinary_modified_body_signature':verdict,'zip_crc_and_reextraction_exact':True,'sections':verified_sections,'allowed_rcx_change_ranges':[[hex(a),hex(b)] for a,b in ranges],'outside_allowed_ranges_unchanged':True,'original_module_sha256':sha(original_module),'final_decoded_module_sha256':sha(final_module),'final_module_matches_tested_module':True,'module_patches':patches,'compression':compression,'original_frame':original_frame,'final_frame':final_frame,'second_frame_preserved':True,'second_frame_original_offset':hex(end),'second_frame_new_offset':hex(new_end),'second_frame_decoded_sha256':sha(second_final),'allocation_end':hex(slot_end),'native_scenarios_passed':native['executed_scenarios'],'native_case_counts':native['case_counts'],'native_verdict_hooks':0,'native_tests_run_on_final_efu_extraction':True,'hardware_update_boot_printing_tested':False,'full_receiver_native_loader_hardware_huffman_executed':False,'persistence_scope':'Native accounting RAM and dirty flags. Actual physical cartridge EEPROM writes and restoration across reboot not validated.'}
 (P/'KU25Q4-R46-validation.json').write_text(json.dumps(report,indent=2)+'\n');out.with_suffix('.efu.sha256').write_text(report['efu_sha256']+'  '+out.name+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('module_patches','sections','original_frame','final_frame')},indent=2))
if __name__=='__main__':main()
