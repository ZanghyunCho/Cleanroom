"""R3: R2 plus zero writes for only pair 22/23, without fractional changes."""
import hashlib,struct
from build_ku_r2 import build as build_r2
from build_ku_stage1 import P,BASE,branch,word
from build_ku_stage2 import Asm,SET40,ADD40
START=0x2aeb0

def build():
 r2,_=build_r2();code=bytearray(r2);a=Asm(START)
 a.label('set');a.w(0xe3500022);a.w(0x03510023);a.b('zero',cond=0)
 a.label('native');a.w(struct.unpack_from('<I',r2,SET40)[0]);a.b(SET40+4)
 a.label('zero');a.w(0xe92d4010);a.w(0xe24dd008);a.w(0xe3a0c000);a.w(0xe58dc000);a.w(0xe58dc004);a.b('native',link=True);a.w(0xe28dd008);a.w(0xe8bd8010)
 a.label('add');a.w(0xe3500022);a.w(0x03510023);a.b('zero',cond=0);a.w(struct.unpack_from('<I',r2,ADD40)[0]);a.b(ADD40+4)
 helper=a.finish();end=START+len(helper);assert end<=0x2afb8
 for off in range(0,len(r2)-4,4):
  w=struct.unpack_from('<I',r2,off)[0]
  if w>>25&7==5:
   d=w&0xffffff;d-=1<<24 if d&0x800000 else 0;t=off+8+d*4
   assert not START<=t<end or 0x2ae88<=off<0x2afb8,(hex(off),hex(t))
  assert not BASE+START<=w<BASE+end
 ranges=[(START,end),(SET40,SET40+4),(ADD40,ADD40+4)]
 code[START:end]=helper
 for off,label in ((SET40,'set'),(ADD40,'add')):code[off:off+4]=branch(off,a.labels[label])
 assert all(any(lo<=i<hi for lo,hi in ranges) for i,(x,y) in enumerate(zip(r2,code)) if x!=y)
 report={'label':'KU25Q4-R3-primary-usage-zero-write','baseline':'R2 user reports boot and printing passed','baseline_module_sha256':hashlib.sha256(r2).hexdigest(),'module_sha256':hashlib.sha256(code).hexdigest(),'change_ranges_vs_R2':[[hex(lo),hex(hi)] for lo,hi in ranges],'target_pair':['0x22','0x23'],'semantics':'R2 zero read retained; set/add clear selected stored ledger through original setter; reads still do not clear RAM','fractional_accumulators_changed':False,'other_pairs_changed':False,'additional_ID33_changed':False,'hardware_boot_print_tested':False,'physical_chip_EEPROM_verified':False,'complete_zero_usage_implementation':False}
 (P/'KU25Q4-R3-control.bin').write_bytes(code);return bytes(code),report
