"""R4: R3 plus primary fractional update only; one instruction changed."""
import hashlib
from build_ku_r3 import build as build_r3
from build_ku_stage1 import P,word
OFFSET=0x2a280

def build():
 r3,_=build_r3();code=bytearray(r3)
 assert code[OFFSET:OFFSET+4]==word(0xe0801005)
 code[OFFSET:OFFSET+4]=word(0xe3a01000)
 assert code[:OFFSET]==r3[:OFFSET] and code[OFFSET+4:]==r3[OFFSET+4:]
 report={'label':'KU25Q4-R4-primary-fraction-zero','baseline':'R3 user reports boot and printing passed','baseline_module_sha256':hashlib.sha256(r3).hexdigest(),'module_sha256':hashlib.sha256(code).hexdigest(),'change_ranges_vs_R3':[[hex(OFFSET),hex(OFFSET+4)]],'fraction_array':'0x4495916c','target_pair':['0x22','0x23'],'semantics':'Primary fractional update substitutes zero before native quotient/remainder calculation; old remainder is cleared on this update path','secondary_fraction_array_changed':False,'read_time_fraction_clear_added':False,'hardware_boot_print_tested':False,'complete_zero_usage_implementation':False}
 (P/'KU25Q4-R4-control.bin').write_bytes(code);return bytes(code),report
