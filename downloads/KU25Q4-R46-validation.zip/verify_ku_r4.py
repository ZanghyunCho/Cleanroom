import hashlib,itertools,struct
from build_ku_r4 import build
from build_ku_r2 import build as build_r2,GET40
from verify_ku_stage1 import Machine,DIRTY,verify as verify_s1
from verify_ku_stage2 import seedpair,call40,SET40,ADD40

def verify_ledgers(code):
 expected,manifest=build();assert code==expected;r2,_=build_r2();report=verify_s1(code)
 counts={'S1_regressions':report['executed_scenarios'],'percentage':10}
 for slot in range(10):assert Machine(code).call(0x2ae88,slot)==100
 a,b=Machine(r2),Machine(code);cases=[]
 pairs=((0x22,0x23),(0x24,0x25),(0x30,0x31),(0x22,0x25),(0x24,0x23))
 for pair,slot,low,high,amount,fn in itertools.product(pairs,range(10),(0,123,0xffffffff),(0,255),(0,17,0xffffffff),(GET40,SET40,ADD40)):
  # Each independent case begins with identical RAM; prior targeted writes differ by design.
  b.write(0x44900000,a.read(0x44900000,0x100000))
  for m in (a,b):desc,lows,highs=seedpair(m,pair,slot,low,high)
  before=b.read(0x44900000,0x100000)
  ra=call40(a,fn,pair,slot,amount,1);rb=call40(b,fn,pair,slot,amount,1)
  after=b.read(0x44900000,0x100000)
  if pair==(0x22,0x23) and fn in (SET40,ADD40):
   target=bytearray(before);ptr,n,hptr,hn=desc
   target[ptr-0x44900000+4*slot:ptr-0x44900000+4*slot+4]=bytes(4)
   target[hptr-0x44900000+slot]=0
   for idx,value in zip(pair,(low,high)):struct.pack_into('<I',target,DIRTY-0x44900000+idx*4,int(value!=0))
   assert after==target,(pair,slot,fn)
  else:
   assert rb==ra and after==a.read(0x44900000,0x100000)
   if fn==GET40:assert after==before
  assert a.read(0x421ff000,8)==b.read(0x421ff000,8)==struct.pack('<II',amount,1)
  cases.append({'pair':pair,'slot':slot,'stored':[low,high],'amount_low':amount,'fn':hex(fn),'RAM_and_stack_checked':True})
 counts['ledger_boundary_and_regression_cases']=len(cases)
 return {'module_sha256':hashlib.sha256(code).hexdigest(),'executed_scenarios':sum(counts.values()),'case_counts':counts,'cases':cases,'scope':manifest,'native_verdict_hooks':0,'hardware_boot_print_tested':False}


def verify(code):
 report=verify_ledgers(code)
 from build_ku_r3 import build as build_r3
 from verify_ku_stage2 import init_profile
 r3,_=build_r3();cases=[]
 for slot,old,amount in itertools.product(range(10),(0,123,999),(1,999,1000,0xffffffff)):
  observations=[]
  for label,data in (('R3',r3),('R4',code)):
   m=Machine(data);init_profile(m);mapped=m.call(0x32e70,slot)
   for pair in ((0x22,0x23),(0x24,0x25),(0x30,0x31)):seedpair(m,pair,mapped,123,1)
   primary=0x4495916c;secondary=0x449591ac
   values=list(range(100,116));values[mapped]=old
   m.write(primary,struct.pack('<16I',*values));m.write(secondary,struct.pack('<16I',*range(200,216)))
   before=m.read(secondary,64);m.call(0x2a20c,slot,amount)
   after=list(struct.unpack('<16I',m.read(primary,64)))
   assert m.read(secondary,64)==before
   if label=='R4':
    expected=values[:];expected[mapped]=0;assert after==expected,(slot,old,amount,after)
   observations.append(after[mapped])
  cases.append({'slot':slot,'fixture_mapped_index':mapped,'old':old,'amount':amount,'R3_fraction':observations[0],'R4_fraction':observations[1]})
 assert any(x['R3_fraction']!=x['R4_fraction'] for x in cases)
 report['fraction_cases']=cases;report['case_counts']['native_primary_fraction_updates']=len(cases);report['executed_scenarios']+=len(cases)
 return report
