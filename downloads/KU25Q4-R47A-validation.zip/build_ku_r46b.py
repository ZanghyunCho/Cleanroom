"""R4.6B: only the local usage operand in consume precheck, keep global getter."""
import hashlib
from build_ku_r4 import build as build_r4
from build_ku_stage1 import P,BASE,word,branch
OFFSET=0x19234

def build():
 base,_=build_r4();code=bytearray(base)
 assert base[OFFSET:OFFSET+8]==word(0xe1a00004)+branch(OFFSET+4,0x29ba0,link=True)
 code[OFFSET:OFFSET+8]=word(0xe3a00000)+word(0xe3a01000)
 assert code[:OFFSET]==base[:OFFSET] and code[OFFSET+8:]==base[OFFSET+8:]
 assert code[0x29ba0:0x29bb0]==base[0x29ba0:0x29bb0]
 report={'label':'KU25Q4-R46B-precheck-local-operand','baseline':'R4 hardware-reported pass','baseline_module_sha256':hashlib.sha256(base).hexdigest(),'module_sha256':hashlib.sha256(code).hexdigest(),'only_change_vs_R4':[hex(OFFSET),hex(OFFSET+8)],'global_usage_getter_original':True,'semantics':'Replace the usage operand with uint64 zero only at native precheck 0x190cc callsite; global usage reads retain R4 values','R45_identity_cover_included':False,'stored_usage_changed':False,'chip_wire_responses_changed':False,'hardware_boot_tested':False,'all_job_to_precheck_mappings_verified':False}
 (P/'KU25Q4-R46B-control.bin').write_bytes(code);return bytes(code),report
