"""Native expected-SKU lookup with active-profile RAM fixtures, no verdict hooks."""
from pathlib import Path
import struct,json,hashlib
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm_const import *
P=Path(__file__).resolve().parent;data=(P/'FWCL14TL.rcx-016a412e.decoded.bin').read_bytes();B=0x4529f000
u=Uc(UC_ARCH_ARM,UC_MODE_ARM);u.mem_map(0x45000000,0x1000000);u.mem_write(B,data);u.mem_map(0x49000000,0x1000000);u.mem_map(0x42000000,0x200000);u.mem_map(0x48000000,0x1000)
nv_profile=[1];nv_calls=[]
def hook(u,address,size,user):
 if address==B+0x30f5c0:
  key=u.reg_read(UC_ARM_REG_R0);dest=u.reg_read(UC_ARM_REG_R1);length=u.reg_read(UC_ARM_REG_R2)
  assert key==0x261 and length==1
  nv_calls.append({'id':hex(key),'length':length,'fixture_value':nv_profile[0]})
  u.mem_write(dest,bytes(nv_profile));u.reg_write(UC_ARM_REG_R0,1);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
u.hook_add(UC_HOOK_CODE,hook)
obj=struct.unpack_from('<I',data,0x1b94c)[0];rows=[]
for profile in range(4):
 record=0x54cf44+12*profile;profile_id,table,count=struct.unpack_from('<3I',data,record);assert count==10
 nv_profile[0]=profile_id
 # Run original profile initialization tail, after unrelated object constructors.
 u.mem_write(0x421ff000,bytes(36)+struct.pack('<I',0x48000000))
 u.reg_write(UC_ARM_REG_CPSR,0x13);u.reg_write(UC_ARM_REG_SP,0x421ff000);u.reg_write(UC_ARM_REG_R4,0)
 u.emu_start(B+0x1b57c,0x48000000,count=100000)
 assert u.reg_read(UC_ARM_REG_PC)==0x48000000
 assert struct.unpack('<I',bytes(u.mem_read(obj+4,4)))[0]==B+record

 for i in range(count):
  off=table-B+32*i;role=struct.unpack_from('<I',data,off)[0];expected=struct.unpack_from('<I',data,off+8)[0]
  buf=0x42001000;u.mem_write(buf,bytes((1,0,role)))
  u.reg_write(UC_ARM_REG_CPSR,0x13);u.reg_write(UC_ARM_REG_SP,0x421ff000);u.reg_write(UC_ARM_REG_LR,0x48000000);u.reg_write(UC_ARM_REG_R0,buf);u.reg_write(UC_ARM_REG_R1,0)
  u.emu_start(B+0x30cc4c,0x48000000,count=100000);assert u.reg_read(UC_ARM_REG_PC)==0x48000000
  actual=u.reg_read(UC_ARM_REG_R0);assert actual==expected
  value=bytes(u.mem_read(actual,20)).split(b'\0')[0].decode()
  rows.append({'active_profile_fixture':profile_id,'role_id':role,'lookup_result':value})
report={'main_module_sha256':hashlib.sha256(data).hexdigest(),'native_lookup_entry':'0x455abc4c','cases_passed':len(rows),'native_result_hooks':0,'profile_selection':'Original initializer reads key 0x261, one byte, then selects active SKU profile; NVRAM transport uses fixture values, actual device contents were not read','NVRAM_read_fixture_calls':nv_calls,'cases':rows}
(P/'KU25Q4-R45-country-sku-contract.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
