"""Identity negative controls: native field selectors and chip byte-read fixtures."""
from pathlib import Path
import json,hashlib
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import *
from build_ku_r47 import build,BASE
from build_ku_r46b import build as build_base
from verify_ku_stage1 import Machine
class FieldMachine(Machine):
 def __init__(self,code):
  super().__init__(code);self.reads=[];self.u.hook_add(UC_HOOK_CODE,self.hook)
 def hook(self,u,address,size,user):
  if address==BASE+0x2c970:
   slot=u.reg_read(UC_ARM_REG_R0);offset=u.reg_read(UC_ARM_REG_R1);out=u.reg_read(UC_ARM_REG_R2)
   self.reads.append((slot,offset));self.setval(out,(slot*17+offset*3)&255)
   u.reg_write(UC_ARM_REG_R0,0);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
code,_=build();original,_=build_base();cases=[]
for slot in range(10):
 for field in (0,1,3,4):
  for length in (0,1,6,32):
   a,b=FieldMachine(original),FieldMachine(code);out=0x42001000
   for m in (a,b):m.write(out,b'\xcc'*80);m.call(0x2d0bc,slot,field,out,length)
   assert a.read(out,80)==b.read(out,80) and a.reads==b.reads
   cases.append({'slot':slot,'field':field,'length':length,'native_output_and_chip_reads_identical':True})
report={'candidate_module_sha256':hashlib.sha256(code).hexdigest(),'nonmanufacturer_field_cases_passed':len(cases),'fixtures':'Physical chip byte-read boundary only','cases':cases,'all_UI_PC_web_paths_verified':False}
Path(__file__).with_name('KU25Q4-R47-identity-regression.json').write_text(json.dumps(report,indent=2)+'\n');print(len(cases))
