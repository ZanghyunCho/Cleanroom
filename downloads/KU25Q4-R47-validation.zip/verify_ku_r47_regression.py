import hashlib,itertools
from build_ku_r47 import build
from build_ku_r4 import build as build_r4
from verify_ku_r47_core import verify as core
from probe_ku_r46b_precheck import verify as precheck
from verify_ku_stage1 import Machine
from verify_ku_stage2 import seedpair
from unicorn.arm_const import UC_ARM_REG_R1

def verify(code):
 expected,scope=build();assert code==expected;base,_=build_r4()
 assert code[0x29ba0:0x29bb0]==base[0x29ba0:0x29bb0]
 report=core(code);extra=precheck(code)
 report['case_counts']['native_preconsume_comparisons']=extra['native_precheck_scenarios_passed']
 n=0
 for slot,low,high in itertools.product(range(10),(0,123,0xffffffff),(0,255)):
  a,b=Machine(base),Machine(code)
  for m in (a,b):seedpair(m,(0x30,0x31),slot,low,high)
  before=b.read(0x44900000,0x100000)
  assert a.call(0x29ba0,slot)==low and a.u.reg_read(UC_ARM_REG_R1)==high
  assert b.call(0x29ba0,slot)==low and b.u.reg_read(UC_ARM_REG_R1)==high
  assert b.read(0x44900000,0x100000)==before;n+=1
 report['case_counts']['global_usage_getter_original_and_RAM_preserved']=n
 report['executed_scenarios']=sum(report['case_counts'].values())
 report['scope']=scope;report['R45_identity_cover_included']=False
 return report
