"""R4.7: hardware-passed R4.6B plus independently isolated R4.5 identity/lid edits."""
import hashlib,json
from build_ku_r4 import build as build_r4
from build_ku_r45 import build as build_r45
from build_ku_r46b import build as build_r46b
from build_ku_stage1 import P,BASE
from build_ku_r45_cover_prep import QUERY,INK_IDS

def build():
 r4,_=build_r4();r45,identity=build_r45();r46b,_=build_r46b();code=bytearray(r46b)
 changes=[i for i,(x,y) in enumerate(zip(r4,r45)) if x!=y]
 for i in changes:assert code[i]==r4[i];code[i]=r45[i]
 assert code[0x19234:0x1923c]==r46b[0x19234:0x1923c]
 assert code[0x29ba0:0x29bb0]==r4[0x29ba0:0x29bb0]
 assert all(i in changes for i,(x,y) in enumerate(zip(r46b,code)) if x!=y)
 report={'label':'KU25Q4-R47-identity-cover-LOONA','baseline':'R4.6B user reports normal operation','baseline_module_sha256':hashlib.sha256(r46b).hexdigest(),'module_sha256':hashlib.sha256(code).hexdigest(),'R45_identity_and_lid_edits':identity,'global_usage_getter_original':True,'R46B_local_precheck_preserved':True,'changed_bytes_vs_R46B':len(changes),'country_SKU_selection':'Native NVRAM-selected catalog preserved; full UI/PC/web propagation unverified','LOONA':'Added by packager from known published resource','hardware_tested':False}
 (P/'KU25Q4-R47-control.bin').write_bytes(code);return bytes(code),report
