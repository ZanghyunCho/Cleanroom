"""Package non-interlock ink-cover C1 on S2-LOONA; verify the final EFU."""
import hashlib,json,struct,zipfile
from build_ku_r47 import build,P
from decode_crom import decode
from encode_crom import encode
from build_ku_controls import sections
from verify_ku_r47 import verify
sha=lambda b:hashlib.sha256(b).hexdigest()
BASELINE='cd015d121d260fef96ee418bf6fdcf55c7bc8e7a35bef30c93d0bd79c557a04e'
def main():
 src=P/'FWCL14TL_KU25Q4-R46B-precheck-local-operand.efu';assert sha(src.read_bytes())==BASELINE
 with zipfile.ZipFile(src) as z:assert z.testzip() is None;info=z.getinfo('FWCL14TL.rcx');old=z.read(info)
 # Original module is required solely for the retained S1/S2 native comparison suites.
 official=P/'FWCL14TL_KU25Q4.efu';assert sha(official.read_bytes())=='fb8bc19af5a13bb6dba43f8971aafeb062425e030be0c761eeccbf6000c99a56'
 with zipfile.ZipFile(official) as z:orig=z.read('FWCL14TL.rcx')
 original_control,_=decode(orig,0x11412e);(P/'FWCL14TL.rcx-0011412e.decoded.bin').write_bytes(original_control)
 start,limit=0x11412e,0x41412e;previous,previous_info=decode(old,start);(P/'KU25Q4-R46B-control.bin').write_bytes(previous)
 from build_ku_r46b import build as build_baseline
 assert previous==build_baseline()[0]
 code,patches=build();frame_end=int(previous_info['container_end'],16);second_size=int.from_bytes(old[frame_end+2:frame_end+6],'big');second=old[frame_end:frame_end+second_size]
 assert second.startswith(b'\xff\xd8') and old[frame_end+second_size:limit]==b'\xff'*(limit-frame_end-second_size)
 encoded,compression=encode(code,old[start:frame_end],positive_padding=True,restrict_to_template_symbols=True);assert len(encoded)+second_size<=limit-start and compression['dma_output_bytes']%48==0
 updated=bytearray(old);replacement=encoded+second;updated[start:limit]=replacement+b'\xff'*(limit-start-len(replacement))
 logo_source=P/'FWCL14TL_KU25Q4-S2-LOONA.efu';assert sha(logo_source.read_bytes())=='633456ec029012746a6c814161911c6a19532a3034d99a90e2d0cd1ee82273ef'
 with zipfile.ZipFile(logo_source) as z:assert z.testzip() is None;logo_reference=z.read('FWCL14TL.rcx')
 updated[0x41412e:0x41812e]=logo_reference[0x41412e:0x41812e]
 sign=old.index(b'EPSONSIGN');body=sign+4096;m=struct.unpack_from('<I',old,body+28)[0];n=struct.unpack_from('<I',old,body+64)[0];begin=body+4096+m;end=begin+n
 struct.pack_into('<H',updated,body+54,sum(updated[begin:end])&65535);updated[body+68:body+88]=hashlib.sha1(updated[begin:end]+hashlib.sha1(updated[body:body+14]).digest()).digest()
 ranges=sorted([(body+54,body+56),(body+68,body+88),(start,0x41812e)]);prev=0
 for lo,hi in ranges:assert updated[prev:lo]==old[prev:lo];prev=hi
 assert updated[prev:]==old[prev:] and len(updated)==len(old)
 out=P/'FWCL14TL_KU25Q4-R47-identity-cover-LOONA.efu'
 with zipfile.ZipFile(out,'w') as z:z.writestr(info,updated)
 with zipfile.ZipFile(out) as z:assert z.testzip() is None;final=z.read('FWCL14TL.rcx');assert final==updated
 checks=sections(final);module,ci=decode(final,start);assert module==code
 new_end=start+len(encoded);assert final[new_end:new_end+second_size]==second
 second_a,_=decode(b'CROM'+second,0);second_b,_=decode(b'CROM'+final[new_end:new_end+second_size],0);assert second_a==second_b
 assert final[0x41412e:0x41812e]==logo_reference[0x41412e:0x41812e];logo,li=decode(final,0x41412e)
 assert sha(logo)=='7911319cc1eab60d50b123a4cd430991d67f0591f9a112ef5b122a9c47e0cd78'
 assert final[sign+32:sign+96]==old[sign+32:sign+96] and final[0x1112e:0x1116e]==old[0x1112e:0x1116e]
 assert struct.unpack_from('<I',final,sign+16)[0]==len(final)-body+1
 native=verify(module);(P/'KU25Q4-R47-native-results.json').write_text(json.dumps(native,indent=2)+'\n')
 report={'filename':out.name,'efu_sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'baseline_R46B_sha256':BASELINE,'rcx_sha256':sha(final),'original_key_and_signature_bytes_preserved':True,'declared_body_bytes':len(final)-body+1,'actual_body_bytes':len(final)-body,'modified_body_ecdsa_signature_valid':False,'zip_crc_and_reextraction_exact':True,'host_sections':checks,'allowed_rcx_change_ranges':[[hex(a),hex(b)] for a,b in ranges],'outside_allowed_ranges_byte_identical':True,'patched_control_sha256':sha(module),'final_control_exactly_matches_tested_code':True,'patches':patches,'compression':compression,'second_frame_preserved':True,'second_frame_original_offset':hex(frame_end),'second_frame_new_offset':hex(new_end),'second_frame_decoded_sha256':sha(second_b),'LOONA_resource_byte_identical_to_published_LOONA':True,'LOONA_resource_sha256':sha(logo),'native_scenarios_passed':native['executed_scenarios'],'native_case_counts':native['case_counts'],'native_tests_on_final_extracted_module':True,'native_fixture_boundaries':native['fixtures'],'interlock_classification_evidence':native['interlock_classification_evidence'],'actual_interlock_and_emergency_logic_byte_identical':True,'hardware_print_vibration_tested':False,'limits':['No physical update/boot/printing/vibration verification','Not a hardware cover-sensor test; only the identified two non-interlock ink-cover software paths were changed','Separate safety interlocks, other-cover errors, cartridge presence and communication faults are preserved']}
 (P/'KU25Q4-R47-validation.json').write_text(json.dumps(report,indent=2)+'\n');out.with_suffix('.efu.sha256').write_text(report['efu_sha256']+'  '+out.name+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('patches','host_sections')},indent=2))
if __name__=='__main__':main()
