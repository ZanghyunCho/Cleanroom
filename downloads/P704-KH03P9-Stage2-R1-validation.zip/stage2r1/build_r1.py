"""P704 Stage2 R1: restore original maintenance validity handshake flags."""
from pathlib import Path
import hashlib,json,struct,sys,zipfile
ROOT=Path(__file__).resolve().parent;INPUT=ROOT.parent;BASE=0x43808000
sys.path.insert(0,str(INPUT/'stage2'))
from build_stage2 import patch_module as build_stage2
sys.path.insert(0,str(INPUT/'prior'))
from encode_crom import encode
from decode_crom import decode
sys.path.insert(0,str(INPUT))
from build_controls import sections

def sha(b):return hashlib.sha256(b).hexdigest()

def patch_module():
    stage2,m=build_stage2();code=bytearray(stage2);original=(INPUT/'decoded/0x4f0a12e.bin').read_bytes();fixes=[]
    for off,expected in ((0xb1c5c,0xe3a00000),(0xb1c7c,0xe3a00000),(0xb1c8c,0xe3a05000)):
        before=struct.pack('<I',expected);assert code[off:off+4]==before
        after=original[off:off+4];code[off:off+4]=after
        fixes.append(dict(offset=hex(off),address=hex(BASE+off),before=before.hex(),after=after.hex(),
            reason='Restore original field 0x49/0x4b read/write needed by native maintenance record validation'))
    allowed={i for p in fixes for i in range(int(p['offset'],16),int(p['offset'],16)+4)}
    diff=[i for i,(a,b) in enumerate(zip(stage2,code)) if a!=b];assert set(diff)<=allowed and len(diff)==7
    # State/status generation itself is not forced to Ready.
    for lo,hi in ((0x402e4,0x4031c),(0x56160,0x561d0),(0xddc98,0xddda8),(0xe70d8,0xe7248),(0xb0c7c,0xb0d40),(0xb0e28,0xb0e84)):
        assert code[lo:hi]==original[lo:hi]
    m.update(label='P704-Stage2-R1-maintenance-handshake-fix',previous_stage2_module_sha256=sha(stage2),
        patched_module_sha256=sha(code),fixes=fixes,changed_bytes_vs_stage2=len(diff),
        all_stage1_patches_preserved=False,restored_stage1_instruction_sites=3,
        maintenance_remaining_and_usage_changes_preserved=True,all_stage2_ink_changes_preserved=True,
        root_cause_scope='Native maintenance record validation regression reproduced; connection to observed remote driver printing indication remains a device-validation hypothesis.',
        physical_update_tested=False,physical_driver_status_fix_confirmed=False)
    (ROOT/'r1-module.bin').write_bytes(code);(ROOT/'patches.json').write_text(json.dumps(m,indent=2)+'\n')
    return bytes(code),m

def package():
    code,m=patch_module();original=(INPUT/'FW4838TL.rcx').read_bytes();sign=original.index(b'EPSONSIGN');body=sign+4096
    start=0x4f0a12e;end=start+4+int.from_bytes(original[start+6:start+10],'big');n=int.from_bytes(original[end+2:end+6],'big');second=original[end:end+n]
    assert original[end+n:]==b'\xff'*(len(original)-end-n)
    encoded,compression=encode(code,original[start:end]);assert compression['padding_tokens']>0 and compression['dma_output_bytes']%48==0
    assert len(encoded)+n<=len(original)-start
    d=bytearray(original);d[start:]=encoded+second+b'\xff'*(len(original)-start-len(encoded)-n)
    sec=0x4ef712e;meta=struct.unpack_from('<I',d,sec+28)[0];length=struct.unpack_from('<I',d,sec+64)[0];begin=sec+4096+meta
    struct.pack_into('<H',d,sec+54,sum(d[begin:begin+length])&65535)
    d[sec+68:sec+88]=hashlib.sha1(d[begin:begin+length]+hashlib.sha1(d[sec:sec+14]).digest()).digest()
    actual=len(d)-body;struct.pack_into('<I',d,sign+16,actual+1)
    previous=0
    for lo,hi in ((sign+16,sign+20),(sec+54,sec+56),(sec+68,sec+88),(start,len(d))):
        assert d[previous:lo]==original[previous:lo];previous=hi
    assert len(d)==len(original) and d[sign+32:sign+96]==original[sign+32:sign+96] and d[0xb13e:0xb17e]==original[0xb13e:0xb17e]
    file=ROOT/'FW4838TL_KH03P9-P704-Stage2-R1-handshake-fix.efu'
    with zipfile.ZipFile(INPUT/'FW4838TL.efu') as z:info=z.getinfo('FW4838TL.rcx')
    with zipfile.ZipFile(file,'w') as z:z.writestr(info,d)
    with zipfile.ZipFile(file) as z:assert z.testzip() is None;final=z.read('FW4838TL.rcx');assert final==d
    restored,_=decode(final,start);assert restored==code
    newend=start+len(encoded);assert final[newend:newend+n]==second
    x,_=decode(b'CROM'+second,0);y,_=decode(b'CROM'+final[newend:newend+n],0);assert x==y
    m.update(file=file.name,bytes=file.stat().st_size,sha256=sha(file.read_bytes()),rcx_sha256=sha(final),
        actual_body_bytes=actual,declared_body_bytes=actual+1,compression=compression,sections=sections(final),
        final_crc_ok=True,final_module_exact=True,second_frame_identical=True,second_frame_new_offset=hex(newend),public_key_and_signature_preserved=True,unexpected_changes=False)
    (ROOT/'validation.json').write_text(json.dumps(m,indent=2)+'\n');(ROOT/(file.name+'.sha256')).write_text(m['sha256']+'  '+file.name+'\n')
    print(file.name,m['sha256'],flush=True)

if __name__=='__main__':package()
