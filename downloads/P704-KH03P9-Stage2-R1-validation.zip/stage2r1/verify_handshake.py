"""Original vs old Stage1/Stage2 vs R1 maintenance validity-cycle regression."""
import sys,json,itertools,hashlib,struct
from pathlib import Path
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import *
from build_r1 import ROOT,INPUT,BASE,patch_module
sys.path.insert(0,str(INPUT/'stage1'))
from verify_stage1 import Machine,BUF

def run(code,first,second,write_result=0,read_result=0,cycles=1):
    m=Machine(code);commands=[];writes=[]
    m.u.mem_write(m.cache+0x49*2,struct.pack('<H',first));m.u.mem_write(m.cache+0x4b*2,struct.pack('<H',second))
    def fixture(u,a,size,user):
        if a==BASE+0xb1c88:writes.append(u.reg_read(UC_ARM_REG_R0))
        if a in (BASE+0xaf14c,BASE+0xaf0b0):
            command=u.reg_read(UC_ARM_REG_R0);commands.append([hex(a-BASE),hex(command)])
            # External chip transfer completion boundary only. Flag setters,
            # getters, native validation and error selection run unchanged.
            ret=write_result if a==BASE+0xaf14c else read_result
            u.reg_write(UC_ARM_REG_R0,ret);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
    m.u.hook_add(UC_HOOK_CODE,fixture)
    observations=[]
    for i in range(cycles):
        m.u.mem_write(m.dirty,bytes(96));writes_before=len(writes)
        init=m.call(0xb0e28);verify=m.call(0xb0cf4)
        flags=[]
        for off in (0xb1c48,0xb1c68):m.call(off,BUF);flags.append(m.u.mem_read(BUF,1)[0])
        error=m.literal(0xafc28)
        observations.append({'initialize_return':init,'validation_return':verify,'flag_49_4b':flags,
            'cache_fields':[int.from_bytes(m.u.mem_read(m.cache+i*2,2),'little') for i in (0x49,0x4b)],
            'error':list(m.u.mem_read(error,2)),'writes_this_cycle':len(writes)-writes_before,
            'dirty_49_4b':[m.u.mem_read(m.dirty+i,1)[0] for i in (0x49,0x4b)]})
    return {'cycles':observations,'transport_calls':commands,'flag_write_arguments':writes}

def main():
    code,manifest=patch_module()
    versions={'official':(INPUT/'decoded/0x4f0a12e.bin').read_bytes(),
        'stage1':(INPUT/'stage1/stage1-module.bin').read_bytes(),
        'stage2':(INPUT/'stage2/stage2-module.bin').read_bytes(),'r1':code}
    cases=[]
    for a,b,write,read in itertools.product((0,1),(0,1),(0,1),(0,1)):
        observations={label:run(data,a,b,write,read) for label,data in versions.items()}
        assert observations['r1']==observations['official']
        if write==read==0:
            assert observations['official']['cycles'][0]['validation_return']==0
            assert observations['stage1']['cycles'][0]['validation_return']==observations['stage2']['cycles'][0]['validation_return']==1
            assert observations['stage1']['cycles'][0]['error']==observations['stage2']['cycles'][0]['error']==[3,0x53]
            assert observations['r1']['cycles'][0]['flag_49_4b']==[1,1]
        else:
            # If valid flags already exist, no transfer is needed; injected
            # transport failures must not invent work that was never requested.
            expected=1 if observations['r1']['transport_calls'] else 0
            assert observations['r1']['cycles'][0]['validation_return']==expected
        cases.append({'initial_flags':[a,b],'transfer_write_result':write,'transfer_read_result':read,'results':observations})
    repeated={label:run(data,0,0,cycles=20) for label,data in versions.items()}
    assert repeated['r1']==repeated['official']
    assert sum(c['writes_this_cycle'] for c in repeated['official']['cycles'])==1
    assert sum(c['writes_this_cycle'] for c in repeated['stage1']['cycles'])==sum(c['writes_this_cycle'] for c in repeated['stage2']['cycles'])==20
    assert all(c['validation_return']==0 for c in repeated['r1']['cycles'])
    assert all(c['validation_return']==1 for c in repeated['stage1']['cycles'])
    preserved={}
    original=versions['official']
    for name,lo,hi in (('SetPrintState',0x402e4,0x4031c),('GetPrintState_region',0x56160,0x561d0),
        ('NotifyIdle',0xddc98,0xddda8),('JobStatus',0xe70d8,0xe7248)):
        assert code[lo:hi]==original[lo:hi]
        preserved[name]={'start':hex(BASE+lo),'end_exclusive':hex(BASE+hi),'original_sha256':hashlib.sha256(original[lo:hi]).hexdigest()}
    report={'passed':len(cases)+1,'failed':0,'cases':cases,'repeated_cycle_test':repeated,
        'preserved_job_state_code':preserved,'module_sha256':hashlib.sha256(code).hexdigest(),
        'scope':'Native record setup, field reads/writes, verification and error selection; chip transfer boundary modeled. Driver polling, full device boot and physical fix not reproduced.'}
    (ROOT/'native-handshake-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS',report['passed'],'handshake cases; old S1/S2 repeat writes 20 times; original/R1 once',flush=True)

if __name__=='__main__':main()
