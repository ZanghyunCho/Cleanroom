# Reproduce KU25Q4 C1
Python 3.10+, cryptography, and unicorn are required; preserve TLS/package verification.
Place both files alongside package_ku_cover.py:
- FWCL14TL_KU25Q4-S2-LOONA.efu
  SHA256 633456ec029012746a6c814161911c6a19532a3034d99a90e2d0cd1ee82273ef
- Official FWCL14TL_KU25Q4.efu (original native regression reference only)
  SHA256 fb8bc19af5a13bb6dba43f8971aafeb062425e030be0c761eeccbf6000c99a56
Run python3 package_ku_cover.py. It extracts the baseline, applies the restricted
ink-cover patch, packages EFU and executes the tests on its final extracted module.
No printer or external service is contacted by the build/test scripts.
The baseline and official firmware are not included. The archive contains the
S1/S2 builders and tests only because they supply the native regression suites.
KU25Q4-cover-readonly.asm is original read-only disassembly, not the patch output.
