00101600 24008fe2 add      r0, pc, #0x24
00101604 d66002eb bl       #0x199964
00101608 0400a0e1 mov      r0, r4
0010160c 10d08de2 add      sp, sp, #0x10
00101610 1080bde8 pop      {r4, pc}
00101614 68c68744 strmi    ip, [r7], #0x668
00101618 94c88744 strmi    ip, [r7], #0x894
0010161c 15c78744 strmi    ip, [r7], #0x715
00101620 6e6f206d stcvs    p15, c6, [r0, #-0x1b8]!
00101624 65737361 cmnvs    r3, r5, ror #6
00101628 67650000 andeq    r6, r0, r7, ror #10
0010162c 636f7665 ldrbvs   r6, [r6, #-0xf63]!
00101630 7220213d stclo    p0, c2, [r1, #-0x1c8]!
00101634 20300000 andeq    r3, r0, r0, lsr #32
00101638 70402de9 push     {r4, r5, r6, lr}
0010163c 0050a0e1 mov      r5, r0
00101640 0020a0e1 mov      r2, r0
00101644 58109fe5 ldr      r1, [pc, #0x58]
00101648 58008fe2 add      r0, pc, #0x58
0010164c 58c903eb bl       #0x1f3bb4
00101650 0140a0e3 mov      r4, #1
00101654 0500a0e1 mov      r0, r5
00101658 c9ffffeb bl       #0x101584
0010165c 000050e3 cmp      r0, #0
00101660 10109015 ldrne    r1, [r0, #0x10]
00101664 00005113 cmpne    r1, #0
00101668 0100000a beq      #0x101674
0010166c 31ff2fe1 blx      r1
00101670 0040a0e1 mov      r4, r0
00101674 28109fe5 ldr      r1, [pc, #0x28]
00101678 44008fe2 add      r0, pc, #0x44
0010167c 4cc903eb bl       #0x1f3bb4
00101680 010054e3 cmp      r4, #1
00101684 44108f02 addeq    r1, pc, #0x44
00101688 4c108f12 addne    r1, pc, #0x4c
0010168c 54008fe2 add      r0, pc, #0x54
00101690 47c903eb bl       #0x1f3bb4
00101694 50008fe2 add      r0, pc, #0x50
00101698 45c903eb bl       #0x1f3bb4
0010169c 0400a0e1 mov      r0, r4
001016a0 7080bde8 pop      {r4, r5, r6, pc}
001016a4 f8c68744 strmi    ip, [r7], #0x6f8
001016a8 5b4d6563 .byte    0x5b, 0x4d, 0x65, 0x63
001016ac 68615d20 subshs   r6, sp, r8, ror #2
001016b0 25732843 .byte    0x25, 0x73, 0x28, 0x43
001016b4 6f766572 rsbvc    r7, r5, #0x6f00000
001016b8 54797065 ldrbvs   r7, [r0, #-0x954]!
001016bc 3a256429 stmdbhs  r4!, {r1, r3, r4, r5, r8, sl, sp} ^
001016c0 0a000000 andeq    r0, r0, sl
001016c4 5b4d6563 .byte    0x5b, 0x4d, 0x65, 0x63
001016c8 68615d20 subshs   r6, sp, r8, ror #2
001016cc 25735b00 subseq   r7, fp, r5, lsr #6
001016d0 72657475 ldrbvc   r6, [r4, #-0x572]!
001016d4 726e3a4f svcmi    #0x3a6e72
001016d8 4b000000 andeq    r0, r0, fp, asr #32
001016dc 72657475 ldrbvc   r6, [r4, #-0x572]!
001016e0 726e3a4e mrcmi    p14, #1, r6, c10, c2, #3
001016e4 47000000 andeq    r0, r0, r7, asr #32
001016e8 25730000 andeq    r7, r0, r5, lsr #6
001016ec 5d0a0000 andeq    r0, r0, sp, asr sl
001016f0 70402de9 push     {r4, r5, r6, lr}
001016f4 0050a0e1 mov      r5, r0
001016f8 0020a0e1 mov      r2, r0
001016fc b8109fe5 ldr      r1, [pc, #0xb8]
00101700 60004fe2 sub      r0, pc, #0x60
00101704 2ac903eb bl       #0x1f3bb4
00101708 0140a0e3 mov      r4, #1
0010170c 0500a0e1 mov      r0, r5
00101710 9bffffeb bl       #0x101584
00101714 000050e3 cmp      r0, #0
00101718 14109015 ldrne    r1, [r0, #0x14]
0010171c 00005113 cmpne    r1, #0
00101720 0100000a beq      #0x10172c
00101724 31ff2fe1 blx      r1
00101728 0040a0e1 mov      r4, r0
0010172c 88109fe5 ldr      r1, [pc, #0x88]
00101730 74004fe2 sub      r0, pc, #0x74
00101734 1ec903eb bl       #0x1f3bb4
00101738 010054e3 cmp      r4, #1
0010173c 74104f02 subeq    r1, pc, #0x74
00101740 6c104f12 subne    r1, pc, #0x6c
00101744 64004fe2 sub      r0, pc, #0x64
00101748 19c903eb bl       #0x1f3bb4
0010174c 68004fe2 sub      r0, pc, #0x68
00101750 17c903eb bl       #0x1f3bb4
00101754 0400a0e1 mov      r0, r4
00101758 7080bde8 pop      {r4, r5, r6, pc}
0010175c 38402de9 push     {r3, r4, r5, lr}
00101760 0040a0e1 mov      r4, r0
00101764 54109fe5 ldr      r1, [pc, #0x54]
00101768 54008fe2 add      r0, pc, #0x54
0010176c 10c903eb bl       #0x1f3bb4
00101770 0100a0e3 mov      r0, #1
00101774 00008de5 str      r0, [sp]
00101778 fc73ffeb bl       #0xde770
0010177c 000050e3 cmp      r0, #0
00101780 0300001a bne      #0x101794
00101784 be00d4e1 ldrh     r0, [r4, #0xe]
00101788 0d20a0e1 mov      r2, sp
0010178c 0410a0e3 mov      r1, #4
00101790 7c1600eb bl       #0x107188
00101794 24109fe5 ldr      r1, [pc, #0x24]
00101798 dc004fe2 sub      r0, pc, #0xdc
0010179c 04c903eb bl       #0x1f3bb4
001017a0 d8104fe2 sub      r1, pc, #0xd8
001017a4 c4004fe2 sub      r0, pc, #0xc4
001017a8 01c903eb bl       #0x1f3bb4
001017ac c8004fe2 sub      r0, pc, #0xc8
001017b0 ffc803eb bl       #0x1f3bb4
001017b4 0100a0e3 mov      r0, #1
001017b8 3880bde8 pop      {r3, r4, r5, pc}
001017bc 06c78744 strmi    ip, [r7], #0x706
001017c0 23c78744 strmi    ip, [r7], #0x723
001017c4 5b4d6563 .byte    0x5b, 0x4d, 0x65, 0x63
001017c8 68615d20 subshs   r6, sp, r8, ror #2
001017cc 25732829 stmdbhs  r8!, {r0, r2, r5, r8, sb, ip, sp, lr}
001017d0 0a000000 andeq    r0, r0, sl
001017d4 38402de9 push     {r3, r4, r5, lr}
001017d8 0040a0e1 mov      r4, r0
001017dc 00129fe5 ldr      r1, [pc, #0x200]
001017e0 24004fe2 sub      r0, pc, #0x24
001017e4 f2c803eb bl       #0x1f3bb4
001017e8 0010a0e3 mov      r1, #0
001017ec 00108de5 str      r1, [sp]
001017f0 be00d4e1 ldrh     r0, [r4, #0xe]
001017f4 0d20a0e1 mov      r2, sp
001017f8 0410a0e3 mov      r1, #4
001017fc 611600eb bl       #0x107188
00101800 dc119fe5 ldr      r1, [pc, #0x1dc]
00101804 520f4fe2 sub      r0, pc, #0x148
00101808 e9c803eb bl       #0x1f3bb4
0010180c 511f4fe2 sub      r1, pc, #0x144
00101810 130e4fe2 sub      r0, pc, #0x130
00101814 e6c803eb bl       #0x1f3bb4
00101818 4d0f4fe2 sub      r0, pc, #0x134
0010181c e4c803eb bl       #0x1f3bb4
00101820 0100a0e3 mov      r0, #1
00101824 3880bde8 pop      {r3, r4, r5, pc}
00101828 10402de9 push     {r4, lr}
0010182c 0040a0e1 mov      r4, r0
00101830 b0119fe5 ldr      r1, [pc, #0x1b0]
00101834 78004fe2 sub      r0, pc, #0x78
00101838 ddc803eb bl       #0x1f3bb4
0010183c 0400a0e1 mov      r0, r4
00101840 c5ffffeb bl       #0x10175c
00101844 0040a0e1 mov      r4, r0
00101848 0200a0e3 mov      r0, #2
0010184c 9d02feeb bl       #0x822c8
00101850 90119fe5 ldr      r1, [pc, #0x190]
00101854 660f4fe2 sub      r0, pc, #0x198
00101858 d5c803eb bl       #0x1f3bb4
0010185c 010054e3 cmp      r4, #1
00101860 661f4f02 subeq    r1, pc, #0x198
00101864 191e4f12 subne    r1, pc, #0x190
00101868 620f4fe2 sub      r0, pc, #0x188
0010186c d0c803eb bl       #0x1f3bb4
00101870 630f4fe2 sub      r0, pc, #0x18c
00101874 cec803eb bl       #0x1f3bb4
00101878 0400a0e1 mov      r0, r4
0010187c 1080bde8 pop      {r4, pc}
00101880 10402de9 push     {r4, lr}
00101884 0040a0e1 mov      r4, r0
00101888 5c119fe5 ldr      r1, [pc, #0x15c]
0010188c d0004fe2 sub      r0, pc, #0xd0
00101890 c7c803eb bl       #0x1f3bb4
00101894 0400a0e1 mov      r0, r4
00101898 cdffffeb bl       #0x1017d4
0010189c 0040a0e1 mov      r4, r0
001018a0 e3d900eb bl       #0x138034
001018a4 0200a0e3 mov      r0, #2
001018a8 9d02feeb bl       #0x82324
001018ac 38119fe5 ldr      r1, [pc, #0x138]
001018b0 7d0f4fe2 sub      r0, pc, #0x1f4
001018b4 bec803eb bl       #0x1f3bb4
001018b8 010054e3 cmp      r4, #1
001018bc 7d1f4f02 subeq    r1, pc, #0x1f4
001018c0 7b1f4f12 subne    r1, pc, #0x1ec
001018c4 790f4fe2 sub      r0, pc, #0x1e4
001018c8 b9c803eb bl       #0x1f3bb4
001018cc 7a0f4fe2 sub      r0, pc, #0x1e8
001018d0 b7c803eb bl       #0x1f3bb4
001018d4 0400a0e1 mov      r0, r4
001018d8 1080bde8 pop      {r4, pc}
001018dc 10402de9 push     {r4, lr}
001018e0 0040a0e1 mov      r4, r0
001018e4 04119fe5 ldr      r1, [pc, #0x104]
001018e8 4b0f4fe2 sub      r0, pc, #0x12c
001018ec b0c803eb bl       #0x1f3bb4
001018f0 0400a0e1 mov      r0, r4
001018f4 98ffffeb bl       #0x10175c
001018f8 0040a0e1 mov      r4, r0
001018fc 0300a0e3 mov      r0, #3
00101900 7002feeb bl       #0x822c8
00101904 e4109fe5 ldr      r1, [pc, #0xe4]
00101908 930f4fe2 sub      r0, pc, #0x24c
0010190c a8c803eb bl       #0x1f3bb4
00101910 010054e3 cmp      r4, #1
00101914 931f4f02 subeq    r1, pc, #0x24c
00101918 911f4f12 subne    r1, pc, #0x244
0010191c 8f0f4fe2 sub      r0, pc, #0x23c
00101920 a3c803eb bl       #0x1f3bb4
00101924 090d4fe2 sub      r0, pc, #0x240
00101928 a1c803eb bl       #0x1f3bb4
0010192c 0400a0e1 mov      r0, r4
00101930 1080bde8 pop      {r4, pc}
00101934 10402de9 push     {r4, lr}
00101938 0040a0e1 mov      r4, r0
0010193c b0109fe5 ldr      r1, [pc, #0xb0]
00101940 610f4fe2 sub      r0, pc, #0x184
00101944 9ac803eb bl       #0x1f3bb4
00101948 0400a0e1 mov      r0, r4
0010194c a0ffffeb bl       #0x1017d4
00101950 0040a0e1 mov      r4, r0
00101954 0300a0e3 mov      r0, #3
00101958 7102feeb bl       #0x82324
0010195c 90109fe5 ldr      r1, [pc, #0x90]
00101960 a90f4fe2 sub      r0, pc, #0x2a4
00101964 92c803eb bl       #0x1f3bb4
00101968 010054e3 cmp      r4, #1
0010196c a91f4f02 subeq    r1, pc, #0x2a4
00101970 a71f4f12 subne    r1, pc, #0x29c
00101974 a50f4fe2 sub      r0, pc, #0x294
00101978 8dc803eb bl       #0x1f3bb4
0010197c a60f4fe2 sub      r0, pc, #0x298
00101980 8bc803eb bl       #0x1f3bb4
00101984 0400a0e1 mov      r0, r4
00101988 1080bde8 pop      {r4, pc}
0010198c 10402de9 push     {r4, lr}
00101990 0040a0e1 mov      r4, r0
00101994 5c109fe5 ldr      r1, [pc, #0x5c]
00101998 5c008fe2 add      r0, pc, #0x5c
0010199c 84c803eb bl       #0x1f3bb4
001019a0 0400a0e1 mov      r0, r4
001019a4 6cffffeb bl       #0x10175c
001019a8 0040a0e1 mov      r4, r0
001019ac 0400a0e3 mov      r0, #4
001019b0 4402feeb bl       #0x822c8
001019b4 3c109fe5 ldr      r1, [pc, #0x3c]
001019b8 bf0f4fe2 sub      r0, pc, #0x2fc
001019bc 7cc803eb bl       #0x1f3bb4
001019c0 010054e3 cmp      r4, #1
001019c4 bf1f4f02 subeq    r1, pc, #0x2fc
001019c8 bd1f4f12 subne    r1, pc, #0x2f4
001019cc bb0f4fe2 sub      r0, pc, #0x2ec
001019d0 77c803eb bl       #0x1f3bb4
001019d4 2f0e4fe2 sub      r0, pc, #0x2f0
001019d8 75c803eb bl       #0x1f3bb4
001019dc 0400a0e1 mov      r0, r4
001019e0 1080bde8 pop      {r4, pc}
001019e4 37c78744 strmi    ip, [r7], #0x737
001019e8 4cc78744 strmi    ip, [r7], #0x74c
001019ec 68c78744 strmi    ip, [r7], #0x768
001019f0 85c78744 strmi    ip, [r7], #0x785
001019f4 a6c78744 strmi    ip, [r7], #0x7a6
001019f8 c8c78744 strmi    ip, [r7], #0x7c8
001019fc 5b4d6563 .byte    0x5b, 0x4d, 0x65, 0x63
00101a00 68615d20 subshs   r6, sp, r8, ror #2
00101a04 2573284b blmi     #0xb1e6a0
00101a08 75736174 strbtvc  r7, [r1], #-0x375
00101a0c 7375e69c stclls   p5, c7, [r6], #0x1cc
00101a10 aae5afbe cdplt    p5, #0xa, c14, c15, c10, #5
00101a14 e5bf9c28 ldmhs    ip, {r0, r2, r5, r6, r7, r8, sb, sl, fp, ip, sp, pc}
00101a18 43534943 movtmi   r5, #0x9343
00101a1c 2f494b53 movtpl   r4, #0xb92f
00101a20 29290a00 andeq    r2, sl, sb, lsr #18
00101a24 30402de9 push     {r4, r5, lr}
00101a28 0040a0e1 mov      r4, r0
00101a2c 20119fe5 ldr      r1, [pc, #0x120]
00101a30 0cd04de2 sub      sp, sp, #0xc
00101a34 40004fe2 sub      r0, pc, #0x40
00101a38 5dc803eb bl       #0x1f3bb4
00101a3c 0050a0e3 mov      r5, #0
00101a40 0400a0e1 mov      r0, r4
00101a44 0050cde5 strb     r5, [sp]
00101a48 61ffffeb bl       #0x1017d4
00101a4c 0040a0e1 mov      r4, r0
00101a50 77d900eb bl       #0x138034
00101a54 0400a0e3 mov      r0, #4
00101a58 3102feeb bl       #0x82324
00101a5c f4009fe5 ldr      r0, [pc, #0xf4]
00101a60 0d20a0e1 mov      r2, sp
00101a64 0110a0e3 mov      r1, #1
00101a68 531600eb bl       #0x1073bc
00101a6c 0010dde5 ldrb     r1, [sp]
00101a70 000051e3 cmp      r1, #0
00101a74 0700001a bne      #0x101a98
00101a78 d4109fe5 ldr      r1, [pc, #0xd4]
00101a7c d8009fe5 ldr      r0, [pc, #0xd8]
00101a80 0450cde5 strb     r5, [sp, #4]
00101a84 4ac803eb bl       #0x1f3bb4
00101a88 d0009fe5 ldr      r0, [pc, #0xd0]
00101a8c 04208de2 add      r2, sp, #4
00101a90 0110a0e3 mov      r1, #1
00101a94 bb1500eb bl       #0x107188
00101a98 b4109fe5 ldr      r1, [pc, #0xb4]
00101a9c 3e0e4fe2 sub      r0, pc, #0x3e0
00101aa0 43c803eb bl       #0x1f3bb4
00101aa4 010054e3 cmp      r4, #1
00101aa8 3e1e4f02 subeq    r1, pc, #0x3e0
00101aac f61f4f12 subne    r1, pc, #0x3d8
00101ab0 3d0e4fe2 sub      r0, pc, #0x3d0
00101ab4 3ec803eb bl       #0x1f3bb4
00101ab8 f50f4fe2 sub      r0, pc, #0x3d4
00101abc 3cc803eb bl       #0x1f3bb4
00101ac0 0400a0e1 mov      r0, r4
00101ac4 0cd08de2 add      sp, sp, #0xc
00101ac8 3080bde8 pop      {r4, r5, pc}
00101acc f8402de9 push     {r3, r4, r5, r6, r7, lr}
00101ad0 8c109fe5 ldr      r1, [pc, #0x8c]
00101ad4 c60f4fe2 sub      r0, pc, #0x318
00101ad8 35c803eb bl       #0x1f3bb4
00101adc d0741fe5 ldr      r7, [pc, #-0x4d0]
00101ae0 0160a0e3 mov      r6, #1
00101ae4 0040a0e3 mov      r4, #0
00101ae8 00608de5 str      r6, [sp]
00101aec 840084e0 add      r0, r4, r4, lsl #1
00101af0 805187e0 add      r5, r7, r0, lsl #3
00101af4 bc00d5e1 ldrh     r0, [r5, #0xc]
00101af8 d21600eb bl       #0x107648
00101afc 010050e3 cmp      r0, #1
00101b00 0400001a bne      #0x101b18
00101b04 be00d5e1 ldrh     r0, [r5, #0xe]
00101b08 0d20a0e1 mov      r2, sp
00101b0c 0410a0e3 mov      r1, #4
00101b10 9c1500eb bl       #0x107188
00101b14 0060a0e3 mov      r6, #0
00101b18 014084e2 add      r4, r4, #1
00101b1c 060054e3 cmp      r4, #6
00101b20 f1ffff3a blo      #0x101aec
00101b24 38109fe5 ldr      r1, [pc, #0x38]
00101b28 38009fe5 ldr      r0, [pc, #0x38]
00101b2c 20c803eb bl       #0x1f3bb4
00101b30 010056e3 cmp      r6, #1
00101b34 30108f02 addeq    r1, pc, #0x30
00101b38 38108f12 addne    r1, pc, #0x38
00101b3c 40008fe2 add      r0, pc, #0x40
00101b40 1bc803eb bl       #0x1f3bb4
00101b44 3c008fe2 add      r0, pc, #0x3c
00101b48 19c803eb bl       #0x1f3bb4
00101b4c 0600a0e1 mov      r0, r6
00101b50 f880bde8 pop      {r3, r4, r5, r6, r7, pc}
00101b54 e1c78744 strmi    ip, [r7], #0x7e1
00101b58 0df00000 andeq    pc, r0, sp
00101b5c f4c88744 strmi    ip, [r7], #0x8f4
00101b60 44500000 andeq    r5, r0, r4, asr #32
00101b64 fbc78744 strmi    ip, [r7], #0x7fb
00101b68 c4567044 ldrbtmi  r5, [r0], #-0x6c4
00101b6c 72657475 ldrbvc   r6, [r4, #-0x572]!
00101b70 726e3a4f svcmi    #0x3a6e72
00101b74 4b000000 andeq    r0, r0, fp, asr #32
00101b78 72657475 ldrbvc   r6, [r4, #-0x572]!
00101b7c 726e3a4e mrcmi    p14, #1, r6, c10, c2, #3
00101b80 47000000 andeq    r0, r0, r7, asr #32
00101b84 25730000 andeq    r7, r0, r5, lsr #6
00101b88 5d0a0000 andeq    r0, r0, sp, asr sl
00101b8c 70402de9 push     {r4, r5, r6, lr}
00101b90 78109fe5 ldr      r1, [pc, #0x78]
00101b94 f60f4fe2 sub      r0, pc, #0x3d8
00101b98 05c803eb bl       #0x1f3bb4
00101b9c 90651fe5 ldr      r6, [pc, #-0x590]
00101ba0 0040a0e3 mov      r4, #0
00101ba4 840084e0 add      r0, r4, r4, lsl #1
00101ba8 800186e0 add      r0, r6, r0, lsl #3
00101bac be00d0e1 ldrh     r0, [r0, #0xe]
00101bb0 a41600eb bl       #0x107648
00101bb4 010050e3 cmp      r0, #1
00101bb8 0050a0e1 mov      r5, r0
00101bbc 0700000a beq      #0x101be0
00101bc0 014084e2 add      r4, r4, #1
00101bc4 060054e3 cmp      r4, #6
00101bc8 f5ffff3a blo      #0x101ba4
00101bcc 000055e3 cmp      r5, #0
00101bd0 0200001a bne      #0x101be0
00101bd4 38009fe5 ldr      r0, [pc, #0x38]
00101bd8 9a1600eb bl       #0x107648
00101bdc 0050a0e1 mov      r5, r0
00101be0 28109fe5 ldr      r1, [pc, #0x28]
00101be4 84001fe5 ldr      r0, [pc, #-0x84]
00101be8 f1c703eb bl       #0x1f3bb4
00101bec 010055e3 cmp      r5, #1
00101bf0 20108f02 addeq    r1, pc, #0x20
00101bf4 24108f12 addne    r1, pc, #0x24
00101bf8 7c004fe2 sub      r0, pc, #0x7c
00101bfc ecc703eb bl       #0x1f3bb4
00101c00 80004fe2 sub      r0, pc, #0x80
00101c04 eac703eb bl       #0x1f3bb4
00101c08 0500a0e1 mov      r0, r5
00101c0c 7080bde8 pop      {r4, r5, r6, pc}
00101c10 15c88744 strmi    ip, [r7], #0x815
00101c14 33600000 andeq    r6, r0, r3, lsr r0
00101c18 54525545 ldrbmi   r5, [r5, #-0x254]
00101c1c 20000000 andeq    r0, r0, r0, lsr #32
00101c20 46414c53 movtpl   r4, #0xc146
00101c24 45000000 andeq    r0, r0, r5, asr #32
00101c28 70402de9 push     {r4, r5, r6, lr}
00101c2c 28119fe5 ldr      r1, [pc, #0x128]
00101c30 28019fe5 ldr      r0, [pc, #0x128]
00101c34 dec703eb bl       #0x1f3bb4
00101c38 2c001fe5 ldr      r0, [pc, #-0x2c]
00101c3c 0040a0e3 mov      r4, #0
00101c40 801600eb bl       #0x107648
00101c44 0050b0e1 movs     r5, r0
00101c48 3c661f05 ldreq    r6, [pc, #-0x63c]
00101c4c 0c00001a bne      #0x101c84
00101c50 840084e0 add      r0, r4, r4, lsl #1
00101c54 801186e0 add      r1, r6, r0, lsl #3
00101c58 040091e5 ldr      r0, [r1, #4]
00101c5c 010050e3 cmp      r0, #1
00101c60 0400001a bne      #0x101c78
00101c64 bc00d1e1 ldrh     r0, [r1, #0xc]
00101c68 761600eb bl       #0x107648
00101c6c 010050e3 cmp      r0, #1
00101c70 0050a0e1 mov      r5, r0
00101c74 0200000a beq      #0x101c84
00101c78 014084e2 add      r4, r4, #1
00101c7c 060054e3 cmp      r4, #6
00101c80 f2ffff3a blo      #0x101c50
00101c84 d0109fe5 ldr      r1, [pc, #0xd0]
00101c88 28011fe5 ldr      r0, [pc, #-0x128]
00101c8c c8c703eb bl       #0x1f3bb4
00101c90 010055e3 cmp      r5, #1
00101c94 84104f02 subeq    r1, pc, #0x84
00101c98 80104f12 subne    r1, pc, #0x80
00101c9c 120e4fe2 sub      r0, pc, #0x120
00101ca0 c3c703eb bl       #0x1f3bb4
00101ca4 490f4fe2 sub      r0, pc, #0x124
00101ca8 c1c703eb bl       #0x1f3bb4
00101cac 0500a0e1 mov      r0, r5
00101cb0 7080bde8 pop      {r4, r5, r6, pc}
00101cb4 f8402de9 push     {r3, r4, r5, r6, r7, lr}
00101cb8 0060a0e1 mov      r6, r0
00101cbc 0020a0e1 mov      r2, r0
00101cc0 9c109fe5 ldr      r1, [pc, #0x9c]
00101cc4 9c008fe2 add      r0, pc, #0x9c
00101cc8 b9c703eb bl       #0x1f3bb4
00101ccc 0100a0e3 mov      r0, #1
00101cd0 00008de5 str      r0, [sp]
00101cd4 a0009fe5 ldr      r0, [pc, #0xa0]
00101cd8 0040a0e3 mov      r4, #0
00101cdc bcf6ffeb bl       #0xff7d4
00101ce0 010050e3 cmp      r0, #1
00101ce4 d8561f15 ldrne    r5, [pc, #-0x6d8]
00101ce8 1300000a beq      #0x101d3c
00101cec 840084e0 add      r0, r4, r4, lsl #1
00101cf0 800185e0 add      r0, r5, r0, lsl #3
00101cf4 bc10d0e1 ldrh     r1, [r0, #0xc]
00101cf8 060051e1 cmp      r1, r6
00101cfc 0300001a bne      #0x101d10
00101d00 be00d0e1 ldrh     r0, [r0, #0xe]
00101d04 0d20a0e1 mov      r2, sp
00101d08 0410a0e3 mov      r1, #4
00101d0c 1d1500eb bl       #0x107188
00101d10 014084e2 add      r4, r4, #1
00101d14 060054e3 cmp      r4, #6
00101d18 f3ffff3a blo      #0x101cec
00101d1c 40109fe5 ldr      r1, [pc, #0x40]
00101d20 c0011fe5 ldr      r0, [pc, #-0x1c0]
00101d24 a2c703eb bl       #0x1f3bb4
00101d28 50008fe2 add      r0, pc, #0x50
00101d2c a0c703eb bl       #0x1f3bb4
00101d30 1b0e4fe2 sub      r0, pc, #0x1b0
00101d34 9ec703eb bl       #0x1f3bb4
00101d38 f880bde8 pop      {r3, r4, r5, r6, r7, pc}
00101d3c 20109fe5 ldr      r1, [pc, #0x20]
00101d40 e0011fe5 ldr      r0, [pc, #-0x1e0]
00101d44 9ac703eb bl       #0x1f3bb4
00101d48 34008fe2 add      r0, pc, #0x34
00101d4c 98c703eb bl       #0x1f3bb4
00101d50 1d0e4fe2 sub      r0, pc, #0x1d0
00101d54 96c703eb bl       #0x1f3bb4
00101d58 f880bde8 pop      {r3, r4, r5, r6, r7, pc}
00101d5c 2fc88744 strmi    ip, [r7], #0x82f
00101d60 c4577044 ldrbtmi  r5, [r0], #-0x7c4
00101d64 4dc88744 strmi    ip, [r7], #0x84d
00101d68 5b4d6563 .byte    0x5b, 0x4d, 0x65, 0x63
00101d6c 68615d20 subshs   r6, sp, r8, ror #2
00101d70 25732869 stmdbvs  r8!, {r0, r2, r5, r8, sb, ip, sp, lr}
00101d74 643a2564 strtvs   r3, [r5], #-0xa64
00101d78 290a0000 andeq    r0, r0, sb, lsr #20
00101d7c 0bf00000 andeq    pc, r0, fp
00101d80 00000000 andeq    r0, r0, r0
00101d84 e383a6e3 .byte    0xe3, 0x83, 0xa6, 0xe3
00101d88 83bce382 rschi    fp, r3, #0x8300
00101d8c b6e383bc stclt    p3, c14, [r3], {0xb6}
00101d90 e383a1e3 .byte    0xe3, 0x83, 0xa1, 0xe3
00101d94 83b3e383 .byte    0x83, 0xb3, 0xe3, 0x83
00101d98 86e3838a bhi      #0xfe1fabb8
00101d9c e383b3e3 .byte    0xe3, 0x83, 0xb3, 0xe3
00101da0 82b9e4b8 stmlt    r4!, {r1, r7, r8, fp, ip, sp, pc} ^
00101da4 ade381af svcge    #0x81e3ad
00101da8 e382a8e3 .byte    0xe3, 0x82, 0xa8, 0xe3
00101dac 83a9e383 .byte    0x83, 0xa9, 0xe3, 0x83
00101db0 bce9809a bls      #0xfe13c4a8
00101db4 e79fa5e3 .byte    0xe7, 0x9f, 0xa5, 0xe3
00101db8 8197e381 mvnhi    sb, r1, lsl #15
00101dbc aae38184 strhi    lr, [r1], #0x3aa
00101dc0 00000000 andeq    r0, r0, r0
00101dc4 70402de9 push     {r4, r5, r6, lr}
00101dc8 70109fe5 ldr      r1, [pc, #0x70]
00101dcc 74001fe5 ldr      r0, [pc, #-0x74]
00101dd0 77c703eb bl       #0x1f3bb4
00101dd4 c8571fe5 ldr      r5, [pc, #-0x7c8]
00101dd8 0040a0e3 mov      r4, #0
00101ddc 840084e0 add      r0, r4, r4, lsl #1
00101de0 800185e0 add      r0, r5, r0, lsl #3
00101de4 bc00d0e1 ldrh     r0, [r0, #0xc]
00101de8 161600eb bl       #0x107648
00101dec 010050e3 cmp      r0, #1
00101df0 0060a0e1 mov      r6, r0
00101df4 0200000a beq      #0x101e04
00101df8 014084e2 add      r4, r4, #1
00101dfc 060054e3 cmp      r4, #6
00101e00 f5ffff3a blo      #0x101ddc
00101e04 34109fe5 ldr      r1, [pc, #0x34]
00101e08 a8021fe5 ldr      r0, [pc, #-0x2a8]
00101e0c 68c703eb bl       #0x1f3bb4
00101e10 010056e3 cmp      r6, #1
00101e14 811f4f02 subeq    r1, pc, #0x204
00101e18 021c4f12 subne    r1, pc, #0x200
00101e1c 2a0e4fe2 sub      r0, pc, #0x2a0
00101e20 63c703eb bl       #0x1f3bb4
00101e24 a90f4fe2 sub      r0, pc, #0x2a4
00101e28 61c703eb bl       #0x1f3bb4
00101e2c 0600a0e1 mov      r0, r6
00101e30 7080bde8 pop      {r4, r5, r6, pc}
00101e34 08109fe5 ldr      r1, [pc, #8]
00101e38 08008fe2 add      r0, pc, #8
00101e3c 5cc703ea b        #0x1f3bb4
00101e40 66c88744 strmi    ip, [r7], #0x866
00101e44 7bc88744 strmi    ip, [r7], #0x87b
00101e48 5b4d6563 .byte    0x5b, 0x4d, 0x65, 0x63
00101e4c 68615d20 subshs   r6, sp, r8, ror #2
00101e50 25733a20 eorshs   r7, sl, r5, lsr #6
00101e54 200a0000 andeq    r0, r0, r0, lsr #20
00101e58 d0229fe5 ldr      r2, [pc, #0x2d0]
00101e5c 0010a0e3 mov      r1, #0
0007e1e0 73d605ea b        #0x1f3bb4
0007e1e4 70402de9 push     {r4, r5, r6, lr}
0007e1e8 0050a0e1 mov      r5, r0
0007e1ec 24119fe5 ldr      r1, [pc, #0x124]
0007e1f0 e00c1fe5 ldr      r0, [pc, #-0xce0]
0007e1f4 0040a0e3 mov      r4, #0
0007e1f8 0160a0e3 mov      r6, #1
0007e1fc 6cd605eb bl       #0x1f3bb4
0007e200 0600a0e1 mov      r0, r6
0007e204 0b0d02eb bl       #0x101638
0007e208 010050e3 cmp      r0, #1
0007e20c 0140a013 movne    r4, #1
0007e210 000054e3 cmp      r4, #0
0007e214 0110a013 movne    r1, #1
0007e218 0010a003 moveq    r1, #0
0007e21c 0500a0e1 mov      r0, r5
0007e220 39f2ffeb bl       #0x7ab0c
0007e224 ec109fe5 ldr      r1, [pc, #0xec]
0007e228 e80d1fe5 ldr      r0, [pc, #-0xde8]
0007e22c 60d605eb bl       #0x1f3bb4
0007e230 0410a0e1 mov      r1, r4
0007e234 df0f4fe2 sub      r0, pc, #0x37c
0007e238 5dd605eb bl       #0x1f3bb4
0007e23c 7040bde8 pop      {r4, r5, r6, lr}
0007e240 e30f4fe2 sub      r0, pc, #0x38c
0007e244 5ad605ea b        #0x1f3bb4
0007e248 70402de9 push     {r4, r5, r6, lr}
0007e24c 0060a0e1 mov      r6, r0
0007e250 c4109fe5 ldr      r1, [pc, #0xc4]
0007e254 440d1fe5 ldr      r0, [pc, #-0xd44]
0007e258 0040a0e3 mov      r4, #0
0007e25c 0150a0e3 mov      r5, #1
0007e260 53d605eb bl       #0x1f3bb4
0007e264 0500a0e1 mov      r0, r5
0007e268 200d02eb bl       #0x1016f0
0007e26c 010050e3 cmp      r0, #1
0007e270 0200001a bne      #0x7e280
0007e274 a11902eb bl       #0x104900
0007e278 010050e3 cmp      r0, #1
0007e27c 0000000a beq      #0x7e284
0007e280 0140a0e3 mov      r4, #1
0007e284 000054e3 cmp      r4, #0
0007e288 0110a013 movne    r1, #1
0007e28c 0010a003 moveq    r1, #0
0007e290 0600a0e1 mov      r0, r6
0007e294 1cf2ffeb bl       #0x7ab0c
0007e298 7c109fe5 ldr      r1, [pc, #0x7c]
0007e29c 5c0e1fe5 ldr      r0, [pc, #-0xe5c]
0007e2a0 43d605eb bl       #0x1f3bb4
0007e2a4 0410a0e1 mov      r1, r4
0007e2a8 3f0e4fe2 sub      r0, pc, #0x3f0
0007e2ac 40d605eb bl       #0x1f3bb4
0007e2b0 7040bde8 pop      {r4, r5, r6, lr}
0007e2b4 010b4fe2 sub      r0, pc, #0x400
0007e2b8 3dd605ea b        #0x1f3bb4
0007e2bc 10402de9 push     {r4, lr}
0007e2c0 0040a0e1 mov      r4, r0
0007e2c4 54109fe5 ldr      r1, [pc, #0x54]
0007e2c8 b80d1fe5 ldr      r0, [pc, #-0xdb8]
0007e2cc 38d605eb bl       #0x1f3bb4
0007e2d0 5c8201eb bl       #0xdec48
0007e2d4 0400a0e1 mov      r0, r4
0007e2d8 ce7606eb bl       #0x21be18
0007e2dc 3c109fe5 ldr      r1, [pc, #0x3c]
0007e2e0 a00e1fe5 ldr      r0, [pc, #-0xea0]
0007e2e4 32d605eb bl       #0x1f3bb4
0007e2e8 34008fe2 add      r0, pc, #0x34
0007e2ec 30d605eb bl       #0x1f3bb4
0007e2f0 1040bde8 pop      {r4, lr}
0007e2f4 2c008fe2 add      r0, pc, #0x2c
0007e2f8 2dd605ea b        #0x1f3bb4
0007e2fc 11df8544 strmi    sp, [r5], #0xf11
0007e300 2adf8544 strmi    sp, [r5], #0xf2a
0007e304 30600000 andeq    r6, r0, r0, lsr r0
0007e308 3edf8544 strmi    sp, [r5], #0xf3e
0007e30c 53df8544 strmi    sp, [r5], #0xf53
0007e310 31600000 andeq    r6, r0, r1, lsr r0
0007e314 6edf8544 strmi    sp, [r5], #0xf6e
0007e318 8adf8544 strmi    sp, [r5], #0xf8a
0007e31c 9fdf8544 strmi    sp, [r5], #0xf9f
0007e320 b5df8544 strmi    sp, [r5], #0xfb5
0007e324 00000000 andeq    r0, r0, r0
0007e328 5d0a0000 andeq    r0, r0, sp, asr sl
0007e32c 70402de9 push     {r4, r5, r6, lr}
0007e330 0050a0e1 mov      r5, r0
0007e334 44109fe5 ldr      r1, [pc, #0x44]
0007e338 280e1fe5 ldr      r0, [pc, #-0xe28]
0007e33c 1cd605eb bl       #0x1f3bb4