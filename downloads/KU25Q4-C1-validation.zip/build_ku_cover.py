"""KU25Q4: only the two non-interlock ink-cartridge cover status paths."""
from pathlib import Path
import hashlib,json,struct
from build_ku_stage1 import P,BASE,word,branch
SOURCE='2c23dd32742e4060cdeb1c9e20a9da49d6d54072094d1e4eb0082826f7661453'
QUERY=0x107648;GATE=0x2ba30
INK_IDS=(0x6009,0x600a,0x602f,0x6030)
sha=lambda b:hashlib.sha256(b).hexdigest()
def movw(reg,value):return word(0xe3000000|((value&0xf000)<<4)|(reg<<12)|(value&0xfff))
def build():
 source=(P/'KU25Q4-S2-control.bin').read_bytes();assert sha(source)==SOURCE;code=bytearray(source);patches=[]
 def put(off,old,new,why):
  assert len(old)==len(new) and code[off:off+len(old)]==old,(hex(off),code[off:off+len(old)].hex(),old.hex())
  code[off:off+len(old)]=new;patches.append({'address':hex(BASE+off),'offset':hex(off),'before':old.hex(),'after':new.hex(),'reason':why})
 table=0x278668;records=[]
 for i in range(6):
  fields=struct.unpack_from('<6I',source,table+i*24);records.append({'type':fields[0],'interlock_flag':fields[1],'sensor_status_id':hex(fields[3]&65535),'state_id':hex(fields[3]>>16),'open_callback':hex(fields[4]),'close_callback':hex(fields[5])})
 assert records[0]['interlock_flag']==1
 assert records[2]['type']==2 and records[2]['interlock_flag']==0 and records[2]['sensor_status_id']=='0x602f' and records[2]['state_id']=='0x6009'
 assert records[3]['type']==3 and records[3]['interlock_flag']==0 and records[3]['sensor_status_id']=='0x6030' and records[3]['state_id']=='0x600a'
 # Reuse only the now-retired ink-cover aggregate body. No outside interior refs.
 for off in range(0,len(source)-4,4):
  w=struct.unpack_from('<I',source,off)[0]
  if w>>25&7==5:
   v=w&0xffffff;v-=1<<24 if v&(1<<23) else 0;t=off+8+v*4
   assert not (GATE<=t<0x2ba74 and not 0x2ba28<=off<0x2ba74),(hex(off),hex(t))
  assert not BASE+GATE<=w<BASE+0x2ba74
 # Read/filter only the exact ink status IDs. Every other ID executes its native prologue/body.
 gate=bytearray();return0=GATE+56
 for ident in INK_IDS:
  gate+=movw(12,ident)+word(0xe150000c)+branch(GATE+len(gate)+8,return0,cond=0)
 gate+=source[QUERY:QUERY+4]+branch(GATE+52,QUERY+4)+word(0xe3a00000)+word(0xe12fff1e)
 assert len(gate)==64
 put(0x2ba28,source[0x2ba28:0x2ba30],word(0xe3a00001)+word(0xe12fff1e),'The ink-cover-only two-bank aggregate reports closed/ready')
 put(GATE,source[GATE:GATE+64],bytes(gate),'Return closed only for four confirmed non-interlock ink-cover sensor/state IDs')
 put(QUERY,source[QUERY:QUERY+4],branch(QUERY,GATE),'Route status queries through the exact ink-cover ID filter')
 put(0x2b9c4,word(0xe7d00004),word(0xe3a00000),'Left/right cached ink-cover getter returns closed')
 put(0x2b9e0,word(0xe1a05001),word(0xe3a05000),'Left/right ink-cover setter stores closed in the original two-byte array')
 for off,target,name in ((0x101828,0x101880,'left/home'),(0x1018dc,0x101934,'right/full')):
  put(off,word(0xe92d4010),branch(off,target),f'Non-interlock ink {name} open callback follows its original corresponding close callback')
 # Preserve the actual interlock classification, checker, emergency-stop logic and other cover families.
 for lo,hi in ((table,table+6*24),(0x101c28,0x101cb4),(0x101cb4,0x101d5c),(0x31bdc,0x31ca0)):
  assert code[lo:hi]==source[lo:hi]
 allowed={i for r in patches for i in range(int(r['offset'],16),int(r['offset'],16)+len(bytes.fromhex(r['after'])))}
 diffs=[i for i,(a,b) in enumerate(zip(source,code)) if a!=b];assert set(diffs)<=allowed
 manifest={'label':'KU25Q4-S2-LOONA-ink-cover-closed','source_S2_module_sha256':SOURCE,'module_sha256':sha(code),'ink_cover_types':[2,3],'ink_cover_status_ids':[hex(x) for x in INK_IDS],'cover_records_original_and_unchanged':records,'patches':patches,'changed_bytes':len(diffs),'actual_interlock_checker_byte_identical':True,'emergency_stop_handler_byte_identical':True,'maintenance_cover_functions_byte_identical':True,'physical_tested':False,'scope':'Two non-interlock ink-cartridge cover status paths only; actual motion/protective cover functions are not changed.'}
 (P/'KU25Q4-cover-control.bin').write_bytes(code);(P/'KU25Q4-cover-patches.json').write_text(json.dumps(manifest,indent=2)+'\n');return bytes(code),manifest
if __name__=='__main__':
 _,r=build();print(json.dumps({k:v for k,v in r.items() if k!='patches'},indent=2))
