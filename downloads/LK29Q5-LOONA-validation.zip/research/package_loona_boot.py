"""Package user-supplied exact logo pixels onto known E/F1 baselines."""
import hashlib
import json
import struct
import zipfile
from pathlib import Path
from PIL import Image
from decode_crom import ROOT, decode
from audit_boot_logo import START, NEXT, PIXELS, sha
from replace_boot_logo_resource import replace
from audit_recovery_failure import loader_audit, checksum_audit


def main():
    source = ROOT / 'research-assets/boot-logo/loona-source.png'
    image = Image.open(source).convert('RGBA')
    assert image.size == (480, 272)
    rgba = image.tobytes()
    argb = bytearray(PIXELS)
    for destination, origin in enumerate((3, 0, 1, 2)):
        argb[destination::4] = rgba[origin::4]
    official = (ROOT / 'FW7560TL.rcx').read_bytes()
    slot, pixel_report = replace(official, bytes(argb))
    expected, _ = decode(b'CROM' + slot[4:], 0)
    preview = Image.frombytes('RGBA', (480, 272), expected[:PIXELS], 'raw', 'ARGB')
    assert preview.tobytes() == rgba
    preview.save(ROOT / 'research-assets/boot-logo/loona-decoded-preview.png')
    frame_end = 4 + int.from_bytes(slot[6:10], 'big')
    loader = loader_audit('LOONA-boot-resource', slot[:frame_end],
                          official[0x25bb23:0x25bb23+0xae8], expected)
    assert loader['native_lz_output_exact'] and loader['native_dma_mod48'] == 0
    receiver = (ROOT / 'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
    reports = []
    for variant, stem, digest in [
        ('E', 'FW7560TL_LK29Q5-startup-E-zero-new-consumption',
         '6dcd7e3e62f43af50cc2fb3f4f0cf623a8ee21d0603c4dc4e833d90374aee766'),
        ('F1', 'FW7560TL_LK29Q5-startup-F1-profile-exemption',
         '9687f463b43d9fa6a597c1a93c2c56ada687cb967adac8b4dc096a7e60325da1'),
    ]:
        baseline = ROOT / 'experimental' / (stem + '.efu')
        assert sha(baseline.read_bytes()) == digest
        with zipfile.ZipFile(baseline) as archive:
            entry = archive.getinfo('FW7560TL.rcx')
            old = archive.read(entry)
        updated = bytearray(old)
        updated[START:NEXT] = slot
        sign = old.index(b'EPSONSIGN')
        body = sign + 4096
        assert struct.unpack_from('<I', old, sign + 16)[0] == len(old) - body + 1
        metadata = struct.unpack_from('<I', old, body + 28)[0]
        size = struct.unpack_from('<I', old, body + 64)[0]
        begin = body + 4096 + metadata
        end = begin + size
        assert begin <= START < NEXT <= end
        struct.pack_into('<H', updated, body + 54, sum(updated[begin:end]) & 65535)
        updated[body+68:body+88] = hashlib.sha1(
            updated[begin:end] + hashlib.sha1(updated[body:body+14]).digest()).digest()
        allowed = sorted([(START, NEXT), (body+54, body+56), (body+68, body+88)])
        previous = 0
        for lo, hi in allowed:
            assert old[previous:lo] == updated[previous:lo]
            previous = hi
        assert old[previous:] == updated[previous:] and len(old) == len(updated)
        assert old[0x11153:0x11193] == updated[0x11153:0x11193]
        assert old[sign+32:sign+96] == updated[sign+32:sign+96]
        sections = []
        pos = body
        while pos < len(updated):
            header = updated[pos:pos+4096]
            assert header.startswith(b'EPSON')
            meta = struct.unpack_from('<I', header, 28)[0]
            length = struct.unpack_from('<I', header, 64)[0]
            start = pos + 4096 + meta
            finish = start + length
            assert finish <= len(updated)
            assert sum(updated[pos+4096:start]) & 65535 == struct.unpack_from('<H', header, 18)[0]
            assert sum(updated[start:finish]) & 65535 == struct.unpack_from('<H', header, 54)[0]
            assert hashlib.sha1(updated[start:finish] + hashlib.sha1(header[:14]).digest()).digest() == header[68:88]
            sections.append({'offset': hex(pos), 'checks_passed': True})
            pos = finish
        assert len(sections) == 4 and pos == len(updated)
        print('Native payload checksum', variant, flush=True)
        checksum = checksum_audit('LOONA-'+variant, bytes(updated),
                                  receiver[0x4419e2e0-0x4409b000:0x4419e324-0x4409b000])
        assert checksum['native_checksum_return'] == 1
        output = ROOT / 'experimental' / f'FW7560TL_LK29Q5-LOONA-{variant}.efu'
        with zipfile.ZipFile(output, 'w') as archive:
            archive.writestr(entry, updated)
        with zipfile.ZipFile(output) as archive:
            assert archive.testzip() is None
            assert archive.read('FW7560TL.rcx') == updated
        report = dict(
            variant=variant, artifact=output.name, efu_sha256=sha(output.read_bytes()),
            rcx_sha256=sha(updated), baseline_efu_sha256=digest,
            source_png_sha256=sha(source.read_bytes()), exact_source_pixels=True,
            original_code_and_data_tail_preserved=True,
            maintenance_module_and_other_modules_unchanged_from_baseline=True,
            changes_vs_baseline='Logo slot and first-section payload sum/SHA1 only',
            declared_body_length=struct.unpack_from('<I', updated, sign+16)[0],
            actual_body_length=len(updated)-body,
            original_key_and_signature_bytes_preserved=True,
            ecdsa_signature_valid_after_modification=False,
            host_sections=sections, native_checksum=checksum,
            native_logo_loader=loader, resource=pixel_report,
            hardware_tested=False, full_upper_receiver_replay=False,
            limits=['No physical boot, panel controller, USB updater or flash test',
                    'Hardware Huffman modeled at completion boundary',
                    'Prior E/F1 tests do not prove the combined logo artifact boots',
                    'No ink-cartridge feature or cover-sensor modification included'])
        report_path = output.with_suffix('.validation.json')
        report_path.write_text(json.dumps(report, indent=2) + '\n')
        Path(str(output)+'.sha256').write_text(report['efu_sha256']+'  '+output.name+'\n')
        reports.append(report)
        print('PASS', variant, report['efu_sha256'], flush=True)
    (ROOT/'validation/loona-boot-packages.json').write_text(json.dumps(reports, indent=2)+'\n')


if __name__ == '__main__':
    main()
