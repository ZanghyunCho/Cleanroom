"""Extract and round-trip the original early display resource. No EFU emitted."""
import hashlib
import json
from pathlib import Path
from decode_crom import ROOT, decode
from encode_crom import encode
from PIL import Image

START, NEXT = 0x21b553, 0x21f553
WIDTH, HEIGHT = 480, 272
PIXELS = WIDTH * HEIGHT * 4


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    rcx = (ROOT / 'FW7560TL.rcx').read_bytes()
    assert sha(rcx) == '5a8c9ff4c942e436e7ab9da60237dd7d60587715071d748a58c90fe20ca557b1'
    original, decoded = decode(rcx, START)
    assert len(original) == 523120
    assert sha(original) == 'b1974aa39932de0523e77bda2075b0255dd146d3b1a49d0a69774ca6c51a0024'
    assert all(original[i] == 255 for i in range(0, PIXELS, 4))
    end = int(decoded['container_end'], 16)
    assert rcx[end:NEXT] == b'\xff' * (NEXT - end)
    folder = ROOT / 'research-assets/boot-logo'
    folder.mkdir(exist_ok=True, parents=True)
    preview = folder / 'epson-boot-original.png'
    Image.frombytes('RGBA', (WIDTH, HEIGHT), original[:PIXELS], 'raw', 'ARGB').save(preview)
    frame, compression = encode(original, rcx[START:end], positive_padding=True,
                                restrict_to_template_symbols=True)
    restored, _ = decode(frame, 0)
    assert restored == original
    assert len(frame) <= NEXT - START
    (folder / 'epson-boot-original.argb').write_bytes(original[:PIXELS])
    report = {
        'original_rcx_sha256': sha(rcx), 'resource_rcx_offset': hex(START),
        'resource_flash_offset_inferred': '0x277400',
        'next_initialized_data_flash_offset': '0x27b400',
        'loader_literal_rcx_offset': '0xa3bf',
        'resource_sha256': sha(original), 'decoded_size': len(original),
        'width': WIDTH, 'height': HEIGHT, 'pixel_format': 'A,R,G,B bytes; alpha=255',
        'pixel_size': PIXELS, 'following_code_and_data_size': len(original) - PIXELS,
        'following_code_and_data_sha256': sha(original[PIXELS:]),
        'original_frame_size': end - START, 'allocated_frame_space': NEXT - START,
        'reencoded_original_frame_size': len(frame), 'compression': compression,
        'original_resource_roundtrip_exact': True,
        'preview': str(preview.relative_to(ROOT)),
        'boot_screen_visual_match': 'Extracted EPSON on white; agrees with user photo',
        'replacement_image_bytes_available': (folder / 'loona-source.png').is_file(),
        'firmware_generated': False, 'hardware_tested': False,
        'limits': ['No physical boot test or complete loader replay',
                   'Roundtrip is software Huffman/LZ verification, not hardware decompression'],
    }
    output = ROOT / 'validation/boot-logo-audit.json'
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(output)
    print(f'Original {WIDTH}x{HEIGHT} ARGB resource verified; {len(original)-PIXELS} trailing bytes preserved')


if __name__ == '__main__':
    main()
