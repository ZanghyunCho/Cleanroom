"""Build an isolated CROM replacement from an exact 480x272 ARGB buffer.

The input must be rendered from the user's actual source artwork. This tool
does not redraw logos or emit a flashable EFU. Code/data following the pixels
and bytes outside the 16 KiB resource slot remain identical.
"""
import argparse
import json
from pathlib import Path
from audit_boot_logo import START, NEXT, WIDTH, HEIGHT, PIXELS, sha
from decode_crom import ROOT, decode
from encode_crom import encode


def replace(rcx, argb):
    if len(argb) != PIXELS or any(argb[i] != 255 for i in range(0, PIXELS, 4)):
        raise ValueError('Expected opaque 480x272 A,R,G,B bytes')
    original, info = decode(rcx, START)
    if sha(original) != 'b1974aa39932de0523e77bda2075b0255dd146d3b1a49d0a69774ca6c51a0024':
        raise ValueError('Unrecognized original logo resource')
    end = int(info['container_end'], 16)
    if rcx[end:NEXT] != bytes([255]) * (NEXT - end):
        raise ValueError('Resource padding contains unrecognized data')
    replacement = argb + original[PIXELS:]
    frame, compression = encode(replacement, rcx[START:end],
                                positive_padding=True,
                                restrict_to_template_symbols=True)
    if len(frame) > NEXT - START:
        raise ValueError('Replacement exceeds the original 16 KiB slot')
    result = bytearray(rcx)
    result[START:NEXT] = frame + bytes([255]) * (NEXT - START - len(frame))
    assert result[:START] == rcx[:START] and result[NEXT:] == rcx[NEXT:]
    restored, _ = decode(result, START)
    assert restored[:PIXELS] == argb and restored[PIXELS:] == original[PIXELS:]
    return bytes(result[START:NEXT]), dict(
        width=WIDTH, height=HEIGHT, raw_image_sha256=sha(argb),
        resource_sha256=sha(restored), compression=compression,
        trailing_code_and_data_preserved=True,
        bytes_outside_resource_slot_preserved=True,
        efu_generated=False, hardware_tested=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--argb', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True,
                        help='Resource slot only, NOT an EFU or SPI image')
    args = parser.parse_args()
    rcx = (ROOT / 'FW7560TL.rcx').read_bytes()
    if sha(rcx) != '5a8c9ff4c942e436e7ab9da60237dd7d60587715071d748a58c90fe20ca557b1':
        raise ValueError('Unrecognized original RCX')
    slot, report = replace(rcx, args.argb.read_bytes())
    args.output.write_bytes(slot)
    args.output.with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
    print(f'{args.output}: resource only; not installable')


if __name__ == '__main__':
    main()
