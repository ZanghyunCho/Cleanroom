"""Compare I2 with original I1 after the specific non-logo acknowledgement."""
import json,struct
from build_ink_i2 import build,ROOT
from build_ink_i1 import build as build_i1
from verify_ink_i1 import verify as verify_i1
from probe_maintenance_state import Control
from unicorn.arm_const import UC_ARM_REG_R2

def bit(n,record,slot,value):
    n.u.reg_write(UC_ARM_REG_R2,value);n.call(0x433f60e0,record,slot)

def setup(code,flag8,flag16,ack29):
    n=Control(code);n.u.mem_write(n.literal(0x433f6378,0x27c),bytes(8))
    meta=n.literal(0x43403788,-0x1e4)
    error=n.literal(0x43403c74,-0x6cc)
    n.u.mem_write(error,bytes([64])*12)
    for slot in range(12):
        n.u.mem_write(meta+20*slot+8,struct.pack('<I',flag8))
        n.u.mem_write(meta+20*slot+16,struct.pack('<I',flag16))
        bit(n,0x29,slot,ack29)
    return n

def result(n,slot):return (n.call(0x43403c04,slot),n.call(0x43403330,slot))

def main():
    code,manifest=build();i1,_=build_i1();regression=verify_i1(code,manifest)
    assert regression['scenario_count']==1671
    matrix=[]
    for flag8 in (0,1):
        for flag16 in (0,1):
            for ack29 in (0,1):
                for slot in range(12):
                    reference=setup(i1,flag8,flag16,ack29)
                    bit(reference,0x28,slot,1)
                    candidate=setup(code,flag8,flag16,ack29)
                    error_pointer=candidate.literal(0x43403c74,-0x6cc)
                    ref_error=reference.literal(0x43403c74,-0x6cc)
                    for incoming in range(70):
                        candidate.u.mem_write(error_pointer+slot,b'\x40')
                        reference.u.mem_write(ref_error+slot,b'\x40')
                        candidate.call(0x43403c10,slot,incoming)
                        reference.call(0x43403c10,slot,incoming)
                        actual=result(candidate,slot);expected=result(reference,slot)
                        assert actual==expected,(slot,incoming,flag8,flag16,ack29,actual,expected)
                        matrix.append(dict(slot=slot,incoming=incoming,metadata8=flag8,metadata16=flag16,
                                           other_approval29=ack29,selected_error=actual[0],raw_state=actual[1]))
    protected=[]
    for slot in range(12):
        for error in range(64):
            n=setup(code,1,1,0)
            n.u.mem_write(n.literal(0x43403c74,-0x6cc)+slot,bytes([error]))
            ptr=n.literal(0x43403330,0x280);n.u.mem_write(ptr+slot,b'\x04')
            before=result(n,slot);n.call(0x43403c10,slot,64)
            assert result(n,slot)==before
            protected.append(dict(slot=slot,latched_error=error,raw_state_unchanged=True))
    # Repeated jobs with approval reset: I1 re-raises 0x43, I2 remains equivalent
    # to the actual original acknowledgement routine, not just a changed UI byte.
    cycles=[]
    old=setup(i1,1,0,0);new=setup(code,1,0,0)
    for job in range(10):
        for n in (old,new):
            bit(n,0x28,0,0)
            n.u.mem_write(n.literal(0x43403c74,-0x6cc),b'\x40')
            n.call(0x43403c10,0,64)
        assert result(old,0)==(67,10)
        assert result(new,0)==(64,0)
        old.call(0x4340fdb4)
        assert result(old,0)==result(new,0)
        cycles.append(dict(job=job,I1_before_ack=[67,10],I1_after_original_ack=list(result(old,0)),I2=list(result(new,0))))
    report=dict(module_sha256=manifest['module_sha256'],scenario_count=1671+len(matrix)+len(protected)+1,
                I1_regressions=regression,approval_matrix=matrix,protected_errors=protected,repeated_job_sequence=cycles,
                native_verdict_hooks=0,physical_tested=False,
                discovered_chain='AcceptNoLogoInk -> RPC command 0x23 -> 0x43411030 -> original 0x4340fdb4 -> approval record 0x28',
                limitations=['Synthetic metadata and job cycles, not physical printing',
                    'Other warning/compatibility conditions and explicit errors remain',
                    'Actual UI confirmation suppression needs a printer test'])
    assert report['scenario_count']==9160
    (ROOT/'validation/ink-I2-native-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS I2',report['scenario_count'],'cases; original acknowledgement matches 10 repeated synthetic jobs')

if __name__=='__main__':main()
