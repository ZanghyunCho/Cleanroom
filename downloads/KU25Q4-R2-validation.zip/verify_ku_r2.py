import hashlib,itertools,struct
from build_ku_r2 import build,GET40
from build_ku_r1 import build as build_r1
from verify_ku_r1 import verify as verify_r1
from verify_ku_stage1 import Machine
from verify_ku_stage2 import seedpair,call40,SET40,ADD40

def verify(code):
 expected,manifest=build();assert code==expected;r1,_=build_r1()
 # Existing R1 verifier checks byte identity, so execute its independent tests on R1,
 # then run the same S1 regression suite and percentage checks on this candidate.
 from verify_ku_stage1 import verify as verify_s1
 report=verify_s1(code)
 for slot in range(10):assert Machine(code).call(0x2ae88,slot)==100
 counts={'S1_regressions':report['executed_scenarios'],'R1_percentage':10}
 a,b=Machine(r1),Machine(code);cases=[]
 pairs=((0x22,0x23),(0x24,0x25),(0x30,0x31),(0x22,0x25),(0x24,0x23))
 for pair,slot,low,high,fn in itertools.product(pairs,range(10),(0,123,0xffffffff),(0,255),(GET40,SET40,ADD40)):
  for m in (a,b):seedpair(m,pair,slot,low,high)
  before_a=a.read(0x44900000,0x100000);before_b=b.read(0x44900000,0x100000)
  ra=call40(a,fn,pair,slot,17,1);rb=call40(b,fn,pair,slot,17,1)
  after_a=a.read(0x44900000,0x100000);after_b=b.read(0x44900000,0x100000)
  assert after_a==after_b
  if fn==GET40:
   assert before_a==after_a and before_b==after_b
   assert rb==((0,0) if pair==(0x22,0x23) else ra)
  else:assert rb==ra
  assert a.read(0x421ff000,8)==b.read(0x421ff000,8)==struct.pack('<II',17,1)
  cases.append({'pair':list(pair),'slot':slot,'low':low,'high':high,'function':hex(fn),'R1_return':ra,'R2_return':rb,'RAM_matches_R1':True})
 counts['ledger_read_and_write_regressions']=len(cases)
 return {'module_sha256':hashlib.sha256(code).hexdigest(),'executed_scenarios':sum(counts.values()),'case_counts':counts,'cases':cases,'scope':manifest,'native_verdict_hooks':0,'hardware_boot_print_tested':False}
