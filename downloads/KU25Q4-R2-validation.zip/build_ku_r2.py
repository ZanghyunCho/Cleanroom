"""R2 diagnostic: only read result for ledger pair 22/23 is zero; storage untouched."""
import hashlib,struct
from build_ku_r1 import build as build_r1
from build_ku_stage1 import P,BASE,branch,word
GET40=0x13df0;GATE=0x2ae90

def build():
 r1,_=build_r1();assert hashlib.sha256(r1).hexdigest()=='31f34f7672f74033e4e72e07aaec29c09e95397ef56b0f48af80f5c3a042877d'
 code=bytearray(r1)
 helper=b''.join(map(word,[0xe3500022,0x03510023,0x03a00000,0x03a01000,0x012fff1e]))+r1[GET40:GET40+4]+branch(GATE+24,GET40+4)
 assert len(helper)==28 and r1[GET40:GET40+4]==word(0xe92d40f0)
 # The helper uses the retired percentage body, after R1's unconditional return.
 for off in range(0,len(r1)-4,4):
  w=struct.unpack_from('<I',r1,off)[0]
  if w>>25&7==5:
   d=w&0xffffff;d-=1<<24 if d&0x800000 else 0;t=off+8+d*4
   assert not (GATE<=t<GATE+28 and not 0x2ae88<=off<0x2afb8)
  assert not BASE+GATE<=w<BASE+GATE+28
 code[GET40:GET40+4]=branch(GET40,GATE);code[GATE:GATE+28]=helper
 ranges=[(GET40,GET40+4),(GATE,GATE+28)]
 assert all(any(lo<=i<hi for lo,hi in ranges) for i,(a,b) in enumerate(zip(r1,code)) if a!=b)
 manifest={'label':'KU25Q4-R2-primary-usage-read-only','baseline':'R1 user reports boot, printing and percentage 100 passed','baseline_module_sha256':hashlib.sha256(r1).hexdigest(),'module_sha256':hashlib.sha256(code).hexdigest(),'change_ranges_vs_R1':[[hex(a),hex(b)] for a,b in ranges],'zero_read_pair':['0x22','0x23'],'zero_result_registers':['r0','r1'],'stored_usage_changed':False,'set_add_functions_changed':False,'other_usage_pairs_changed':False,'hardware_boot_print_tested':False,'complete_zero_usage_implementation':False,'chipless_support':False}
 (P/'KU25Q4-R2-control.bin').write_bytes(code)
 return bytes(code),manifest
