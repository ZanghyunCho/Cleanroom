import hashlib
from build_ku_r1 import build
from build_ku_stage1 import build as build_s1
from verify_ku_stage1 import verify as verify_s1,Machine

def verify(code):
 expected,manifest=build();s1,_=build_s1();assert code==expected
 assert code[:0x2ae88]==s1[:0x2ae88] and code[0x2ae90:]==s1[0x2ae90:]
 report=verify_s1(code)
 for slot in range(10):
  m=Machine(code)
  before=m.read(0x44900000,0x100000)
  assert m.call(0x2ae88,slot)==100
  assert m.read(0x44900000,0x100000)==before
 report['case_counts']['R1_ink_percentage_and_RAM_preservation']=10
 report['executed_scenarios']+=10
 report['module_sha256']=hashlib.sha256(code).hexdigest()
 report['R1_scope']=manifest
 return report
