"""KU25Q4 stage 1: maintenance accounting IDs only, two configured slots."""
from pathlib import Path
import hashlib,json,struct
P=Path(__file__).resolve().parent;BASE=0x44604000;SOURCE='e6c02c744d84e50bebc97dc2f348525d58ddd290e011f7133fd0567a06263288'
GET,SET,ADD=0x13aec,0x13b94,0x13d24
GET_GATE,SET_GATE,ADD_GATE=0x3021c,0x30248,0x30260
sha=lambda b:hashlib.sha256(b).hexdigest()
def word(v):return struct.pack('<I',v)
def branch(src,dst,cond=14,link=False):
 delta=dst-src-8;assert delta%4==0 and -(1<<25)<=delta<(1<<25)
 return word((cond<<28)|0x0a000000|(int(link)<<24)|((delta//4)&0xffffff))
def build():
 original=(P/'FWCL14TL.rcx-0011412e.decoded.bin').read_bytes();assert sha(original)==SOURCE;code=bytearray(original);patches=[]
 def put(off,old,new,why):
  assert code[off:off+len(old)]==old;(code.__setitem__(slice(off,off+len(old)),new));assert len(old)==len(new)
  patches.append({'address':hex(BASE+off),'module_offset':hex(off),'before':old.hex(),'after':new.hex(),'reason':why})
 # The replaced primary-add body has no external branches or pointers into its interior.
 for off in range(0,len(original)-4,4):
  w=struct.unpack_from('<I',original,off)[0]
  if w>>25&7==5:
   imm=w&0xffffff;imm-=1<<24 if imm&(1<<23) else 0;t=off+8+imm*4
   assert not (0x3020c<t<0x30278 and not 0x3020c<=off<0x30278),(hex(off),hex(t))
  assert not BASE+0x3020c<w<BASE+0x30278
 # Original entry continues to accept slot,amount; writes zero through the native setter.
 body=word(0xe3a02000)+word(0xe1a01000)+word(0xe3a0001d)+branch(0x30218,SET)
 assert len(body)==16
 cmp3=word(0xe350001d)+word(0x1350001e)+word(0x13500026)
 get=cmp3+branch(GET_GATE+12,GET_GATE+36,cond=1)+word(0xe92d4010)+branch(GET_GATE+20,0x302ec,link=True)+branch(GET_GATE+24,SET,link=True)+word(0xe3a00000)+word(0xe8bd8010)+original[GET:GET+4]+branch(GET_GATE+40,GET+4)
 setgate=cmp3+word(0x03a02000)+original[SET:SET+4]+branch(SET_GATE+20,SET+4)
 add=cmp3+branch(ADD_GATE+12,SET,cond=0)+original[ADD:ADD+4]+branch(ADD_GATE+20,ADD+4)
 assert len(get)==44 and len(setgate)==24 and len(add)==24
 put(0x3020c,original[0x3020c:0x30278],body+get+setgate+add,'Replace primary maintenance addition with zero write; reuse its retired body for ID-specific read/set/add gates')
 for off,target in ((GET,GET_GATE),(SET,SET_GATE),(ADD,ADD_GATE)):
  put(off,original[off:off+4],branch(off,target),'Only IDs 0x1d,0x1e,0x26 clear stored maintenance usage; all other IDs execute original prologue and body')
 put(0x302a4,word(0xe1a02001),word(0xe3a02000),'Ignore new fractional maintenance consumption amount')
 put(0x302b4,word(0xe0833002),word(0xe3a03000),'Clear pre-existing fractional remainder on fractional accounting update')
 put(0x31760,word(0xe7d14000),word(0xe3a04064),'Report 100 in numeric maintenance states 0,8,9, preserving original error encodings')
 put(0x302e4,original[0x302e4:0x302ec],word(0xe3a00064)+word(0xe12fff1e),'Return 100 for maintenance remaining-capacity calculation')
 # The retired calculation body is unreachable after the new return; reject
 # any external reference into the 20-byte fractional-clear helper region.
 for off in range(0,len(original)-4,4):
  w=struct.unpack_from('<I',original,off)[0]
  if w>>25&7==5:
   imm=w&0xffffff;imm-=1<<24 if imm&(1<<23) else 0;t=off+8+imm*4
   assert not (0x302ec<=t<0x30300 and not 0x302e4<=off<0x30380)
  assert not BASE+0x302ec<=w<BASE+0x30300
 fraction=struct.unpack_from('<I',original,0x302a8+8+0x35c)[0]
 helper=word(0xe3a02000)+word(0xe59fc004)+word(0xe78c2101)+word(0xe12fff1e)+word(fraction)
 put(0x302ec,original[0x302ec:0x30300],helper,'Clear the selected slot fractional remainder on every maintenance accounting read, before the native zero setter')
 allowed={i for patch in patches for i in range(int(patch['module_offset'],16),int(patch['module_offset'],16)+len(bytes.fromhex(patch['after'])))}
 diffs=[i for i,(a,b) in enumerate(zip(original,code)) if a!=b];assert set(diffs)<=allowed and len(code)==len(original)
 assert struct.unpack_from('<II',original,0x3297c)==(0xe3a00002,0xe12fff1e)
 manifest={'label':'KU25Q4-S1-maintenance-zero-usage','original_control_sha256':SOURCE,'modified_control_sha256':sha(code),'load_address':hex(BASE),'module_bytes':len(code),'configured_maintenance_slots':2,'maintenance_accounting_ids':['0x1d','0x1e','0x26'],'patches':patches,'changed_bytes':len(diffs),'semantics':'Native setters clear pre-existing RAM usage on accounting reads, sets and additions; fractional accounting reads and updates clear remainder. Numeric report and capacity calculation return 100.','preserved':['Other accounting IDs, including ink','Two-slot count and slot addressing','Original error encodings 105,110,114,119','Chip access, printer mode, mechanical controls and cover checks'],'not_claimed':['Every direct or DMA write to RAM intercepted','Physical chip EEPROM already cleared','Physical update, boot, printing or waste-fluid consumption tested','Operation with cartridges absent']}
 (P/'KU25Q4-S1-control.bin').write_bytes(code);(P/'KU25Q4-S1-patches.json').write_text(json.dumps(manifest,indent=2)+'\n');return bytes(code),manifest
if __name__=='__main__':
 _,r=build();print(json.dumps(r,indent=2))
