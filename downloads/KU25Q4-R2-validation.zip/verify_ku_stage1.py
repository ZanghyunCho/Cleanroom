"""Execute original and modified ARM accounting routines, without verdict hooks."""
from pathlib import Path
import hashlib,itertools,json,struct
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_ARM
from unicorn.arm_const import *
from build_ku_stage1 import build,BASE,GET,SET,ADD,P
class Machine:
 def __init__(self,code):
  self.code=code;self.u=Uc(UC_ARCH_ARM,UC_MODE_ARM);self.u.mem_map(0x44000000,0x1000000);self.u.mem_write(BASE,code);self.u.mem_map(0x42000000,0x200000);self.u.mem_map(0x48000000,0x1000)
 def call(self,off,*args):
  u=self.u;u.reg_write(UC_ARM_REG_CPSR,0x13);u.reg_write(UC_ARM_REG_SP,0x421ff000);u.reg_write(UC_ARM_REG_LR,0x48000000)
  for reg in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3):u.reg_write(reg,0)
  for reg,val in zip((UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3),args):u.reg_write(reg,val)
  u.emu_start(BASE+off,0x48000000,count=1000000);assert u.reg_read(UC_ARM_REG_PC)==0x48000000,(hex(off),hex(u.reg_read(UC_ARM_REG_PC)))
  return u.reg_read(UC_ARM_REG_R0)
 def read(self,addr,n=4):return bytes(self.u.mem_read(addr,n))
 def write(self,addr,b):self.u.mem_write(addr,b)
 def val(self,addr):return struct.unpack('<I',self.read(addr))[0]
 def setval(self,addr,val):self.write(addr,struct.pack('<I',val))
 def literal(self,off,disp):return struct.unpack_from('<I',self.code,off+8+disp)[0]
 def descriptor(self,idx):return struct.unpack_from('<II',self.code,0x4483d16c-BASE+idx*8)
DIRTY=0x4498c8c0
TARGETS=(0x1d,0x1e,0x26)
def seed(m,idx,values=(101,202,303,404)):
 ptr,size=m.descriptor(idx);assert size>=16;m.write(ptr,struct.pack('<4I',*values));m.setval(DIRTY+idx*4,0);return ptr

def verify(code, *, excluded_other_ids=()):
 original=(P/'FWCL14TL.rcx-0011412e.decoded.bin').read_bytes();a=Machine(original);b=Machine(code);counts={};samples={}
 assert a.call(0x3297c)==b.call(0x3297c)==2;counts['configured_slot_count']=1
 cases=[]
 for idx,slot,stored,amount,op in itertools.product(TARGETS,range(2),(0,1,123000000,0xffffffff),(0,1,999,1000,500000000,0xffffffff),('get','set','add')):
  values=[101,202,303,404];values[slot]=stored
  for m in (a,b):seed(m,idx,values)
  fn={'get':GET,'set':SET,'add':ADD}[op]
  before=struct.pack('<4I',*values)
  ra=a.call(fn,idx,slot,amount);rb=b.call(fn,idx,slot,amount)
  ptr,_=b.descriptor(idx);expected=values[:];expected[slot]=0
  assert b.read(ptr,16)==struct.pack('<4I',*expected),(hex(idx),slot,op,stored,amount)
  if op=='get':assert ra==stored and rb==0
  expected_original=values[:]
  if op=='set':expected_original[slot]=amount
  if op=='add':expected_original[slot]=(stored+amount)&0xffffffff
  assert a.read(ptr,16)==struct.pack('<4I',*expected_original)
  assert b.val(DIRTY+idx*4)==int(stored!=0)
  cases.append({'id':hex(idx),'slot':slot,'before':stored,'amount':amount,'operation':op,'candidate_stored':0,'other_slots_unchanged':True})
 counts['maintenance_accounting_cases']=len(cases);samples['maintenance']=cases
 # Nonmaintenance IDs with valid uint32 storage use exactly the original routines.
 regression=[]
 for idx in range(0x5b):
  if idx in TARGETS or idx in excluded_other_ids:continue
  ptr,size=a.descriptor(idx)
  if ptr%4 or not 0x44000000<=ptr<0x44ffffe0 or size<8:continue
  for slot,op,amount in itertools.product(range(2),('get','set','add'),(0,1,0xffffffff)):
   initial=struct.pack('<2I',100,200)
   for m in (a,b):m.write(ptr,initial);m.setval(DIRTY+idx*4,0)
   fn={'get':GET,'set':SET,'add':ADD}[op]
   ra=a.call(fn,idx,slot,amount);rb=b.call(fn,idx,slot,amount)
   assert a.read(ptr,8)==b.read(ptr,8) and a.read(DIRTY+idx*4)==b.read(DIRTY+idx*4),(idx,slot,op)
   assert ra==rb,(idx,op,hex(ra),hex(rb))
   regression.append({'id':hex(idx),'slot':slot,'operation':op,'amount':amount,'same_result_and_RAM':True})
 counts['other_accounting_regressions']=len(regression);samples['other_accounting']=regression
 # Native maintenance-specific helper entries and fractional remainder, both boxes.
 helpers=[];fraction=b.literal(0x302a8,0x35c)
 for fn,slot,stored,remainder,delta in itertools.product((0x301fc,0x3020c,0x30284,0x30294,0x302a4),range(2),(0,123,0xffffffff),(0,1,999),(0,1,1000,0xffffffff)):
  for idx in TARGETS:seed(b,idx,(stored,stored,333,444))
  b.write(fraction,struct.pack('<4I',remainder,remainder,7,8));b.call(fn,slot,delta)
  target=0x1d if fn in (0x301fc,0x3020c) else 0x1e if fn in (0x30284,0x30294) else 0x26
  ptr,_=b.descriptor(target);assert b.val(ptr+slot*4)==0
  if fn==0x302a4:
   assert b.val(fraction+slot*4)==0
   assert b.val(fraction+(1-slot)*4)==remainder
  assert b.val(ptr+(1-slot)*4)==stored
  helpers.append({'helper':hex(BASE+fn),'slot':slot,'stored':stored,'remainder':remainder,'delta':delta,'stored_after':0})
 counts['specific_helper_cases']=len(helpers);samples['helpers']=helpers
 fraction_reads=[]
 for idx,slot,remainder in itertools.product(TARGETS,range(2),(0,1,999,0xffffffff)):
  seed(b,idx);b.write(fraction,struct.pack('<4I',remainder,remainder,7,8))
  assert b.call(GET,idx,slot)==0
  assert b.val(fraction+slot*4)==0 and b.val(fraction+(1-slot)*4)==remainder
  fraction_reads.append({'id':hex(idx),'slot':slot,'fraction_before':remainder,'fraction_after':0,'other_slot_preserved':True})
 counts['fraction_clear_on_read_cases']=len(fraction_reads);samples['fraction_reads']=fraction_reads
 # Remaining report keeps original state/error dispatch, changing numeric states only.
 state=b.literal(0x31714,0xbc);remain=b.literal(0x3175c,0x78);reports=[]
 for slot,raw,cached in itertools.product(range(2),range(10),(0,1,50,99,100)):
  for m in (a,b):m.write(state,bytes((raw,raw)));m.write(remain,bytes((cached,cached)))
  old=a.call(0x31714,slot);new=b.call(0x31714,slot)
  assert new==(100 if raw in (0,8,9) else old)
  assert b.read(state,2)==bytes((raw,raw)) and b.read(remain,2)==bytes((cached,cached))
  reports.append({'slot':slot,'raw_state':raw,'cached_remaining':cached,'original':old,'candidate':new})
 counts['remaining_report_cases']=len(reports);samples['remaining_reports']=reports
 calculated=[]
 for slot,stored in itertools.product(range(2),(0,1,500000000,0xffffffff)):
  seed(b,0x1d,(stored,stored,333,444));assert b.call(0x302e4,slot)==100;calculated.append({'slot':slot,'stored':stored,'calculated_remaining':100})
 counts['remaining_calculation_cases']=len(calculated)
 # Positive original consumption and accumulated-value read prove the harness is not a no-op.
 seed(a,0x1d,(123,456,333,444));assert a.call(GET,0x1d,1)==456;a.call(ADD,0x1d,1,10);assert a.call(GET,0x1d,1)==466
 counts['original_positive_controls']=1
 # Repeated mixed writes/reads/consumption exercise cleared state and separation of slots.
 for idx in TARGETS:seed(b,idx,(123,456,333,444))
 for _ in range(40):
  for slot in range(2):
   for fn in (0x301fc,0x3020c,0x30284,0x30294,0x302a4):b.call(fn,slot,0xffffffff)
   for idx in TARGETS:assert b.call(GET,idx,slot)==0
 for idx in TARGETS:
  ptr,_=b.descriptor(idx);assert b.read(ptr,16)==struct.pack('<4I',0,0,333,444)
 counts['repeated_mixed_sequences']=1
 # Execute the actual two-slot consumption worker, using original profile 0 data.
 # The uninitialized selector is initialized as RAM, with no code/verdict hooks.
 workers=[]
 for amounts,stored,remainder in itertools.product(((1000,2000),(1,1),(999,1000),(0xffffffff,1000)),(0,123,100000000),(0,999)):
  observations=[]
  for label,data in (('original',original),('stage1',code)):
   m=Machine(data);profile=m.literal(0x33f0c,-0x490);m.write(profile-0x3b,b'\0')
   for idx in TARGETS:seed(m,idx,(stored,stored,333,444))
   m.write(fraction,struct.pack('<4I',remainder,remainder,7,8));m.write(state,b'\0\0')
   request=0x42001000;m.write(request,struct.pack('<4I',amounts[0],0,amounts[1],0))
   result=m.call(0x1a120,request)
   values=[list(struct.unpack('<4I',m.read(m.descriptor(idx)[0],16))) for idx in TARGETS]
   assert result==1
   if label=='stage1':assert values==[[0,0,333,444]]*3 and m.read(fraction,16)==struct.pack('<4I',0,0,7,8)
   observations.append({'image':label,'worker_return':result,'counters':values})
  assert observations[0]['counters']!=observations[1]['counters']
  workers.append({'requested_amounts':amounts,'stored_before':stored,'fraction_before':remainder,'observations':observations})
 counts['two_slot_consumption_worker_cases']=len(workers);samples['consumption_worker']=workers
 return {'module_sha256':hashlib.sha256(code).hexdigest(),'executed_scenarios':sum(counts.values()),'case_counts':counts,'native_verdict_hooks':0,'original_and_candidate_ARM_executed':True,'fractional_remainder_address':hex(fraction),'state_address':hex(state),'remaining_address':hex(remain),'cases':samples,'scope':'Actual ARM helper instructions with synthetic RAM; no EEPROM/chip I/O, task scheduling, complete printer boot, printing or physical waste-fluid generation.'}
if __name__=='__main__':
 code,manifest=build();r=verify(code);(P/'KU25Q4-S1-native-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='cases'},indent=2))
