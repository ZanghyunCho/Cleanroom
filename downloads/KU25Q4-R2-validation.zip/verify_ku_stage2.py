"""Execute KU25Q4 S2 ink accounting and S1 regressions without verdict hooks."""
import hashlib,itertools,json,struct
from build_ku_stage2 import build,PAIRS,GET40,SET40,ADD40,P
from build_ku_stage1 import build as build_s1,BASE
from verify_ku_stage1 import Machine,DIRTY,verify as verify_s1,seed,GET,SET,ADD
from unicorn.arm_const import UC_ARM_REG_R1,UC_ARM_REG_PC

def call40(m,fn,pair,slot,low=0,high=0):
 m.write(0x421ff000,struct.pack('<II',low,high));r0=m.call(fn,pair[0],pair[1],slot);return r0,m.u.reg_read(UC_ARM_REG_R1)
def seedpair(m,pair,slot,low,high):
 a,an=m.descriptor(pair[0]);b,bn=m.descriptor(pair[1]);assert an>=(slot+1)*4 and bn>slot
 lows=[(0x11220000+i)&0xffffffff for i in range(an//4)];highs=bytearray((i+17)&255 for i in range(bn));lows[slot]=low;highs[slot]=high
 m.write(a,struct.pack('<'+'I'*len(lows),*lows));m.write(b,bytes(highs))
 for idx in pair:m.setval(DIRTY+idx*4,0)
 return (a,an,b,bn),m.read(a,an),m.read(b,bn)
def init_profile(m):
 profile=m.literal(0x33f0c,-0x490);m.write(profile-0x3b,b'\0')
 # Original ink-role mapping is initialized to roles 2..11: ten configured colors.
 roles=m.literal(0x32ebc,-0x318);m.write(roles,bytes(range(2,12)))
 return roles

def verify(code):
 s1,_=build_s1();a=Machine(s1);b=Machine(code);counts={};cases={}
 regression=verify_s1(code,excluded_other_ids=(0x33,));counts['S1_regressions_except_new_ink_ID33']=regression['executed_scenarios']
 assert a.call(0x32984)==b.call(0x32984)==10 and b.call(0x3297c)==2;counts['configured_slot_counts']=1
 results=[]
 frac=[int(x,16) for x in json.loads((P/'KU25Q4-S2-patches.json').read_text())['fraction_arrays']]
 for pair,slot,stored,high,amount,op in itertools.product(PAIRS,range(10),(0,123,0xffffffff),(0,1,255),(0,1,1000,0xffffffff),('get','set','add')):
  for m in (a,b):
   descriptor,lows,highs=seedpair(m,pair,slot,stored,high)
   for ptr in frac:m.write(ptr,struct.pack('<16I',*range(100,116)))
  fn={'get':GET40,'set':SET40,'add':ADD40}[op]
  before=a.read(0x421ff000,8);ra=call40(a,fn,pair,slot,amount,1);rb=call40(b,fn,pair,slot,amount,1)
  ptr,n,hptr,hn=descriptor;expected=bytearray(lows);expected[slot*4:slot*4+4]=bytes(4);expected_hi=bytearray(highs);expected_hi[slot]=0
  assert b.read(ptr,n)==expected and b.read(hptr,hn)==expected_hi,(pair,slot,op)
  if op=='get':assert ra==(stored,high) and rb==(0,0)
  # The original caller's outgoing argument storage must not be modified.
  assert b.read(0x421ff000,8)==struct.pack('<II',amount,1)
  for p in frac:
   values=list(range(100,116));values[slot]=0;assert b.read(p,64)==struct.pack('<16I',*values)
  assert b.val(DIRTY+pair[0]*4)==int(stored!=0) and b.val(DIRTY+pair[1]*4)==int(high!=0)
  results.append({'pair':[hex(x) for x in pair],'slot':slot,'stored_low':stored,'stored_high':high,'amount':amount,'op':op,'stored_after':[0,0],'other_slots_preserved':True})
 counts['ink_pair_read_set_add_cases']=len(results);cases['ink_accounting']=results
 # Mismatched and unrelated valid low/high pairs must retain S1 native behavior.
 unrelated=[]
 pairs=((0x22,0x25),(0x24,0x23),(0x30,0x23),(0x2f,0x31))
 for pair,slot,op,amount in itertools.product(pairs,range(10),('get','set','add'),(0,1,0xffffffff)):
  for m in (a,b):seedpair(m,pair,slot,123,2)
  fn={'get':GET40,'set':SET40,'add':ADD40}[op];ra=call40(a,fn,pair,slot,amount,3);rb=call40(b,fn,pair,slot,amount,3)
  for idx in pair:
   ptr,n=a.descriptor(idx);assert a.read(ptr,n)==b.read(ptr,n) and a.read(DIRTY+idx*4)==b.read(DIRTY+idx*4)
  assert ra==rb
  unrelated.append({'pair':pair,'slot':slot,'op':op,'amount':amount,'same_result_and_RAM':True})
 counts['unrelated_pair_regressions']=len(unrelated);cases['unrelated_pairs']=unrelated
 # Ink ID 0x33 uses the 32-bit API; its slot index must never touch S1 fractional storage.
 extra=[]
 maintenance_fraction=0x4498b3d4
 for slot,stored,amount,op in itertools.product(range(10),(0,123,0xffffffff),(0,1,0xffffffff),('get','set','add')):
  ptr,n=b.descriptor(0x33);initial=[i+100 for i in range(n//4)];initial[slot]=stored;b.write(ptr,struct.pack('<'+'I'*len(initial),*initial));b.setval(DIRTY+0x33*4,0)
  b.write(maintenance_fraction,bytes(range(64)));before=b.read(maintenance_fraction,64)
  rb=b.call({'get':GET,'set':SET,'add':ADD}[op],0x33,slot,amount);expected=initial[:];expected[slot]=0
  assert b.read(ptr,n)==struct.pack('<'+'I'*len(expected),*expected) and b.read(maintenance_fraction,64)==before
  if op=='get':assert rb==0
  extra.append({'slot':slot,'stored':stored,'amount':amount,'op':op,'stored_after':0,'maintenance_fraction_unchanged':True})
 counts['ink_ID33_cases']=len(extra);cases['ID33']=extra
 # Pure percentage API returns 100 for each configured ink slot, without state writes.
 percentages=[];state=b.literal(0x2aea4,0x11c);cached=b.literal(0x2af38,0x90)
 for slot,raw,remaining in itertools.product(range(10),range(15),(0,1,50,99,100)):
  b.write(state,bytes([raw])*12);b.write(cached,bytes([remaining])*12);before_state=b.read(state,12);before_cached=b.read(cached,12)
  assert b.call(0x2ae88,slot)==100 and b.read(state,12)==before_state and b.read(cached,12)==before_cached
  percentages.append({'slot':slot,'raw_state':raw,'cached':remaining,'returned':100,'raw_state_preserved':True})
 counts['ink_percentage_cases']=len(percentages);cases['percentages']=percentages
 # Direct extra usage accumulator and notification accumulator: get/set/add zero RAM.
 direct=[];rawptr=b.literal(0x2a110,0x1c4);notify=b.literal(0x2be6c,0x44);enabled=b.literal(0x2bdd4,0xd8)
 for slot,before,amount,fn in itertools.product(range(10),(0,123,0xffffffffffffffff),(0,1,0xffffffff),(0x2a0dc,0x2a0f4,0x2a110,0x2be5c,0x2bdd4)):
  ptr=notify if fn in (0x2be5c,0x2bdd4) else rawptr
  initial=[i+100 for i in range(12)];initial[slot]=before;b.write(ptr,struct.pack('<12Q',*initial));b.setval(enabled+4,1)
  b.call(fn,slot,amount);expected=initial[:];expected[slot]=0
  assert b.read(ptr,96)==struct.pack('<12Q',*expected),(hex(fn),slot)
  direct.append({'fn':hex(BASE+fn),'slot':slot,'before':before,'amount':amount,'stored_after':0})
 counts['direct_accumulator_cases']=len(direct);cases['direct_accumulators']=direct
 # Original primary and secondary helpers are exercised, with original role mapping.
 helpers=[]
 for fn,slot,amount in itertools.product((0x29c88,0x2a20c),range(10),(1,999,1000,0xffffffff)):
  observations=[]
  for label,data in (('S1',s1),('S2',code)):
   m=Machine(data);init_profile(m)
   for pair in PAIRS:
    ptr,n=m.descriptor(pair[0]);hi,hn=m.descriptor(pair[1]);m.write(ptr,bytes(n));m.write(hi,bytes(hn))
   for ptr in frac:m.write(ptr,bytes(64))
   m.call(fn,slot,amount)
   snapshots=[]
   for pair in PAIRS:
    ptr,n=m.descriptor(pair[0]);hi,hn=m.descriptor(pair[1]);snapshots.append((m.read(ptr,n).hex(),m.read(hi,hn).hex()))
   fractions=[m.read(ptr,64).hex() for ptr in frac]
   if label=='S2':assert all(set(bytes.fromhex(x))<={0} for record in snapshots for x in record) and all(set(bytes.fromhex(x))<={0} for x in fractions)
   observations.append({'image':label,'ledgers':snapshots,'fractions':fractions})
  assert (observations[0]['ledgers'],observations[0]['fractions'])!=(observations[1]['ledgers'],observations[1]['fractions'])
  helpers.append({'fn':hex(BASE+fn),'slot':slot,'amount':amount,'observations':observations})
 counts['original_ink_helper_controls']=len(helpers);cases['ink_helpers']=helpers
 workers=[]
 for fn,mode,amount in ((0x18ca8,0,1),(0x18ca8,0,1000),(0x18ca8,0,0xffffffff),(0x18d18,0,1),(0x18d18,0,1000),(0x18d18,2,1000),(0x18d18,2,0xffffffff)):
  observations=[]
  for label,data in (('S1',s1),('S2',code)):
   m=Machine(data);init_profile(m);m.write(state,bytes(12));request=0x42001000
   if fn==0x18ca8:m.write(request,b''.join(struct.pack('<II',amount,0) for _ in range(10)))
   else:m.write(request,struct.pack('<12I',*([amount]*12))+struct.pack('<I',mode))
   m.setval(enabled+4,1)
   result=m.call(fn,request);assert result==1
   records=[]
   for idx in (0x22,0x23,0x24,0x25,0x30,0x31,0x33):
    ptr,n=m.descriptor(idx);records.append(m.read(ptr,n).hex())
   aux=[m.read(ptr,64).hex() for ptr in frac]
   for ptr in (rawptr,notify,m.literal(0x2bd78,0x13c)):aux.append(m.read(ptr,96).hex())
   if label=='S2':assert all(set(bytes.fromhex(x))<={0} for x in records+aux)
   observations.append({'image':label,'result':result,'records':records,'auxiliary_accumulators':aux})
  assert (observations[0]['records'],observations[0]['auxiliary_accumulators'])!=(observations[1]['records'],observations[1]['auxiliary_accumulators']),(hex(fn),mode,amount)
  workers.append({'worker':hex(BASE+fn),'mode':mode,'amount_for_all_10_slots':amount,'observations':observations})
 counts['actual_10_slot_ink_worker_cases']=len(workers);cases['ink_workers']=workers
 return {'module_sha256':hashlib.sha256(code).hexdigest(),'executed_scenarios':sum(counts.values()),'case_counts':counts,'S1_regressions':regression,'cases':cases,'native_verdict_hooks':0,'source':'Actual ARM instructions; original S1 versus S2, synthetic initialized RAM/profile/role fixtures','limitations':['No S2 physical update, startup, printing or ink generation','No physical EEPROM or every restore path validation','Raw ink errors, absence, branding and approval prompts are retained']}
if __name__=='__main__':
 code,_=build();r=verify(code);(P/'KU25Q4-S2-native-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ('cases','S1_regressions')},indent=2))
