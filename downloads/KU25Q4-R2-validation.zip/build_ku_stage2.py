"""KU25Q4 S2: keep S1 maintenance behavior; zero identified ink ledgers."""
from pathlib import Path
import hashlib,json,struct
from build_ku_stage1 import build as build_s1,BASE,P,word,branch,GET,SET,ADD,GET_GATE,SET_GATE,ADD_GATE
GET40,SET40,ADD40=0x13df0,0x13f54,0x140c8
PAIRS=((0x22,0x23),(0x24,0x25),(0x30,0x31))
sha=lambda b:hashlib.sha256(b).hexdigest()
class Asm:
 def __init__(self,start):self.start=start;self.words=[];self.labels={};self.fix=[]
 @property
 def pc(self):return self.start+len(self.words)*4
 def label(self,n):self.labels[n]=self.pc
 def w(self,w):self.words.append(word(w))
 def b(self,target,cond=14,link=False):self.fix.append((len(self.words),target,cond,link));self.words.append(bytes(4))
 def finish(self):
  for n,t,c,l in self.fix:self.words[n]=branch(self.start+n*4,self.labels[t] if isinstance(t,str) else t,c,l)
  return b''.join(self.words)
def build():
 original=(P/'FWCL14TL.rcx-0011412e.decoded.bin').read_bytes();s1,s1_manifest=build_s1();assert sha(s1)=='49bd6d6d5eedaa7c869405bddd4f34e30089ee224c1763cac9eb756df21951f5'
 code=bytearray(s1);patches=[]
 def put(off,old,new,why):
  assert len(old)==len(new) and code[off:off+len(old)]==old,(hex(off),code[off:off+len(old)].hex(),old.hex())
  code[off:off+len(old)]=new;patches.append({'address':hex(BASE+off),'module_offset':hex(off),'before':old.hex(),'after':new.hex(),'reason':why})
 # No external branch/pointer enters the retired percentage function body.
 for off in range(0,len(original)-4,4):
  w=struct.unpack_from('<I',original,off)[0]
  if w>>25&7==5:
   v=w&0xffffff;v-=1<<24 if v&(1<<23) else 0;t=off+8+v*4
   assert not (0x2ae90<=t<0x2afb8 and not 0x2ae88<=off<0x2afb8),(hex(off),hex(t))
   for lo,hi in ((0x2a0dc,0x2a0f4),(0x2be5c,0x2be94)):
    assert not (lo<t<hi and not lo<=off<hi),(hex(off),hex(t))
  assert not (BASE+0x2ae90<=w<BASE+0x2afb8 and not 0x2ae88<=off<0x2afb8)
  for lo,hi in ((0x2a0dc,0x2a0f4),(0x2be5c,0x2be94)):
   assert not BASE+lo<w<BASE+hi
 a=Asm(0x2ae90)
 def checks(match):
  for lo,hi in PAIRS:a.w(0xe3500000|lo);a.w(0x03510000|hi);a.b(match,cond=0)
 a.label('get');checks('get_zero');a.w(struct.unpack_from('<I',original,GET40)[0]);a.b(GET40+4)
 a.label('get_zero');a.w(0xe92d4010);a.w(0xe24dd008);a.w(0xe3a0c000);a.w(0xe58dc000);a.w(0xe58dc004);a.b(SET40,link=True);a.w(0xe28dd008);a.w(0xe3a00000);a.w(0xe3a01000);a.w(0xe8bd8010)
 a.label('set');checks('set_zero');a.label('set_native');a.w(struct.unpack_from('<I',original,SET40)[0]);a.b(SET40+4)
 a.label('set_zero');a.w(0xe92d4010);a.b('clear_fraction',link=True);a.w(0xe24dd008);a.w(0xe3a0c000);a.w(0xe58dc000);a.w(0xe58dc004);a.b('set_native',link=True);a.w(0xe28dd008);a.w(0xe8bd8010)
 a.label('add');checks('set');a.w(struct.unpack_from('<I',original,ADD40)[0]);a.b(ADD40+4)
 a.label('clear_fraction');a.w(0xe3a03000);a.w(0xe59fc00c);a.w(0xe78c3102);a.w(0xe59fc008);a.w(0xe78c3102);a.w(0xe12fff1e)
 fraction1=struct.unpack_from('<I',original,0x2a248+8+0xa4)[0];fraction2=struct.unpack_from('<I',original,0x2a278+8+0x78)[0];a.w(fraction1);a.w(fraction2)
 gates=a.finish();assert len(gates)<=0x2afb8-0x2ae90
 put(0x2ae88,original[0x2ae88:0x2ae90],word(0xe3a00064)+word(0xe12fff1e),'All 10 ink percentage getter results are 100; raw state and notification error fields are unchanged')
 put(0x2ae90,original[0x2ae90:0x2ae90+len(gates)],gates,'Reused retired percentage body for exact ink-accounting pair gates and per-ledger fractional reset')
 for fn,label in ((GET40,'get'),(SET40,'set'),(ADD40,'add')):put(fn,original[fn:fn+4],branch(fn,a.labels[label]),'Zero only the identified ink low/high ledger pairs; execute native getter/setter/addition for every other pair')
 # Extend S1 nonmatching paths for ink usage ID 0x33, without ever invoking
 # the maintenance-only fractional array with an ink slot index.
 for off in range(0,len(original)-4,4):
  w=struct.unpack_from('<I',original,off)[0]
  if w>>25&7==5:
   v=w&0xffffff;v-=1<<24 if v&(1<<23) else 0;t=off+8+v*4
   assert not (0x30300<=t<0x30344 and not 0x302e4<=off<0x30380)
  assert not BASE+0x30300<=w<BASE+0x30344
 x=Asm(0x30300);x.label('get33');x.w(0xe3500033);x.b('get_native',cond=1);x.w(0xe92d4010);x.w(0xe3a02000);x.b(SET,link=True);x.w(0xe3a00000);x.w(0xe8bd8010);x.label('get_native');x.w(struct.unpack_from('<I',original,GET)[0]);x.b(GET+4)
 x.label('set33');x.w(0xe3500033);x.w(0x03a02000);x.w(struct.unpack_from('<I',original,SET)[0]);x.b(SET+4)
 x.label('add33');x.w(0xe3500033);x.b(SET,cond=0);x.w(struct.unpack_from('<I',original,ADD)[0]);x.b(ADD+4)
 ext=x.finish();assert len(ext)==68
 put(0x30300,s1[0x30300:0x30344],ext,'Add zero read/set/add handling for ink usage ID 0x33; maintenance IDs retain their original S1 path')
 for off,name in ((GET_GATE+36,'get33'),(SET_GATE+16,'set33'),(ADD_GATE+16,'add33')):put(off,s1[off:off+4],branch(off,x.labels[name]),'Extend only the S1 nonmaintenance fallback for ink counter 0x33')
 # Additional 64-bit RAM usage accumulator reached by the actual ink worker.
 raw=word(struct.unpack_from('<I',original,0x2a0dc)[0])+word(0xe0811180)+word(0xe3a00000)+word(0xe5810000)+word(0xe5810004)+word(0xe12fff1e)
 put(0x2a0dc,original[0x2a0dc:0x2a0f4],raw,'Reading the extra ink accumulator clears its actual 64-bit RAM entry and returns zero')
 put(0x2a0f4,word(struct.unpack_from('<I',original,0x2a0f4)[0]),word(0xe3a02000),'Extra ink accumulator setter stores zero instead of a converted positive value')
 for off,expected,new,why in [(0x2a11c,0xe0933001,0xe3a03000,'Extra ink usage addition stores low word zero'),(0x2a120,0xe2ac1000,0xe3a01000,'Extra ink usage addition stores high word zero'),(0x2bdf0,0xe0922001,0xe3a02000,'Notification usage accumulator low word zero'),(0x2bdf4,0xe2a31000,0xe3a01000,'Notification usage accumulator high word zero')]:put(off,word(expected),word(new),why)
 for off,expected,new,why in [(0x2bd84,0xe091c005,0xe3a0c000,'Alternate notification consumption accumulator low word zero'),(0x2bd88,0xe2a31000,0xe3a01000,'Alternate notification consumption accumulator high word zero')]:put(off,word(expected),word(new),why)
 # The notification numeric usage getter also clears the selected RAM entry.
 notify=word(0xe59fc054)+word(0xe08cc180)+word(0xe3a00000)+word(0xe58c0000)+word(0xe58c0004)+word(0xe12fff1e)
 put(0x2be5c,original[0x2be5c:0x2be74],notify,'Notification numeric usage getter clears its selected 64-bit accumulator and returns zero')
 allowed={i for patch in patches for i in range(int(patch['module_offset'],16),int(patch['module_offset'],16)+len(bytes.fromhex(patch['after'])))}
 diffs=[i for i,(u,v) in enumerate(zip(s1,code)) if u!=v];assert set(diffs)<=allowed and len(code)==len(s1)
 manifest={'label':'KU25Q4-S2-all-cartridge-zero-usage','S1_module_sha256':sha(s1),'S1_hardware_result':'User reports S1 passed; exact tested device operations not independently observed','module_sha256':sha(code),'load_address':hex(BASE),'configured_ink_slots':10,'configured_maintenance_slots':2,'ink_accounting_pairs':[[hex(l),hex(h)] for l,h in PAIRS],'additional_ink_counter':'0x33','fraction_arrays':[hex(fraction1),hex(fraction2)],'patches_vs_S1':patches,'changed_bytes_vs_S1':len(diffs),'gate_addresses':{k:hex(BASE+v) for k,v in a.labels.items()},'preserved':['S1 maintenance behavior','Raw ink states and cartridge detection','Branding/authentication fields and approval prompts','Unrelated accounting pairs','Chip I/O, printhead drive and mechanical control'],'physical_S2_tested':False,'limitations':['RAM accounting and report changes do not prove physical EEPROM contents or persistence','Not all possible direct/DMA or restoration writes are intercepted','No claim of absent-cartridge operation or suppression of ink-state/communication errors']}
 (P/'KU25Q4-S2-control.bin').write_bytes(code);(P/'KU25Q4-S2-patches.json').write_text(json.dumps(manifest,indent=2)+'\n');return bytes(code),manifest
if __name__=='__main__':
 _,r=build();print(json.dumps({k:v for k,v in r.items() if k!='patches_vs_S1'},indent=2))
