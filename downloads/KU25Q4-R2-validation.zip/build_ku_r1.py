"""R1 diagnostic: S1 plus ink percentage reporting only; no S2 accounting edits."""
import hashlib,struct
from build_ku_stage1 import build as build_s1,P,BASE

def build():
 s1,_=build_s1();code=bytearray(s1);off=0x2ae88
 assert s1[off:off+8]==bytes.fromhex('30402de90cd04de2')
 code[off:off+8]=bytes.fromhex('6400a0e31eff2fe1')
 assert code[:off]==s1[:off] and code[off+8:]==s1[off+8:]
 manifest={'label':'KU25Q4-R1-ink-report-only','baseline':'S1 user-reported pass; present boot recovery not yet retested','S1_module_sha256':hashlib.sha256(s1).hexdigest(),'module_sha256':hashlib.sha256(code).hexdigest(),'only_changed_range_vs_S1':['0x2ae88','0x2ae90'],'ink_percentage':100,'ink_usage_frozen':False,'S2_accounting_patches_included':False,'LOONA_included':False,'C1_included':False,'chipless_support':False,'hardware_boot_tested':False}
 (P/'KU25Q4-R1-control.bin').write_bytes(code)
 return bytes(code),manifest
