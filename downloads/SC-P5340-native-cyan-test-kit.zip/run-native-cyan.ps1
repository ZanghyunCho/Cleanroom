param(
    [ValidateSet('Inspect', 'PrintCyan')]
    [string]$Mode = 'Inspect'
)
$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$resultDirectory = Join-Path $PSScriptRoot ("native-cyan-{0}-{1}" -f $Mode, $stamp)
New-Item -ItemType Directory -Path $resultDirectory | Out-Null
$helper = Join-Path $PSScriptRoot 'scp5340-native-cyan.exe'
$record = [ordered]@{
    tool = 'SC-P5340 native cyan experiment'
    mode = $Mode
    started_utc = [DateTime]::UtcNow.ToString('o')
    helper_exit = $null
    helper_timed_out = $false
    transport_accepted = $false
    physical_print_verified = $false
    automatic_retry = $false
    error = $null
}
try {
    $expected = (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'scp5340-native-cyan.exe.sha256') -Raw).Trim().Split(' ')[0]
    if ($expected -notmatch '^[0-9a-fA-F]{64}$') { throw 'Invalid helper checksum file.' }
    $actual = (Get-FileHash -LiteralPath $helper -Algorithm SHA256).Hash
    if ($actual -ne $expected) { throw 'Helper checksum mismatch. No helper was started.' }
    $record['helper_sha256'] = $actual.ToLowerInvariant()
    $start = New-Object System.Diagnostics.ProcessStartInfo
    $start.FileName = $helper
    $start.Arguments = '--inspect'
    if ($Mode -eq 'PrintCyan') { $start.Arguments = '--send-cyan' }
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $start
    if (-not $process.Start()) { throw 'Unable to start helper.' }
    $stdoutTask = $process.StandardOutput.ReadToEndAsync()
    $stderrTask = $process.StandardError.ReadToEndAsync()
    if (-not $process.WaitForExit(30000)) {
        $record['helper_timed_out'] = $true
        $process.Kill()
        $process.WaitForExit()
    }
    $stdout = $stdoutTask.Result
    $stderr = $stderrTask.Result
    $record['helper_exit'] = $process.ExitCode
    $process.Dispose()
    [IO.File]::WriteAllText((Join-Path $resultDirectory 'helper.jsonl'), $stdout, (New-Object Text.UTF8Encoding($false)))
    [IO.File]::WriteAllText((Join-Path $resultDirectory 'helper-stderr.txt'), $stderr, (New-Object Text.UTF8Encoding($false)))
    $events = @()
    foreach ($line in ($stdout -split '\r?\n')) {
        if ($line.Trim()) { $events += ($line | ConvertFrom-Json) }
    }
    foreach ($event in $events) {
        if ($event.event -eq 'write_result' -and $event.transport_accepted -eq $true) {
            $record['transport_accepted'] = $true
        }
    }
} catch {
    $record['error'] = $_.Exception.Message
}
$record['finished_utc'] = [DateTime]::UtcNow.ToString('o')
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $resultDirectory 'result.json') -Encoding UTF8
$archive = $resultDirectory + '.zip'
Compress-Archive -Path (Join-Path $resultDirectory '*') -DestinationPath $archive
Write-Host ('Result: ' + $archive)
if ($Mode -eq 'PrintCyan') {
    Write-Host 'Sending bytes is not proof of printing. Report whether a short cyan line appeared.'
    Write-Host 'If nothing printed or an error appeared, do not automatically repeat the print experiment.'
} else {
    Write-Host 'Inspection only. No print data was sent.'
}
if ($record['error']) { Write-Host ('Error: ' + $record['error']) }
