/* User-operated Windows x64 cyan-only USB print experiment.
 * Default/--inspect performs identification only. --send-cyan writes exactly
 * one embedded 622-byte print candidate; no arbitrary file/command input.
 * No firmware, cleaning, registry, queue or driver configuration writes. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winioctl.h>
#include <setupapi.h>
#include <usbprint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <wctype.h>
#include "native_cyan_packet.h"

static const GUID printer_interface = {0x28d78fad,0x5a12,0x11d1,{0xae,0x5b,0,0,0xf8,3,0xa8,0xc2}};

static int target_path(const wchar_t *path) {
    size_t length = wcslen(path);
    if (length > 32767) return 0;
    wchar_t *lower = calloc(length + 1, sizeof(wchar_t));
    if (!lower) return 0;
    for (size_t i = 0; i < length; ++i) lower[i] = towlower(path[i]);
    const wchar_t *hit = wcsstr(lower, L"vid_04b8&pid_1334&mi_00");
    int match = hit && (hit[23] == L'#' || hit[23] == 0);
    free(lower); return match;
}
static int field_equals(const unsigned char *data, size_t size, const char *key, const char *value) {
    size_t k = strlen(key), v = strlen(value);
    for (size_t i = 0; i + k + v <= size; ++i) {
        if (i != 0 && i != 2 && data[i - 1] != ';') continue;
        if (memcmp(data + i, key, k) || memcmp(data + i + k, value, v)) continue;
        if (i + k + v == size || data[i + k + v] == ';') return 1;
    }
    return 0;
}
static int target_identity(const unsigned char *data, size_t size) {
    return field_equals(data, size, "MFG:", "EPSON") &&
        (field_equals(data, size, "MDL:", "SC-P5300 Series") ||
         field_equals(data, size, "MDL:", "SC-P5340") ||
         field_equals(data, size, "MDL:", "SC-P5340 Series"));
}
static DWORD identity(HANDLE device, unsigned char *data, DWORD capacity, DWORD *received) {
    OVERLAPPED operation = {0};
    operation.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (!operation.hEvent) return GetLastError();
    BOOL ok = DeviceIoControl(device, IOCTL_USBPRINT_GET_1284_ID, NULL, 0,
                              data, capacity, received, &operation);
    DWORD error = ok ? 0 : GetLastError();
    if (!ok && error == ERROR_IO_PENDING) {
        if (WaitForSingleObject(operation.hEvent, 3000) == WAIT_OBJECT_0)
            error = GetOverlappedResult(device, &operation, received, FALSE) ? 0 : GetLastError();
        else {
            CancelIoEx(device, &operation);
            GetOverlappedResult(device, &operation, received, TRUE);
            error = ERROR_TIMEOUT;
        }
    }
    CloseHandle(operation.hEvent); return error;
}
static int self_test(void) {
    static const unsigned char good[] = "xxMFG:EPSON;MDL:SC-P5300 Series;";
    static const unsigned char wrong[] = "xxMFG:EPSON;MDL:SC-P5000 Series;";
    static const unsigned char prefix[] = "xxMFG:EPSON;MDL:SC-P5300 SeriesX;";
    static const unsigned char spoof[] = "xxXMFG:EPSON;MDL:SC-P5300 Series;";
    static const unsigned char header[] = {
        0x1b,0x40,0x1b,0x28,0x47,0x01,0,0x01,
        0x1b,0x28,0x44,0x04,0,0x80,0x16,0x08,0x08,
        0x1b,0x28,0x76,0x02,0,0x40,0,0x0d,
        0x1b,0x28,0x24,0x04,0,0x0c,0,0,0,
        0x1b,0x69,0x02,0,0x01,0x24,0,0x10,0
    };
    if (sizeof(cyan_packet) != 622 || sizeof(header) != 43 ||
        memcmp(cyan_packet, header, sizeof(header)) ||
        memcmp(cyan_packet + 619, "\x0c\x1b@", 3)) return 1;
    for (size_t row = 0; row < 16; ++row)
        for (size_t col = 0; col < 36; ++col)
            if (cyan_packet[43 + row * 36 + col] != (row % 2 ? 0x55 : 0xaa)) return 1;
    if (!target_identity(good, sizeof(good) - 1) ||
        target_identity(wrong, sizeof(wrong) - 1) ||
        target_identity(prefix, sizeof(prefix) - 1) || target_identity(spoof, sizeof(spoof) - 1)) return 1;
    if (!target_path(L"usb#VID_04B8&PID_1334&MI_00#test") ||
         target_path(L"usb#vid_04b8&pid_008c#test") ||
         target_path(L"usb#vid_04b8&pid_1334&mi_01#test") ||
         target_path(L"usb#vid_04b8&pid_1334&mi_000#test")) return 1;
    puts("{\"event\":\"self_test\",\"passed\":true,\"hardware_tested\":false}"); return 0;
}
static int send_once(const wchar_t *path) {
    HANDLE device = CreateFileW(path, GENERIC_READ | GENERIC_WRITE, 0, NULL,
                               OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
    if (device == INVALID_HANDLE_VALUE) {
        printf("{\"event\":\"error\",\"stage\":\"exclusive_open\",\"code\":%lu}\n", GetLastError()); return 1;
    }
    unsigned char data[8192] = {0}; DWORD received = 0;
    DWORD error = identity(device, data, sizeof(data), &received);
    if (error || received > sizeof(data) || !target_identity(data, received)) {
        printf("{\"event\":\"error\",\"stage\":\"recheck_identity\",\"code\":%lu}\n", error);
        CloseHandle(device); return 1;
    }
    OVERLAPPED operation = {0}; DWORD written = 0;
    operation.hEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
    if (!operation.hEvent) { CloseHandle(device); return 1; }
    printf("{\"event\":\"print_attempt\",\"ink\":\"C\",\"bytes\":%zu,\"packet_sha256\":\"%s\",\"attempt\":1}\n", sizeof(cyan_packet), packet_sha256);
    BOOL ok = WriteFile(device, cyan_packet, (DWORD)sizeof(cyan_packet), &written, &operation);
    error = ok ? 0 : GetLastError();
    if (!ok && error == ERROR_IO_PENDING) {
        if (WaitForSingleObject(operation.hEvent, 3000) == WAIT_OBJECT_0)
            error = GetOverlappedResult(device, &operation, &written, FALSE) ? 0 : GetLastError();
        else {
            CancelIoEx(device, &operation);
            GetOverlappedResult(device, &operation, &written, TRUE);
            error = ERROR_TIMEOUT;
        }
    }
    CloseHandle(operation.hEvent); CloseHandle(device);
    int accepted = !error && written == sizeof(cyan_packet);
    printf("{\"event\":\"write_result\",\"bytes\":%lu,\"error\":%lu,\"transport_accepted\":%s,\"physical_print_verified\":false,\"automatic_retry\":false}\n",
           written, error, accepted ? "true" : "false");
    return accepted ? 0 : 1;
}
int wmain(int argc, wchar_t **argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    setvbuf(stdout, NULL, _IONBF, 0);
    if (sizeof(void *) != 8 || IOCTL_USBPRINT_GET_1284_ID != 0x220034) return 2;
    if (argc == 2 && !wcscmp(argv[1], L"--self-test")) return self_test();
    if (argc == 2 && !wcscmp(argv[1], L"--packet")) {
        for (size_t i = 0; i < sizeof(cyan_packet); ++i) printf("%02x", cyan_packet[i]);
        putchar('\n'); return 0;
    }
    int sending = argc == 2 && !wcscmp(argv[1], L"--send-cyan");
    if (argc != 1 && !sending && !(argc == 2 && !wcscmp(argv[1], L"--inspect"))) return 2;
    if (self_test()) return 2;
    HDEVINFO devices = SetupDiGetClassDevsW(&printer_interface, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
    if (devices == INVALID_HANDLE_VALUE) {
        printf("{\"event\":\"error\",\"stage\":\"enumeration\",\"code\":%lu}\n", GetLastError()); return 1;
    }
    unsigned matches = 0; int complete = 1; wchar_t *selected = NULL;
    for (DWORD index = 0; index < 256; ++index) {
        SP_DEVICE_INTERFACE_DATA iface = {0}; iface.cbSize = sizeof(iface);
        if (!SetupDiEnumDeviceInterfaces(devices, NULL, &printer_interface, index, &iface)) {
            if (GetLastError() != ERROR_NO_MORE_ITEMS) complete = 0;
            break;
        }
        DWORD needed = 0;
        SetupDiGetDeviceInterfaceDetailW(devices, &iface, NULL, 0, &needed, NULL);
        if (needed < sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA_W) || needed > 65536) { complete = 0; continue; }
        PSP_DEVICE_INTERFACE_DETAIL_DATA_W detail = calloc(1, needed);
        if (!detail) { complete = 0; break; }
        detail->cbSize = sizeof(*detail);
        if (!SetupDiGetDeviceInterfaceDetailW(devices, &iface, detail, needed, NULL, NULL)) {
            free(detail); complete = 0; continue;
        }
        if (target_path(detail->DevicePath)) {
            unsigned char data[8192] = {0}; DWORD size = 0;
            HANDLE device = CreateFileW(detail->DevicePath, 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                       NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
            if (device == INVALID_HANDLE_VALUE)
                device = CreateFileW(detail->DevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                    NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
            DWORD error = device == INVALID_HANDLE_VALUE ? GetLastError() : identity(device, data, sizeof(data), &size);
            if (device != INVALID_HANDLE_VALUE) CloseHandle(device);
            int valid = !error && size <= sizeof(data) && target_identity(data, size);
            printf("{\"event\":\"target_check\",\"vid\":\"04b8\",\"pid\":\"1334\",\"interface\":\"00\",\"identity_error\":%lu,\"model_allowed\":%s}\n",error,valid ? "true" : "false");
            if (!valid) complete = 0;
            else {
                ++matches;
                if (matches == 1) {
                    size_t length = (wcslen(detail->DevicePath) + 1) * sizeof(wchar_t);
                    selected = malloc(length);
                    if (selected) memcpy(selected, detail->DevicePath, length);
                }
            }
        }
        free(detail);
        if (index == 255) complete = 0;
    }
    SetupDiDestroyDeviceInfoList(devices);
    printf("{\"event\":\"selection\",\"matching_targets\":%u,\"complete\":%s,\"send_requested\":%s}\n", matches, complete ? "true" : "false", sending ? "true" : "false");
    int result = 1;
    if (complete && matches == 1 && selected) result = sending ? send_once(selected) : 0;
    else puts("{\"event\":\"refused\",\"reason\":\"exactly_one_verified_target_required\",\"data_written\":false}");
    free(selected); return result;
}
