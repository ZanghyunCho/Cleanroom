"""R4.6: zero the chip-accounted usage query used by native consume prechecks."""
import hashlib
from build_ku_r4 import build as build_r4
from build_ku_stage1 import P,word,BASE
OFFSET=0x29ba0

def build():
 base,_=build_r4();code=bytearray(base)
 assert base[OFFSET:OFFSET+12]==bytes.fromhex('0020a0e13110a0e33000a0e3')
 code[OFFSET:OFFSET+12]=word(0xe3a00000)+word(0xe3a01000)+word(0xe12fff1e)
 assert code[:OFFSET]==base[:OFFSET] and code[OFFSET+12:]==base[OFFSET+12:]
 report={'label':'KU25Q4-R46A-R4-usage-query-only','baseline':'R4 user reported reboot, printing and cleaning preserve values','module_sha256':hashlib.sha256(code).hexdigest(),'baseline_module_sha256':hashlib.sha256(base).hexdigest(),'only_change_vs_R4':[hex(OFFSET),hex(OFFSET+12)],'semantics':'Usage getter for pair 30/31 returns uint64 zero; native capacity/request comparisons and raw-state checks unchanged','stored_chip_usage_changed':False,'chip_wire_response_replaced':False,'InitialCharge_CL1_CL2_CL3_individual_hardware_tests':False,'all_job_to_precheck_mappings_verified':False}
 (P/'KU25Q4-R46A-control.bin').write_bytes(code);return bytes(code),report
