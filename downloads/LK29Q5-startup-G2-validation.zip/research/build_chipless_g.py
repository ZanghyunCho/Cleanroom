"""G diagnostic: avoid waste bus setup/finish after F1 selects exemption.

This is a hypothesis-isolation build, not proof of the physical failure cause.
Original delays, software state, ink bus code and cover logic stay intact.
"""
import hashlib
import json
import struct
from build_chipless_control import build as build_f1, ROOT, BASE


def build():
    f1, previous = build_f1()
    code = bytearray(f1)
    additions = []
    for address, expected, replacement, reason in [
        (0x4340617c, 0x433f74d8, 0xe3a00000, 'Skip waste-only bus begin, preserve original success branch and delay'),
        (0x43406194, 0x433f7568, 0xe3a00000, 'Skip matching waste-only bus end, preserve original trailing software/delay path'),
        (0x434062b0, 0x433f7790, 0xe12fff1e, 'Skip waste-only presence-finish bus callback'),
    ]:
        off = address - BASE
        old = struct.unpack_from('<I', f1, off)[0]
        assert old >> 24 == (0xea if address == 0x434062b0 else 0xeb)
        immediate = old & 0xffffff
        if immediate & 0x800000:
            immediate -= 0x1000000
        assert address + 8 + immediate * 4 == expected
        struct.pack_into('<I', code, off, replacement)
        additions.append(dict(address=hex(address), before=struct.pack('<I',old).hex(),
                              after=struct.pack('<I',replacement).hex(), reason=reason))
    original = (ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes()
    # The profile exemption remains active; this build is not for profile-0 use.
    assert struct.unpack_from('<I',code,0x4340acf0-BASE)[0] == 0xe3a00001
    report = dict(label='G-waste-bus-isolation', module_sha256=hashlib.sha256(code).hexdigest(),
                  F1_module_sha256=previous['module_sha256'], patches=previous['patches']+additions,
                  changed_bytes=sum(a!=b for a,b in zip(original,code)),
                  extra_instruction_sites_vs_F1=3, physical_tested=False,
                  hypothesis='F1 skipped individual workers but retained waste-specific bus lifecycle calls',
                  preserved=['Original state getter, counter reads and status functions',
                             'Original delays/software branches following begin/end calls',
                             'Original shared bus implementation and ink paths',
                             'Cover input functions and E/F1 changes'],
                  limits=['Physical failure cause is unconfirmed',
                          'Actual absence, hot removal and complete boot remain hardware tests',
                          'Real waste collection is still necessary'])
    (ROOT/'experimental/maintenance-control.chipless-G.bin').write_bytes(code)
    (ROOT/'experimental/maintenance-control.chipless-G.json').write_text(json.dumps(report,indent=2)+'\n')
    return bytes(code), report


if __name__ == '__main__':
    _, report = build()
    print(report['module_sha256'])
