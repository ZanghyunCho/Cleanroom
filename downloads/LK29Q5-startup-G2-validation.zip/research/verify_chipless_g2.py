"""G2 guarded recovery through the actual patched periodic function."""
import hashlib,json,struct
from pathlib import Path
from build_chipless_g2 import build,ROOT,HELPER
from verify_consumption_control import verify as verify_e
from probe_maintenance_recovery import setup,snapshot
from unicorn.arm_const import UC_ARM_REG_R4,UC_ARM_REG_R5,UC_ARM_REG_R6,UC_ARM_REG_R7,UC_ARM_REG_R8,UC_ARM_REG_R9,UC_ARM_REG_R10,UC_ARM_REG_R11

def main():
    code,manifest=build()
    regression=verify_e(code,manifest);assert regression['scenario_count']==395
    g=(ROOT/'experimental/maintenance-control.chipless-G.bin').read_bytes()
    cases=[]
    for mode in (0,1):
        for state in range(8):
            for error in range(36):
                n=setup(code)
                # Synthetic state/error combinations test each guard independently.
                error_ptr=n.literal(0x43408368,-0x2b4)
                n.u.mem_write(error_ptr,bytes([error]))
                n.u.mem_write(n.state,bytes([state]))
                n.u.mem_write(n.literal(0x433f6378,0x27c),struct.pack('<I',mode)+bytes(4))
                before=snapshot(n);trace_start=len(n.trace)
                regs=(UC_ARM_REG_R4,UC_ARM_REG_R5,UC_ARM_REG_R6,UC_ARM_REG_R7,UC_ARM_REG_R8,UC_ARM_REG_R9,UC_ARM_REG_R10,UC_ARM_REG_R11)
                for i,reg in enumerate(regs):n.u.reg_write(reg,0x11220000+i)
                result=n.call(0x4340e4c8,0)
                assert all(n.u.reg_read(reg)==0x11220000+i for i,reg in enumerate(regs))
                trace=n.trace[trace_start:];after=snapshot(n)
                recover=mode==0 and state in (1,2) and error in (32,33,34)
                assert trace.count(HELPER)==1 and trace.count(0x433ff89c)==1
                assert trace.count(0x4340dc0c)==int(recover)
                assert after['counters']==before['counters']
                if recover:
                    assert after['raw_state']==0 and after['selected_error']==32 and after['usable']==1
                else:
                    assert after['raw_state']==state and after['selected_error']==error
                old=setup(g)
                old.u.mem_write(error_ptr,bytes([error]));old.u.mem_write(old.state,bytes([state]))
                old.u.mem_write(old.literal(0x433f6378,0x27c),struct.pack('<I',mode)+bytes(4))
                assert result==old.call(0x4340e4c8,0)
                if not recover:assert after==snapshot(old)
                assert bytes(n.u.mem_read(HELPER,manifest['helper_size']))==code[HELPER-0x433e0000:HELPER-0x433e0000+manifest['helper_size']]
                cases.append(dict(mode=mode,raw_state=state,selected_error=error,
                                  revalidation_calls=int(recover),result=after))
    # Actual error setter and periodic processing, rather than manually-seeded pairs.
    transitions=[]
    for error in (12,33,34,35):
        results={}
        for variant,body in [('G',g),('G2',code)]:
            n=setup(body);n.call(0x43408308,0,error)
            before=snapshot(n);n.call(0x4340e4c8,0);after=snapshot(n)
            n.call(0x4340e4c8,0);repeated=snapshot(n)
            assert repeated==after and after['counters']==before['counters']
            results[variant]=dict(before=before,after=after,repeated=repeated)
        assert results['G']['after']==results['G']['before']
        if error in (33,34):assert results['G2']['after']['raw_state']==0
        else:assert results['G2']['after']==results['G2']['before']
        transitions.append(dict(error=error,results=results))
    report=dict(module_sha256=hashlib.sha256(code).hexdigest(),scenario_count=395+len(cases)+len(transitions),
                E_regressions=regression,guard_cases=cases,transition_cases=transitions,
                native_verdict_hooks=0,physical_tested=False,
                limitations=['Synthetic error/state combinations, not actual electrical removal',
                  'No whole boot, scheduler, interruption or reentrant execution',
                  'If the periodic worker does not run in the failed printer, this repair cannot run',
                  'Inherits G bus lifecycle isolation; physical cause remains unconfirmed'])
    (ROOT/'validation/chipless-G2-native-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS',report['scenario_count'],'G2 cases;',len(cases),'guard combinations')

if __name__=='__main__':main()
