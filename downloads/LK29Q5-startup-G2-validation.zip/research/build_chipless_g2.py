"""G2 diagnostic: guarded revalidation at the end of the periodic waste scan.

Retains G lifecycle isolation. Does not force the raw state getter to zero.
No physical boot or removal success is implied by building this module.
"""
import hashlib,json,struct
from build_chipless_g import build as build_g,ROOT,BASE

HELPER=0x4340560c
HOOK=0x4340e534

def branch(address,target,link=False,condition=14):
    delta=target-address-8
    assert delta%4==0 and -(1<<25)<=delta<(1<<25)
    return (condition<<28)|(0x0b000000 if link else 0x0a000000)|((delta//4)&0xffffff)

def build():
    previous,manifest=build_g();code=bytearray(previous)
    # This body is unreachable under F1's always-true profile predicate.
    # The existing gate/prologue/epilogue before it are preserved.
    gate=struct.unpack_from('<4I',previous,0x434055fc-BASE)
    assert gate==(branch(0x434055fc,0x4340ace0,True),0xe3500000,0x128dd00c,0x18bd83f0)
    assert struct.unpack_from('<I',previous,0x4340acf0-BASE)[0]==0xe3a00001
    assert struct.unpack_from('<I',previous,HOOK-BASE)[0]==branch(HOOK,0x433ff89c,True)
    words=[];labels={};fixups=[]
    def put(w):words.append(w)
    def call(target):put(branch(HELPER+4*len(words),target,True))
    def jump(label,condition):
        fixups.append((len(words),label,condition));put(0)
    put(0xe92d4070) # push r4,r5,r6,lr; preserve 8-byte stack alignment
    call(0x433ff89c) # original tail call must still run exactly once
    put(0xe1a04000) # save its return value
    call(0x433f6378);put(0xe3500000);jump('done',1)
    put(0xe3a00000);call(0x4340ace0);put(0xe3500000);jump('done',0)
    put(0xe3a00000);call(0x43407f5c)
    put(0xe3500001);jump('candidate',0)
    put(0xe3500002);jump('done',1)
    labels['candidate']=len(words)
    put(0xe3a00000);call(0x434082fc)
    put(0xe3500020);jump('done',3) # selected error below 32: preserve critical/latched error
    put(0xe3500022);jump('done',8) # above 34 also remains untouched
    put(0xe3a00003);call(0x4340dc0c) # original validation, not a synthetic normal verdict
    labels['done']=len(words)
    put(0xe1a00004);put(0xe8bd8070)
    for index,label,condition in fixups:
        words[index]=branch(HELPER+4*index,HELPER+4*labels[label],False,condition)
    helper=struct.pack('<'+'I'*len(words),*words)
    assert HELPER+len(helper)<=0x43405720
    code[HELPER-BASE:HELPER-BASE+len(helper)]=helper
    struct.pack_into('<I',code,HOOK-BASE,branch(HOOK,HELPER,True))
    allowed=set(range(HELPER-BASE,HELPER-BASE+len(helper)))|set(range(HOOK-BASE,HOOK-BASE+4))
    assert all(i in allowed for i,(a,b) in enumerate(zip(previous,code)) if a!=b)
    report=dict(label='G2-guarded-revalidation-diagnostic',module_sha256=hashlib.sha256(code).hexdigest(),
                G_module_sha256=manifest['module_sha256'],helper_address=hex(HELPER),helper_size=len(helper),
                hook_address=hex(HOOK),patches=manifest['patches']+[
                    dict(address=hex(HELPER),before=previous[HELPER-BASE:HELPER-BASE+len(helper)].hex(),after=helper.hex(),reason='Guarded original revalidation helper in unreachable F1 body'),
                    dict(address=hex(HOOK),before=previous[HOOK-BASE:HOOK-BASE+4].hex(),after=code[HOOK-BASE:HOOK-BASE+4].hex(),reason='Call guarded helper after original periodic processing')],
                conditions='Normal operating mode AND exemption active AND raw state in {1,2} AND selected error in {32,33,34}',
                original_gate_preserved=True,module_size_unchanged=True,
                physical_tested=False,limits=['Inherits unproven G bus isolation hypothesis',
                  'Recovery only if the periodic path executes; complete scheduler not tested',
                  'Actual absent boot and removal errors remain unknown',
                  'Reuses code reachable only if F1 profile invariant is violated; not valid without F1'])
    (ROOT/'experimental/maintenance-control.chipless-G2.bin').write_bytes(code)
    (ROOT/'experimental/maintenance-control.chipless-G2.json').write_text(json.dumps(report,indent=2)+'\n')
    return bytes(code),report

if __name__=='__main__':
    _,r=build();print(r['module_sha256'])
