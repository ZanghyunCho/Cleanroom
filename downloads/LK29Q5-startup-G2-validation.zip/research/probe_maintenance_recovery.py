"""Original error-latch/raw-state recovery experiments on F1 and G.

This tests synthetic errors and original helpers, not actual chip removal.
No firmware is rebuilt or patched by this probe.
"""
import hashlib
import json
import struct
from pathlib import Path
from maintenance_v3_fixture import Fixture
from probe_maintenance_state import ROOT


def snapshot(n):
    output=0x42001000
    n.call(0x43410748,output)
    return dict(selected_error=n.call(0x434082fc),raw_state=n.call(0x43407f5c),
                usable=n.u.mem_read(output,1)[0],remaining=n.call(0x43407ffc),
                counters=[struct.unpack('<I',n.u.mem_read(p,4))[0]
                          for p in (0x437cfebc,0x437cfecc,0x437cff9c)])


def setup(code):
    n=Fixture(code,0,False)
    n.call(0x434051b4);n.call(0x43405798,0);n.call(0x4340e428,3)
    n.u.mem_write(0x42003000,struct.pack('<I',1)+bytes(12))
    for i,p in enumerate((0x437cfebc,0x437cfecc,0x437cff9c)):
        n.u.mem_write(p,struct.pack('<I',123000000+i))
    return n


def main():
    sequences=[];workers=[]
    candidates=[(0x4340e428,(3,)),(0x4340e15c,(0x42001000,)),
                (0x4340df98,(0x42001000,0)),(0x4340de44,(0,0)),
                (0x4340e1f4,(0x42003000,10)),(0x43405bec,(0,10)),
                (0x4340dc0c,(3,)),
                (0x43407ec4,())]
    for variant in ('F1','G'):
        code=(ROOT/f'experimental/maintenance-control.chipless-{variant}.bin').read_bytes()
        for error,state in ((33,1),(34,2),(12,4)):
            n=setup(code);initial=snapshot(n)
            n.call(0x43408308,0,error);latched=snapshot(n)
            # Errors below 32 latch; 33/34 are transient and permit replacement.
            n.call(0x43408308,0,32);normal_attempt=snapshot(n)
            if error < 32:
                assert normal_attempt==latched
            else:
                assert normal_attempt['raw_state']==0 and normal_attempt['usable']==1
            n.call(0x43408308,0,error)
            n.call(0x434083bc);cleared=snapshot(n)
            assert cleared['selected_error']==32 and cleared['raw_state']==state and cleared['usable']==0
            gate=n.call(0x43410008,0)
            assert gate==0 and n.call(0x43407f5c)==state
            ret=n.call(0x4340e1f4,0x42003000,10);after_worker=snapshot(n)
            assert ret==1 and after_worker['raw_state']==state and after_worker['usable']==0
            n.call(0x43407ec4);after_init=snapshot(n)
            assert after_init['raw_state']==0 and after_init['usable']==1
            assert all(row['counters']==initial['counters'] for row in
                       (latched,normal_attempt,cleared,after_worker,after_init))
            sequences.append(dict(variant=variant,module_sha256=hashlib.sha256(code).hexdigest(),
                                  synthetic_error=error,initial=initial,latched=latched,
                                  normal_result_while_latched=normal_attempt,
                                  error_selector_clear_only=cleared,worker_return=ret,
                                  logical_recovery_gate_with_zero_flag=gate,
                                  after_successful_worker=after_worker,
                                  after_status_initializer_only=after_init))
            for function,args in candidates:
                n=setup(code);n.call(0x43408308,0,error);n.call(0x434083bc)
                ret=n.call(function,*args);current=snapshot(n)
                assert current['raw_state']==(0 if function in (0x43407ec4,0x4340dc0c) else state)
                workers.append(dict(variant=variant,synthetic_error=error,function=hex(function),
                                    return_value=ret,result=current))
    report=dict(sequence_cases=sequences,individual_worker_cases=workers,
                sequence_count=len(sequences),individual_count=len(workers),
                firmware_modified=False,physical_tested=False,
                conclusions=[
                    'First-error selection and raw cartridge state are separate',
                    'Clearing the error selector alone does not restore usable state',
                    'A successful exempt worker can leave an error state unchanged',
                    'The original status initializer restores state without changing sampled counters',
                    'The original general revalidation worker also restores state after clearing the selected error',
                    'Errors 33/34 are replaceable; errors below 32 have first-error latch semantics'],
                not_proven=[
                    'Actual errors emitted during physical absence or removal',
                    'Which initializer or worker the physical boot/reinsert scheduler calls',
                    'That runtime status initialization is a safe fix',
                    'Whole printer recovery, interrupt delivery or cold boot'])
    path=ROOT/'validation/maintenance-recovery-probe.json'
    path.write_text(json.dumps(report,indent=2)+'\n')
    print(path, len(sequences),'sequences,',len(workers),'independent worker cases')


if __name__=='__main__':main()
