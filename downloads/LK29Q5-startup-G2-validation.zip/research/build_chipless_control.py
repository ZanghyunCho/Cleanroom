"""F1: E plus one-byte default-result change in original profile predicate.
This tests the existing chip-exemption branches, not a global state override.
"""
import hashlib,json,struct
from build_consumption_control import build as build_e,ROOT
from build_remaining_report_control import BASE

def build():
 e,em=build_e();original=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes();code=bytearray(e)
 address=0x4340acf0;off=address-BASE;before=struct.pack('<I',0xe3a00000);after=struct.pack('<I',0xe3a00001)
 assert code[off:off+4]==before;code[off:off+4]=after
 assert sum(a!=b for a,b in zip(e,code))==1
 patches=em['patches']+[{'address':hex(address),'before':before.hex(),'after':after.hex(),'reason':'Default original profile predicate result to 1; keep original profile reads and conditional result path'}]
 diffs=[i for i,(a,b) in enumerate(zip(original,code)) if a!=b]
 allowed={i for p in patches for i in range(int(p['address'],16)-BASE,int(p['address'],16)-BASE+4)}
 assert len(diffs)==12 and set(diffs)<=allowed
 for a,n in [(0x43407f5c,0x24),(0x43406890,0x1c),(0x434068bc,0xc),(0x43410748,0xe0),(0x43408308,0xb4),(0x43408468,0x6c)]:
  assert code[a-BASE:a-BASE+n]==original[a-BASE:a-BASE+n]
 manifest={'label':'F1-profile-exemption-probe','module_sha256':hashlib.sha256(code).hexdigest(),'E_module_sha256':em['module_sha256'],
 'patches':patches,'extra_changed_bytes_vs_E':1,'changed_bytes':12,'instruction_sites':7,
 'intent':'Exercise original chip-exemption branches with real counter reads and E zero-new-usage logic',
 'preserved':['Original raw state getter and transitions','Real existing counter reads','Original profile-record reads','Cover checks and error selector','C/D/E changes'],
 'limitations':['Profile predicate affects multiple original paths','Physical boot and missing-chip operation unverified','Same general exemption predicate was part of failed v3 together with other changes; F1 isolates it',
 'UI/RTOS completion behavior and actual bus callbacks not established','Actual waste collection is still necessary'],
 'physical_boot_tested':False,'physical_chipless_tested':False}
 (ROOT/'experimental/maintenance-control.chipless-F1.bin').write_bytes(code)
 (ROOT/'experimental/maintenance-control.chipless-F1.json').write_text(json.dumps(manifest,indent=2)+'\n')
 return bytes(code),manifest
if __name__=='__main__':
 _,r=build();print(json.dumps(r,indent=2))
