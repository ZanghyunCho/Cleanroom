"""Package G diagnostic on the exact F1+LOONA baseline; retain all other bytes."""
import hashlib
import argparse
import json
import struct
import zipfile
from pathlib import Path
from decode_crom import ROOT, decode
from encode_crom import encode
from audit_recovery_failure import loader_audit, checksum_audit


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--variant',choices=('G','G2'),default='G')
    variant=parser.parse_args().variant
    baseline = ROOT/'experimental/FW7560TL_LK29Q5-LOONA-F1.efu'
    assert sha(baseline.read_bytes()) == '1f4925e8d8dd3d023962214ff78b48147ca64d7e4a974db470bae0c43a4159c7'
    code = (ROOT/f'experimental/maintenance-control.chipless-{variant}.bin').read_bytes()
    tests = json.loads((ROOT/f'validation/chipless-{variant}-native-results.json').read_text())
    expected_cases={'G':430,'G2':975}[variant]
    assert tests['module_sha256'] == sha(code) and tests['scenario_count'] == expected_cases
    with zipfile.ZipFile(baseline) as z:
        entry = z.getinfo('FW7560TL.rcx')
        old = z.read(entry)
    start, limit = 0x14153, 0x21b553
    end = start + 4 + int.from_bytes(old[start+6:start+10],'big')
    assert old[end:end+2] == b'\xff\xd8'
    second_size = int.from_bytes(old[end+2:end+6],'big')
    second = old[end:end+second_size]
    assert old[end+second_size:limit] == b'\xff'*(limit-end-second_size)
    compressed, compression = encode(code,old[start:end],positive_padding=True)
    replacement = compressed+second
    assert len(replacement) <= limit-start
    updated = bytearray(old)
    updated[start:limit] = replacement + b'\xff'*(limit-start-len(replacement))
    decoded, _ = decode(updated,start)
    assert decoded == code
    sign = old.index(b'EPSONSIGN');body=sign+4096
    assert struct.unpack_from('<I',old,sign+16)[0] == len(old)-body+1
    meta = struct.unpack_from('<I',old,body+28)[0]
    size = struct.unpack_from('<I',old,body+64)[0]
    begin=body+4096+meta;finish=begin+size
    struct.pack_into('<H',updated,body+54,sum(updated[begin:finish])&65535)
    updated[body+68:body+88]=hashlib.sha1(updated[begin:finish]+hashlib.sha1(updated[body:body+14]).digest()).digest()
    previous=0
    for lo,hi in sorted([(start,limit),(body+54,body+56),(body+68,body+88)]):
        assert old[previous:lo] == updated[previous:lo]
        previous=hi
    assert old[previous:]==updated[previous:] and len(old)==len(updated)
    pos=body;sections=[]
    while pos<len(updated):
        h=updated[pos:pos+4096];assert h.startswith(b'EPSON')
        m=struct.unpack_from('<I',h,28)[0];n=struct.unpack_from('<I',h,64)[0]
        lo=pos+4096+m;hi=lo+n;assert hi<=len(updated)
        assert sum(updated[pos+4096:lo])&65535==struct.unpack_from('<H',h,18)[0]
        assert sum(updated[lo:hi])&65535==struct.unpack_from('<H',h,54)[0]
        assert hashlib.sha1(updated[lo:hi]+hashlib.sha1(h[:14]).digest()).digest()==h[68:88]
        sections.append(dict(offset=hex(pos),checks_passed=True));pos=hi
    assert len(sections)==4 and pos==len(updated)
    official=(ROOT/'FW7560TL.rcx').read_bytes()
    loader=loader_audit(variant+'-maintenance',compressed,official[0x25bb23:0x25bb23+0xae8],code)
    receiver=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
    checksum=checksum_audit(variant+'-maintenance',bytes(updated),receiver[0x4419e2e0-0x4409b000:0x4419e324-0x4409b000])
    assert checksum['native_checksum_return']==1 and loader['native_lz_output_exact'] and loader['native_dma_mod48']==0
    output=ROOT/f'experimental/FW7560TL_LK29Q5-LOONA-{variant}.efu'
    with zipfile.ZipFile(output,'w') as z:z.writestr(entry,updated)
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None and z.read(entry.filename)==updated
    report=dict(artifact=output.name,efu_sha256=sha(output.read_bytes()),rcx_sha256=sha(updated),
                baseline='F1+LOONA',baseline_efu_sha256=sha(baseline.read_bytes()),module_sha256=sha(code),
                native_scenarios=expected_cases,compression=compression,native_loader=loader,native_checksum=checksum,
                host_sections=sections,second_control_frame_preserved=True,LOONA_slot_preserved=True,
                receiver_and_public_key_and_signature_bytes_preserved=True,
                body_declared_length=len(updated)-body+1,body_actual_length=len(updated)-body,
                signature_valid_after_modification=False,physical_tested=False,full_receiver_replay=False,
                user_F1_observation=dict(installed_works=True,absent_boot_fails=True,hot_removal_stops=True,
                                         original_and_LOONA_both_fail=True,no_maintenance_cover=True),
                limits=['Bus lifecycle/recovery hypothesis, not confirmed physical root cause',
                        'No complete cold boot, physical absence or hot-removal execution',
                        'Hardware Huffman modeled at completion boundary',
                        'No ink cartridge feature or cover sensor change included'])
    output.with_suffix('.validation.json').write_text(json.dumps(report,indent=2)+'\n')
    Path(str(output)+'.sha256').write_text(report['efu_sha256']+'  '+output.name+'\n')
    print('PASS',variant,'package',report['efu_sha256'])


if __name__=='__main__':main()
