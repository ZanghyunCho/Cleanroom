"""Read-only P704 ARM header and receiver branch probes; no firmware output."""
from pathlib import Path
import hashlib, json, struct
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm_const import *

ROOT = Path(__file__).resolve().parent
DUMP = Path('/workspace/p5300-analysis')
STOP = 0x52000000

def machine(code):
    u = Uc(UC_ARCH_ARM, UC_MODE_ARM)
    u.reg_write(UC_ARM_REG_C1_C0_2, 0xf << 20)
    u.reg_write(UC_ARM_REG_FPEXC, 0x40000000)
    for a, n in [(0,0x1000000),(0x45000000,0x40000),
                 (0x48b3b000,0x2000),(0x49004000,0x1000),
                 (0x50000000,0x20000),(0x51000000,0x20000),(STOP,0x1000),
                 (0x8b8a8000,0x2000)]:
        u.mem_map(a,n)
    u.mem_write(0,code)
    # Original module's absolute data addresses imply this relocation bias;
    # independently checked using its SHA-256 IV and switch-table targets.
    if len(code) == 7921996:
        u.mem_map(0x482ba000,0x800000)
        u.mem_write(0x482ba854,code)
    return u

def call(u, pc, *args):
    u.reg_write(UC_ARM_REG_CPSR,0x13)
    u.reg_write(UC_ARM_REG_SP,0x5101f000)
    u.reg_write(UC_ARM_REG_LR,STOP)
    for reg,val in zip((UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3),args):
        u.reg_write(reg,val)
    u.emu_start(pc,STOP,count=10000000)
    if u.reg_read(UC_ARM_REG_PC)!=STOP:
        raise RuntimeError('instruction budget exhausted at '+hex(u.reg_read(UC_ARM_REG_PC)))
    return u.reg_read(UC_ARM_REG_R0)

def header_tests():
    d=(ROOT/'FW4838TL.rcx').read_bytes();s=d.index(b'EPSONSIGN');h=d[s:s+4096]
    other=Path('/workspace/p5300-analysis/FWCL14TL.rcx').read_bytes();os=other.index(b'EPSONSIGN')
    results=[]
    for label,header in [('official_KH',h),('wrong_KU',other[os:os+4096]),('zero_length',h[:16]+bytes(4)+h[20:])]:
        u=machine((DUMP/'IC102.BIN').read_bytes())
        u.mem_write(0x50000000,header)
        ret=call(u,0xa144,0x50000000,0x50010000)
        results.append(dict(case=label,returned=ret,remaining=struct.unpack('<I',u.mem_read(0x50010000,4))[0]))
    assert [r['returned'] for r in results]==[1,0,0]
    return results

def receiver_tests():
    code=(DUMP/'decoded/IC102.BIN-0xe0000.bin').read_bytes()
    results=[]
    for remaining in (64,65,63):
        u=machine(code)
        u.mem_write(0x4501bdb0,struct.pack('<II',1,remaining))
        u.mem_write(0x50000000,bytes(range(64)))
        # Transport fixture only: read callback reports the requested size.
        u.mem_write(0x50010000,bytes.fromhex('0100a0e11eff2fe1'))
        # Run the original SHA-256 initializer and update, without replacing them.
        entered=[]
        def trace(uc,address,size,user):
            if address==0xf6a9c:
                digest=bytes(uc.mem_read(uc.reg_read(UC_ARM_REG_R0),32))
                assert digest==hashlib.sha256(bytes(range(64))).digest()
                entered.append(address)
                uc.reg_write(UC_ARM_REG_PC,STOP)
                uc.emu_stop()
        u.hook_add(UC_HOOK_CODE,trace)
        assert call(u,0xf7594,0,0x48b3b768)==1
        u.reg_write(UC_ARM_REG_CPSR,0x13)
        u.reg_write(UC_ARM_REG_SP,0x5101f000)
        u.reg_write(UC_ARM_REG_LR,STOP)
        for reg,val in zip((UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2),(0x50010000,0x50000000,64)):
            u.reg_write(reg,val)
        u.emu_start(0xf6978,STOP,count=10000000)
        pc=u.reg_read(UC_ARM_REG_PC)
        assert pc in (STOP,0xf76e4),hex(pc)
        results.append(dict(initial_remaining=remaining,remaining=struct.unpack('<I',u.mem_read(0x4501bdb4,4))[0],state=u.mem_read(0x4501bdb0,1)[0],verification_call_reached=bool(entered),native_sha256_matches_host=True if entered else None,returned=u.reg_read(UC_ARM_REG_R0) if pc==STOP and not entered else None))
    assert results[0]['verification_call_reached']
    assert results[1]['returned']==1 and results[1]['remaining']==1 and results[1]['state']==1 and not results[1]['verification_call_reached']
    assert results[2]['returned']==0
    return results

if __name__=='__main__':
    result={'header_tests':header_tests(),'receiver_tests':receiver_tests(),
            'scope':'Original ARM instructions; synthetic transport callback. Execution stops at the verification call instruction, before the callee executes; ECDSA result is never forced. Original SHA-256 executes and its finalized digest matches host SHA-256. No upper receiver, installation, flash, or boot claim.'}
    (ROOT/'native-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
