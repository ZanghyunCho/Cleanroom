@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0run-native-cyan.ps1" -Mode PrintCyan
pause
