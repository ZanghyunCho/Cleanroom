#ifndef NATIVE_CYAN_QUEUES_H
#define NATIVE_CYAN_QUEUES_H
#include <wchar.h>
int cyan_queue_self_test(void);
int cyan_list_printers(void);
int cyan_send_queue_hex(const wchar_t *name_hex, const wchar_t *port_hex, const wchar_t *driver_hex);
#endif
