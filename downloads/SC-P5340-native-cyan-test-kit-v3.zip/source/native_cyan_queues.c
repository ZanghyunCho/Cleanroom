/* Explicit Windows queue selection. Fixed packet only; RAW datatype preserves
 * its bytes. Queue/driver/port are rechecked immediately before StartDoc. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winspool.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <string.h>
#include "native_cyan_queues.h"
#include "native_cyan_packet.h"

static int allowed_driver(const wchar_t *driver) {
    static const wchar_t *allowed[] = {L"EPSON SC-P5300 Series", L"EPSON SC-P5340", L"EPSON SC-P5340 Series"};
    if (!driver) return 0;
    for (size_t i = 0; i < sizeof(allowed) / sizeof(allowed[0]); ++i)
        if (!_wcsicmp(driver, allowed[i])) return 1;
    return 0;
}
static int allowed_port(const wchar_t *port) {
    return port && *port && !wcschr(port, L',') &&
        _wcsicmp(port, L"FILE:") && _wcsicmp(port, L"PORTPROMPT:") &&
        _wcsicmp(port, L"NUL:") && _wcsicmp(port, L"NUL");
}
static int eligible(const PRINTER_INFO_2W *info) {
    return info && info->pPrinterName && *info->pPrinterName &&
        allowed_driver(info->pDriverName) && allowed_port(info->pPortName) &&
        !(info->Attributes & PRINTER_ATTRIBUTE_WORK_OFFLINE);
}
static void hex_wide(const wchar_t *text) {
    if (!text) return;
    const unsigned char *bytes = (const unsigned char *)text;
    for (size_t i = 0; i < wcslen(text) * sizeof(wchar_t); ++i) printf("%02x", bytes[i]);
}
static int digit(wchar_t ch) {
    if (ch >= L'0' && ch <= L'9') return ch - L'0';
    if (ch >= L'a' && ch <= L'f') return ch - L'a' + 10;
    if (ch >= L'A' && ch <= L'F') return ch - L'A' + 10;
    return -1;
}
static wchar_t *decode_hex(const wchar_t *hex) {
    size_t count = wcslen(hex);
    if (!count || count % 4 || count > 8192) return NULL;
    wchar_t *result = calloc(count / 4 + 1, sizeof(wchar_t));
    if (!result) return NULL;
    for (size_t i = 0; i < count; i += 4) {
        int a = digit(hex[i]), b = digit(hex[i+1]), c = digit(hex[i+2]), d = digit(hex[i+3]);
        if (a < 0 || b < 0 || c < 0 || d < 0) { free(result); return NULL; }
        unsigned value = (unsigned)((a << 4) | b | (c << 12) | (d << 8));
        if (!value) { free(result); return NULL; }
        result[i / 4] = (wchar_t)value;
    }
    return result;
}
static int selection_matches(const PRINTER_INFO_2W *info, const wchar_t *name,
                             const wchar_t *port, const wchar_t *driver) {
    return eligible(info) && !_wcsicmp(info->pPrinterName, name) &&
        !_wcsicmp(info->pPortName, port) && !_wcsicmp(info->pDriverName, driver);
}
int cyan_queue_self_test(void) {
    PRINTER_INFO_2W info = {0};
    info.pPrinterName = L"Photo Printer"; info.pPortName = L"USB026";
    info.pDriverName = L"EPSON SC-P5300 Series";
    if (!eligible(&info) || !selection_matches(&info, L"Photo Printer", L"USB026", info.pDriverName)) return 1;
    if (selection_matches(&info, L"Other Printer", L"USB026", info.pDriverName) ||
        selection_matches(&info, L"Photo Printer", L"USB027", info.pDriverName) ||
        selection_matches(&info, L"Photo Printer", L"USB026", L"EPSON SC-P5000 Series")) return 1;
    info.pPortName = L"IP_192.0.2.1"; if (!eligible(&info)) return 1;
    const wchar_t *blocked[] = {L"FILE:", L"PORTPROMPT:", L"NUL:", L"USB001,USB002", L""};
    for (size_t i = 0; i < sizeof(blocked)/sizeof(blocked[0]); ++i) {
        info.pPortName = (wchar_t *)blocked[i]; if (eligible(&info)) return 1;
    }
    info.pPortName = L"USB026"; info.Attributes = PRINTER_ATTRIBUTE_WORK_OFFLINE;
    if (eligible(&info)) return 1;
    info.Attributes = 0; info.pDriverName = L"Microsoft Print to PDF";
    if (eligible(&info) || allowed_driver(L"EPSON SC-P5300 SeriesX")) return 1;
    wchar_t *decoded = decode_hex(L"410022005c00f5bc"); /* A, quote, slash, Korean syllable */
    if (!decoded || decoded[0] != L'A' || decoded[1] != L'"' || decoded[2] != L'\\' || decoded[3] != 0xbcf5) {
        free(decoded); return 1;
    }
    free(decoded);
    const wchar_t *bad[] = {L"", L"0000", L"410", L"zzzz", L"410000004200"};
    for (size_t i = 0; i < sizeof(bad)/sizeof(bad[0]); ++i) {
        decoded = decode_hex(bad[i]); if (decoded) { free(decoded); return 1; }
    }
    return 0;
}
int cyan_list_printers(void) {
    DWORD bytes = 0, count = 0;
    DWORD flags = PRINTER_ENUM_LOCAL | PRINTER_ENUM_CONNECTIONS;
    BOOL ok = EnumPrintersW(flags, NULL, 2, NULL, 0, &bytes, &count);
    DWORD error = ok ? 0 : GetLastError();
    if (!bytes && ok) { puts("{\"event\":\"queue_scan_done\",\"count\":0,\"complete\":true}"); return 0; }
    if ((!ok && error != ERROR_INSUFFICIENT_BUFFER) || !bytes || bytes > 16 * 1024 * 1024) {
        printf("{\"event\":\"error\",\"stage\":\"list_printers\",\"code\":%lu}\n",error); return 1;
    }
    BYTE *buffer = malloc(bytes);
    if (!buffer) return 1;
    if (!EnumPrintersW(flags, NULL, 2, buffer, bytes, &bytes, &count)) {
        printf("{\"event\":\"error\",\"stage\":\"list_printers\",\"code\":%lu}\n",GetLastError());
        free(buffer); return 1;
    }
    PRINTER_INFO_2W *list = (PRINTER_INFO_2W *)buffer;
    for (DWORD i = 0; i < count; ++i) {
        printf("{\"event\":\"printer_queue\",\"eligible\":%s,\"name_utf16\":\"",eligible(&list[i]) ? "true" : "false");
        hex_wide(list[i].pPrinterName); printf("\",\"port_utf16\":\""); hex_wide(list[i].pPortName);
        printf("\",\"driver_utf16\":\""); hex_wide(list[i].pDriverName);
        printf("\",\"status\":%lu}\n",list[i].Status);
    }
    printf("{\"event\":\"queue_scan_done\",\"count\":%lu,\"complete\":true}\n",count);
    free(buffer); return 0;
}
int cyan_send_queue_hex(const wchar_t *name_hex, const wchar_t *port_hex, const wchar_t *driver_hex) {
    wchar_t *name = decode_hex(name_hex), *port = decode_hex(port_hex), *driver = decode_hex(driver_hex);
    HANDLE printer = NULL; BYTE *buffer = NULL; DWORD job = 0, written = 0, error = 0;
    const char *stage = "selection_arguments"; int accepted = 0;
    error = ERROR_INVALID_PARAMETER;
    if (!name || !port || !driver || !allowed_driver(driver) || !allowed_port(port)) goto done;
    error = 0;
    PRINTER_DEFAULTSW defaults = {0}; defaults.DesiredAccess = PRINTER_ACCESS_USE;
    stage = "open_selected_printer";
    if (!OpenPrinterW(name, &printer, &defaults)) { error = GetLastError(); goto done; }
    DWORD needed = 0;
    GetPrinterW(printer, 2, NULL, 0, &needed);
    stage = "recheck_selected_printer";
    if (!needed || needed > 16 * 1024 * 1024) { error = ERROR_INVALID_DATA; goto done; }
    buffer = malloc(needed);
    if (!buffer) { error = ERROR_NOT_ENOUGH_MEMORY; goto done; }
    if (!GetPrinterW(printer, 2, buffer, needed, &needed)) { error = GetLastError(); goto done; }
    if (!selection_matches((PRINTER_INFO_2W *)buffer, name, port, driver)) {
        error = ERROR_INVALID_DATA; goto done;
    }
    DOC_INFO_1W document = {L"SC-P5340 native cyan experiment", NULL, L"RAW"};
    stage = "start_raw_job";
    job = StartDocPrinterW(printer, 1, (BYTE *)&document);
    if (!job) { error = GetLastError(); goto done; }
    printf("{\"event\":\"spooler_job_started\",\"job_id\":%lu,\"datatype\":\"RAW\",\"queue_name_utf16\":\"",job);
    hex_wide(name); printf("\",\"port_utf16\":\""); hex_wide(port); puts("\"}");
    stage = "start_page";
    if (!StartPagePrinter(printer)) { error = GetLastError(); goto done; }
    puts("{\"event\":\"queue_write_attempt\",\"ink\":\"C\",\"bytes\":622,\"automatic_retry\":false}");
    stage = "write_raw_job";
    if (!WritePrinter(printer, (LPVOID)cyan_packet, (DWORD)sizeof(cyan_packet), &written)) {
        error = GetLastError(); goto done;
    }
    if (written != sizeof(cyan_packet)) { error = ERROR_WRITE_FAULT; goto done; }
    stage = "end_page";
    if (!EndPagePrinter(printer)) { error = GetLastError(); goto done; }
    stage = "end_raw_job";
    if (!EndDocPrinter(printer)) { error = GetLastError(); goto done; }
    accepted = 1;
done:
    if (!accepted) {
        if (printer && job) AbortPrinter(printer);
        printf("{\"event\":\"error\",\"stage\":\"%s\",\"code\":%lu}\n",stage,error);
    }
    printf("{\"event\":\"queue_result\",\"job_id\":%lu,\"bytes\":%lu,\"error\":%lu,\"spooler_accepted\":%s,\"physical_print_verified\":false,\"automatic_retry\":false}\n",
           job,written,error,accepted ? "true" : "false");
    if (printer) ClosePrinter(printer);
    free(buffer); free(name); free(port); free(driver); return accepted ? 0 : 1;
}
