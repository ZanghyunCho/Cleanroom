"""Offline construction of isolated, uncompressed native raster fragments.

Input must already be an ink-separated, packed 1/2-bit plane. This is neither
an RGB renderer nor a complete print job; it has no device/network transport.
Channel names follow the supplied dump's inferred nozzle-pattern mapping.
"""
from collections.abc import Mapping
from dataclasses import dataclass
import struct

# Independently expressed protocol facts, not proprietary implementation code.
NATIVE_CODE = {'PK': 0x00, 'MK': 0x05, 'C': 0x02, 'VM': 0x01,
               'Y': 0x04, 'LC': 0x12, 'VLM': 0x11}


@dataclass(frozen=True)
class SixInkRaster:
    black: str = 'PK'

    def __post_init__(self):
        if self.black not in ('PK', 'MK'):
            raise ValueError('Select PK or MK explicitly')

    @property
    def channels(self):
        return (self.black, 'C', 'VM', 'Y', 'LC', 'VLM')

    def fragment(self, ink, *, bits, row_bytes, rows, packed_plane):
        """Build ESC i + seven-byte header + raw packed plane, and nothing else.

        row_bytes counts packed bytes, not pixels. Rows are limited to the
        firmware's observed 16-row non-extended path. Page setup, feed, pass
        scheduling and color separation must be established separately.
        """
        if ink not in self.channels:
            raise ValueError('Ink is excluded from the selected six-ink set')
        if type(bits) is not int or bits not in (1, 2):
            raise ValueError('Only 1 or 2 packed bits per sample are supported')
        # The observed plain row reader sign-extends this count to 16 bits.
        # Keep the entire row representable as a positive signed count.
        if type(row_bytes) is not int or not 1 <= row_bytes <= 32767:
            raise ValueError('row_bytes must be between 1 and 32767')
        if type(rows) is not int or not 1 <= rows <= 16:
            raise ValueError('rows must be between 1 and 16')
        if not isinstance(packed_plane, bytes):
            raise TypeError('packed_plane must be immutable bytes')
        if len(packed_plane) != row_bytes * rows:
            raise ValueError('Packed plane does not match declared dimensions')
        return b'\x1bi' + struct.pack('<BBBHH', NATIVE_CODE[ink], 0, bits, row_bytes, rows) + packed_plane

    def band_fragments(self, planes, *, bits, row_bytes, rows):
        """Return six CR-aligned raster fragments, without feed or page setup.

        All six planes must be supplied, including an all-zero plane where
        appropriate. CR resets native horizontal position before each ink.
        Vertical movement and band flushing remain the caller's responsibility.
        """
        if not isinstance(planes, Mapping) or set(planes) != set(self.channels):
            raise ValueError('Supply exactly the selected six ink planes')
        return b''.join(b'\r' + self.fragment(ink, bits=bits, row_bytes=row_bytes,
                                            rows=rows, packed_plane=planes[ink])
                        for ink in self.channels)
