"""Fixed tiny cyan-only candidate for a user-operated native-mode experiment.

The mode prefix comes from the firmware's stored-page emitter. USB recognition
and physical printing are UNVERIFIED. This is not an installer or a six-ink RIP.
Only native graphics/reset/position/raster/FF commands are included; no REMOTE1.
"""
import hashlib
import struct
from six_ink_raster import SixInkRaster

MODE_PREFIX = bytes.fromhex('1b2847010001')
WIDTH_BYTES, ROWS = 36, 16
PIXELS = b''.join(bytes([0xAA if row % 2 == 0 else 0x55]) * WIDTH_BYTES for row in range(ROWS))


def body():
    resolution = b'\x1b(D\x04\0' + struct.pack('<HBB', 5760, 8, 8)
    y = b'\x1b(v\x02\0' + struct.pack('<H', 64)
    x = b'\x1b($\x04\0' + struct.pack('<I', 12)
    raster = SixInkRaster().fragment('C', bits=1, row_bytes=WIDTH_BYTES, rows=ROWS, packed_plane=PIXELS)
    return b'\x1b@' + resolution + y + b'\r' + x + raster + b'\x0c\x1b@'


def candidate():
    native = body()
    return native[:2] + MODE_PREFIX + native[2:]


def manifest():
    packet = candidate()
    return {'experiment': 'single tiny cyan-only native-mode candidate',
            'bytes': len(packet), 'sha256': hashlib.sha256(packet).hexdigest(),
            'nominal_dpi': [720, 720], 'ink': 'C', 'native_code': 2,
            'bits': 1, 'width_bytes': WIDTH_BYTES, 'rows': ROWS,
            'nominal_pattern_mm': [288 / 720 * 25.4, ROWS / 720 * 25.4],
            'nominal_offset_mm': [12 / 60 * 25.4, 64 / 360 * 25.4],
            'dot_fraction': 0.5, 'remote1_commands': [],
            'usb_mode_entry_validated': False, 'physical_print_verified': False,
            'note': 'Nominal coordinates rely on observed native defaults; actual media/backend behavior is unverified'}
