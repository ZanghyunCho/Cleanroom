﻿param(
    [ValidateSet('Inspect', 'PrintCyan')]
    [string]$Mode = 'Inspect'
)
$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$resultDirectory = Join-Path $PSScriptRoot ("native-cyan-{0}-{1}" -f $Mode, $stamp)
New-Item -ItemType Directory -Path $resultDirectory | Out-Null
$helper = Join-Path $PSScriptRoot 'scp5340-native-cyan.exe'
$stdoutLog = New-Object Text.StringBuilder
$stderrLog = New-Object Text.StringBuilder
$record = [ordered]@{
    tool = 'SC-P5340 native cyan experiment'
    revision = 3
    mode = $Mode
    delivery_method = 'windows_raw_queue'
    started_utc = [DateTime]::UtcNow.ToString('o')
    helper_exit = $null
    helper_timed_out = $false
    bytes_written = 0
    write_error = $null
    data_write_attempted = $false
    spooler_accepted = $false
    spooler_job_id = $null
    selected_printer = $null
    selected_port = $null
    selected_driver = $null
    cancelled = $false
    physical_print_verified = $false
    automatic_retry = $false
    error = $null
}
function Decode-QueueText {
    param([string]$Hex)
    if (-not $Hex -or $Hex.Length % 4 -ne 0 -or $Hex -notmatch '^[0-9a-fA-F]+$') {
        throw 'Invalid printer selection text.'
    }
    $bytes = New-Object byte[] ($Hex.Length / 2)
    for ($i = 0; $i -lt $bytes.Length; $i++) {
        $bytes[$i] = [Convert]::ToByte($Hex.Substring($i * 2, 2), 16)
    }
    return [Text.Encoding]::Unicode.GetString($bytes)
}
function Invoke-CyanHelper {
    param([string]$Arguments)
    $start = New-Object Diagnostics.ProcessStartInfo
    $start.FileName = $helper
    $start.Arguments = $Arguments
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = New-Object Diagnostics.Process
    $process.StartInfo = $start
    try {
        if (-not $process.Start()) { throw 'Unable to start helper.' }
        $stdoutTask = $process.StandardOutput.ReadToEndAsync()
        $stderrTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(30000)) {
            $record['helper_timed_out'] = $true
            $process.Kill()
            $process.WaitForExit()
        }
        $stdout = $stdoutTask.Result
        $stderr = $stderrTask.Result
        [void]$stdoutLog.AppendLine($stdout)
        [void]$stderrLog.AppendLine($stderr)
        $exitCode = $process.ExitCode
        $record['helper_exit'] = $exitCode
        $events = @()
        foreach ($line in ($stdout -split '\r?\n')) {
            if ($line.Trim()) { $events += ($line | ConvertFrom-Json) }
        }
        return [pscustomobject]@{ ExitCode = $exitCode; Events = $events }
    } finally {
        $process.Dispose()
    }
}
try {
    $expected = (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'scp5340-native-cyan.exe.sha256') -Raw).Trim().Split(' ')[0]
    if ($expected -notmatch '^[0-9a-fA-F]{64}$') { throw 'Invalid helper checksum file.' }
    $actual = (Get-FileHash -LiteralPath $helper -Algorithm SHA256).Hash
    if ($actual -ne $expected) { throw 'Helper checksum mismatch. No helper was started.' }
    $record['helper_sha256'] = $actual.ToLowerInvariant()
    $scan = Invoke-CyanHelper '--list-printers'
    if ($scan.ExitCode -ne 0 -or -not @($scan.Events | Where-Object { $_.event -eq 'queue_scan_done' -and $_.complete }).Count) {
        throw 'Unable to enumerate Windows printers. See helper.jsonl.'
    }
    $choices = @($scan.Events | Where-Object { $_.event -eq 'printer_queue' -and $_.eligible } | ForEach-Object {
        [pscustomobject]@{
            Name = Decode-QueueText $_.name_utf16
            Port = Decode-QueueText $_.port_utf16
            Driver = Decode-QueueText $_.driver_utf16
            NameHex = $_.name_utf16
            PortHex = $_.port_utf16
            DriverHex = $_.driver_utf16
        }
    })
    Write-Host ''
    if ($Mode -eq 'PrintCyan') {
        Write-Host '패턴을 인쇄할 프린터를 선택하세요. (SC-P5300/5340 드라이버만 표시)'
    } else {
        Write-Host '선택 가능한 프린터 목록입니다. (인쇄하지 않음)'
    }
    for ($i = 0; $i -lt $choices.Count; $i++) {
        Write-Host ('[{0}] {1}    포트: {2}' -f ($i + 1), $choices[$i].Name, $choices[$i].Port)
    }
    if ($choices.Count -eq 0) {
        throw '선택 가능한 프린터가 없습니다. Windows 드라이버와 연결 포트를 확인하세요. FILE: 출력과 오프라인 작업 큐는 제외됩니다.'
    }
    if ($Mode -eq 'PrintCyan') {
        $selection = 0
        while ($true) {
            $answer = Read-Host '프린터 번호 입력 (0 또는 Enter: 취소)'
            if (-not $answer.Trim()) { $selection = 0; break }
            if ([int]::TryParse($answer, [ref]$selection) -and $selection -ge 0 -and $selection -le $choices.Count) { break }
            Write-Host '목록에 있는 번호를 입력하세요.'
        }
        if ($selection -eq 0) {
            $record['cancelled'] = $true
        } else {
            $chosen = $choices[$selection - 1]
            $record['selected_printer'] = $chosen.Name
            $record['selected_port'] = $chosen.Port
            $record['selected_driver'] = $chosen.Driver
            Write-Host ('선택: {0} / {1}' -f $chosen.Name, $chosen.Port)
            $arguments = '--send-cyan-queue {0} {1} {2}' -f $chosen.NameHex, $chosen.PortHex, $chosen.DriverHex
            $sent = Invoke-CyanHelper $arguments
            foreach ($event in $sent.Events) {
                if ($event.event -eq 'queue_write_attempt') { $record['data_write_attempted'] = $true }
                if ($event.event -eq 'spooler_job_started') { $record['spooler_job_id'] = $event.job_id }
                if ($event.event -eq 'queue_result') {
                    $record['bytes_written'] = $event.bytes
                    $record['write_error'] = $event.error
                    $record['spooler_accepted'] = $event.spooler_accepted
                }
                if ($event.event -eq 'error') {
                    $record['error'] = ('{0}, Windows code: {1}' -f $event.stage, $event.code)
                }
            }
            if ($sent.ExitCode -ne 0 -and -not $record['error']) {
                $record['error'] = ('Helper exit {0}; inspect helper.jsonl.' -f $sent.ExitCode)
            }
        }
    }
} catch {
    $record['error'] = $_.Exception.Message
}
[IO.File]::WriteAllText((Join-Path $resultDirectory 'helper.jsonl'), $stdoutLog.ToString(), (New-Object Text.UTF8Encoding($false)))
[IO.File]::WriteAllText((Join-Path $resultDirectory 'helper-stderr.txt'), $stderrLog.ToString(), (New-Object Text.UTF8Encoding($false)))
$record['finished_utc'] = [DateTime]::UtcNow.ToString('o')
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $resultDirectory 'result.json') -Encoding UTF8
$archive = $resultDirectory + '.zip'
Compress-Archive -Path (Join-Path $resultDirectory '*') -DestinationPath $archive
Write-Host ('결과 ZIP: ' + $archive)
if ($Mode -eq 'PrintCyan') {
    if ($record['cancelled']) {
        Write-Host '취소했습니다. 인쇄 데이터는 보내지 않았습니다.'
    } elseif (-not $record['data_write_attempted']) {
        Write-Host '인쇄 데이터를 보내지 않았습니다. 아래 오류와 결과 ZIP을 확인하세요.'
    } elseif ($record['spooler_accepted']) {
        Write-Host ('Windows 인쇄 큐에 접수됐습니다. 작업 번호: ' + $record['spooler_job_id'])
        Write-Host '실제 인쇄 여부는 미확인입니다. 청록 선이 나왔는지 알려주세요.'
    } else {
        Write-Host '큐 전송이 완료되지 않았습니다. 일부 데이터가 전달됐을 수 있습니다.'
    }
    Write-Host '출력이 없으면 자동으로 반복 실행하지 마세요.'
} else {
    Write-Host '목록 확인만 했습니다. 인쇄 데이터는 보내지 않았습니다.'
}
if ($record['error']) { Write-Host ('오류: ' + $record['error']) }
