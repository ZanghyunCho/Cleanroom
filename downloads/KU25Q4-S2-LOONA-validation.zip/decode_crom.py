"""Decode Epson CROM Huffman/LZ data without changing firmware bytes."""
from pathlib import Path
import hashlib
import json
import struct

ROOT = Path(__file__).resolve().parents[1]


def decode(rom, offset):
    if rom[offset:offset + 6] != b'CROM\xff\xd8':
        raise ValueError('Invalid CROM signature')
    end = offset + 4 + int.from_bytes(rom[offset + 6:offset + 10], 'big')
    p = offset + 10
    if rom[p:p + 2] != b'\xff\xc4':
        raise ValueError('Missing Huffman tables')
    table_end = p + 2 + int.from_bytes(rom[p + 2:p + 4], 'big')
    q = p + 4
    tables = []
    for table_id in (0xf0, 0xf1, 0xf2):
        if rom[q] != table_id:
            raise ValueError('Unexpected Huffman table order')
        counts = rom[q + 1:q + 17]
        symbols = rom[q + 17:q + 17 + sum(counts)]
        lookup = [None] * 65536
        code = k = 0
        for bits, count in enumerate(counts, 1):
            for _ in range(count):
                start = code << (16 - bits)
                size = 1 << (16 - bits)
                if start + size > 65536:
                    raise ValueError('Oversubscribed Huffman table')
                lookup[start:start + size] = [(symbols[k], bits)] * size
                k += 1
                code += 1
            code <<= 1
        tables.append(lookup)
        q += 17 + len(symbols)
    if q != table_end or rom[q:q + 2] != b'\xff\xb1':
        raise ValueError('Invalid token block boundary')
    header_len = int.from_bytes(rom[q + 2:q + 4], 'big')
    packed_size, token_count = struct.unpack_from('>II', rom, q + 5)
    packed_start = q + 2 + header_len
    literal_header = packed_start + packed_size
    if rom[literal_header:literal_header + 4] != b'\xff\xb2\x00\x06':
        raise ValueError('Invalid literal block')
    literal_size = int.from_bytes(rom[literal_header + 4:literal_header + 8], 'big')
    literal_start = literal_header + 8
    literal_end = literal_start + literal_size
    if literal_end > len(rom) or literal_end > end:
        raise ValueError('Literal data exceeds CROM bounds')
    packed = rom[packed_start:packed_start + packed_size] + b'\x00\x00\x00'
    bitpos = 0
    litpos = literal_start
    output = bytearray()
    for _ in range(token_count):
        token = []
        for table in tables:
            pos, shift = divmod(bitpos, 8)
            window = (packed[pos] << 16) | (packed[pos + 1] << 8) | packed[pos + 2]
            entry = table[(window >> (8 - shift)) & 0xffff]
            if entry is None:
                raise ValueError('Invalid Huffman code')
            value, bits = entry
            bitpos += bits
            if bitpos > packed_size * 8:
                raise ValueError('Token stream exhausted')
            token.append(value)
        count, low, high = token
        distance = low | (high << 8)
        if distance:
            count = (count + 2) & 0xff
            if distance > len(output):
                raise ValueError('Backreference precedes output')
            for _ in range(count):
                output.append(output[-distance])
        elif count != 255:
            count += 1
            if litpos + count > literal_end:
                raise ValueError('Literal stream exhausted')
            output.extend(rom[litpos:litpos + count])
            litpos += count
        if len(output) > 64 * 1024 * 1024:
            raise ValueError('Decoded output exceeds size limit')
    return bytes(output), {
        'source_offset': hex(offset), 'container_end': hex(end),
        'packed_size': packed_size, 'token_count': token_count,
        'literal_size': literal_size, 'literal_bytes_used': litpos - literal_start,
        'token_bits_used': bitpos, 'decoded_size': len(output),
        'sha256': hashlib.sha256(output).hexdigest(),
    }


if __name__ == '__main__':
    rom = (ROOT / 'original/merged.bin').read_bytes()
    data, report = decode(rom, 0x2d6c00)
    expected = '52bff0422d872906047c36ed8abfca899934acdf3a7ec7b7edb3ab76a6003d94'
    report['matches_research_sha256'] = report['sha256'] == expected
    print(json.dumps(report, indent=2))
    if not report['matches_research_sha256']:
        raise SystemExit('Decoded hash mismatch; refusing to label this the original module')
    (ROOT / 'decoded').mkdir(exist_ok=True)
    (ROOT / 'decoded/crom-002d6c00-0.bin').write_bytes(data)
    (ROOT / 'validation/crom-decoding.json').write_text(json.dumps(report, indent=2) + '\n')
