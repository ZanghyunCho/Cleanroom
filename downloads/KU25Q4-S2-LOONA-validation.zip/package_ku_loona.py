"""Replace KU25Q4 early boot bitmap on the exact S2 baseline; keep S2 code."""
from pathlib import Path
import hashlib,json,struct,zipfile
from PIL import Image
from decode_crom import decode
from encode_crom import encode
from build_ku_controls import sections
P=Path(__file__).resolve().parent
BASELINE='66bd161b0b9c6fa2da49af0cca8cb412c2840a195f5f658acb45f0b56d292cc8'
SOURCE='c4192fb7f7173da0192dfa9b9c91bee36b1d721fddddbabc2d522f8c221cfe2a'
STOCK_RESOURCE='5f4b3537569473df36f1b78fd8ad4f03210e341a8b07c1ceb2f9ebfd5c823a45'
CONTROL='2c23dd32742e4060cdeb1c9e20a9da49d6d54072094d1e4eb0082826f7661453'
START,NEXT=0x41412e,0x41812e
WIDTH,HEIGHT=480,272;PIXELS=WIDTH*HEIGHT*4
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
 source=P/'loona-source.png';assert sha(source.read_bytes())==SOURCE
 image=Image.open(source).convert('RGBA');assert image.size==(WIDTH,HEIGHT);rgba=image.tobytes();assert set(rgba[3::4])=={255}
 baseline=P/'FWCL14TL_KU25Q4-S2-all-cartridge-zero-usage.efu';assert sha(baseline.read_bytes())==BASELINE
 with zipfile.ZipFile(baseline) as z:assert z.testzip() is None;info=z.getinfo('FWCL14TL.rcx');old=z.read(info)
 sections(old);sign=old.index(b'EPSONSIGN');body=sign+4096
 assert struct.unpack_from('<I',old,sign+16)[0]==len(old)-body+1
 stock,oldinfo=decode(old,START);assert sha(stock)==STOCK_RESOURCE and len(stock)==522884 and set(stock[3:PIXELS:4])=={255}
 # KU uses R,G,B,A; the P7500 asset's A,R,G,B layout must not be reused.
 Image.frombytes('RGBA',(WIDTH,HEIGHT),stock[:PIXELS]).save(P/'KU25Q4-original-boot-logo-RGBA.png')
 end=int(oldinfo['container_end'],16);assert old[end:NEXT]==b'\xff'*(NEXT-end)
 module=rgba+stock[PIXELS:];frame,compression=encode(module,old[START:end],positive_padding=True,restrict_to_template_symbols=True)
 assert len(frame)<=NEXT-START and compression['dma_output_bytes']%48==0
 updated=bytearray(old);updated[START:NEXT]=frame+b'\xff'*(NEXT-START-len(frame))
 # The bitmap lies in the first section payload, whose sum/SHA1 must be refreshed.
 metadata=struct.unpack_from('<I',old,body+28)[0];size=struct.unpack_from('<I',old,body+64)[0];begin=body+4096+metadata;finish=begin+size
 assert begin<=START<NEXT<=finish
 struct.pack_into('<H',updated,body+54,sum(updated[begin:finish])&65535)
 updated[body+68:body+88]=hashlib.sha1(updated[begin:finish]+hashlib.sha1(updated[body:body+14]).digest()).digest()
 allowed=sorted([(START,NEXT),(body+54,body+56),(body+68,body+88)]);prev=0
 for lo,hi in allowed:assert updated[prev:lo]==old[prev:lo];prev=hi
 assert updated[prev:]==old[prev:] and len(updated)==len(old)
 out=P/'FWCL14TL_KU25Q4-S2-LOONA.efu'
 with zipfile.ZipFile(out,'w') as z:z.writestr(info,updated)
 with zipfile.ZipFile(out) as z:assert z.testzip() is None;final=z.read('FWCL14TL.rcx');assert final==updated
 host_sections=sections(final);restored,newinfo=decode(final,START)
 assert restored==module and restored[:PIXELS]==rgba and restored[PIXELS:]==stock[PIXELS:]
 Image.frombytes('RGBA',(WIDTH,HEIGHT),restored[:PIXELS]).save(P/'KU25Q4-S2-LOONA-preview.png')
 assert Image.open(P/'KU25Q4-S2-LOONA-preview.png').convert('RGBA').tobytes()==rgba
 control,controlinfo=decode(final,0x11412e);assert sha(control)==CONTROL
 oldcontrol,_=decode(old,0x11412e);assert control==oldcontrol
 assert final[sign+32:sign+96]==old[sign+32:sign+96] and final[0x1112e:0x1116e]==old[0x1112e:0x1116e]
 report={'filename':out.name,'efu_sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'baseline_S2_efu_sha256':BASELINE,'rcx_sha256':sha(final),'source_png_sha256':SOURCE,'source_provenance':'Original LOONA artwork from repository LK29Q5-LOONA-validation.zip, visually matching the current supplied reference; current inline attachment file bytes were not exposed to the executor.','width':WIDTH,'height':HEIGHT,'pixel_format':'R,G,B,A bytes; alpha=255','source_pixels_exact':True,'no_resize_redraw_or_color_change':True,'resource_offset':hex(START),'resource_slot_end':hex(NEXT),'original_resource_sha256':STOCK_RESOURCE,'new_resource_sha256':sha(restored),'resource_decoded_bytes':len(restored),'pixel_bytes':PIXELS,'trailing_code_data_bytes':len(stock)-PIXELS,'trailing_code_data_sha256':sha(stock[PIXELS:]),'trailing_code_data_preserved':True,'allowed_rcx_change_ranges':[[hex(a),hex(b)] for a,b in allowed],'outside_allowed_ranges_identical_to_S2':True,'S2_control_module_sha256':sha(control),'S2_control_byte_identical':True,'retained_S2_native_test_evidence':'7063 scenarios passed on the byte-identical S2 control module; tests were not rerun for this bitmap-only change.','original_key_signature_and_declared_length_preserved_from_S2':True,'actual_body_bytes':len(final)-body,'declared_body_bytes':struct.unpack_from('<I',final,sign+16)[0],'modified_body_ecdsa_signature_valid':False,'zip_crc_and_reextraction_exact':True,'host_sections':host_sections,'compression':compression,'original_frame':oldinfo,'final_frame':newinfo,'physical_boot_display_tested':False,'native_loader_hardware_huffman_or_panel_controller_executed':False,'limits':['Source archive bitmap was used without redrawing; current reference is a visual match, not a byte comparison with the inaccessible inline attachment.','No physical update, full boot, panel controller or hardware Huffman/DMA test.','S2 feature behavior is preserved byte-for-byte; S1 reported success is not a physical success result for S2-LOONA.']}
 (P/'KU25Q4-S2-LOONA-validation.json').write_text(json.dumps(report,indent=2)+'\n');out.with_suffix('.efu.sha256').write_text(report['efu_sha256']+'  '+out.name+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
