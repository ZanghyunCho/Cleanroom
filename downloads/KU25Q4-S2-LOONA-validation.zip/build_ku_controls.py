"""Build KU25Q4 A/B isolation controls; no executable behavior patches."""
from pathlib import Path
import hashlib,json,struct,zipfile
from decode_crom import decode
from encode_crom import encode
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec,utils
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def sections(d):
 pos=d.index(b'EPSONSIGN')+4096;out=[]
 while pos<len(d):
  h=d[pos:pos+4096];assert h.startswith(b'EPSON')
  m=struct.unpack_from('<I',h,28)[0];n=struct.unpack_from('<I',h,64)[0];begin=pos+4096+m;end=begin+n
  assert end<=len(d)
  checks={'metadata_sum16':sum(d[pos+4096:begin])&65535==struct.unpack_from('<H',h,18)[0], 'payload_sum16':sum(d[begin:end])&65535==struct.unpack_from('<H',h,54)[0], 'sha1':hashlib.sha1(d[begin:end]+hashlib.sha1(h[:14]).digest()).digest()==h[68:88]}
  assert all(checks.values())
  out.append({'offset':hex(pos),'metadata_bytes':m,'payload_bytes':n,'end':hex(end),'checks':checks});pos=end
 assert pos==len(d) and len(out)==2
 return out

def main():
 src=P/'FWCL14TL_KU25Q4.efu';assert sha(src.read_bytes())=='fb8bc19af5a13bb6dba43f8971aafeb062425e030be0c761eeccbf6000c99a56'
 with zipfile.ZipFile(src) as z:
  assert z.testzip() is None;info=z.getinfo('FWCL14TL.rcx');orig=z.read(info)
 sign=orig.index(b'EPSONSIGN');body=sign+4096;actual=len(orig)-body
 assert orig[sign+9:sign+13]==b'KU23' and struct.unpack_from('<I',orig,sign+16)[0]==actual
 original_sections=sections(orig)
 start=0x11412e;slot_end=0x41412e;frame_end=start+4+int.from_bytes(orig[start+6:start+10],'big')
 second_size=int.from_bytes(orig[frame_end+2:frame_end+6],'big');second=orig[frame_end:frame_end+second_size]
 assert second.startswith(b'\xff\xd8') and orig[frame_end+second_size:slot_end]==b'\xff'*(slot_end-frame_end-second_size)
 control,original_crom=decode(orig,start)
 assert sha(control)=='e6c02c744d84e50bebc97dc2f348525d58ddd290e011f7133fd0567a06263288'
 key=orig[0x1112e:0x1116e];sig=orig[sign+32:sign+96]
 pub=ec.EllipticCurvePublicNumbers(int.from_bytes(key[:32],'big'),int.from_bytes(key[32:],'big'),ec.SECP256R1()).public_key()
 der=utils.encode_dss_signature(int.from_bytes(sig[:32],'big'),int.from_bytes(sig[32:],'big'))
 pub.verify(der,orig[body:],ec.ECDSA(hashes.SHA256()))
 encoded,compression=encode(control,orig[start:frame_end],positive_padding=True,restrict_to_template_symbols=True)
 assert len(encoded)+len(second)<=slot_end-start
 assert encoded!=orig[start:frame_end] and compression['dma_output_bytes']%48==0
 reports=[]
 for label in ('A-envelope-only','B-original-code-reencoded'):
  d=bytearray(orig);struct.pack_into('<I',d,sign+16,actual+1);new_end=frame_end
  if label.startswith('B'):
   replacement=encoded+second;d[start:slot_end]=replacement+b'\xff'*(slot_end-start-len(replacement));new_end=start+len(encoded)
   h=body;m=struct.unpack_from('<I',d,h+28)[0];n=struct.unpack_from('<I',d,h+64)[0];begin=h+4096+m;end=begin+n
   struct.pack_into('<H',d,h+54,sum(d[begin:end])&65535);d[h+68:h+88]=hashlib.sha1(d[begin:end]+hashlib.sha1(d[h:h+14]).digest()).digest()
  allowed=[(sign+16,sign+20)]
  if label.startswith('B'):allowed += [(body+54,body+56),(body+68,body+88),(start,slot_end)]
  prev=0
  for lo,hi in sorted(allowed):assert d[prev:lo]==orig[prev:lo];prev=hi
  assert d[prev:]==orig[prev:] and len(d)==len(orig)
  assert d[sign+32:sign+96]==sig and d[0x1112e:0x1116e]==key
  out=P/f'FWCL14TL_KU25Q4-{label}.efu'
  if out.exists():
   with zipfile.ZipFile(out) as z:assert z.read('FWCL14TL.rcx')==d
  else:
   with zipfile.ZipFile(out,'w') as z:z.writestr(info,d)
  with zipfile.ZipFile(out) as z:assert z.testzip() is None;final=z.read('FWCL14TL.rcx');assert final==d
  restored,crom=decode(final,start);assert restored==control
  assert final[new_end:new_end+second_size]==second
  # The secondary frame is also decoded independently using the same CROM grammar.
  restored_second,second_report=decode(b'CROM'+final[new_end:new_end+second_size],0)
  old_second,_=decode(b'CROM'+second,0);assert restored_second==old_second
  verified_sections=sections(final)
  try:pub.verify(der,final[body:],ec.ECDSA(hashes.SHA256()));verdict='valid'
  except InvalidSignature:verdict='invalid'
  assert verdict==('valid' if label.startswith('A') else 'invalid')
  r={'label':label,'filename':out.name,'bytes':out.stat().st_size,'efu_sha256':sha(out.read_bytes()),'source_efu_sha256':sha(src.read_bytes()),'original_rcx_sha256':sha(orig),'rcx_sha256':sha(final),'actual_body_bytes':actual,'declared_body_bytes':actual+1,'body_identical_to_official':final[body:]==orig[body:],'original_public_key_and_signature_preserved':True,'public_key_sha256':sha(key),'ordinary_body_ecdsa_verification':verdict,'zip_crc_and_reextraction_exact':True,'all_sections_verified':verified_sections,'changes_confined_to_declared_ranges':True,'allowed_rcx_change_ranges':[[hex(lo),hex(hi)] for lo,hi in sorted(allowed)],'original_crom':original_crom,'final_crom':crom,'final_decoded_control_sha256':sha(restored),'decoded_control_identical_to_official':True,'second_frame_bytes_preserved':True,'second_frame_decoded_sha256':sha(restored_second),'second_frame_original_offset':hex(frame_end),'second_frame_new_offset':hex(new_end),'slot_start':hex(start),'slot_end':hex(slot_end),'compression':compression if label.startswith('B') else None,'hardware_update_and_boot_tested':False,'native_loader_or_full_receiver_executed':False,'maintenance_behavior':'Official unmodified executable behavior; no absent-box or remaining-level patches.'}
  (P/f'KU25Q4-{label}-validation.json').write_text(json.dumps(r,indent=2)+'\n');out.with_suffix('.efu.sha256').write_text(r['efu_sha256']+'  '+out.name+'\n');reports.append(r)
  print(label,r['efu_sha256'],r['bytes'],'signature',verdict,'decoded exact',True,flush=True)
 (P/'KU25Q4-controls-validation.json').write_text(json.dumps({'controls':reports,'scope':'Host packing and codec validation. No physical update, flash write, native DMA/Huffman, full receiver or startup execution.'},indent=2)+'\n')
if __name__=='__main__':main()
