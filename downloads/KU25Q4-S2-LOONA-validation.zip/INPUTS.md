# Reproduce KU25Q4 S2-LOONA
Python 3.10+, Pillow, and cryptography are required. Keep package/TLS verification enabled.
Place the previously published FWCL14TL_KU25Q4-S2-all-cartridge-zero-usage.efu
alongside package_ku_loona.py. Its SHA-256 must be:
66bd161b0b9c6fa2da49af0cca8cb412c2840a195f5f658acb45f0b56d292cc8
The original archived loona-source.png is included. Run python3 package_ku_loona.py.
It validates the baseline and artwork, replaces only the RGBA logo pixels,
preserves trailing code/data, packages EFU, re-extracts it and checks exact pixels,
S2 code identity, all sections and ZIP integrity. No printer is accessed.
The shared sections helper comes from build_ku_controls.py; its main is not run.
