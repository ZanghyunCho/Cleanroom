"""Execute original maintenance-box state/counter helpers on RAM fixtures.

No function verdict is hooked. Only RAM data is initialized for each experiment.
No firmware image is patched or emitted.
"""
from pathlib import Path
import hashlib
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM
from unicorn.arm_const import (UC_ARM_REG_CPSR, UC_ARM_REG_SP, UC_ARM_REG_LR,
                               UC_ARM_REG_PC, UC_ARM_REG_R0, UC_ARM_REG_R1)

BASE = 0x433e0000
REMAIN_FN = 0x43407ffc
ADD_NOTIFY_COUNTER_FN = 0x4340167c
SLOT_COUNT_FN = 0x43409724
SET_ERROR_FN = 0x43408308
SET_REMAIN_FN = 0x43407fd8


class Control:
    def __init__(self, code):
        self.code = code
        self.u = Uc(UC_ARCH_ARM, UC_MODE_ARM)
        self.u.mem_map(BASE, 0x400000)
        self.u.mem_write(BASE, code)
        self.u.mem_map(0x42000000, 0x200000)
        self.u.mem_map(0x48000000, 0x1000)

    def literal(self, instruction_address, displacement):
        return struct.unpack_from('<I', self.code,
                                  instruction_address + 8 + displacement - BASE)[0]

    def call(self, address, first=0, second=0):
        u = self.u
        u.reg_write(UC_ARM_REG_CPSR, 0x13)
        u.reg_write(UC_ARM_REG_SP, 0x421ff000)
        u.reg_write(UC_ARM_REG_LR, 0x48000000)
        u.reg_write(UC_ARM_REG_R0, first)
        u.reg_write(UC_ARM_REG_R1, second)
        u.emu_start(address, 0x48000000, count=1000000)
        assert u.reg_read(UC_ARM_REG_PC) == 0x48000000
        return u.reg_read(UC_ARM_REG_R0)

    def immutable_functions(self):
        for address, size in [(REMAIN_FN, 0xbc), (ADD_NOTIFY_COUNTER_FN, 0x30),
                              (SLOT_COUNT_FN, 8), (SET_ERROR_FN, 0xb4),
                              (SET_REMAIN_FN, 0x24)]:
            expected = self.code[address - BASE:address - BASE + size]
            assert bytes(self.u.mem_read(address, size)) == expected


def main():
    code = (ROOT / 'decoded/lk29q5-crom-00014153.bin').read_bytes()
    native = Control(code)
    state_ptr = native.literal(0x43408000, 0xc4)
    notification_ptr = native.literal(0x4340167c, 0x84)
    counter_ptr = native.literal(0x4340168c, 0x88)
    slot_count = native.call(SLOT_COUNT_FN)
    assert slot_count == 1
    remain_cases = []
    for state in range(8):
        for remaining in (0, 1, 50, 100):
            native.u.mem_write(state_ptr, bytes([state]))
            native.u.mem_write(state_ptr + 8, bytes([remaining]))
            result = native.call(REMAIN_FN, 0)
            expected = remaining if state in (0, 6, 7) else {
                1: 105, 2: 110, 3: 114, 4: 114, 5: 119,
            }[state]
            assert result == expected, (state, remaining, result)
            native.immutable_functions()
            remain_cases.append({'box_index': 0, 'state': state,
                                 'stored_remaining': remaining, 'return': result})
    counter_cases = []
    for enabled in (0, 1):
        for before, addition in [(0, 0), (0, 123), (0xffffffff, 1),
                                 (0xfffffffffffffffe, 3)]:
            native.u.mem_write(notification_ptr + 4, struct.pack('<I', enabled))
            native.u.mem_write(counter_ptr, struct.pack('<Q', before))
            native.call(ADD_NOTIFY_COUNTER_FN, 0, addition)
            after = struct.unpack('<Q', native.u.mem_read(counter_ptr, 8))[0]
            expected = ((before + addition) & 0xffffffffffffffff) if enabled else before
            assert after == expected, (enabled, before, addition, after)
            native.immutable_functions()
            counter_cases.append({'notification_enabled': enabled,
                                  'before': before, 'addition': addition, 'after': after})
    error_ptr = native.literal(0x43408368, -0x2b4)
    error_table = native.literal(0x43408384, 0x344)
    error_cases = []
    for error in range(36):
        native.u.mem_write(error_ptr, b'\x20')  # Original "no selected error" sentinel.
        native.u.mem_write(state_ptr, b'\x00')
        native.u.mem_write(state_ptr + 8, b'\x64')
        native.call(SET_ERROR_FN, 0, error)
        state = native.u.mem_read(state_ptr, 1)[0]
        expected_state = native.u.mem_read(error_table + error * 2, 1)[0]
        assert state == expected_state
        assert native.u.mem_read(error_ptr, 1)[0] == error
        remaining_encoding = native.call(REMAIN_FN, 0)
        native.immutable_functions()
        error_cases.append({'error_index': error, 'resulting_state': state,
                            'remaining_encoding_when_stored_100': remaining_encoding})
    setter_cases = []
    for error, expected in [(32, 100), (33, 105), (34, 110), (0, 114), (3, 119)]:
        native.u.mem_write(error_ptr, b'\x20')
        native.u.mem_write(state_ptr, b'\x00')
        native.u.mem_write(state_ptr + 8, b'\x00')
        native.call(SET_ERROR_FN, 0, error)
        native.call(SET_REMAIN_FN, 0, 100)
        assert native.u.mem_read(state_ptr + 8, 1)[0] == 100
        result = native.call(REMAIN_FN, 0)
        assert result == expected
        native.immutable_functions()
        setter_cases.append({'error_index': error, 'stored_remaining_after_setter': 100,
                             'encoded_return': result})
    report = {
        'version': 'LK29Q5', 'module_load_address': hex(BASE),
        'module_sha256': hashlib.sha256(code).hexdigest(),
        'module_size': len(code),
        'functions': {'remaining_encoding': hex(REMAIN_FN),
                      'notification_counter_addition': hex(ADD_NOTIFY_COUNTER_FN),
                      'error_selection': hex(SET_ERROR_FN),
                      'remaining_storage_setter': hex(SET_REMAIN_FN),
                      'configured_box_count': hex(SLOT_COUNT_FN)},
        'ram': {'remaining_state': hex(state_ptr),
                'notification_state': hex(notification_ptr),
                'notification_counter_array': hex(counter_ptr)},
        'configured_box_count': slot_count,
        'remaining_cases': remain_cases, 'notification_counter_cases': counter_cases,
        'error_cases': error_cases,
        'remaining_setter_cases': setter_cases,
        'executed_cases': len(remain_cases) + len(counter_cases) + len(error_cases) + len(setter_cases) + 1,
        'native_code_hooks': 0, 'function_bytes_unchanged': True,
        'scope': 'Original helpers with synthetic RAM. Notification counter is not proven to be the persistent CSIC consumption counter. State codes are not assigned hardware meanings.',
        'firmware_modified': False,
    }
    out = ROOT / 'validation/maintenance-state-native-results.json'
    out.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ('remaining_cases', 'notification_counter_cases', 'error_cases', 'remaining_setter_cases')}, indent=2))


if __name__ == '__main__':
    main()
