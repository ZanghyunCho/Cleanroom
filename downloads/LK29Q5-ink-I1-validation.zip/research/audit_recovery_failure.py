"""Audit failed EFU packaging against original ARM checksum/loader routines.

Reports real native helper results. Hardware Huffman completion is modeled only
for the LZ copy test; it does not claim a hardware boot or Recovery reproduction.
"""
from pathlib import Path
import hashlib
import json
import struct
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm_const import (UC_ARM_REG_CPSR, UC_ARM_REG_SP, UC_ARM_REG_LR,
                               UC_ARM_REG_PC, UC_ARM_REG_R0, UC_ARM_REG_R1,
                               UC_ARM_REG_R2, UC_ARM_REG_R3)


def call(u, address, *args, max_chunks=30):
    u.reg_write(UC_ARM_REG_CPSR, 0x13)
    u.reg_write(UC_ARM_REG_SP, 0x421ff000)
    u.reg_write(UC_ARM_REG_LR, 0x48000000)
    for reg, value in zip((UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3), args):
        u.reg_write(reg, value)
    pc = address
    for _ in range(max_chunks):
        u.emu_start(pc, 0x48000000, count=100000000)
        pc = u.reg_read(UC_ARM_REG_PC)
        if pc == 0x48000000:
            return u.reg_read(UC_ARM_REG_R0)
    raise RuntimeError('Native instruction budget exhausted')


def token_bytes(data):
    p = 10
    end = p + 2 + int.from_bytes(data[p + 2:p + 4], 'big')
    q, tables = p + 4, []
    for _ in range(3):
        counts = data[q + 1:q + 17]
        symbols = data[q + 17:q + 17 + sum(counts)]
        table, code, index = [None] * 65536, 0, 0
        for bits, count in enumerate(counts, 1):
            for _ in range(count):
                start, width = code << (16 - bits), 1 << (16 - bits)
                table[start:start + width] = [(symbols[index], bits)] * width
                code += 1
                index += 1
            code <<= 1
        tables.append(table)
        q += 17 + len(symbols)
    assert q == end
    count = struct.unpack_from('>I', data, q + 9)[0]
    start = q + 2 + int.from_bytes(data[q + 2:q + 4], 'big')
    size = struct.unpack_from('>I', data, q + 5)[0]
    packed = data[start:start + size] + bytes(3)
    out, bitpos = bytearray(), 0
    for _ in range(count):
        for table in tables:
            pos, shift = divmod(bitpos, 8)
            window = (packed[pos] << 16) | (packed[pos + 1] << 8) | packed[pos + 2]
            symbol, bits = table[(window >> (8 - shift)) & 65535]
            bitpos += bits
            assert bitpos <= size * 8
            out.append(symbol)
    return bytes(out)


def loader_audit(label, container, loader, expected):
    u = Uc(UC_ARCH_ARM, UC_MODE_ARM)
    for address, size in [(0x44099000, 0x1000), (0x46000000, 0x200000),
                          (0x42000000, 0x200000), (0x48000000, 0x1000),
                          (0xf6051000, 0x1000), (0xf6063000, 0x1000),
                          (0x433e0000, 0x400000), (0xb1000000, 0x400000)]:
        u.mem_map(address, size)
    u.mem_write(0x44099000, loader)
    u.mem_write(0x46000000, container)
    assert call(u, 0x44099350, 0x42002000, 0x46000004) == 1
    descriptor = bytes(u.mem_read(0x42002000, 28))
    fields = struct.unpack('<7I', descriptor)
    assert call(u, 0x440993f8, 0x42002000, 0x46001000, 0x42010000) == 1
    dma = struct.unpack('<I', u.mem_read(0xf605115c, 4))[0]
    assert dma == (fields[4] + fields[3]) * 3
    tokens = token_bytes(container)
    u.mem_write(0xb1000000, tokens)
    u.mem_write(0x42001000, struct.pack('<II', 0x46000004, 0x433e0000))
    fixture_calls = 0

    def huffman_completed(uc, address, size, user_data):
        nonlocal fixture_calls
        fixture_calls += 1
        context = uc.reg_read(UC_ARM_REG_R0)
        index = uc.reg_read(UC_ARM_REG_R1)
        assert index == 0
        uc.mem_write(context - 0x118, descriptor)
        uc.mem_write(context + 0x3c, struct.pack('<I', 0xb1000000))
        uc.reg_write(UC_ARM_REG_R0, 1)
        uc.reg_write(UC_ARM_REG_PC, uc.reg_read(UC_ARM_REG_LR))

    u.hook_add(UC_HOOK_CODE, huffman_completed, begin=0x44099664, end=0x44099664)
    native_return = call(u, 0x4409997c, 0x42001000, 1)
    result = bytes(u.mem_read(0x433e0000, len(expected)))
    assert result == expected, (label, 'native LZ copy differs from module')
    assert native_return == 1
    return {'image': label, 'token_count': fields[4], 'padding_tokens': fields[3],
            'padded_count_mod16': (fields[4] + fields[3]) % 16,
            'native_dma_output_bytes': dma, 'native_dma_mod48': dma % 48,
            'native_lz_copy_return': native_return, 'native_lz_output_exact': True,
            'huffman_completion_fixture_calls': fixture_calls,
            'hardware_huffman_execution': False}


def checksum_audit(label, rcx, routine):
    sign = rcx.index(b'EPSONSIGN')
    header = sign + 4096
    meta = struct.unpack_from('<I', rcx, header + 28)[0]
    length = struct.unpack_from('<I', rcx, header + 64)[0]
    begin = header + 4096 + meta
    payload = rcx[begin:begin + length]
    declared = struct.unpack_from('<H', rcx, header + 54)[0]
    actual = sum(payload) & 65535
    u = Uc(UC_ARCH_ARM, UC_MODE_ARM)
    for address, size in [(0x4419e000, 0x1000), (0x50000000, 0x7000000),
                          (0x42000000, 0x200000), (0x48000000, 0x1000)]:
        u.mem_map(address, size)
    u.mem_write(0x4419e2e0, routine)
    u.mem_write(0x50000000, payload)
    result = call(u, 0x4419e2e0, 0x50000000, length, declared)
    assert result == int(actual == declared)
    digest = hashlib.sha1(payload + hashlib.sha1(rcx[header:header + 14]).digest()).digest()
    assert digest == rcx[header + 68:header + 88]
    return {'image': label, 'payload_bytes': length, 'declared_sum16': declared,
            'actual_sum16': actual, 'native_checksum_return': result,
            'inner_sha1_matches': True}


def main():
    official = (ROOT / 'FW7560TL.rcx').read_bytes()
    candidates = [('failed_v1', ROOT / 'experimental/FW7560TL_LK29Q5-maintenance-prototype.efu'),
                  ('diagnostic_v2', ROOT / 'experimental/FW7560TL_LK29Q5-maintenance-diagnostic-v2.efu')]
    loader = official[0x25bb23:0x25bb23 + 0xae8]
    main_code = (ROOT / 'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
    routine = main_code[0x4419e2e0 - 0x4409b000:0x4419e2e0 - 0x4409b000 + 0x44]
    control = (ROOT / 'decoded/lk29q5-crom-00014153.bin').read_bytes()
    prototype = (ROOT / 'experimental/maintenance-control.prototype.bin').read_bytes()
    images = [('official', official)]
    for label, path in candidates:
        with zipfile.ZipFile(path) as archive:
            images.append((label, archive.read('FW7560TL.rcx')))
    checksums, loaders, original_frames = [], [], []
    for label, rcx in images:
        result = checksum_audit(label, rcx, routine)
        checksums.append(result)
        start = 0x14153
        end = start + 4 + int.from_bytes(rcx[start + 6:start + 10], 'big')
        result = loader_audit(label, rcx[start:end], loader,
                              control if label == 'official' else prototype)
        loaders.append(result)
        print('Audited', label, flush=True)
    assert [x['native_checksum_return'] for x in checksums] == [1, 0, 1]
    assert [x['native_dma_mod48'] for x in loaders] == [0, 6, 0]
    # Check every original frame, not just the frame changed in the candidate.
    pos = 0
    while True:
        start = official.find(b'CROM\xff\xd8', pos)
        if start < 0:
            break
        pos, frame = start + 6, start + 4
        while official[frame:frame + 2] == b'\xff\xd8':
            size = int.from_bytes(official[frame + 2:frame + 6], 'big')
            q = frame + 6
            q += 2 + int.from_bytes(official[q + 2:q + 4], 'big')
            count = struct.unpack_from('>I', official, q + 9)[0]
            padding = official[q + 13]
            assert (count + padding) % 16 == 0
            original_frames.append({'offset': hex(frame), 'tokens': count, 'padding': padding})
            frame += size
    report = {'user_observation': 'Failed candidate entered Recovery after reboot; official EFU restored successfully',
              'checksums': checksums, 'loaders': loaders,
              'original_alignment_frames_checked': original_frames,
              'confirmed_packaging_defects': ['Section payload sum16 left stale after recompression',
                                               'Original padding-token count copied instead of recalculated'],
              'physical_recovery_root_cause_confirmed': False,
              'scope': 'Native checksum and loader metadata/setup/LZ copy; Huffman completion fixture used for LZ test. No full startup, physical Huffman, CSIC, flash or updater execution.',
              'diagnostic_v2_hardware_ready': False}
    out = ROOT / 'validation/recovery-failure-audit.json'
    out.write_text(json.dumps(report, indent=2) + '\n')
    print('Saved', out)


if __name__ == '__main__':
    main()
