"""E counters must match D's original zero-delta semantics, not fake getters."""
import hashlib,itertools,json,struct
from build_consumption_control import build,ROOT
from build_lifetime_control import build as build_d
from probe_maintenance_state import Control
from verify_lifetime_control import verify as verify_d
from verify_lifetime_control import setup

def seed(code,stored,remainder,state=0,dirty_before=0):
 n,ptr=setup(code,stored,state)
 counters=(0x437cfebc,0x437cfecc,0x437cff9c)
 values=(stored,(stored+17)&0xffffffff,(stored+31)&0xffffffff)
 for p,value in zip(counters,values):n.u.mem_write(p,struct.pack('<I',value))
 fraction=n.literal(0x434068ec,0x2b8);n.u.mem_write(fraction,struct.pack('<I',remainder))
 dirty=n.literal(0x4340ae1c,0xc)
 for index in (0x1d,0x1e,0x26):n.u.mem_write(dirty+index*4,struct.pack('<I',dirty_before))
 return n,ptr,counters,fraction,dirty,values

def snapshot(n,counters,fraction,dirty):
 return {'counter_bytes':[bytes(n.u.mem_read(p,16)).hex() for p in counters],
 'counter_values':[struct.unpack('<I',n.u.mem_read(p,4))[0] for p in counters],
 'remainder':struct.unpack('<I',n.u.mem_read(fraction,4))[0],
 'dirty':[struct.unpack('<I',n.u.mem_read(dirty+i*4,4))[0] for i in (0x1d,0x1e,0x26)]}

def verify(code,manifest):
 d,_=build_d();regression=verify_d(code,manifest,reference_delta=0,label='E')
 assert regression['scenario_count']==118
 helpers=[]
 for fn,stored,rem,delta in itertools.product((0x434068ac,0x434068d8,0x434068e8),(0,123000000,1000000000,0xffffffff),(0,1,999999),(0,1,999999,1000000,500000000,0xffffffff)):
  observations=[]
  for data,requested in ((d,0),(code,delta)):
   n,state,counters,fraction,dirty,values=seed(data,stored,rem,dirty_before=1 if delta&1 else 0)
   before=snapshot(n,counters,fraction,dirty);result=n.call(fn,0,requested);after=snapshot(n,counters,fraction,dirty)
   assert before==after
   assert n.call(0x43406890)==values[0] and n.call(0x434068bc)==values[1]
   observations.append({'return':result,'state':after})
  assert observations[0]==observations[1]
  helpers.append({'helper':hex(fn),'stored_primary':stored,'fraction':rem,'requested_delta':delta,'result':observations[1],'matches_D_zero_delta':True})
 flows=[]
 for state_value,stored,rem in itertools.product(range(8),(0,123000000,1000000000),(0,999999)):
  results=[]
  for data,requested in ((d,0),(code,500000000)):
   n,state,counters,fraction,dirty,values=seed(data,stored,rem,state_value)
   before=snapshot(n,counters,fraction,dirty)
   request=0x42001000;n.u.mem_write(request,struct.pack('<II',requested,0)+bytes(24))
   ret=n.call(0x43410430,request)
   if requested==0:n.u.mem_write(request,struct.pack('<I',500000000))
   ready=n.call(0x43410144,request)
   after=snapshot(n,counters,fraction,dirty);assert before==after
   results.append({'add_return':ret,'readiness':ready,'raw_state':n.call(0x43407f5c),'report':n.call(0x43407ffc),'stored':after})
  assert results[0]==results[1]
  flows.append({'state':state_value,'primary_before':stored,'fraction_before':rem,'E_requested_delta':500000000,'result':results[1],'matches_D_zero_delta':True})
 # Counterfactual D must really increase values for a positive request.
 n,state,counters,fraction,dirty,values=seed(d,123,999999)
 for fn in (0x434068ac,0x434068d8,0x434068e8):n.call(fn,0,1)
 negative=snapshot(n,counters,fraction,dirty)
 assert negative['counter_values']==[124,141,155] and negative['remainder']==0
 # Repeated requests do not cause drift in E, including fractional carry.
 repeated=[]
 for stored,rem in itertools.product((0,123000000,1000000000,0xffffffff),(0,1,999999)):
  n,state,counters,fraction,dirty,values=seed(code,stored,rem);before=snapshot(n,counters,fraction,dirty)
  for _ in range(20):
   for fn in (0x434068ac,0x434068d8,0x434068e8):n.call(fn,0,999999)
  assert snapshot(n,counters,fraction,dirty)==before
  repeated.append({'primary':stored,'fraction':rem,'calls':60,'unchanged':True})
 report={'module_sha256':manifest['module_sha256'],'scenario_count':118+len(helpers)+len(flows)+1+len(repeated),
 'D_regressions':regression,'helper_cases':helpers,'worker_cases':flows,'D_positive_increment_control':negative,'repeated_cases':repeated,
 'native_verdict_hooks':0,'scope':'RAM/native helpers and worker; real EEPROM, chip I/O, scheduling and printing not executed',
 'precondition':'Fractional remainder is in the original normalized range 0..999999',
 'not_claimed':['Physical usage freeze','Reset accumulated counters','No-cartridge operation','Every possible synchronization write suppressed']}
 assert report['scenario_count']==395
 return report

def main():
 code,manifest=build();report=verify(code,manifest)
 (ROOT/'validation/consumption-E-native-results.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS',report['scenario_count'],'native cases; original reads/dirty state preserved; new usage delta zero')
if __name__=='__main__':main()
