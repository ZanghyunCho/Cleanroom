"""Compare C to original, retaining error encodings and actual consumption."""
import hashlib,json,struct
from build_remaining_report_control import build,ROOT,BASE
from probe_maintenance_state import Control
from probe_maintenance_notifications import capture_reports

def verify(code,manifest,reference_delta=500000000):
 original=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes();cases=[]
 for state in range(8):
  for stored in (0,1,50,100):
   n=Control(code);ptr=n.literal(0x43408000,0xc4)
   n.u.mem_write(ptr,bytes([state]));n.u.mem_write(ptr+8,bytes([stored]))
   before=bytes(n.u.mem_read(ptr,16));value=n.call(0x43407ffc)
   expected=100 if state in (0,6,7) else {1:105,2:110,3:114,4:114,5:119}[state]
   assert value==expected and bytes(n.u.mem_read(ptr,16))==before
   assert n.call(0x43407f5c)==state
   cases.append({'state':state,'stored_remaining':stored,'reported':value,'raw_state_and_RAM_unchanged':True})
 reports=[]
 for remaining in (50,100):
  refs=capture_reports(original,tuple(range(8)),remaining=remaining)
  results=capture_reports(code,tuple(range(8)),remaining=remaining)
  for ref,c in zip(refs,results):
   expected=ref['report_bytes'][:]
   if c['state_fixture'] in (0,6,7):expected[3]=100
   assert c['report_bytes']==expected and c['events']==ref['events']
   reports.append({'stored_remaining':remaining,'state':c['state_fixture'],'original_report_hex':ref['report_hex'],'candidate_report_hex':c['report_hex'],'events_preserved':True})
 flows=[]
 for state in (0,2,7):
  observations=[]
  for index,data in enumerate((original,code)):
   n=Control(data);n.u.mem_write(n.literal(0x433f6378,0x27c),bytes(8));ptr=n.literal(0x43408000,0xc4)
   n.u.mem_write(ptr,bytes([state]));n.u.mem_write(ptr+8,b'\x64')
   n.u.mem_write(n.literal(0x43406940,0x274),struct.pack('<I',1000000))
   n.u.mem_write(n.literal(0x43406b60,0x5c),struct.pack('<I',900000))
   counters=(0x437cfebc,0x437cfecc,0x437cff9c,0x437ceba4)
   for p in counters:n.u.mem_write(p,bytes(16))
   request=0x42001000;n.u.mem_write(request,struct.pack('<II',reference_delta if index==0 else 500000000,0)+bytes(24))
   add=n.call(0x43410430,request)
   # Validate the same selected box even when reference usage addition was zero.
   if reference_delta==0 and index==0:n.u.mem_write(request,struct.pack('<I',500000000))
   ready=n.call(0x43410144,request)
   observations.append({'add_return':add,'readiness_return':ready,'calculated_remaining':n.call(0x43406928),
      'stored_remaining':n.u.mem_read(ptr+8,1)[0],'raw_state':n.call(0x43407f5c),
      'counters':[struct.unpack('<I',n.u.mem_read(p,4))[0] for p in counters]})
  assert observations[0]==observations[1]
  flows.append({'state':state,'original_and_candidate':observations[0]})
 assert flows[0]['original_and_candidate']['counters'][0]==reference_delta
 assert flows[0]['original_and_candidate']['stored_remaining']==(50 if reference_delta==500000000 else 100)
 assert flows[1]['original_and_candidate']['readiness_return']==0
 errors=[]
 for error in range(36):
  results=[]
  for data in (original,code):
   n=Control(data);n.u.mem_write(n.literal(0x43408368,-0x2b4),b'\x20')
   n.u.mem_write(n.literal(0x43408000,0xc4),b'\0');n.call(0x43408308,0,error)
   results.append(n.call(0x43407f5c))
  assert results[0]==results[1];errors.append({'error':error,'state':results[0]})
 result={'consumption_reference_delta':reference_delta,'module_sha256':manifest['module_sha256'],'scenario_count':len(cases)+len(reports)+len(flows)+len(errors),
 'remaining_cases':cases,'notification_cases':reports,'original_consumption_flow_cases':flows,'error_transition_cases':errors,
 'maintenance_verdict_hooks':0,'notification_fixtures':['Event sink','Message allocation','Message delivery'],
 'limitations':['No full boot or real chip I/O','C retains physical cartridge requirement and real consumption','States 0,6,7 numeric report only; error encodings preserved']}
 assert result['scenario_count']==87
 return result

def main():
 code,manifest=build();result=verify(code,manifest)
 (ROOT/'validation/remaining-report-C-native-results.json').write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',result['scenario_count'],'native cases; one instruction site; real consumption and error rejection retained')
if __name__=='__main__':main()
