"""I1 ink reporting/usage diagnostic on E, not G/G2.

Canonical presentation fields are changed, not physical presence or cryptography.
"""
import hashlib,json,struct
from build_consumption_control import build as build_e,ROOT
from build_remaining_report_control import BASE

def bl(address,target):return 0xeb000000|(((target-address-8)//4)&0xffffff)

def build():
    original,em=build_e();code=bytearray(original);patches=em['patches'][:]
    def patch(address,expected,words,reason):
        off=address-BASE;before=struct.pack('<'+'I'*len(expected),*expected)
        after=struct.pack('<'+'I'*len(words),*words)
        assert code[off:off+len(before)]==before
        code[off:off+len(after)]=after
        patches.append(dict(address=hex(address),before=before.hex(),after=after.hex(),reason=reason))
    # Keep the raw state getter untouched; replace only the pure percentage getter.
    patch(0x4340347c,[0xe92d40f0,0xe24dd00c],[0xe3a00064,0xe12fff1e],
          'Pure remaining-report getter returns 100; internal state getter remains original')
    patch(0x433f3430,[0xe1a05000],[0xe3a05000],
          'Notification builder uses normal installed presentation class')
    patch(0x433f343c,[0xe1a06000],[0xe3a06000],
          'Notification builder uses original zero branding/conformity presentation class')
    # Preserve native 64-bit addition and deferred dirty-store behavior, with zero delta.
    address=0x433ffe8c
    before=[0xe52de004,0xe24dd00c,0xe3a03000,0xe88d000a,0xe1a02000,
            0xe3a01030,0xe3a0002f,bl(address+28,0x433f5b88),0xe28dd00c,0xe49df004]
    after=[0xe1a02000,0xe3a01000,0xe3a03000,0xe92d401a,0xe3a01030,
           0xe3a0002f,bl(address+24,0x433f5b88),0xe28dd008,0xe8bd8010,0xe1a00000]
    patch(address,before,after,'Primary usage helper executes original 64-bit addition with zero delta')
    patch(0x43400538,[0xe1a05001],[0xe3a05000],
          'Secondary/fractional usage helper receives zero requested delta')
    for a,n in [(0x43403330,0xc),(0x43403c10,0x124),(0x43403a7c,0x20),
                (0x433ffda4,0x10),(0x43408804,0x90)]:
        assert code[a-BASE:a-BASE+n]==original[a-BASE:a-BASE+n]
    report=dict(label='I1-ink-report-and-usage-diagnostic',module_sha256=hashlib.sha256(code).hexdigest(),
                E_module_sha256=em['module_sha256'],patches=patches,baseline='E, not F1/G/G2',
                physical_tested=False,
                implemented=['100 remaining-report return','Normal installed/zero branding notification fields',
                             'Zero input to two identified usage-addition helpers'],
                not_proven=['UI meaning of every notification field','Suppression of every non-genuine/incompatible prompt',
                            'Physical ink presence, chip acceptance, actual ink-end behavior',
                            'Every independent counter/reconciliation/restore path',
                            'Operation with cartridges physically removed'],
                no_owner_private_key_access=True)
    (ROOT/'experimental/ink-control.I1.bin').write_bytes(code)
    (ROOT/'experimental/ink-control.I1.json').write_text(json.dumps(report,indent=2)+'\n')
    return bytes(code),report

if __name__=='__main__':
    _,r=build();print(r['module_sha256'])
