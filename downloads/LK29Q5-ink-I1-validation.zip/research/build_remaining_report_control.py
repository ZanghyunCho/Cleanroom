"""C: one ARM instruction changes numeric remaining report, not state/CSIC."""
import hashlib,json,struct
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];BASE=0x433e0000
ADDRESS=0x43408044

def build():
 original=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes()
 assert hashlib.sha256(original).hexdigest()=='82c4c34f4ed5c1dd7118dd74839b499329d732d37b467df734ed5382a25dedac'
 off=ADDRESS-BASE;before=original[off:off+4]
 assert before==bytes.fromhex('0540d0e7') # ldrb r4,[r0,r5]
 after=struct.pack('<I',0xe3a04064) # mov r4,#100; state dispatch and epilogue preserved
 code=original[:off]+after+original[off+4:]
 assert code[:off]==original[:off] and code[off+4:]==original[off+4:]
 manifest={'label':'C-remaining-report-only','address':hex(ADDRESS),'before':before.hex(),'after':after.hex(),
 'original_module_sha256':hashlib.sha256(original).hexdigest(),'module_sha256':hashlib.sha256(code).hexdigest(),
 'instruction_sites':1,'changed_bytes':sum(a!=b for a,b in zip(original,code)),
 'numeric_remaining_states':[0,6,7],'preserved_status_encodings':{'1':105,'2':110,'3':114,'4':114,'5':119},
 'preserved':['Internal raw state and transitions','Original profile selection and chip I/O','Consumption reads and increments','Capacity/limit calculation','Notification state/error fields','Cover status checks'],
 'not_implemented':['Zero consumption','Operate without a maintenance cartridge'],
 'hardware_boot_status':'Unverified diagnostic candidate'}
 (ROOT/'experimental/maintenance-control.report-C.bin').write_bytes(code)
 (ROOT/'experimental/maintenance-control.report-C.json').write_text(json.dumps(manifest,indent=2)+'\n')
 return code,manifest
if __name__=='__main__':
 _,r=build();print(json.dumps(r,indent=2))
