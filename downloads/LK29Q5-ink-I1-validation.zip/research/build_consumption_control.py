"""E: retain D and turn three usage addition arguments into zero deltas.
Keep native arithmetic, return values, dirty tracking, reads and chip coherence.
"""
import hashlib,json,struct
from build_lifetime_control import build as build_d,ROOT
from build_remaining_report_control import BASE

def build():
 original=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes();d,dm=build_d();code=bytearray(d);patches=dm['patches'][:]
 for address,reason in [(0x434068ac,'Primary consumption: zero requested delta'),(0x434068d8,'Secondary consumption: zero requested delta'),(0x434068e8,'Whole/fractional consumption: zero requested delta')]:
  off=address-BASE;before=struct.pack('<I',0xe1a02001);after=struct.pack('<I',0xe3a02000)
  assert code[off:off+4]==before;code[off:off+4]=after
  patches.append({'address':hex(address),'before':before.hex(),'after':after.hex(),'reason':reason})
 allowed={i for p in patches for i in range(int(p['address'],16)-BASE,int(p['address'],16)-BASE+4)}
 diffs=[i for i,(a,b) in enumerate(zip(original,code)) if a!=b];assert len(diffs)==11 and set(diffs)<=allowed
 for address,size in [(0x43406890,0x1c),(0x434068bc,0xc),(0x433f5708,0xf4),(0x4340ace0,0x2c),(0x43407f5c,0x24)]:
  assert code[address-BASE:address-BASE+size]==original[address-BASE:address-BASE+size]
 manifest={'label':'E-zero-new-consumption','module_sha256':hashlib.sha256(code).hexdigest(),
 'original_module_sha256':hashlib.sha256(original).hexdigest(),'D_module_sha256':dm['module_sha256'],
 'patches':patches,'changed_bytes':11,'instruction_sites':6,'extra_instruction_sites_vs_D':3,'extra_changed_bytes_vs_D':6,
 'semantics':'Three usage addition helpers receive delta 0; original native bodies and return semantics execute',
 'preserved':['Actual stored counter reads','Native dirty tracking and zero-delta return behavior','Original chip I/O and synchronization','D lifetime handling','C 100-percent numeric report','Original raw state/profile/cover/other errors'],
 'not_implemented':['Reset existing accumulated usage to zero','Suppress every reconciliation/restore write','Operation without a maintenance cartridge'],
 'physical_boot_tested':False,'physical_usage_freeze_tested':False}
 (ROOT/'experimental/maintenance-control.consumption-E.bin').write_bytes(code)
 (ROOT/'experimental/maintenance-control.consumption-E.json').write_text(json.dumps(manifest,indent=2)+'\n')
 return bytes(code),manifest
if __name__=='__main__':
 _,r=build();print(json.dumps(r,indent=2))
