"""D extends successful C with two one-byte lifetime predicate changes.
Never forces raw state/profile/counters or edits persistent chip contents.
"""
import hashlib,json,struct
from build_remaining_report_control import build as build_c,ROOT,BASE

def build():
 original=(ROOT/'decoded/lk29q5-crom-00014153.bin').read_bytes();code,c=build_c();data=bytearray(code)
 patches=[{'address':c['address'],'before':c['before'],'after':c['after'],'reason':'C numeric remaining report retained'}]
 for address,before,after,reason in [
  (0x43405998,0x03a04001,0x03a04000,'Persistent life-bit predicate: keep reads, return no expired bit'),
  (0x43406b54,0x93a00001,0x93a00000,'Usage limit predicate: keep counter reads and output flag writes, return no full verdict'),
 ]:
  off=address-BASE;old=struct.pack('<I',before);new=struct.pack('<I',after)
  assert data[off:off+4]==old;data[off:off+4]=new
  patches.append({'address':hex(address),'before':old.hex(),'after':new.hex(),'reason':reason})
 allowed={i for p in patches for i in range(int(p['address'],16)-BASE,int(p['address'],16)-BASE+4)}
 diffs=[i for i,(a,b) in enumerate(zip(original,data)) if a!=b];assert len(diffs)==5 and set(diffs)<=allowed
 report={'label':'D-lifetime-control','module_sha256':hashlib.sha256(data).hexdigest(),'original_module_sha256':hashlib.sha256(original).hexdigest(),
 'patches':patches,'changed_bytes':5,'instruction_sites':3,'extra_changed_bytes_vs_C':2,
 'preserved':['Raw state getter and state transitions','Error selector including direct error 35 handling',
 'Original chip/profile selection','Original counters and increments','Original capacity calculation','Near-limit predicate and warning','Chip I/O and synchronization','Cover handling'],
 'not_implemented':['Zero consumption','Operation without a maintenance cartridge','Erasure/reset of chip or nonvolatile life records'],
 'physical_boot_tested':False,'physical_expired_cartridge_operation_tested':False}
 (ROOT/'experimental/maintenance-control.lifetime-D.bin').write_bytes(data)
 (ROOT/'experimental/maintenance-control.lifetime-D.json').write_text(json.dumps(report,indent=2)+'\n')
 return bytes(data),report
if __name__=='__main__':
 _,r=build();print(json.dumps(r,indent=2))
