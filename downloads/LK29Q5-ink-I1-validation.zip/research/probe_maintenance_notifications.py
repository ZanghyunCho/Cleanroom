"""Capture original waste-status report generation at transport boundaries."""
from pathlib import Path
import json
import struct
from probe_maintenance_state import Control, BASE
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import (UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2,
                               UC_ARM_REG_PC, UC_ARM_REG_LR)

ROOT = Path(__file__).resolve().parents[1]


def capture_reports(code, states=(0, 2, 7), remaining=100):
    results = []
    for state in states:
        n = Control(code)
        events, messages = [], []

        def ret(value=0):
            n.u.reg_write(UC_ARM_REG_R0, value)
            n.u.reg_write(UC_ARM_REG_PC, n.u.reg_read(UC_ARM_REG_LR))

        def event(u, a, size, data):
            ident = u.reg_read(UC_ARM_REG_R0)
            ptr = u.reg_read(UC_ARM_REG_R2)
            value = struct.unpack('<I', u.mem_read(ptr, 4))[0]
            events.append({'id': hex(ident), 'value': value})
            ret()

        def allocate_message(u, a, size, data):
            out = u.reg_read(UC_ARM_REG_R1)
            u.mem_write(0x42010000, bytes(1024))
            u.mem_write(out, struct.pack('<I', 0x42010000))
            ret()

        def post_message(u, a, size, data):
            ptr = u.reg_read(UC_ARM_REG_R1)
            messages.append(bytes(u.mem_read(ptr, 0x2c)).hex())
            ret()

        for address, callback in [(0x43557388, event),
                                  (0x4360ee3c, allocate_message),
                                  (0x4360f7b0, post_message)]:
            n.u.hook_add(UC_HOOK_CODE, callback, begin=address, end=address)
        status = n.literal(0x43408000, 0xc4)
        n.u.mem_write(status, bytes([state]) + bytes(3))
        n.u.mem_write(status + 4, bytes(8))
        n.u.mem_write(status + 8, bytes([remaining]))
        report_ptr = n.call(0x433f2ee4, 0)
        n.u.mem_write(report_ptr, bytes(8))
        for setter in (0x43407f50, 0x43407f74, 0x43407fcc):
            n.call(setter, 1)
        n.call(0x433f3b7c)
        report = bytes(n.u.mem_read(report_ptr, 8))
        assert len(events) == 6 and len(messages) == 1
        assert bytes(n.u.mem_read(0x433f3b7c, 0x244)) == code[0x433f3b7c - BASE:0x433f3dc0 - BASE]
        results.append({'state_fixture': state, 'stored_remaining': remaining,
                        'report_hex': report.hex(), 'report_bytes': list(report),
                        'events': events, 'posted_messages': messages})
    return results


def main():
    code = (ROOT / 'decoded/lk29q5-crom-00014153.bin').read_bytes()
    results = capture_reports(code)
    normal, error, alternate = results
    assert normal['report_bytes'][2] == 0
    assert alternate['report_bytes'][2] == 2
    assert normal['report_hex'] != alternate['report_hex']
    assert normal['events'] != alternate['events']
    result = {'version': 'LK29Q5', 'cases': results,
              'state7_report_matches_state0': False,
              'original_report_function_unchanged': True,
              'fixtures': ['event sink', 'message allocation', 'message transport'],
              'scope': 'Native report contents captured before delivery; event IDs and external UI interpretation are not assigned names. No printer or host updater is running.',
              'firmware_modified': False}
    out = ROOT / 'validation/maintenance-notifications-native-results.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
