# Reproduce
Place the supplied official FWCL14TL_KU25Q4.efu alongside build_ku_controls.py.
Expected source SHA-256: fb8bc19af5a13bb6dba43f8971aafeb062425e030be0c761eeccbf6000c99a56
Python 3.10+ and cryptography are required. Run python3 build_ku_controls.py.
The script creates both EFUs, SHA-256 files, and JSON reports in its own directory.
The original firmware and flash dumps are not included. No printer is accessed.
The CROM decoder/encoder were reused from this repository's LK29Q5 validation archives.
