# Reproduce KU25Q4 S2
Place supplied official FWCL14TL_KU25Q4.efu alongside these scripts.
Expected SHA-256: fb8bc19af5a13bb6dba43f8971aafeb062425e030be0c761eeccbf6000c99a56
Python 3.10+, cryptography, and unicorn are required. Keep TLS/package verification enabled.
Run python3 package_ku_stage2.py. It extracts the original module, rebuilds S1
and S2, packages EFU, re-extracts the final module, and runs the native tests.
An existing S2 EFU can supply its compressed frame only after byte-exact decoded
comparison with the rebuilt module; all final checks and tests are rerun.
Original firmware and flash dumps are not included. No printer is accessed.
The shared section validator comes from build_ku_controls.py; its main is not run.
