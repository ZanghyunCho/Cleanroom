44633d00 fe0400eb bl       #0x44635100
44633d04 0c00cde5 strb     r0, [sp, #0xc]
44633d08 3310a0e3 mov      r1, #0x33
44633d0c 0400a0e1 mov      r0, r4
44633d10 fa0400eb bl       #0x44635100
44633d14 0d00cde5 strb     r0, [sp, #0xd]
44633d18 a020a0e3 mov      r2, #0xa0
44633d1c 0d10a0e1 mov      r1, sp
44633d20 1600a0e3 mov      r0, #0x16
44633d24 be50cde1 strh     r5, [sp, #0xe]
44633d28 1040cde5 strb     r4, [sp, #0x10]
44633d2c 978dffeb bl       #0x44617390
44633d30 acd08de2 add      sp, sp, #0xac
44633d34 f080bde8 pop      {r4, r5, r6, r7, pc}
44633d38 70402de9 push     {r4, r5, r6, lr}
44633d3c 0040a0e3 mov      r4, #0
44633d40 0d0b00eb bl       #0x4463697c
44633d44 000050e3 cmp      r0, #0
44633d48 7080bd98 popls    {r4, r5, r6, pc}
44633d4c 0400a0e1 mov      r0, r4
44633d50 3d0700eb bl       #0x44635a4c
44633d54 0050a0e1 mov      r5, r0
44633d58 730700eb bl       #0x44635b2c
44633d5c 0060b0e1 movs     r6, r0
44633d60 0e00000a beq      #0x44633da0
44633d64 0020a0e1 mov      r2, r0
44633d68 0410a0e1 mov      r1, r4
44633d6c 1c00a0e3 mov      r0, #0x1c
44633d70 5f8effeb bl       #0x446176f4
44633d74 0410a0e1 mov      r1, r4
44633d78 1800a0e3 mov      r0, #0x18
44633d7c 8d8effeb bl       #0x446177b8
44633d80 1f0055e3 cmp      r5, #0x1f
44633d84 0200002a bhs      #0x44633d94
44633d88 0510a0e1 mov      r1, r5
44633d8c 1a00a0e3 mov      r0, #0x1a
44633d90 888effeb bl       #0x446177b8
44633d94 0610a0e1 mov      r1, r6
44633d98 0400a0e1 mov      r0, r4
44633d9c 9dffffeb bl       #0x44633c18
44633da0 010084e2 add      r0, r4, #1
44633da4 ff4000e2 and      r4, r0, #0xff
44633da8 f30a00eb bl       #0x4463697c
44633dac 040050e1 cmp      r0, r4
44633db0 e5ffff8a bhi      #0x44633d4c
44633db4 7080bde8 pop      {r4, r5, r6, pc}
44633db8 1eff2fe1 bx       lr
44633dbc 0000a0e3 mov      r0, #0
44633dc0 1eff2fe1 bx       lr
44633dc4 f0412de9 push     {r4, r5, r6, r7, r8, lr}
44633dc8 0050a0e1 mov      r5, r0
44633dcc 0160a0e1 mov      r6, r1
44633dd0 0040a0e3 mov      r4, #0
44633dd4 e80a00eb bl       #0x4463697c
44633dd8 000050e3 cmp      r0, #0
44633ddc 0170a083 movhi    r7, #1
44633de0 f081bd98 popls    {r4, r5, r6, r7, r8, pc}
44633de4 030055e3 cmp      r5, #3
44633de8 0300000a beq      #0x44633dfc
44633dec 0400a0e1 mov      r0, r4
44633df0 2c1000eb bl       #0x44637ea8
44633df4 050050e1 cmp      r0, r5
44633df8 0000001a bne      #0x44633e00
44633dfc 047186e7 str      r7, [r6, r4, lsl #2]
44633e00 010084e2 add      r0, r4, #1
44633e04 ff4000e2 and      r4, r0, #0xff
44633e08 db0a00eb bl       #0x4463697c
44633e0c 040050e1 cmp      r0, r4
44633e10 f3ffff8a bhi      #0x44633de4
44633e14 f081bde8 pop      {r4, r5, r6, r7, r8, pc}
44633e18 2c191fe5 ldr      r1, [pc, #-0x92c]
44633e1c 000081e5 str      r0, [r1]
44633e20 1eff2fe1 bx       lr
44633e24 1ecbffea b        #0x44626aa4
44633e28 3c119fe5 ldr      r1, [pc, #0x13c]
44633e2c 000191e7 ldr      r0, [r1, r0, lsl #2]
44633e30 1eff2fe1 bx       lr
44633e34 3a0400ea b        #0x44634f24
44633e38 10402de9 push     {r4, lr}
44633e3c 700500eb bl       #0x44635404
44633e40 0100a0e3 mov      r0, #1
44633e44 1080bde8 pop      {r4, pc}
44633e48 f0412de9 push     {r4, r5, r6, r7, r8, lr}
44633e4c 0150a0e1 mov      r5, r1
44633e50 0080a0e1 mov      r8, r0
44633e54 0040a0e3 mov      r4, #0
44633e58 201000eb bl       #0x44637ee0
44633e5c 000050e3 cmp      r0, #0
44633e60 0d00001a bne      #0x44633e9c
44633e64 0000d5e5 ldrb     r0, [r5]
44633e68 0060a0e3 mov      r6, #0
44633e6c 010050e3 cmp      r0, #1
44633e70 0870a003 moveq    r7, #8
44633e74 0770a013 movne    r7, #7
44633e78 0710a0e1 mov      r1, r7
44633e7c 0800a0e1 mov      r0, r8
44633e80 3c0300eb bl       #0x44634b78
44633e84 0010a0e1 mov      r1, r0
44633e88 0800a0e1 mov      r0, r8
44633e8c 230200eb bl       #0x44634720
44633e90 0040b0e1 movs     r4, r0
44633e94 0240a013 movne    r4, #2
44633e98 0100000a beq      #0x44633ea4
44633e9c 0400a0e1 mov      r0, r4
44633ea0 f081bde8 pop      {r4, r5, r6, r7, r8, pc}
44633ea4 0710a0e1 mov      r1, r7
44633ea8 0800a0e1 mov      r0, r8
44633eac 930400eb bl       #0x44635100
44633eb0 0010d5e5 ldrb     r1, [r5]
44633eb4 010051e3 cmp      r1, #1
44633eb8 0900000a beq      #0x44633ee4
44633ebc 041095e5 ldr      r1, [r5, #4]
44633ec0 010090e0 adds     r0, r0, r1
44633ec4 0000004a bmi      #0x44633ecc
44633ec8 0060a0e1 mov      r6, r0
44633ecc 0800a0e1 mov      r0, r8
44633ed0 e70500eb bl       #0x44635674
44633ed4 000050e3 cmp      r0, #0
44633ed8 0500000a beq      #0x44633ef4
44633edc 0140a0e3 mov      r4, #1
44633ee0 edffffea b        #0x44633e9c
44633ee4 046095e5 ldr      r6, [r5, #4]
44633ee8 000056e3 cmp      r6, #0
44633eec f6ffffaa bge      #0x44633ecc
44633ef0 f4ffffea b        #0x44633ec8
44633ef4 0620a0e1 mov      r2, r6
44633ef8 0710a0e1 mov      r1, r7
44633efc 0800a0e1 mov      r0, r8
44633f00 ccffffeb bl       #0x44633e38
44633f04 000050e3 cmp      r0, #0
44633f08 e3ffff1a bne      #0x44633e9c
44633f0c f2ffffea b        #0x44633edc
44633f10 70402de9 push     {r4, r5, r6, lr}
44633f14 0050a0e1 mov      r5, r0
44633f18 0000d1e5 ldrb     r0, [r1]
44633f1c 0140a0e1 mov      r4, r1
44633f20 000050e3 cmp      r0, #0
44633f24 7080bd18 popne    {r4, r5, r6, pc}
44633f28 0110a0e3 mov      r1, #1
44633f2c 0500a0e1 mov      r0, r5
44633f30 720400eb bl       #0x44635100
44633f34 040084e5 str      r0, [r4, #4]
44633f38 0710a0e3 mov      r1, #7
44633f3c 0500a0e1 mov      r0, r5
44633f40 6e0400eb bl       #0x44635100
44633f44 080084e5 str      r0, [r4, #8]
44633f48 0810a0e3 mov      r1, #8
44633f4c 0500a0e1 mov      r0, r5
44633f50 6a0400eb bl       #0x44635100
44633f54 0c0084e5 str      r0, [r4, #0xc]
44633f58 0500a0e1 mov      r0, r5
44633f5c 6a0600eb bl       #0x4463590c
44633f60 1000c4e5 strb     r0, [r4, #0x10]
44633f64 7080bde8 pop      {r4, r5, r6, pc}
44633f68 ffff0000 .byte    0xff, 0xff, 0x00, 0x00
44633f6c 54b39844 ldrmi    fp, [r8], #0x354
44633f70 d34d6210 .byte    0xd3, 0x4d, 0x62, 0x10
44633f74 10402de9 push     {r4, lr}
44633f78 0040a0e3 mov      r4, #0
44633f7c bcc4ffeb bl       #0x44625274
44633f80 000050e3 cmp      r0, #0
44633f84 0140a013 movne    r4, #1
44633f88 0400a0e1 mov      r0, r4
44633f8c 1080bde8 pop      {r4, pc}
44633f90 70402de9 push     {r4, r5, r6, lr}
44633f94 0040a0e3 mov      r4, #0
44633f98 0410a0e1 mov      r1, r4
44633f9c 3500a0e3 mov      r0, #0x35
44633fa0 d18effeb bl       #0x44617aec
44633fa4 0020a0e1 mov      r2, r0
44633fa8 0410a0e1 mov      r1, r4
44633fac 5800a0e3 mov      r0, #0x58
44633fb0 f78effeb bl       #0x44617b94
44633fb4 0020a0e3 mov      r2, #0
44633fb8 0410a0e1 mov      r1, r4
44633fbc 5a00a0e3 mov      r0, #0x5a
44633fc0 f38effeb bl       #0x44617b94
44633fc4 010084e2 add      r0, r4, #1
44633fc8 ff4010e2 ands     r4, r0, #0xff
44633fcc f1ffff0a beq      #0x44633f98
44633fd0 0040a0e3 mov      r4, #0
44633fd4 680a00eb bl       #0x4463697c
44633fd8 000050e3 cmp      r0, #0
44633fdc 7080bd98 popls    {r4, r5, r6, pc}
44633fe0 0400a0e1 mov      r0, r4
44633fe4 3f0d00eb bl       #0x446374e8
44633fe8 0050a0e1 mov      r5, r0
44633fec 0410a0e1 mov      r1, r4
44633ff0 1300a0e3 mov      r0, #0x13
44633ff4 208effeb bl       #0x4461787c
44633ff8 0020a0e1 mov      r2, r0
44633ffc 0510a0e1 mov      r1, r5
44634000 5a00a0e3 mov      r0, #0x5a
44634004 468fffeb bl       #0x44617d24
44634008 010084e2 add      r0, r4, #1
4463400c ff4000e2 and      r4, r0, #0xff
44634010 590a00eb bl       #0x4463697c
44634014 040050e1 cmp      r0, r4
44634018 f0ffff8a bhi      #0x44633fe0
4463401c 7080bde8 pop      {r4, r5, r6, pc}
44634020 10402de9 push     {r4, lr}
44634024 2f0d00eb bl       #0x446374e8
44634028 1040bde8 pop      {r4, lr}
4463402c 0010a0e1 mov      r1, r0
44634030 5a00a0e3 mov      r0, #0x5a
44634034 088fffea b        #0x44617c5c
44634038 10402de9 push     {r4, lr}
4463403c 290d00eb bl       #0x446374e8
44634040 0010b0e1 movs     r1, r0
44634044 0000a0e3 mov      r0, #0
44634048 0100a003 moveq    r0, #1
4463404c 1080bde8 pop      {r4, pc}
44634050 10402de9 push     {r4, lr}
44634054 f7ffffeb bl       #0x44634038
44634058 0010b0e1 movs     r1, r0
4463405c 0000a0e3 mov      r0, #0
44634060 6400a013 movne    r0, #0x64
44634064 1080bde8 pop      {r4, pc}
44634068 f0412de9 push     {r4, r5, r6, r7, r8, lr}
4463406c 0040a0e1 mov      r4, r0
44634070 c20000eb bl       #0x44634380
44634074 0050a0e1 mov      r5, r0
44634078 0400a0e1 mov      r0, r4
4463407c f3ffffeb bl       #0x44634050
44634080 58619fe5 ldr      r6, [pc, #0x158]
44634084 58719fe5 ldr      r7, [pc, #0x158]
44634088 0400c6e7 strb     r0, [r6, r4]
4463408c 971580e0 umull    r1, r0, r7, r5
44634090 a052a0e1 lsr      r5, r0, #5
44634094 0400a0e1 mov      r0, r4
44634098 540000eb bl       #0x446341f0
4463409c 0510a0e1 mov      r1, r5
446340a0 6eac07eb bl       #0x4481f260
446340a4 0410d6e7 ldrb     r1, [r6, r4]
446340a8 630050e3 cmp      r0, #0x63
446340ac 6300a083 movhi    r0, #0x63
446340b0 910000e0 mul      r0, r1, r0
446340b4 971080e0 umull    r1, r0, r7, r0
446340b8 28119fe5 ldr      r1, [pc, #0x128]
446340bc a002a0e1 lsr      r0, r0, #5
446340c0 0400c1e7 strb     r0, [r1, r4]
446340c4 f081bde8 pop      {r4, r5, r6, r7, r8, pc}
446340c8 f0472de9 push     {r4, r5, r6, r7, r8, sb, sl, lr}
446340cc 000051e3 cmp      r1, #0
446340d0 0060a0e1 mov      r6, r0
446340d4 6400a013 movne    r0, #0x64
446340d8 0a00001a bne      #0x44634108
446340dc a70000eb bl       #0x44634380
446340e0 fc109fe5 ldr      r1, [pc, #0xfc]
446340e4 912080e0 umull    r2, r0, r1, r0
446340e8 a042a0e1 lsr      r4, r0, #5
446340ec 0600a0e1 mov      r0, r6
446340f0 3e0000eb bl       #0x446341f0
446340f4 0410a0e1 mov      r1, r4
446340f8 58ac07eb bl       #0x4481f260
446340fc ff0000e2 and      r0, r0, #0xff
44634100 630050e3 cmp      r0, #0x63
44634104 6300a083 movhi    r0, #0x63
44634108 d0109fe5 ldr      r1, [pc, #0xd0]
4463410c d4809fe5 ldr      r8, [pc, #0xd4]
44634110 0610d1e7 ldrb     r1, [r1, r6]
44634114 810060e1 smulbb   r0, r1, r0
44634118 cc109fe5 ldr      r1, [pc, #0xcc]
4463411c 910000e0 mul      r0, r1, r0
44634120 010080e0 add      r0, r0, r1
44634124 0001a0e1 lsl      r0, r0, #2
44634128 204ca0e1 lsr      r4, r0, #0x18
4463412c 0600d8e7 ldrb     r0, [r8, r6]
44634130 040050e1 cmp      r0, r4
44634134 f087bd08 popeq    {r4, r5, r6, r7, r8, sb, sl, pc}
44634138 0600a0e1 mov      r0, r6
4463413c e90c00eb bl       #0x446374e8
44634140 0090a0e1 mov      sb, r0
44634144 0010a0e1 mov      r1, r0
44634148 3600a0e3 mov      r0, #0x36
4463414c 668effeb bl       #0x44617aec
44634150 0058a0e1 lsl      r5, r0, #0x10
44634154 2558a0e1 lsr      r5, r5, #0x10
44634158 0910a0e1 mov      r1, sb
4463415c 3500a0e3 mov      r0, #0x35
44634160 618effeb bl       #0x44617aec
44634164 0070a0e1 mov      r7, r0
44634168 0600d8e7 ldrb     r0, [r8, r6]
4463416c 000054e1 cmp      r4, r0
44634170 04004090 subls    r0, r0, r4
44634174 05008090 addls    r0, r0, r5
44634178 0900009a bls      #0x446341a4
4463417c 000044e0 sub      r0, r4, r0
44634180 0008a0e1 lsl      r0, r0, #0x10
44634184 2008a0e1 lsr      r0, r0, #0x10
44634188 000055e1 cmp      r5, r0
4463418c 00004580 subhi    r0, r5, r0
44634190 0300008a bhi      #0x446341a4
44634194 050040e0 sub      r0, r0, r5
44634198 007087e0 add      r7, r7, r0
4463419c 0020a0e3 mov      r2, #0
446341a0 010000ea b        #0x446341ac
446341a4 0028a0e1 lsl      r2, r0, #0x10
446341a8 2228a0e1 lsr      r2, r2, #0x10
446341ac 0910a0e1 mov      r1, sb
446341b0 3600a0e3 mov      r0, #0x36
446341b4 768effeb bl       #0x44617b94
446341b8 0720a0e1 mov      r2, r7
446341bc 0910a0e1 mov      r1, sb
446341c0 3500a0e3 mov      r0, #0x35
446341c4 728effeb bl       #0x44617b94
446341c8 0720a0e1 mov      r2, r7
446341cc 0910a0e1 mov      r1, sb
446341d0 5800a0e3 mov      r0, #0x58
446341d4 6e8effeb bl       #0x44617b94
446341d8 0640c8e7 strb     r4, [r8, r6]
446341dc f087bde8 pop      {r4, r5, r6, r7, r8, sb, sl, pc}
446341e0 a89f8e44 strmi    sb, [lr], #0xfa8
446341e4 1f85eb51 mvnpl    r8, pc, lsl r5
446341e8 a49f8e44 strmi    sb, [lr], #0xfa4
446341ec d7a30000 ldrdeq   sl, fp, [r0], -r7
446341f0 0010a0e1 mov      r1, r0
446341f4 1d00a0e3 mov      r0, #0x1d
446341f8 3b8effea b        #0x44617aec
446341fc 0120a0e1 mov      r2, r1
44634200 0010a0e1 mov      r1, r0
44634204 1d00a0e3 mov      r0, #0x1d
44634208 618effea b        #0x44617b94
4463420c 70402de9 push     {r4, r5, r6, lr}
44634210 0150a0e1 mov      r5, r1
44634214 0040a0e1 mov      r4, r0
44634218 3b0f00eb bl       #0x44637f0c
4463421c 000050e3 cmp      r0, #0
44634220 0f00000a beq      #0x44634264
44634224 0410a0e1 mov      r1, r4
44634228 1d00a0e3 mov      r0, #0x1d
4463422c 2e8effeb bl       #0x44617aec
44634230 d0139fe5 ldr      r1, [pc, #0x3d0]
44634234 fa2fa0e3 mov      r2, #0x3e8
44634238 041191e7 ldr      r1, [r1, r4, lsl #2]
4463423c 910202e0 mul      r2, r1, r2
44634240 020050e1 cmp      r0, r2
44634244 0600008a bhi      #0x44634264
44634248 050080e0 add      r0, r0, r5
4463424c 000052e1 cmp      r2, r0
44634250 0300008a bhi      #0x44634264
44634254 0410a0e1 mov      r1, r4
44634258 7040bde8 pop      {r4, r5, r6, lr}
4463425c 1d00a0e3 mov      r0, #0x1d
44634260 4b8effea b        #0x44617b94
44634264 0520a0e1 mov      r2, r5
44634268 0410a0e1 mov      r1, r4
4463426c 7040bde8 pop      {r4, r5, r6, lr}
44634270 1d00a0e3 mov      r0, #0x1d
44634274 aa8effea b        #0x44617d24
44634278 0010a0e1 mov      r1, r0
4463427c 1e00a0e3 mov      r0, #0x1e
44634280 198effea b        #0x44617aec
44634284 0120a0e1 mov      r2, r1
44634288 0010a0e1 mov      r1, r0
4463428c 1e00a0e3 mov      r0, #0x1e
44634290 3f8effea b        #0x44617b94
44634294 0120a0e1 mov      r2, r1
44634298 0010a0e1 mov      r1, r0
4463429c 1e00a0e3 mov      r0, #0x1e
446342a0 9f8effea b        #0x44617d24
446342a4 0120a0e1 mov      r2, r1
446342a8 5c139fe5 ldr      r1, [pc, #0x35c]
446342ac 30002de9 push     {r4, r5}
446342b0 003191e7 ldr      r3, [r1, r0, lsl #2]
446342b4 023083e0 add      r3, r3, r2
446342b8 50239fe5 ldr      r2, [pc, #0x350]
446342bc 92438ce0 umull    r4, ip, r2, r3
446342c0 2c23a0e1 lsr      r2, ip, #6
446342c4 7cc0e0e3 mvn      ip, #0x7c
446342c8 920c0ce0 mul      ip, r2, ip
446342cc 8c3183e0 add      r3, r3, ip, lsl #3
446342d0 003181e7 str      r3, [r1, r0, lsl #2]
446342d4 3000bde8 pop      {r4, r5}
446342d8 0010a0e1 mov      r1, r0
446342dc 2600a0e3 mov      r0, #0x26
446342e0 8f8effea b        #0x44617d24
446342e4 70402de9 push     {r4, r5, r6, lr}
446342e8 0060a0e1 mov      r6, r0
446342ec bfffffeb bl       #0x446341f0
446342f0 18139fe5 ldr      r1, [pc, #0x318]
446342f4 0040a0e3 mov      r4, #0
446342f8 912080e0 umull    r2, r0, r1, r0
446342fc 2053a0e1 lsr      r5, r0, #6
44634300 dbc3ffeb bl       #0x44625274
44634304 000050e3 cmp      r0, #0
44634308 0f00000a beq      #0x4463434c
4463430c 0600a0e1 mov      r0, r6
44634310 5d0500eb bl       #0x4463588c
44634314 640050e3 cmp      r0, #0x64
44634318 0100a093 movls    r0, #1
4463431c 1300009a bls      #0x44634370
44634320 ec129fe5 ldr      r1, [pc, #0x2ec]
44634324 910000e0 mul      r0, r1, r0
44634328 010080e0 add      r0, r0, r1
4463432c 201ba0e1 lsr      r1, r0, #0x16
44634330 050081e0 add      r0, r1, r5
44634334 010040e2 sub      r0, r0, #1
44634338 c8ab07eb bl       #0x4481f260
4463433c 630050e3 cmp      r0, #0x63
44634340 0140a023 movhs    r4, #1
44634344 0b00002a bhs      #0x44634378
44634348 080000ea b        #0x44634370
4463434c c4029fe5 ldr      r0, [pc, #0x2c4]
44634350 c4129fe5 ldr      r1, [pc, #0x2c4]
44634354 060190e7 ldr      r0, [r0, r6, lsl #2]
44634358 912080e0 umull    r2, r0, r1, r0
4463435c a012a0e1 lsr      r1, r0, #5
44634360 0500a0e1 mov      r0, r5
44634364 bdab07eb bl       #0x4481f260
44634368 640050e3 cmp      r0, #0x64
4463436c 0100002a bhs      #0x44634378
44634370 640060e2 rsb      r0, r0, #0x64
44634374 ff4000e2 and      r4, r0, #0xff
44634378 0400a0e1 mov      r0, r4
4463437c 7080bde8 pop      {r4, r5, r6, pc}
44634380 90129fe5 ldr      r1, [pc, #0x290]
44634384 000191e7 ldr      r0, [r1, r0, lsl #2]
44634388 fa1fa0e3 mov      r1, #0x3e8
4463438c 910000e0 mul      r0, r1, r0
44634390 1eff2fe1 bx       lr
44634394 f8402de9 push     {r3, r4, r5, r6, r7, lr}
44634398 0040a0e1 mov      r4, r0
4463439c fa0fa0e3 mov      r0, #0x3e8
446343a0 910005e0 mul      r5, r1, r0
446343a4 0d10a0e1 mov      r1, sp
446343a8 0400a0e1 mov      r0, r4
446343ac b70b00eb bl       #0x44637290
446343b0 00009de5 ldr      r0, [sp]
446343b4 0010d0e5 ldrb     r1, [r0]
446343b8 5000a0e3 mov      r0, #0x50
446343bc ca8dffeb bl       #0x44617aec
446343c0 40129fe5 ldr      r1, [pc, #0x240]
446343c4 000055e1 cmp      r5, r0
446343c8 00004580 subhi    r0, r5, r0
446343cc 0160a0e3 mov      r6, #1
446343d0 04018187 strhi    r0, [r1, r4, lsl #2]
446343d4 04618197 strls    r6, [r1, r4, lsl #2]
446343d8 00009de5 ldr      r0, [sp]
446343dc 0110d0e5 ldrb     r1, [r0, #1]
446343e0 5100a0e3 mov      r0, #0x51
446343e4 c08dffeb bl       #0x44617aec
446343e8 2c229fe5 ldr      r2, [pc, #0x22c]
446343ec 923581e0 umull    r3, r1, r2, r5
446343f0 a112a0e1 lsr      r1, r1, #5
446343f4 910000e0 mul      r0, r1, r0
446343f8 18129fe5 ldr      r1, [pc, #0x218]
446343fc 000050e3 cmp      r0, #0
44634400 040181e7 str      r0, [r1, r4, lsl #2]
44634404 0400a0e1 mov      r0, r4
44634408 04618107 streq    r6, [r1, r4, lsl #2]
4463440c b30e00eb bl       #0x44637ee0
44634410 000050e3 cmp      r0, #0
44634414 f880bd18 popne    {r3, r4, r5, r6, r7, pc}
44634418 00009de5 ldr      r0, [sp]
4463441c 0210d0e5 ldrb     r1, [r0, #2]
44634420 5200a0e3 mov      r0, #0x52
44634424 b08dffeb bl       #0x44617aec
44634428 f0119fe5 ldr      r1, [pc, #0x1f0]
4463442c 040181e7 str      r0, [r1, r4, lsl #2]
44634430 00009de5 ldr      r0, [sp]
44634434 0310d0e5 ldrb     r1, [r0, #3]
44634438 5300a0e3 mov      r0, #0x53
4463443c aa8dffeb bl       #0x44617aec
44634440 dc119fe5 ldr      r1, [pc, #0x1dc]
44634444 640050e3 cmp      r0, #0x64
44634448 6400a023 movhs    r0, #0x64
4463444c 040181e7 str      r0, [r1, r4, lsl #2]
44634450 f880bde8 pop      {r3, r4, r5, r6, r7, pc}
44634454 f0472de9 push     {r4, r5, r6, r7, r8, sb, sl, lr}
44634458 0150a0e1 mov      r5, r1
4463445c 0080a0e1 mov      r8, r0
44634460 0010a0e1 mov      r1, r0
44634464 2100a0e3 mov      r0, #0x21
44634468 9f8dffeb bl       #0x44617aec
4463446c 0040b0e1 movs     r4, r0
44634470 0090a0e3 mov      sb, #0
44634474 0100000a beq      #0x44634480
44634478 050054e1 cmp      r4, r5
4463447c 0100009a bls      #0x44634488
44634480 0520a0e1 mov      r2, r5
44634484 210000ea b        #0x44634510
44634488 0800a0e1 mov      r0, r8
4463448c 57ffffeb bl       #0x446341f0
44634490 0060a0e1 mov      r6, r0
44634494 0800a0e1 mov      r0, r8
44634498 76ffffeb bl       #0x44634278
4463449c 0020a0e1 mov      r2, r0
446344a0 7c019fe5 ldr      r0, [pc, #0x17c]
446344a4 0030a0e3 mov      r3, #0
446344a8 080190e7 ldr      r0, [r0, r8, lsl #2]
446344ac 920081e0 umull    r0, r1, r2, r0
446344b0 6420a0e3 mov      r2, #0x64
446344b4 b5a407eb bl       #0x4481d790
446344b8 0070a0e1 mov      r7, r0
446344bc 5c019fe5 ldr      r0, [pc, #0x15c]
446344c0 01a0a0e1 mov      sl, r1
446344c4 082190e7 ldr      r2, [r0, r8, lsl #2]
446344c8 045045e0 sub      r5, r5, r4
446344cc 920581e0 umull    r0, r1, r2, r5
446344d0 1e0090e2 adds     r0, r0, #0x1e
446344d4 0010a1e2 adc      r1, r1, #0
446344d8 3c20a0e3 mov      r2, #0x3c
446344dc 0030a0e3 mov      r3, #0
446344e0 aaa407eb bl       #0x4481d790
446344e4 002097e0 adds     r2, r7, r0
446344e8 0a10a1e0 adc      r1, r1, sl
446344ec 062052e0 subs     r2, r2, r6
446344f0 0010d1e2 sbcs     r1, r1, #0
446344f4 00704630 sublo    r7, r6, r0
446344f8 0710a0e1 mov      r1, r7
446344fc 0800a0e1 mov      r0, r8
44634500 3dffffeb bl       #0x446341fc
44634504 070056e1 cmp      r6, r7
44634508 0190a013 movne    sb, #1
4463450c 052084e0 add      r2, r4, r5
44634510 0810a0e1 mov      r1, r8
44634514 2100a0e3 mov      r0, #0x21
44634518 9d8dffeb bl       #0x44617b94
4463451c 0900a0e1 mov      r0, sb
44634520 f087bde8 pop      {r4, r5, r6, r7, r8, sb, sl, pc}
44634524 0010a0e1 mov      r1, r0
44634528 0020a0e3 mov      r2, #0
4463452c 2100a0e3 mov      r0, #0x21
44634530 978dffea b        #0x44617b94
44634534 70402de9 push     {r4, r5, r6, lr}
44634538 0140a0e1 mov      r4, r1
4463453c 0050a0e1 mov      r5, r0
44634540 2affffeb bl       #0x446341f0
44634544 c4109fe5 ldr      r1, [pc, #0xc4]
44634548 912080e0 umull    r2, r0, r1, r0
4463454c c4209fe5 ldr      r2, [pc, #0xc4]
44634550 2013a0e1 lsr      r1, r0, #6
44634554 053192e7 ldr      r3, [r2, r5, lsl #2]
44634558 0000a0e3 mov      r0, #0
4463455c 010053e1 cmp      r3, r1
44634560 0020a0e1 mov      r2, r0
44634564 0100a093 movls    r0, #1
44634568 0020c495 strbls   r2, [r4]
4463456c 7080bd98 popls    {r4, r5, r6, pc}
44634570 90309fe5 ldr      r3, [pc, #0x90]
44634574 053193e7 ldr      r3, [r3, r5, lsl #2]
44634578 010053e1 cmp      r3, r1
4463457c 0110a093 movls    r1, #1
44634580 0010c495 strbls   r1, [r4]
44634584 0020c485 strbhi   r2, [r4]
44634588 7080bde8 pop      {r4, r5, r6, pc}
4463458c 10402de9 push     {r4, lr}
44634590 0040a0e1 mov      r4, r0
44634594 15ffffeb bl       #0x446341f0
44634598 70109fe5 ldr      r1, [pc, #0x70]
4463459c 912080e0 umull    r2, r0, r1, r0
446345a0 60209fe5 ldr      r2, [pc, #0x60]
446345a4 2013a0e1 lsr      r1, r0, #6
446345a8 042192e7 ldr      r2, [r2, r4, lsl #2]
446345ac 0000a0e3 mov      r0, #0
446345b0 010052e1 cmp      r2, r1
446345b4 0100a093 movls    r0, #1
446345b8 1080bde8 pop      {r4, pc}
446345bc 10402de9 push     {r4, lr}
446345c0 0040a0e1 mov      r4, r0
446345c4 0010a0e1 mov      r1, r0
446345c8 1d00a0e3 mov      r0, #0x1d
446345cc 468dffeb bl       #0x44617aec
446345d0 0030a0e1 mov      r3, r0
446345d4 2c009fe5 ldr      r0, [pc, #0x2c]
446345d8 fa1fa0e3 mov      r1, #0x3e8
446345dc 040190e7 ldr      r0, [r0, r4, lsl #2]
446345e0 0020a0e3 mov      r2, #0
446345e4 910000e0 mul      r0, r1, r0
446345e8 000053e1 cmp      r3, r0
446345ec 0300008a bhi      #0x44634600
446345f0 011080e2 add      r1, r0, #1
446345f4 0400a0e1 mov      r0, r4
446345f8 fffeffeb bl       #0x446341fc
446345fc 0120a0e3 mov      r2, #1
44634600 0200a0e1 mov      r0, r2
44634604 1080bde8 pop      {r4, pc}
44634608 94b39844 ldrmi    fp, [r8], #0x394
4463460c d4b39844 ldrmi    fp, [r8], #0x3d4
44634610 d34d6210 .byte    0xd3, 0x4d, 0x62, 0x10
44634614 d7a30000 ldrdeq   sl, fp, [r0], -r7
44634618 a4b39844 ldrmi    fp, [r8], #0x3a4
4463461c 1f85eb51 mvnpl    r8, pc, lsl r5
44634620 b4b39844 ldrmi    fp, [r8], #0x3b4
44634624 c4b39844 ldrmi    fp, [r8], #0x3c4
44634628 0000a0e3 mov      r0, #0
4463462c 1eff2fe1 bx       lr
44634630 0000a0e3 mov      r0, #0
44634634 1eff2fe1 bx       lr
44634638 0000a0e3 mov      r0, #0
4463463c 1eff2fe1 bx       lr
44634640 0000a0e3 mov      r0, #0
44634644 1eff2fe1 bx       lr
44634648 30402de9 push     {r4, r5, lr}
4463464c 34d04de2 sub      sp, sp, #0x34
44634650 0040a0e3 mov      r4, #0
44634654 00408de5 str      r4, [sp]
44634658 04408de5 str      r4, [sp, #4]
4463465c 0050a0e1 mov      r5, r0
44634660 08408de5 str      r4, [sp, #8]
44634664 0c408de5 str      r4, [sp, #0xc]
44634668 10408de5 str      r4, [sp, #0x10]
4463466c 14408de5 str      r4, [sp, #0x14]
44634670 18408de5 str      r4, [sp, #0x18]
44634674 2e10a0e3 mov      r1, #0x2e
44634678 0500a0e1 mov      r0, r5
4463467c 1c408de5 str      r4, [sp, #0x1c]
44634680 20408de5 str      r4, [sp, #0x20]
44634684 24408de5 str      r4, [sp, #0x24]
44634688 28408de5 str      r4, [sp, #0x28]
4463468c 2c408de5 str      r4, [sp, #0x2c]
44634690 9a0200eb bl       #0x44635100
44634694 0000cde5 strb     r0, [sp]
44634698 2f10a0e3 mov      r1, #0x2f
4463469c 0500a0e1 mov      r0, r5
446346a0 960200eb bl       #0x44635100
446346a4 0100cde5 strb     r0, [sp, #1]
446346a8 3010a0e3 mov      r1, #0x30
446346ac 0500a0e1 mov      r0, r5
446346b0 920200eb bl       #0x44635100
446346b4 0200cde5 strb     r0, [sp, #2]
446346b8 3110a0e3 mov      r1, #0x31
446346bc 0500a0e1 mov      r0, r5
446346c0 8e0200eb bl       #0x44635100
446346c4 0300cde5 strb     r0, [sp, #3]
446346c8 3210a0e3 mov      r1, #0x32
446346cc 0500a0e1 mov      r0, r5
446346d0 8a0200eb bl       #0x44635100
446346d4 0400cde5 strb     r0, [sp, #4]
446346d8 3610a0e3 mov      r1, #0x36
446346dc 0500a0e1 mov      r0, r5
446346e0 860200eb bl       #0x44635100
446346e4 0500cde5 strb     r0, [sp, #5]
446346e8 0530a0e1 mov      r3, r5
446346ec 1820a0e3 mov      r2, #0x18
446346f0 18108de2 add      r1, sp, #0x18
446346f4 2f00a0e3 mov      r0, #0x2f
446346f8 678bffeb bl       #0x4461749c
446346fc 1820a0e3 mov      r2, #0x18
44634700 18108de2 add      r1, sp, #0x18
44634704 0d00a0e1 mov      r0, sp
44634708 62a607fa blx      #0x4481e098
4463470c 000050e3 cmp      r0, #0
44634710 0140a013 movne    r4, #1
44634714 0400a0e1 mov      r0, r4
44634718 34d08de2 add      sp, sp, #0x34
4463471c 3080bde8 pop      {r4, r5, pc}
44634720 30402de9 push     {r4, r5, lr}
44634724 0cd04de2 sub      sp, sp, #0xc
44634728 0050a0e1 mov      r5, r0
4463472c 630d00eb bl       #0x44637cc0
44634730 0000cde5 strb     r0, [sp]
44634734 0500a0e1 mov      r0, r5
44634738 d10100eb bl       #0x44634e84
4463473c 04008de5 str      r0, [sp, #4]
44634740 0d00a0e1 mov      r0, sp
44634744 69d9ffeb bl       #0x4462acf0
44634748 090050e3 cmp      r0, #9
4463474c 0040a0e1 mov      r4, r0
44634750 0400000a beq      #0x44634768
44634754 170050e3 cmp      r0, #0x17
44634758 0600000a beq      #0x44634778
4463475c 200054e3 cmp      r4, #0x20
44634760 0c00001a bne      #0x44634798
44634764 070000ea b        #0x44634788
44634768 0010a0e3 mov      r1, #0
4463476c 0500a0e1 mov      r0, r5
44634770 b80400eb bl       #0x44635a58
44634774 070000ea b        #0x44634798
44634778 0110a0e3 mov      r1, #1
4463477c 0500a0e1 mov      r0, r5
44634780 b40400eb bl       #0x44635a58
44634784 030000ea b        #0x44634798
44634788 0110a0e3 mov      r1, #1
4463478c 0500a0e1 mov      r0, r5
44634790 590300eb bl       #0x446354fc
44634794 0040a0e3 mov      r4, #0
44634798 0400a0e1 mov      r0, r4
4463479c 0cd08de2 add      sp, sp, #0xc
446347a0 3080bde8 pop      {r4, r5, pc}
446347a4 f0472de9 push     {r4, r5, r6, r7, r8, sb, sl, lr}
446347a8 0080a0e1 mov      r8, r0
446347ac 030082e2 add      r0, r2, #3
446347b0 fc6000e2 and      r6, r0, #0xfc
446347b4 0150a0e1 mov      r5, r1
446347b8 0070a0e3 mov      r7, #0
446347bc 0740a0e1 mov      r4, r7
446347c0 0610a0e1 mov      r1, r6
446347c4 0800a0e1 mov      r0, r8
446347c8 d4ffffeb bl       #0x44634720
446347cc 000050e3 cmp      r0, #0
446347d0 0170a013 movne    r7, #1
446347d4 0100000a beq      #0x446347e0
446347d8 0700a0e1 mov      r0, r7
446347dc f087bde8 pop      {r4, r5, r6, r7, r8, sb, sl, pc}
446347e0 0800a0e1 mov      r0, r8
446347e4 a60100eb bl       #0x44634e84
446347e8 000056e3 cmp      r6, #0
446347ec b4929f85 ldrhi    sb, [pc, #0x2b4]
446347f0 09c18981 orrhi    ip, sb, sb, lsl #2
446347f4 f7ffff9a bls      #0x446347d8
446347f8 0920a0e1 mov      r2, sb
446347fc b010d0e1 ldrh     r1, [r0]
44634800 b030d5e1 ldrh     r3, [r5]
44634804 021001e0 and      r1, r1, r2
44634808 023003e0 and      r3, r3, r2
4463480c 030051e1 cmp      r1, r3
44634810 0800000a beq      #0x44634838
44634814 0b10a0e3 mov      r1, #0xb
44634818 0800a0e1 mov      r0, r8
4463481c 8d0400eb bl       #0x44635a58
44634820 0170a0e3 mov      r7, #1
44634824 ebffffea b        #0x446347d8
44634828 200054e3 cmp      r4, #0x20
4463482c 0c20a021 movhs    r2, ip
44634830 f1ffff2a bhs      #0x446347fc
44634834 efffffea b        #0x446347f8
44634838 011084e2 add      r1, r4, #1
4463483c ff4001e2 and      r4, r1, #0xff
44634840 060054e1 cmp      r4, r6
44634844 020080e2 add      r0, r0, #2
44634848 025085e2 add      r5, r5, #2
4463484c f5ffff3a blo      #0x44634828
44634850 e0ffffea b        #0x446347d8
44634854 70402de9 push     {r4, r5, r6, lr}
44634858 08d04de2 sub      sp, sp, #8
4463485c 0140a0e1 mov      r4, r1
44634860 0060a0e1 mov      r6, r0
44634864 150d00eb bl       #0x44637cc0
44634868 0000cde5 strb     r0, [sp]
4463486c 0600a0e1 mov      r0, r6
44634870 830100eb bl       #0x44634e84
44634874 04008de5 str      r0, [sp, #4]
44634878 0d00a0e1 mov      r0, sp
4463487c 60d9ffeb bl       #0x4462ae04
44634880 0a0050e3 cmp      r0, #0xa
44634884 0050a0e1 mov      r5, r0
44634888 0200001a bne      #0x44634898
4463488c 0310a0e3 mov      r1, #3
44634890 0600a0e1 mov      r0, r6
44634894 6f0400eb bl       #0x44635a58
44634898 000054e3 cmp      r4, #0
4463489c 0600a001 moveq    r0, r6
446348a0 9f01000b bleq     #0x44634f24
446348a4 0500a0e1 mov      r0, r5
446348a8 08d08de2 add      sp, sp, #8
446348ac 7080bde8 pop      {r4, r5, r6, pc}
446348b0 10402de9 push     {r4, lr}
446348b4 0140a0e1 mov      r4, r1
446348b8 930100eb bl       #0x44634f0c
446348bc 0010a0e3 mov      r1, #0
446348c0 2b20a0e3 mov      r2, #0x2b
446348c4 0010c4e5 strb     r1, [r4]
446348c8 0230d0e7 ldrb     r3, [r0, r2]
446348cc 010053e3 cmp      r3, #1
446348d0 0400000a beq      #0x446348e8
446348d4 000052e3 cmp      r2, #0
446348d8 01104212 subne    r1, r2, #1
446348dc ff200112 andne    r2, r1, #0xff
446348e0 f8ffff1a bne      #0x446348c8
446348e4 1080bde8 pop      {r4, pc}
446348e8 010082e2 add      r0, r2, #1
446348ec 0000c4e5 strb     r0, [r4]
446348f0 1080bde8 pop      {r4, pc}
446348f4 38402de9 push     {r3, r4, r5, lr}
446348f8 0040a0e3 mov      r4, #0
446348fc 0d10a0e1 mov      r1, sp
44634900 0040cde5 strb     r4, [sp]
44634904 e9ffffeb bl       #0x446348b0
44634908 0000dde5 ldrb     r0, [sp]
4463490c 000050e3 cmp      r0, #0
44634910 0140a013 movne    r4, #1
44634914 0400a0e1 mov      r0, r4
44634918 3880bde8 pop      {r3, r4, r5, pc}
4463491c f0402de9 push     {r4, r5, r6, r7, lr}
44634920 c4d04de2 sub      sp, sp, #0xc4
44634924 0160a0e1 mov      r6, r1
44634928 0050a0e1 mov      r5, r0
4463492c 0040a0e3 mov      r4, #0
44634930 6a0d00eb bl       #0x44637ee0
44634934 000050e3 cmp      r0, #0
44634938 1500001a bne      #0x44634994
4463493c 0000a0e3 mov      r0, #0
44634940 c000cde5 strb     r0, [sp, #0xc0]
44634944 0500a0e1 mov      r0, r5
44634948 4d0100eb bl       #0x44634e84
4463494c 0070a0e1 mov      r7, r0
44634950 0500a0e1 mov      r0, r5
44634954 e6ffffeb bl       #0x446348f4
44634958 010050e3 cmp      r0, #1
4463495c 0c00001a bne      #0x44634994
44634960 c0108de2 add      r1, sp, #0xc0
44634964 0500a0e1 mov      r0, r5
44634968 d0ffffeb bl       #0x446348b0
4463496c c020a0e3 mov      r2, #0xc0
44634970 0710a0e1 mov      r1, r7
44634974 0d00a0e1 mov      r0, sp
44634978 25a607eb bl       #0x4481e214
4463497c 0610a0e1 mov      r1, r6
44634980 0500a0e1 mov      r0, r5
44634984 b2ffffeb bl       #0x44634854
44634988 000050e3 cmp      r0, #0
4463498c 0140a013 movne    r4, #1
44634990 0200000a beq      #0x446349a0
44634994 0400a0e1 mov      r0, r4
44634998 c4d08de2 add      sp, sp, #0xc4
4463499c f080bde8 pop      {r4, r5, r6, r7, pc}
446349a0 c020dde5 ldrb     r2, [sp, #0xc0]
446349a4 0d10a0e1 mov      r1, sp
446349a8 0500a0e1 mov      r0, r5
446349ac 7cffffeb bl       #0x446347a4
446349b0 0040a0e1 mov      r4, r0
446349b4 f6ffffea b        #0x44634994
446349b8 10402de9 push     {r4, lr}
446349bc 0040a0e1 mov      r4, r0
446349c0 18d04de2 sub      sp, sp, #0x18
446349c4 0000a0e3 mov      r0, #0
446349c8 00008de5 str      r0, [sp]
446349cc 04008de5 str      r0, [sp, #4]
446349d0 08008de5 str      r0, [sp, #8]
446349d4 0c008de5 str      r0, [sp, #0xc]
446349d8 10008de5 str      r0, [sp, #0x10]
446349dc 14008de5 str      r0, [sp, #0x14]
446349e0 2e10a0e3 mov      r1, #0x2e
446349e4 0400a0e1 mov      r0, r4
446349e8 c40100eb bl       #0x44635100
446349ec 0000cde5 strb     r0, [sp]
446349f0 2f10a0e3 mov      r1, #0x2f
446349f4 0400a0e1 mov      r0, r4
446349f8 c00100eb bl       #0x44635100
446349fc 0100cde5 strb     r0, [sp, #1]
44634a00 3010a0e3 mov      r1, #0x30
44634a04 0400a0e1 mov      r0, r4
44634a08 bc0100eb bl       #0x44635100
44634a0c 0200cde5 strb     r0, [sp, #2]
44634a10 3110a0e3 mov      r1, #0x31
44634a14 0400a0e1 mov      r0, r4
44634a18 b80100eb bl       #0x44635100
44634a1c 0300cde5 strb     r0, [sp, #3]
44634a20 3210a0e3 mov      r1, #0x32
44634a24 0400a0e1 mov      r0, r4
44634a28 b40100eb bl       #0x44635100
44634a2c 0400cde5 strb     r0, [sp, #4]
44634a30 3610a0e3 mov      r1, #0x36
44634a34 0400a0e1 mov      r0, r4
44634a38 b00100eb bl       #0x44635100
44634a3c 0500cde5 strb     r0, [sp, #5]
44634a40 0430a0e1 mov      r3, r4
44634a44 1820a0e3 mov      r2, #0x18
44634a48 0d10a0e1 mov      r1, sp
44634a4c 2f00a0e3 mov      r0, #0x2f
44634a50 c48affeb bl       #0x44617568
44634a54 18d08de2 add      sp, sp, #0x18
44634a58 1080bde8 pop      {r4, pc}
44634a5c 0000a0e3 mov      r0, #0
44634a60 1eff2fe1 bx       lr
44634a64 04e02de5 str      lr, [sp, #-4]!
44634a68 0cd04de2 sub      sp, sp, #0xc
44634a6c f3c0ffeb bl       #0x44624e40
44634a70 000050e3 cmp      r0, #0
44634a74 0800000a beq      #0x44634a9c
44634a78 2c209fe5 ldr      r2, [pc, #0x2c]
44634a7c 2c108fe2 add      r1, pc, #0x2c
44634a80 28008fe2 add      r0, pc, #0x28
44634a84 07008de8 stm      sp, {r0, r1, r2}
44634a88 0030a0e3 mov      r3, #0
44634a8c 0320a0e1 mov      r2, r3
44634a90 18108fe2 add      r1, pc, #0x18
44634a94 18008fe2 add      r0, pc, #0x18
44634a98 b1a305eb bl       #0x4479d964
44634a9c 0000a0e3 mov      r0, #0
44634aa0 0cd08de2 add      sp, sp, #0xc
44634aa4 04f09de4 pop      {pc}
44634aa8 ff1f0000 strdeq   r1, r2, [r0], -pc
44634aac e7010000 andeq    r0, r0, r7, ror #3
44634ab0 00000000 andeq    r0, r0, r0
44634ab4 30000000 andeq    r0, r0, r0, lsr r0
44634ab8 0000a0e3 mov      r0, #0
44634abc 1eff2fe1 bx       lr
44634ac0 86d8ffea b        #0x4462ace0
44634ac4 87d8ffea b        #0x4462ace8
44634ac8 0620a0e3 mov      r2, #6
44634acc 002080e5 str      r2, [r0]
44634ad0 0100a0e3 mov      r0, #1
44634ad4 000081e5 str      r0, [r1]
44634ad8 1eff2fe1 bx       lr
44634adc f0412de9 push     {r4, r5, r6, r7, r8, lr}
44634ae0 0040a0e3 mov      r4, #0
44634ae4 a40700eb bl       #0x4463697c
44634ae8 000050e3 cmp      r0, #0
44634aec f081bd98 popls    {r4, r5, r6, r7, r8, pc}
44634af0 0050a0e3 mov      r5, #0
44634af4 60619fe5 ldr      r6, [pc, #0x160]
44634af8 037c86e2 add      r7, r6, #0x300
44634afc 842084e0 add      r2, r4, r4, lsl #1
44634b00 021386e0 add      r1, r6, r2, lsl #6
44634b04 0000a0e3 mov      r0, #0
44634b08 822287e0 add      r2, r7, r2, lsl #5
44634b0c 803081e0 add      r3, r1, r0, lsl #1
44634b10 b050c3e1 strh     r5, [r3]
44634b14 0050c2e7 strb     r5, [r2, r0]
44634b18 010080e2 add      r0, r0, #1
44634b1c ff0000e2 and      r0, r0, #0xff
44634b20 600050e3 cmp      r0, #0x60
44634b24 f8ffff3a blo      #0x44634b0c
44634b28 010084e2 add      r0, r4, #1
44634b2c ff4000e2 and      r4, r0, #0xff
44634b30 910700eb bl       #0x4463697c
44634b34 040050e1 cmp      r0, r4
44634b38 efffff8a bhi      #0x44634afc
44634b3c f081bde8 pop      {r4, r5, r6, r7, r8, pc}
44634b40 10402de9 push     {r4, lr}
44634b44 0040a0e3 mov      r4, #0
44634b48 b90d00eb bl       #0x44638234
44634b4c 08219fe5 ldr      r2, [pc, #0x108]
44634b50 800080e0 add      r0, r0, r0, lsl #1
44634b54 0010a0e3 mov      r1, #0
44634b58 000382e0 add      r0, r2, r0, lsl #6
44634b5c 842080e0 add      r2, r0, r4, lsl #1
44634b60 b010c2e1 strh     r1, [r2]
44634b64 012084e2 add      r2, r4, #1
44634b68 ff4002e2 and      r4, r2, #0xff
44634b6c 600054e3 cmp      r4, #0x60
44634b70 f9ffff3a blo      #0x44634b5c
44634b74 1080bde8 pop      {r4, pc}
44634b78 0000a0e3 mov      r0, #0
44634b7c 1eff2fe1 bx       lr
44634b80 a90d00ea b        #0x4463822c
44634b84 f0412de9 push     {r4, r5, r6, r7, r8, lr}
44634b88 0040a0e3 mov      r4, #0
44634b8c 10d04de2 sub      sp, sp, #0x10
44634b90 0170a0e1 mov      r7, r1
44634b94 0450a0e1 mov      r5, r4
44634b98 0480a0e1 mov      r8, r4
44634b9c f7ffffeb bl       #0x44634b80
44634ba0 0060a0e1 mov      r6, r0
44634ba4 9e0d00eb bl       #0x44638224
44634ba8 0010d0e5 ldrb     r1, [r0]
44634bac 5c0051e3 cmp      r1, #0x5c
44634bb0 1800000a beq      #0x44634c18
44634bb4 841084e0 add      r1, r4, r4, lsl #1
44634bb8 8120d0e7 ldrb     r2, [r0, r1, lsl #1]
44634bbc 060052e1 cmp      r2, r6
44634bc0 0c00001a bne      #0x44634bf8
44634bc4 811080e0 add      r1, r0, r1, lsl #1
44634bc8 b2c0d1e1 ldrh     ip, [r1, #2]
44634bcc 0410d1e5 ldrb     r1, [r1, #4]
44634bd0 0120a0e3 mov      r2, #1
44634bd4 01001ce3 tst      ip, #1
44634bd8 0c30a0e1 mov      r3, ip
44634bdc 0300001a bne      #0x44634bf0
44634be0 8220a0e1 lsl      r2, r2, #1
44634be4 0c0012e1 tst      r2, ip
44634be8 a330a0e1 lsr      r3, r3, #1
44634bec fbffff0a beq      #0x44634be0
44634bf0 135185e1 orr      r5, r5, r3, lsl r1
44634bf4 0180a0e3 mov      r8, #1
44634bf8 011084e2 add      r1, r4, #1
44634bfc ff4001e2 and      r4, r1, #0xff
44634c00 841084e0 add      r1, r4, r4, lsl #1
44634c04 8110d0e7 ldrb     r1, [r0, r1, lsl #1]
44634c08 5c0051e3 cmp      r1, #0x5c
44634c0c e8ffff1a bne      #0x44634bb4
44634c10 000058e3 cmp      r8, #0
44634c14 0d00001a bne      #0x44634c50
44634c18 000057e3 cmp      r7, #0
44634c1c 0b00000a beq      #0x44634c50
44634c20 86c0ffeb bl       #0x44624e40
44634c24 000050e3 cmp      r0, #0
44634c28 0800000a beq      #0x44634c50
44634c2c 9820a0e3 mov      r2, #0x98
44634c30 28108fe2 add      r1, pc, #0x28
44634c34 24008fe2 add      r0, pc, #0x24
44634c38 07008de8 stm      sp, {r0, r1, r2}
44634c3c 0030a0e3 mov      r3, #0
44634c40 0320a0e1 mov      r2, r3
44634c44 14108fe2 add      r1, pc, #0x14
44634c48 14008fe2 add      r0, pc, #0x14
44634c4c 44a305eb bl       #0x4479d964
44634c50 0500a0e1 mov      r0, r5
44634c54 10d08de2 add      sp, sp, #0x10
44634c58 f081bde8 pop      {r4, r5, r6, r7, r8, pc}
44634c5c e4b39844 ldrmi    fp, [r8], #0x3e4
44634c60 00000000 andeq    r0, r0, r0
44634c64 30000000 andeq    r0, r0, r0, lsr r0
44634c68 f04f2de9 push     {r4, r5, r6, r7, r8, sb, sl, fp, lr}
44634c6c 0050a0e3 mov      r5, #0
44634c70 0cd04de2 sub      sp, sp, #0xc
44634c74 0040a0e1 mov      r4, r0
44634c78 0180a0e1 mov      r8, r1
44634c7c 0290a0e1 mov      sb, r2
44634c80 0170a0e3 mov      r7, #1
44634c84 0560a0e1 mov      r6, r5
44634c88 650d00eb bl       #0x44638224
44634c8c 0010d0e5 ldrb     r1, [r0]
44634c90 5c0051e3 cmp      r1, #0x5c
44634c94 1f00000a beq      #0x44634d18
44634c98 44201fe5 ldr      r2, [pc, #-0x44]
44634c9c 841084e0 add      r1, r4, r4, lsl #1
44634ca0 01a382e0 add      sl, r2, r1, lsl #6
44634ca4 0128e0e3 mvn      r2, #0x10000
44634ca8 851085e0 add      r1, r5, r5, lsl #1
44634cac 8130d0e7 ldrb     r3, [r0, r1, lsl #1]
44634cb0 080053e1 cmp      r3, r8
44634cb4 0f00001a bne      #0x44634cf8
44634cb8 811080e0 add      r1, r0, r1, lsl #1
44634cbc 0130d1e5 ldrb     r3, [r1, #1]
44634cc0 b240d1e1 ldrh     r4, [r1, #2]
44634cc4 0410d1e5 ldrb     r1, [r1, #4]
44634cc8 83308ae0 add      r3, sl, r3, lsl #1
44634ccc b030d3e1 ldrh     r3, [r3]
44634cd0 010014e3 tst      r4, #1
44634cd4 0070a0e3 mov      r7, #0
44634cd8 04c003e0 and      ip, r3, r4
44634cdc 0130a0e3 mov      r3, #1
44634ce0 0300001a bne      #0x44634cf4
44634ce4 833002e0 and      r3, r2, r3, lsl #1
44634ce8 040013e1 tst      r3, r4
44634cec acc0a0e1 lsr      ip, ip, #1
44634cf0 fbffff0a beq      #0x44634ce4
44634cf4 1c6186e1 orr      r6, r6, ip, lsl r1
44634cf8 011085e2 add      r1, r5, #1
44634cfc ff5001e2 and      r5, r1, #0xff
44634d00 851085e0 add      r1, r5, r5, lsl #1
44634d04 8110d0e7 ldrb     r1, [r0, r1, lsl #1]
44634d08 5c0051e3 cmp      r1, #0x5c
44634d0c e5ffff1a bne      #0x44634ca8
44634d10 010057e3 cmp      r7, #1
44634d14 1000001a bne      #0x44634d5c
44634d18 000058e3 cmp      r8, #0
44634d1c 0e00000a beq      #0x44634d5c
44634d20 46c0ffeb bl       #0x44624e40
44634d24 000050e3 cmp      r0, #0
44634d28 0cd08d02 addeq    sp, sp, #0xc
44634d2c f08fbd08 popeq    {r4, r5, r6, r7, r8, sb, sl, fp, pc}
44634d30 d520a0e3 mov      r2, #0xd5
44634d34 dc104fe2 sub      r1, pc, #0xdc
44634d38 e0004fe2 sub      r0, pc, #0xe0
44634d3c 07008de8 stm      sp, {r0, r1, r2}
44634d40 0030a0e3 mov      r3, #0
44634d44 0320a0e1 mov      r2, r3
44634d48 f0104fe2 sub      r1, pc, #0xf0
44634d4c f0004fe2 sub      r0, pc, #0xf0
44634d50 03a305eb bl       #0x4479d964
44634d54 0cd08de2 add      sp, sp, #0xc
44634d58 f08fbde8 pop      {r4, r5, r6, r7, r8, sb, sl, fp, pc}
44634d5c 006089e5 str      r6, [sb]
44634d60 0cd08de2 add      sp, sp, #0xc
44634d64 f08fbde8 pop      {r4, r5, r6, r7, r8, sb, sl, fp, pc}
44634d68 f74f2de9 push     {r0, r1, r2, r4, r5, r6, r7, r8, sb, sl, fp, lr}
44634d6c 10d04de2 sub      sp, sp, #0x10
44634d70 0070a0e1 mov      r7, r0
44634d74 0160a0e1 mov      r6, r1
44634d78 0150a0e3 mov      r5, #1
44634d7c 0040a0e3 mov      r4, #0
44634d80 270d00eb bl       #0x44638224
44634d84 0010d0e5 ldrb     r1, [r0]
44634d88 5c0051e3 cmp      r1, #0x5c
44634d8c 2a00000a beq      #0x44634e3c
44634d90 3c311fe5 ldr      r3, [pc, #-0x13c]
44634d94 872087e0 add      r2, r7, r7, lsl #1
44634d98 02a383e0 add      sl, r3, r2, lsl #6
44634d9c 033c83e2 add      r3, r3, #0x300
44634da0 0118e0e3 mvn      r1, #0x10000
44634da4 82b283e0 add      fp, r3, r2, lsl #5
44634da8 842084e0 add      r2, r4, r4, lsl #1
44634dac 8230d0e7 ldrb     r3, [r0, r2, lsl #1]
44634db0 060053e1 cmp      r3, r6
44634db4 1700001a bne      #0x44634e18
44634db8 822080e0 add      r2, r0, r2, lsl #1
44634dbc 0170d2e5 ldrb     r7, [r2, #1]
44634dc0 b230d2e1 ldrh     r3, [r2, #2]
44634dc4 0420d2e5 ldrb     r2, [r2, #4]
44634dc8 87808ae0 add      r8, sl, r7, lsl #1
44634dcc b0c0d8e1 ldrh     ip, [r8]
44634dd0 010013e3 tst      r3, #1
44634dd4 0050a0e3 mov      r5, #0
44634dd8 0390cce1 bic      sb, ip, r3
44634ddc 18c09de5 ldr      ip, [sp, #0x18]
44634de0 3c22a0e1 lsr      r2, ip, r2
44634de4 02c8a0e1 lsl      ip, r2, #0x10
44634de8 2cc8a0e1 lsr      ip, ip, #0x10
44634dec 0120a0e3 mov      r2, #1
44634df0 0300001a bne      #0x44634e04
44634df4 822001e0 and      r2, r1, r2, lsl #1
44634df8 030012e1 tst      r2, r3
44634dfc 8cc001e0 and      ip, r1, ip, lsl #1
44634e00 fbffff0a beq      #0x44634df4
44634e04 03200ce0 and      r2, ip, r3
44634e08 0130a0e3 mov      r3, #1
44634e0c 092082e1 orr      r2, r2, sb
44634e10 0730cbe7 strb     r3, [fp, r7]
44634e14 b020c8e1 strh     r2, [r8]
44634e18 012084e2 add      r2, r4, #1
44634e1c ff4002e2 and      r4, r2, #0xff
44634e20 842084e0 add      r2, r4, r4, lsl #1
44634e24 8220d0e7 ldrb     r2, [r0, r2, lsl #1]
44634e28 5c0052e3 cmp      r2, #0x5c
44634e2c ddffff1a bne      #0x44634da8
44634e30 010055e3 cmp      r5, #1
44634e34 1cd08d12 addne    sp, sp, #0x1c
44634e38 f08fbd18 popne    {r4, r5, r6, r7, r8, sb, sl, fp, pc}
44634e3c 000056e3 cmp      r6, #0
44634e40 1cd08d02 addeq    sp, sp, #0x1c
44634e44 f08fbd08 popeq    {r4, r5, r6, r7, r8, sb, sl, fp, pc}
44634e48 fcbfffeb bl       #0x44624e40
44634e4c 000050e3 cmp      r0, #0
44634e50 1cd08d02 addeq    sp, sp, #0x1c
44634e54 f08fbd08 popeq    {r4, r5, r6, r7, r8, sb, sl, fp, pc}
44634e58 0030a0e3 mov      r3, #0
44634e5c 40279fe5 ldr      r2, [pc, #0x740]
44634e60 821f4fe2 sub      r1, pc, #0x208
44634e64 830f4fe2 sub      r0, pc, #0x20c
44634e68 07008de8 stm      sp, {r0, r1, r2}
44634e6c 0320a0e1 mov      r2, r3
44634e70 861f4fe2 sub      r1, pc, #0x218
44634e74 860f4fe2 sub      r0, pc, #0x218
44634e78 b9a205eb bl       #0x4479d964
44634e7c 1cd08de2 add      sp, sp, #0x1c
44634e80 f08fbde8 pop      {r4, r5, r6, r7, r8, sb, sl, fp, pc}
44634e84 10402de9 push     {r4, lr}
44634e88 e90c00eb bl       #0x44638234
44634e8c 38121fe5 ldr      r1, [pc, #-0x238]
44634e90 800080e0 add      r0, r0, r0, lsl #1
44634e94 000381e0 add      r0, r1, r0, lsl #6
44634e98 1080bde8 pop      {r4, pc}
44634e9c 70402de9 push     {r4, r5, r6, lr}
44634ea0 0040a0e3 mov      r4, #0
44634ea4 0450a0e1 mov      r5, r4
44634ea8 e10c00eb bl       #0x44638234
44634eac 0060a0e1 mov      r6, r0
44634eb0 db0c00eb bl       #0x44638224
44634eb4 0010d0e5 ldrb     r1, [r0]
44634eb8 5c0051e3 cmp      r1, #0x5c
44634ebc 0900000a beq      #0x44634ee8
44634ec0 841084e0 add      r1, r4, r4, lsl #1
44634ec4 8110d0e7 ldrb     r1, [r0, r1, lsl #1]
44634ec8 2e0051e3 cmp      r1, #0x2e
44634ecc 0a00000a beq      #0x44634efc
44634ed0 011084e2 add      r1, r4, #1
44634ed4 ff4001e2 and      r4, r1, #0xff
44634ed8 841084e0 add      r1, r4, r4, lsl #1
44634edc 8110d0e7 ldrb     r1, [r0, r1, lsl #1]
44634ee0 5c0051e3 cmp      r1, #0x5c
44634ee4 f5ffff1a bne      #0x44634ec0
44634ee8 94121fe5 ldr      r1, [pc, #-0x294]
44634eec 860086e0 add      r0, r6, r6, lsl #1
44634ef0 000381e0 add      r0, r1, r0, lsl #6
44634ef4 850080e0 add      r0, r0, r5, lsl #1
44634ef8 7080bde8 pop      {r4, r5, r6, pc}
44634efc 841084e0 add      r1, r4, r4, lsl #1
44634f00 810080e0 add      r0, r0, r1, lsl #1
44634f04 0150d0e5 ldrb     r5, [r0, #1]
44634f08 f6ffffea b        #0x44634ee8
44634f0c 10402de9 push     {r4, lr}
44634f10 c70c00eb bl       #0x44638234
44634f14 8c169fe5 ldr      r1, [pc, #0x68c]
44634f18 800080e0 add      r0, r0, r0, lsl #1
44634f1c 800281e0 add      r0, r1, r0, lsl #5
44634f20 1080bde8 pop      {r4, pc}
44634f24 10402de9 push     {r4, lr}
44634f28 0040a0e3 mov      r4, #0
44634f2c c00c00eb bl       #0x44638234
44634f30 70269fe5 ldr      r2, [pc, #0x670]
44634f34 800080e0 add      r0, r0, r0, lsl #1
44634f38 0010a0e3 mov      r1, #0
44634f3c 800282e0 add      r0, r2, r0, lsl #5
44634f40 012084e2 add      r2, r4, #1
44634f44 0410c0e7 strb     r1, [r0, r4]
44634f48 ff4002e2 and      r4, r2, #0xff
44634f4c 600054e3 cmp      r4, #0x60
44634f50 faffff3a blo      #0x44634f40
44634f54 1080bde8 pop      {r4, pc}
44634f58 10402de9 push     {r4, lr}
44634f5c 010050e3 cmp      r0, #1
44634f60 06005013 cmpne    r0, #6
44634f64 0140a0e1 mov      r4, r1
44634f68 0300000a beq      #0x44634f7c
44634f6c 2a0050e3 cmp      r0, #0x2a
44634f70 01018100 addeq    r0, r1, r1, lsl #2
44634f74 8040a001 lsleq    r4, r0, #1
44634f78 0a0000ea b        #0x44634fa8
44634f7c 0200a0e1 mov      r0, r2
44634f80 450900eb bl       #0x4463749c
44634f84 20169fe5 ldr      r1, [pc, #0x620]
44634f88 0030a0e3 mov      r3, #0
44634f8c 901182e0 umull    r1, r2, r0, r1
44634f90 94018ce0 umull    r0, ip, r4, r1
44634f94 93c121e0 mla      r1, r3, r1, ip
44634f98 941221e0 mla      r1, r4, r2, r1
44634f9c 0c269fe5 ldr      r2, [pc, #0x60c]
44634fa0 faa107eb bl       #0x4481d790
44634fa4 0040a0e1 mov      r4, r0
44634fa8 0400a0e1 mov      r0, r4
44634fac 1080bde8 pop      {r4, pc}
44634fb0 0010a0e1 mov      r1, r0
44634fb4 021041e2 sub      r1, r1, #2
44634fb8 4c0051e3 cmp      r1, #0x4c
44634fbc 0100a0e3 mov      r0, #1
44634fc0 01f19f37 ldrlo    pc, [pc, r1, lsl #2]
44634fc4 1eff2fe1 bx       lr
44634fc8 f8506344 strbtmi  r5, [r3], #-0xf8
44634fcc f8506344 strbtmi  r5, [r3], #-0xf8
44634fd0 f8506344 strbtmi  r5, [r3], #-0xf8
44634fd4 f8506344 strbtmi  r5, [r3], #-0xf8
44634fd8 c44f6344 strbtmi  r4, [r3], #-0xfc4
44634fdc c44f6344 strbtmi  r4, [r3], #-0xfc4
44634fe0 c44f6344 strbtmi  r4, [r3], #-0xfc4
44634fe4 f8506344 strbtmi  r5, [r3], #-0xf8
44634fe8 c44f6344 strbtmi  r4, [r3], #-0xfc4
44634fec f8506344 strbtmi  r5, [r3], #-0xf8
44634ff0 c44f6344 strbtmi  r4, [r3], #-0xfc4
44634ff4 f8506344 strbtmi  r5, [r3], #-0xf8
44634ff8 c44f6344 strbtmi  r4, [r3], #-0xfc4
44634ffc f8506344 strbtmi  r5, [r3], #-0xf8
44635000 f8506344 strbtmi  r5, [r3], #-0xf8
44635004 f8506344 strbtmi  r5, [r3], #-0xf8
44635008 f8506344 strbtmi  r5, [r3], #-0xf8
4463500c f8506344 strbtmi  r5, [r3], #-0xf8
44635010 f8506344 strbtmi  r5, [r3], #-0xf8
44635014 f8506344 strbtmi  r5, [r3], #-0xf8
44635018 f8506344 strbtmi  r5, [r3], #-0xf8
4463501c f8506344 strbtmi  r5, [r3], #-0xf8
44635020 f8506344 strbtmi  r5, [r3], #-0xf8
44635024 f8506344 strbtmi  r5, [r3], #-0xf8
44635028 f8506344 strbtmi  r5, [r3], #-0xf8
4463502c f8506344 strbtmi  r5, [r3], #-0xf8
44635030 f8506344 strbtmi  r5, [r3], #-0xf8
44635034 f8506344 strbtmi  r5, [r3], #-0xf8
44635038 f8506344 strbtmi  r5, [r3], #-0xf8
4463503c f8506344 strbtmi  r5, [r3], #-0xf8
44635040 f8506344 strbtmi  r5, [r3], #-0xf8
44635044 f8506344 strbtmi  r5, [r3], #-0xf8
44635048 f8506344 strbtmi  r5, [r3], #-0xf8
4463504c f8506344 strbtmi  r5, [r3], #-0xf8
44635050 f8506344 strbtmi  r5, [r3], #-0xf8
44635054 f8506344 strbtmi  r5, [r3], #-0xf8
44635058 f8506344 strbtmi  r5, [r3], #-0xf8
4463505c f8506344 strbtmi  r5, [r3], #-0xf8
44635060 f8506344 strbtmi  r5, [r3], #-0xf8
44635064 f8506344 strbtmi  r5, [r3], #-0xf8
44635068 c44f6344 strbtmi  r4, [r3], #-0xfc4
4463506c c44f6344 strbtmi  r4, [r3], #-0xfc4
44635070 f8506344 strbtmi  r5, [r3], #-0xf8
44635074 f8506344 strbtmi  r5, [r3], #-0xf8
44635078 c44f6344 strbtmi  r4, [r3], #-0xfc4
4463507c c44f6344 strbtmi  r4, [r3], #-0xfc4
44635080 c44f6344 strbtmi  r4, [r3], #-0xfc4
44635084 c44f6344 strbtmi  r4, [r3], #-0xfc4
44635088 c44f6344 strbtmi  r4, [r3], #-0xfc4
4463508c c44f6344 strbtmi  r4, [r3], #-0xfc4
44635090 c44f6344 strbtmi  r4, [r3], #-0xfc4
44635094 c44f6344 strbtmi  r4, [r3], #-0xfc4
44635098 c44f6344 strbtmi  r4, [r3], #-0xfc4
4463509c c44f6344 strbtmi  r4, [r3], #-0xfc4
446350a0 c44f6344 strbtmi  r4, [r3], #-0xfc4
446350a4 c44f6344 strbtmi  r4, [r3], #-0xfc4
446350a8 c44f6344 strbtmi  r4, [r3], #-0xfc4
446350ac c44f6344 strbtmi  r4, [r3], #-0xfc4
446350b0 c44f6344 strbtmi  r4, [r3], #-0xfc4
446350b4 f8506344 strbtmi  r5, [r3], #-0xf8
446350b8 c44f6344 strbtmi  r4, [r3], #-0xfc4
446350bc c44f6344 strbtmi  r4, [r3], #-0xfc4
446350c0 f8506344 strbtmi  r5, [r3], #-0xf8
446350c4 f8506344 strbtmi  r5, [r3], #-0xf8
446350c8 f8506344 strbtmi  r5, [r3], #-0xf8
446350cc f8506344 strbtmi  r5, [r3], #-0xf8
446350d0 f8506344 strbtmi  r5, [r3], #-0xf8
446350d4 f8506344 strbtmi  r5, [r3], #-0xf8
446350d8 f8506344 strbtmi  r5, [r3], #-0xf8
446350dc f8506344 strbtmi  r5, [r3], #-0xf8
446350e0 f8506344 strbtmi  r5, [r3], #-0xf8
446350e4 f8506344 strbtmi  r5, [r3], #-0xf8
446350e8 f8506344 strbtmi  r5, [r3], #-0xf8
446350ec f8506344 strbtmi  r5, [r3], #-0xf8
446350f0 f8506344 strbtmi  r5, [r3], #-0xf8
446350f4 f8506344 strbtmi  r5, [r3], #-0xf8
446350f8 0000a0e3 mov      r0, #0
446350fc 1eff2fe1 bx       lr
44635100 f8432de9 push     {r3, r4, r5, r6, r7, r8, sb, lr}
44635104 0050a0e3 mov      r5, #0
44635108 0060a0e1 mov      r6, r0
4463510c 0140a0e1 mov      r4, r1
44635110 00508de5 str      r5, [sp]
44635114 99feffeb bl       #0x44634b80
44635118 0070a0e1 mov      r7, r0
4463511c 0600a0e1 mov      r0, r6
44635120 430c00eb bl       #0x44638234
44635124 0080a0e1 mov      r8, r0
44635128 0400a0e1 mov      r0, r4
4463512c 9fffffeb bl       #0x44634fb0
44635130 010050e3 cmp      r0, #1
44635134 0300000a beq      #0x44635148
44635138 0b0054e3 cmp      r4, #0xb
4463513c 0d005413 cmpne    r4, #0xd
44635140 0150a003 moveq    r5, #1
44635144 080000ea b        #0x4463516c
44635148 0d20a0e1 mov      r2, sp
4463514c 0710a0e1 mov      r1, r7
44635150 0800a0e1 mov      r0, r8
44635154 c3feffeb bl       #0x44634c68
44635158 00109de5 ldr      r1, [sp]
4463515c 0620a0e1 mov      r2, r6
44635160 0700a0e1 mov      r0, r7
44635164 7bffffeb bl       #0x44634f58
44635168 0050a0e1 mov      r5, r0
4463516c 0500a0e1 mov      r0, r5
44635170 f883bde8 pop      {r3, r4, r5, r6, r7, r8, sb, pc}
44635174 f8432de9 push     {r3, r4, r5, r6, r7, r8, sb, lr}
44635178 0040a0e3 mov      r4, #0
4463517c 006052e2 subs     r6, r2, #0
44635180 0080a0e1 mov      r8, r0
44635184 0150a0e1 mov      r5, r1
44635188 0470a0e1 mov      r7, r4
4463518c 00408de5 str      r4, [sp]
44635190 f883bd98 popls    {r3, r4, r5, r6, r7, r8, sb, pc}
44635194 050054e3 cmp      r4, #5
44635198 04f19f37 ldrlo    pc, [pc, r4, lsl #2]
4463519c 1d0000ea b        #0x44635218
446351a0 b4516344 strbtmi  r5, [r3], #-0x1b4
446351a4 c8516344 strbtmi  r5, [r3], #-0x1c8
446351a8 dc516344 strbtmi  r5, [r3], #-0x1dc
446351ac f0516344 strbtmi  r5, [r3], #-0x1f0
446351b0 04526344 strbtmi  r5, [r3], #-0x204
446351b4 0d20a0e1 mov      r2, sp
446351b8 3710a0e3 mov      r1, #0x37
446351bc 0800a0e1 mov      r0, r8
446351c0 a8feffeb bl       #0x44634c68
446351c4 140000ea b        #0x4463521c
446351c8 0d20a0e1 mov      r2, sp
446351cc 3810a0e3 mov      r1, #0x38
446351d0 0800a0e1 mov      r0, r8
446351d4 a3feffeb bl       #0x44634c68
446351d8 0f0000ea b        #0x4463521c
446351dc 0d20a0e1 mov      r2, sp
446351e0 3910a0e3 mov      r1, #0x39
446351e4 0800a0e1 mov      r0, r8
446351e8 9efeffeb bl       #0x44634c68
446351ec 0a0000ea b        #0x4463521c
446351f0 0d20a0e1 mov      r2, sp
446351f4 3a10a0e3 mov      r1, #0x3a
446351f8 0800a0e1 mov      r0, r8
446351fc 99feffeb bl       #0x44634c68
44635200 050000ea b        #0x4463521c
44635204 0d20a0e1 mov      r2, sp
44635208 3b10a0e3 mov      r1, #0x3b
4463520c 0800a0e1 mov      r0, r8
44635210 94feffeb bl       #0x44634c68
44635214 000000ea b        #0x4463521c
44635218 00708de5 str      r7, [sp]
4463521c 00309de5 ldr      r3, [sp]
44635220 010084e2 add      r0, r4, #1
44635224 0430c5e7 strb     r3, [r5, r4]
44635228 ff4000e2 and      r4, r0, #0xff
4463522c 060054e1 cmp      r4, r6
44635230 d7ffff3a blo      #0x44635194
44635234 f883bde8 pop      {r3, r4, r5, r6, r7, r8, sb, pc}
44635238 f8432de9 push     {r3, r4, r5, r6, r7, r8, sb, lr}
4463523c 0040a0e3 mov      r4, #0
44635240 006052e2 subs     r6, r2, #0
44635244 0080a0e1 mov      r8, r0
44635248 0150a0e1 mov      r5, r1
4463524c 0470a0e1 mov      r7, r4
44635250 00408de5 str      r4, [sp]
44635254 f883bd98 popls    {r3, r4, r5, r6, r7, r8, sb, pc}
44635258 090054e3 cmp      r4, #9
4463525c 04f19f37 ldrlo    pc, [pc, r4, lsl #2]
44635260 350000ea b        #0x4463533c
44635264 88526344 strbtmi  r5, [r3], #-0x288
44635268 9c526344 strbtmi  r5, [r3], #-0x29c
4463526c b0526344 strbtmi  r5, [r3], #-0x2b0
44635270 c4526344 strbtmi  r5, [r3], #-0x2c4
44635274 d8526344 strbtmi  r5, [r3], #-0x2d8
44635278 ec526344 strbtmi  r5, [r3], #-0x2ec
4463527c 00536344 strbtmi  r5, [r3], #-0x300
44635280 14536344 strbtmi  r5, [r3], #-0x314
44635284 28536344 strbtmi  r5, [r3], #-0x328
44635288 0d20a0e1 mov      r2, sp
4463528c 2e10a0e3 mov      r1, #0x2e
44635290 0800a0e1 mov      r0, r8
44635294 73feffeb bl       #0x44634c68
44635298 280000ea b        #0x44635340
4463529c 0d20a0e1 mov      r2, sp
446352a0 2f10a0e3 mov      r1, #0x2f
446352a4 0800a0e1 mov      r0, r8
446352a8 6efeffeb bl       #0x44634c68
446352ac 230000ea b        #0x44635340
446352b0 0d20a0e1 mov      r2, sp
446352b4 3010a0e3 mov      r1, #0x30
446352b8 0800a0e1 mov      r0, r8
446352bc 69feffeb bl       #0x44634c68
446352c0 1e0000ea b        #0x44635340
446352c4 0d20a0e1 mov      r2, sp
446352c8 3110a0e3 mov      r1, #0x31
446352cc 0800a0e1 mov      r0, r8
446352d0 64feffeb bl       #0x44634c68
446352d4 190000ea b        #0x44635340
446352d8 0d20a0e1 mov      r2, sp
446352dc 3210a0e3 mov      r1, #0x32
446352e0 0800a0e1 mov      r0, r8
446352e4 5ffeffeb bl       #0x44634c68
446352e8 140000ea b        #0x44635340
446352ec 0d20a0e1 mov      r2, sp
446352f0 3310a0e3 mov      r1, #0x33
446352f4 0800a0e1 mov      r0, r8
446352f8 5afeffeb bl       #0x44634c68
446352fc 0f0000ea b        #0x44635340
44635300 0d20a0e1 mov      r2, sp
44635304 3410a0e3 mov      r1, #0x34
44635308 0800a0e1 mov      r0, r8
4463530c 55feffeb bl       #0x44634c68
44635310 0a0000ea b        #0x44635340
44635314 0d20a0e1 mov      r2, sp
44635318 3510a0e3 mov      r1, #0x35
4463531c 0800a0e1 mov      r0, r8
44635320 50feffeb bl       #0x44634c68
44635324 050000ea b        #0x44635340
44635328 0d20a0e1 mov      r2, sp
4463532c 3610a0e3 mov      r1, #0x36
44635330 0800a0e1 mov      r0, r8
44635334 4bfeffeb bl       #0x44634c68
44635338 000000ea b        #0x44635340
4463533c 00708de5 str      r7, [sp]
44635340 00309de5 ldr      r3, [sp]
44635344 010084e2 add      r0, r4, #1
44635348 0430c5e7 strb     r3, [r5, r4]
4463534c ff4000e2 and      r4, r0, #0xff
44635350 060054e1 cmp      r4, r6
44635354 bfffff3a blo      #0x44635258
44635358 f883bde8 pop      {r3, r4, r5, r6, r7, r8, sb, pc}
4463535c 70402de9 push     {r4, r5, r6, lr}
44635360 0160a0e1 mov      r6, r1
44635364 0250a0e1 mov      r5, r2
44635368 0340a0e1 mov      r4, r3
4463536c b00b00eb bl       #0x44638234
44635370 010056e3 cmp      r6, #1
44635374 0b00000a beq      #0x446353a8
44635378 020056e3 cmp      r6, #2
4463537c 0d00000a beq      #0x446353b8
44635380 000054e3 cmp      r4, #0
44635384 0000a0e3 mov      r0, #0
44635388 0020a083 movhi    r2, #0
4463538c 7080bd98 popls    {r4, r5, r6, pc}
44635390 0020c5e7 strb     r2, [r5, r0]
44635394 010080e2 add      r0, r0, #1
44635398 ff0000e2 and      r0, r0, #0xff
4463539c 040050e1 cmp      r0, r4
446353a0 faffff3a blo      #0x44635390
446353a4 7080bde8 pop      {r4, r5, r6, pc}
446353a8 0420a0e1 mov      r2, r4
446353ac 0510a0e1 mov      r1, r5
446353b0 7040bde8 pop      {r4, r5, r6, lr}
446353b4 9fffffea b        #0x44635238
446353b8 0420a0e1 mov      r2, r4
446353bc 0510a0e1 mov      r1, r5
446353c0 7040bde8 pop      {r4, r5, r6, lr}
446353c4 6affffea b        #0x44635174
446353c8 10402de9 push     {r4, lr}
446353cc 010051e3 cmp      r1, #1
446353d0 0030a0e1 mov      r3, r0
446353d4 06005113 cmpne    r1, #6
446353d8 0240a0e1 mov      r4, r2
446353dc 0200a0e1 mov      r0, r2
446353e0 1080bd18 popne    {r4, pc}
446353e4 0300a0e1 mov      r0, r3
446353e8 2b0800eb bl       #0x4463749c
446353ec b8119fe5 ldr      r1, [pc, #0x1b8]
446353f0 902183e0 umull    r2, r3, r0, r1
446353f4 b4019fe5 ldr      r0, [pc, #0x1b4]
446353f8 940081e0 umull    r0, r1, r4, r0
446353fc 1040bde8 pop      {r4, lr}
44635400 e2a007ea b        #0x4481d790
44635404 f0412de9 push     {r4, r5, r6, r7, r8, lr}
44635408 0270a0e1 mov      r7, r2
4463540c 0080a0e1 mov      r8, r0
44635410 0140a0e1 mov      r4, r1
44635414 d9fdffeb bl       #0x44634b80
44635418 0050a0e1 mov      r5, r0
4463541c 0800a0e1 mov      r0, r8
44635420 830b00eb bl       #0x44638234
44635424 0060a0e1 mov      r6, r0
44635428 0400a0e1 mov      r0, r4
4463542c dffeffeb bl       #0x44634fb0
44635430 010050e3 cmp      r0, #1
44635434 f081bd18 popne    {r4, r5, r6, r7, r8, pc}
44635438 0410a0e1 mov      r1, r4
4463543c 0800a0e1 mov      r0, r8
44635440 cffdffeb bl       #0x44634b84
44635444 0040a0e1 mov      r4, r0
44635448 0720a0e1 mov      r2, r7
4463544c 0510a0e1 mov      r1, r5
44635450 0600a0e1 mov      r0, r6
44635454 dbffffeb bl       #0x446353c8
44635458 040050e1 cmp      r0, r4
4463545c 0020a0e1 mov      r2, r0
44635460 0420a081 movhi    r2, r4
44635464 0510a0e1 mov      r1, r5
44635468 0600a0e1 mov      r0, r6
4463546c f041bde8 pop      {r4, r5, r6, r7, r8, lr}
44635470 3cfeffea b        #0x44634d68
44635474 f0412de9 push     {r4, r5, r6, r7, r8, lr}
44635478 0060a0e1 mov      r6, r0
4463547c 0170a0e1 mov      r7, r1
44635480 0040a0e3 mov      r4, #0
44635484 0100a0e1 mov      r0, r1
44635488 c8feffeb bl       #0x44634fb0
4463548c 0050a0e1 mov      r5, r0
44635490 0710a0e1 mov      r1, r7
44635494 0600a0e1 mov      r0, r6
44635498 b8fdffeb bl       #0x44634b80
4463549c 010055e3 cmp      r5, #1
446354a0 0070a0e1 mov      r7, r0
446354a4 0d00001a bne      #0x446354e0
446354a8 0010a0e1 mov      r1, r0
446354ac 0600a0e1 mov      r0, r6
446354b0 b3fdffeb bl       #0x44634b84
446354b4 0050a0e1 mov      r5, r0
446354b8 0710a0e1 mov      r1, r7
446354bc 0600a0e1 mov      r0, r6
446354c0 0effffeb bl       #0x44635100
446354c4 050050e1 cmp      r0, r5
446354c8 0400002a bhs      #0x446354e0
446354cc 012080e2 add      r2, r0, #1
446354d0 0710a0e1 mov      r1, r7
446354d4 0600a0e1 mov      r0, r6
446354d8 c9ffffeb bl       #0x44635404
446354dc 0140a0e3 mov      r4, #1
446354e0 0400a0e1 mov      r0, r4
446354e4 f081bde8 pop      {r4, r5, r6, r7, r8, pc}
446354e8 10402de9 push     {r4, lr}
446354ec 500b00eb bl       #0x44638234
446354f0 bc109fe5 ldr      r1, [pc, #0xbc]
446354f4 0000d1e7 ldrb     r0, [r1, r0]
446354f8 1080bde8 pop      {r4, pc}
446354fc 10402de9 push     {r4, lr}
44635500 0140a0e1 mov      r4, r1
44635504 4a0b00eb bl       #0x44638234
44635508 a4109fe5 ldr      r1, [pc, #0xa4]
4463550c 0040c1e7 strb     r4, [r1, r0]
44635510 1080bde8 pop      {r4, pc}
44635514 70402de9 push     {r4, r5, r6, lr}
44635518 450b00eb bl       #0x44638234
4463551c 0050a0e1 mov      r5, r0
44635520 cc281fe5 ldr      r2, [pc, #-0x8cc]
44635524 7c309fe5 ldr      r3, [pc, #0x7c]
44635528 850080e0 add      r0, r0, r5, lsl #1
4463552c 2010a0e3 mov      r1, #0x20
44635530 02c9a0e3 mov      ip, #0x8000
44635534 002382e0 add      r2, r2, r0, lsl #6
44635538 0140a0e3 mov      r4, #1
4463553c 803283e0 add      r3, r3, r0, lsl #5
44635540 810082e0 add      r0, r2, r1, lsl #1
44635544 b0c0c0e1 strh     ip, [r0]
44635548 010081e2 add      r0, r1, #1
4463554c 0140c3e7 strb     r4, [r3, r1]
44635550 ff1000e2 and      r1, r0, #0xff
44635554 2b0051e3 cmp      r1, #0x2b
44635558 f8ffff9a bls      #0x44635540
4463555c 3f20a0e3 mov      r2, #0x3f
44635560 2410a0e3 mov      r1, #0x24
44635564 0500a0e1 mov      r0, r5
44635568 a5ffffeb bl       #0x44635404
4463556c 0f20a0e3 mov      r2, #0xf
44635570 2510a0e3 mov      r1, #0x25
44635574 0500a0e1 mov      r0, r5
44635578 a1ffffeb bl       #0x44635404
4463557c 0500a0e1 mov      r0, r5
44635580 7040bde8 pop      {r4, r5, r6, lr}
44635584 1f20a0e3 mov      r2, #0x1f
44635588 2610a0e3 mov      r1, #0x26
4463558c 9cffffea b        #0x44635404
44635590 2020a0e3 mov      r2, #0x20
44635594 0020c0e5 strb     r2, [r0]
44635598 2b00a0e3 mov      r0, #0x2b
4463559c 0000c1e5 strb     r0, [r1]
446355a0 1eff2fe1 bx       lr
446355a4 1d010000 andeq    r0, r0, sp, lsl r1
446355a8 e4b69844 ldrmi    fp, [r8], #0x6e4
446355ac 40420f00 andeq    r4, pc, r0, asr #4
446355b0 10270000 andeq    r2, r0, r0, lsl r7
446355b4 ac9f8e44 strmi    sb, [lr], #0xfac
446355b8 802080e0 add      r2, r0, r0, lsl #1
446355bc 00029fe5 ldr      r0, [pc, #0x200]
446355c0 0010a0e3 mov      r1, #0
446355c4 020180e0 add      r0, r0, r2, lsl #2
446355c8 b010c0e1 strh     r1, [r0]
446355cc 041080e5 str      r1, [r0, #4]
446355d0 0110a0e3 mov      r1, #1
446355d4 0810c0e5 strb     r1, [r0, #8]
446355d8 1eff2fe1 bx       lr
446355dc f05f2de9 push     {r4, r5, r6, r7, r8, sb, sl, fp, ip, lr}
446355e0 0040a0e3 mov      r4, #0
446355e4 e40400eb bl       #0x4463697c
446355e8 000050e3 cmp      r0, #0
446355ec f09fbd98 popls    {r4, r5, r6, r7, r8, sb, sl, fp, ip, pc}
446355f0 2070a0e3 mov      r7, #0x20
446355f4 cc819fe5 ldr      r8, [pc, #0x1cc]
446355f8 0190a0e3 mov      sb, #1
446355fc 10a088e2 add      sl, r8, #0x10
44635600 046088e2 add      r6, r8, #4
44635604 0050a0e3 mov      r5, #0
44635608 04b04ae2 sub      fp, sl, #4
4463560c 0400a0e1 mov      r0, r4
44635610 0470c8e7 strb     r7, [r8, r4]
44635614 310a00eb bl       #0x44637ee0
44635618 000050e3 cmp      r0, #0
4463561c 0450c617 strbne   r5, [r6, r4]
44635620 0490c607 strbeq   sb, [r6, r4]
44635624 a0019fe5 ldr      r0, [pc, #0x1a0]
44635628 0450cae7 strb     r5, [sl, r4]
4463562c 0450cbe7 strb     r5, [fp, r4]
44635630 0450c0e7 strb     r5, [r0, r4]
44635634 0400a0e1 mov      r0, r4
44635638 deffffeb bl       #0x446355b8
4463563c 8c019fe5 ldr      r0, [pc, #0x18c]
44635640 045180e7 str      r5, [r0, r4, lsl #2]
44635644 010084e2 add      r0, r4, #1
44635648 ff4000e2 and      r4, r0, #0xff
4463564c ca0400eb bl       #0x4463697c
44635650 040050e1 cmp      r0, r4
44635654 ecffff8a bhi      #0x4463560c
44635658 f09fbde8 pop      {r4, r5, r6, r7, r8, sb, sl, fp, ip, pc}
4463565c 70019fe5 ldr      r0, [pc, #0x170]
44635660 000090e5 ldr      r0, [r0]
44635664 1eff2fe1 bx       lr
44635668 64119fe5 ldr      r1, [pc, #0x164]
4463566c 000081e5 str      r0, [r1]
44635670 1eff2fe1 bx       lr
44635674 5c119fe5 ldr      r1, [pc, #0x15c]
44635678 0000d1e7 ldrb     r0, [r1, r0]
4463567c 1eff2fe1 bx       lr
44635680 4c019fe5 ldr      r0, [pc, #0x14c]
44635684 040090e5 ldr      r0, [r0, #4]
44635688 1eff2fe1 bx       lr
4463568c 40119fe5 ldr      r1, [pc, #0x140]
44635690 040081e5 str      r0, [r1, #4]
44635694 1eff2fe1 bx       lr
44635698 38119fe5 ldr      r1, [pc, #0x138]
4463569c 0010d1e7 ldrb     r1, [r1, r0]
446356a0 000051e3 cmp      r1, #0
446356a4 20119f05 ldreq    r1, [pc, #0x120]
446356a8 0000d107 ldrbeq   r0, [r1, r0]
446356ac 0000a013 movne    r0, #0
446356b0 1eff2fe1 bx       lr
446356b4 10219fe5 ldr      r2, [pc, #0x110]
446356b8 0030d2e7 ldrb     r3, [r2, r0]
446356bc 010053e1 cmp      r3, r1
446356c0 1eff2f01 bxeq     lr
446356c4 0010c2e7 strb     r1, [r2, r0]
446356c8 0100a0e3 mov      r0, #1
446356cc 00119fe5 ldr      r1, [pc, #0x100]
446356d0 040081e5 str      r0, [r1, #4]
446356d4 1eff2fe1 bx       lr
446356d8 f4009fe5 ldr      r0, [pc, #0xf4]
446356dc 080090e5 ldr      r0, [r0, #8]
446356e0 1eff2fe1 bx       lr
446356e4 e8109fe5 ldr      r1, [pc, #0xe8]
446356e8 080081e5 str      r0, [r1, #8]
446356ec 1eff2fe1 bx       lr
446356f0 e4209fe5 ldr      r2, [pc, #0xe4]
446356f4 0030d2e7 ldrb     r3, [r2, r0]
446356f8 010053e1 cmp      r3, r1
446356fc 1eff2f01 bxeq     lr
44635700 0010c2e7 strb     r1, [r2, r0]
44635704 0100a0e3 mov      r0, #1
44635708 c4109fe5 ldr      r1, [pc, #0xc4]
4463570c 080081e5 str      r0, [r1, #8]
44635710 1eff2fe1 bx       lr
44635714 bc109fe5 ldr      r1, [pc, #0xbc]
44635718 10402de9 push     {r4, lr}
4463571c 0010d1e7 ldrb     r1, [r1, r0]
44635720 10d04de2 sub      sp, sp, #0x10
44635724 0040a0e3 mov      r4, #0
44635728 0a0051e3 cmp      r1, #0xa
4463572c 01f19f37 ldrlo    pc, [pc, r1, lsl #2]
44635730 140000ea b        #0x44635788
44635734 5c576344 strbtmi  r5, [r3], #-0x75c
44635738 68576344 strbtmi  r5, [r3], #-0x768
4463573c 70576344 strbtmi  r5, [r3], #-0x770
44635740 78576344 strbtmi  r5, [r3], #-0x778
44635744 78576344 strbtmi  r5, [r3], #-0x778
44635748 80576344 strbtmi  r5, [r3], #-0x780
4463574c 78576344 strbtmi  r5, [r3], #-0x778
44635750 78576344 strbtmi  r5, [r3], #-0x778
44635754 5c576344 strbtmi  r5, [r3], #-0x75c
44635758 5c576344 strbtmi  r5, [r3], #-0x75c
4463575c 78109fe5 ldr      r1, [pc, #0x78]
44635760 0040d1e7 ldrb     r4, [r1, r0]
44635764 130000ea b        #0x446357b8
44635768 6940a0e3 mov      r4, #0x69
4463576c 110000ea b        #0x446357b8
44635770 6e40a0e3 mov      r4, #0x6e
44635774 0f0000ea b        #0x446357b8
44635778 7240a0e3 mov      r4, #0x72
4463577c 0d0000ea b        #0x446357b8
44635780 7740a0e3 mov      r4, #0x77
44635784 0b0000ea b        #0x446357b8
44635788 acbdffeb bl       #0x44624e40
4463578c 000050e3 cmp      r0, #0
44635790 0800000a beq      #0x446357b8
44635794 44209fe5 ldr      r2, [pc, #0x44]
44635798 44108fe2 add      r1, pc, #0x44
4463579c 40008fe2 add      r0, pc, #0x40
446357a0 07008de8 stm      sp, {r0, r1, r2}
446357a4 0030a0e3 mov      r3, #0
446357a8 0320a0e1 mov      r2, r3
446357ac 30108fe2 add      r1, pc, #0x30
446357b0 30008fe2 add      r0, pc, #0x30
446357b4 6aa005eb bl       #0x4479d964
446357b8 0400a0e1 mov      r0, r4
446357bc 10d08de2 add      sp, sp, #0x10
446357c0 1080bde8 pop      {r4, pc}
446357c4 64b89844 ldrmi    fp, [r8], #0x864
446357c8 c49f8e44 strmi    sb, [lr], #0xfc4
446357cc cc9f8e44 strmi    sb, [lr], #0xfcc
446357d0 94b89844 ldrmi    fp, [r8], #0x894
446357d4 b09f8e44 strmi    sb, [lr], #0xfb0
446357d8 c89f8e44 strmi    sb, [lr], #0xfc8
446357dc d09f8e44 strmi    sb, [lr], #0xfd0
446357e0 52010000 andeq    r0, r0, r2, asr r1
446357e4 00000000 andeq    r0, r0, r0
446357e8 30000000 andeq    r0, r0, r0, lsr r0
446357ec 20001fe5 ldr      r0, [pc, #-0x20]
446357f0 0c0090e5 ldr      r0, [r0, #0xc]
446357f4 1eff2fe1 bx       lr
446357f8 f0412de9 push     {r4, r5, r6, r7, r8, lr}
446357fc 0060b0e1 movs     r6, r0
44635800 1300001a bne      #0x44635854
44635804 0040a0e3 mov      r4, #0
44635808 5b0400eb bl       #0x4463697c
4463580c 000050e3 cmp      r0, #0
44635810 0f00009a bls      #0x44635854
44635814 18749fe5 ldr      r7, [pc, #0x418]
44635818 5c801fe5 ldr      r8, [pc, #-0x5c]
4463581c 0050a0e3 mov      r5, #0
44635820 0400a0e1 mov      r0, r4
44635824 9f0900eb bl       #0x44637ea8
44635828 0000d7e7 ldrb     r0, [r7, r0]
4463582c 000050e3 cmp      r0, #0
44635830 0200001a bne      #0x44635840
44635834 840084e0 add      r0, r4, r4, lsl #1
44635838 000188e0 add      r0, r8, r0, lsl #2
4463583c 045080e5 str      r5, [r0, #4]
44635840 010084e2 add      r0, r4, #1
44635844 ff4000e2 and      r4, r0, #0xff
44635848 4b0400eb bl       #0x4463697c
4463584c 040050e1 cmp      r0, r4
44635850 f2ffff8a bhi      #0x44635820
44635854 88001fe5 ldr      r0, [pc, #-0x88]
44635858 0c6080e5 str      r6, [r0, #0xc]
4463585c f081bde8 pop      {r4, r5, r6, r7, r8, pc}
44635860 a4201fe5 ldr      r2, [pc, #-0xa4]
44635864 800080e0 add      r0, r0, r0, lsl #1
44635868 000182e0 add      r0, r2, r0, lsl #2
4463586c 0c0090e8 ldm      r0, {r2, r3}
44635870 080090e5 ldr      r0, [r0, #8]
44635874 080081e5 str      r0, [r1, #8]
44635878 0c0081e8 stm      r1, {r2, r3}
4463587c 1eff2fe1 bx       lr
44635880 0010a0e1 mov      r1, r0
44635884 1300a0e3 mov      r0, #0x13
44635888 fb87ffea b        #0x4461787c
4463588c d0101fe5 ldr      r1, [pc, #-0xd0]
44635890 800080e0 add      r0, r0, r0, lsl #1
44635894 000181e0 add      r0, r1, r0, lsl #2
44635898 b000d0e1 ldrh     r0, [r0]
4463589c 1eff2fe1 bx       lr
446358a0 802080e0 add      r2, r0, r0, lsl #1
446358a4 e8001fe5 ldr      r0, [pc, #-0xe8]
446358a8 020180e0 add      r0, r0, r2, lsl #2
446358ac b020d0e1 ldrh     r2, [r0]
446358b0 010052e1 cmp      r2, r1
446358b4 1eff2f01 bxeq     lr
446358b8 b010c0e1 strh     r1, [r0]
446358bc 0100a0e3 mov      r0, #1
446358c0 f4101fe5 ldr      r1, [pc, #-0xf4]
446358c4 0c0081e5 str      r0, [r1, #0xc]
446358c8 1eff2fe1 bx       lr
446358cc 10111fe5 ldr      r1, [pc, #-0x110]
446358d0 800080e0 add      r0, r0, r0, lsl #1
446358d4 000181e0 add      r0, r1, r0, lsl #2
446358d8 040090e5 ldr      r0, [r0, #4]
446358dc 1eff2fe1 bx       lr
446358e0 802080e0 add      r2, r0, r0, lsl #1
446358e4 28011fe5 ldr      r0, [pc, #-0x128]
446358e8 020180e0 add      r0, r0, r2, lsl #2
446358ec 042090e5 ldr      r2, [r0, #4]
446358f0 010052e1 cmp      r2, r1
446358f4 1eff2f01 bxeq     lr
446358f8 041080e5 str      r1, [r0, #4]
446358fc 0100a0e3 mov      r0, #1
44635900 34111fe5 ldr      r1, [pc, #-0x134]
44635904 0c0081e5 str      r0, [r1, #0xc]
44635908 1eff2fe1 bx       lr
4463590c 50111fe5 ldr      r1, [pc, #-0x150]
44635910 800080e0 add      r0, r0, r0, lsl #1
44635914 000181e0 add      r0, r1, r0, lsl #2
44635918 0800d0e5 ldrb     r0, [r0, #8]
4463591c 1eff2fe1 bx       lr
44635920 802080e0 add      r2, r0, r0, lsl #1
44635924 68011fe5 ldr      r0, [pc, #-0x168]
44635928 020180e0 add      r0, r0, r2, lsl #2
4463592c 0820d0e5 ldrb     r2, [r0, #8]
44635930 010052e1 cmp      r2, r1
44635934 0810c015 strbne   r1, [r0, #8]
44635938 1eff2fe1 bx       lr
4463593c 70011fe5 ldr      r0, [pc, #-0x170]
44635940 100090e5 ldr      r0, [r0, #0x10]
44635944 1eff2fe1 bx       lr
44635948 7c111fe5 ldr      r1, [pc, #-0x17c]
4463594c 100081e5 str      r0, [r1, #0x10]
44635950 1eff2fe1 bx       lr
44635954 e9fdffea b        #0x44635100
44635958 7ffeffea b        #0x4463535c
4463595c 30402de9 push     {r4, r5, lr}
44635960 0050a0e1 mov      r5, r0
44635964 1cd04de2 sub      sp, sp, #0x1c
44635968 0000a0e3 mov      r0, #0
4463596c 00008de5 str      r0, [sp]
44635970 04008de5 str      r0, [sp, #4]
44635974 08008de5 str      r0, [sp, #8]
44635978 0c008de5 str      r0, [sp, #0xc]
4463597c 10008de5 str      r0, [sp, #0x10]
44635980 14008de5 str      r0, [sp, #0x14]
44635984 18008de5 str      r0, [sp, #0x18]
44635988 b8011fe5 ldr      r0, [pc, #-0x1b8]
4463598c 0140a0e1 mov      r4, r1
44635990 0500d0e7 ldrb     r0, [r0, r5]
44635994 000050e3 cmp      r0, #0
44635998 0500000a beq      #0x446359b4
4463599c 1a20a0e3 mov      r2, #0x1a
446359a0 0d10a0e1 mov      r1, sp
446359a4 0400a0e1 mov      r0, r4
446359a8 19a207eb bl       #0x4481e214
446359ac 1cd08de2 add      sp, sp, #0x1c
446359b0 3080bde8 pop      {r4, r5, pc}
446359b4 0100a0e3 mov      r0, #1
446359b8 0000c4e5 strb     r0, [r4]
446359bc 2e10a0e3 mov      r1, #0x2e
446359c0 0500a0e1 mov      r0, r5
446359c4 e2ffffeb bl       #0x44635954
446359c8 0100c4e5 strb     r0, [r4, #1]
446359cc 2f10a0e3 mov      r1, #0x2f
446359d0 0500a0e1 mov      r0, r5
446359d4 deffffeb bl       #0x44635954
446359d8 0200c4e5 strb     r0, [r4, #2]
446359dc 2710a0e3 mov      r1, #0x27
446359e0 0500a0e1 mov      r0, r5
446359e4 daffffeb bl       #0x44635954
446359e8 0300c4e5 strb     r0, [r4, #3]
446359ec 2810a0e3 mov      r1, #0x28
446359f0 0500a0e1 mov      r0, r5
446359f4 d6ffffeb bl       #0x44635954
446359f8 0400c4e5 strb     r0, [r4, #4]
446359fc 2910a0e3 mov      r1, #0x29
44635a00 0500a0e1 mov      r0, r5
44635a04 d2ffffeb bl       #0x44635954
44635a08 0500c4e5 strb     r0, [r4, #5]
44635a0c 0930a0e3 mov      r3, #9
44635a10 062084e2 add      r2, r4, #6
44635a14 0110a0e3 mov      r1, #1
44635a18 0500a0e1 mov      r0, r5
44635a1c cdffffeb bl       #0x44635958
44635a20 0930a0e3 mov      r3, #9
44635a24 0f2084e2 add      r2, r4, #0xf
44635a28 0210a0e3 mov      r1, #2
44635a2c 0500a0e1 mov      r0, r5
44635a30 c8ffffeb bl       #0x44635958
44635a34 2b10a0e3 mov      r1, #0x2b
44635a38 0500a0e1 mov      r0, r5
44635a3c c4ffffeb bl       #0x44635954
44635a40 b801c4e1 strh     r0, [r4, #0x18]
44635a44 1cd08de2 add      sp, sp, #0x1c
44635a48 3080bde8 pop      {r4, r5, pc}
44635a4c 8c121fe5 ldr      r1, [pc, #-0x28c]
44635a50 0000d1e7 ldrb     r0, [r1, r0]
44635a54 1eff2fe1 bx       lr
44635a58 10402de9 push     {r4, lr}
44635a5c 240051e3 cmp      r1, #0x24
44635a60 10d04de2 sub      sp, sp, #0x10
44635a64 0040a0e1 mov      r4, r0
44635a68 0c00003a blo      #0x44635aa0
44635a6c f3bcffeb bl       #0x44624e40
44635a70 000050e3 cmp      r0, #0
44635a74 0800000a beq      #0x44635a9c
44635a78 b8219fe5 ldr      r2, [pc, #0x1b8]
44635a7c 2a1e4fe2 sub      r1, pc, #0x2a0
44635a80 a90f4fe2 sub      r0, pc, #0x2a4
44635a84 07008de8 stm      sp, {r0, r1, r2}
44635a88 0030a0e3 mov      r3, #0
44635a8c 0320a0e1 mov      r2, r3
44635a90 ad1f4fe2 sub      r1, pc, #0x2b4
44635a94 ad0f4fe2 sub      r0, pc, #0x2b4
44635a98 b19f05eb bl       #0x4479d964
44635a9c 1f10a0e3 mov      r1, #0x1f
44635aa0 e0021fe5 ldr      r0, [pc, #-0x2e0]
44635aa4 0420d0e7 ldrb     r2, [r0, r4]
44635aa8 200052e3 cmp      r2, #0x20
44635aac 10d08d32 addlo    sp, sp, #0x10
44635ab0 1080bd38 poplo    {r4, pc}
44635ab4 0410c0e7 strb     r1, [r0, r4]
44635ab8 e8221fe5 ldr      r2, [pc, #-0x2e8]
44635abc 78019fe5 ldr      r0, [pc, #0x178]
44635ac0 0430d2e7 ldrb     r3, [r2, r4]
44635ac4 8100d0e7 ldrb     r0, [r0, r1, lsl #1]
44635ac8 000053e1 cmp      r3, r0
44635acc 10d08d02 addeq    sp, sp, #0x10
44635ad0 1080bd08 popeq    {r4, pc}
44635ad4 0400c2e7 strb     r0, [r2, r4]
44635ad8 0c131fe5 ldr      r1, [pc, #-0x30c]
44635adc 0100a0e3 mov      r0, #1
44635ae0 000081e5 str      r0, [r1]
44635ae4 040081e5 str      r0, [r1, #4]
44635ae8 080081e5 str      r0, [r1, #8]
44635aec 10d08de2 add      sp, sp, #0x10
44635af0 1080bde8 pop      {r4, pc}
44635af4 70402de9 push     {r4, r5, r6, lr}
44635af8 0040a0e3 mov      r4, #0
44635afc 9e0300eb bl       #0x4463697c
44635b00 000050e3 cmp      r0, #0
44635b04 44631f85 ldrhi    r6, [pc, #-0x344]
44635b08 2050a083 movhi    r5, #0x20
44635b0c 7080bd98 popls    {r4, r5, r6, pc}
44635b10 010084e2 add      r0, r4, #1
44635b14 0450c6e7 strb     r5, [r6, r4]
44635b18 ff4000e2 and      r4, r0, #0xff
44635b1c 960300eb bl       #0x4463697c
44635b20 040050e1 cmp      r0, r4
44635b24 f9ffff8a bhi      #0x44635b10
44635b28 7080bde8 pop      {r4, r5, r6, pc}
44635b2c 10402de9 push     {r4, lr}
44635b30 240050e3 cmp      r0, #0x24
44635b34 10d04de2 sub      sp, sp, #0x10
44635b38 0040a0e1 mov      r4, r0
44635b3c 0b00003a blo      #0x44635b70
44635b40 bebcffeb bl       #0x44624e40
44635b44 000050e3 cmp      r0, #0
44635b48 0800000a beq      #0x44635b70
44635b4c ec209fe5 ldr      r2, [pc, #0xec]
44635b50 dd1f4fe2 sub      r1, pc, #0x374
44635b54 de0f4fe2 sub      r0, pc, #0x378
44635b58 07008de8 stm      sp, {r0, r1, r2}
44635b5c 0030a0e3 mov      r3, #0
44635b60 0320a0e1 mov      r2, r3
44635b64 e21f4fe2 sub      r1, pc, #0x388
44635b68 e20f4fe2 sub      r0, pc, #0x388
44635b6c 7c9f05eb bl       #0x4479d964
44635b70 c4009fe5 ldr      r0, [pc, #0xc4]
44635b74 840080e0 add      r0, r0, r4, lsl #1
44635b78 0100d0e5 ldrb     r0, [r0, #1]
44635b7c 10d08de2 add      sp, sp, #0x10
44635b80 1080bde8 pop      {r4, pc}
44635b84 1efeffea b        #0x44635404
44635b88 10402de9 push     {r4, lr}
44635b8c 020050e3 cmp      r0, #2
44635b90 10d04de2 sub      sp, sp, #0x10
44635b94 0040a0e1 mov      r4, r0
44635b98 0b00009a bls      #0x44635bcc
44635b9c a7bcffeb bl       #0x44624e40
44635ba0 000050e3 cmp      r0, #0
44635ba4 0800000a beq      #0x44635bcc
44635ba8 94209fe5 ldr      r2, [pc, #0x94]
44635bac 3d1e4fe2 sub      r1, pc, #0x3d0
44635bb0 f50f4fe2 sub      r0, pc, #0x3d4
44635bb4 07008de8 stm      sp, {r0, r1, r2}
44635bb8 0030a0e3 mov      r3, #0
44635bbc 0320a0e1 mov      r2, r3
44635bc0 f91f4fe2 sub      r1, pc, #0x3e4
44635bc4 f90f4fe2 sub      r0, pc, #0x3e4
44635bc8 659f05eb bl       #0x4479d964
44635bcc 60009fe5 ldr      r0, [pc, #0x60]
44635bd0 0400d0e7 ldrb     r0, [r0, r4]
44635bd4 10d08de2 add      sp, sp, #0x10
44635bd8 1080bde8 pop      {r4, pc}
44635bdc 30402de9 push     {r4, r5, lr}
44635be0 020050e3 cmp      r0, #2
44635be4 0cd04de2 sub      sp, sp, #0xc
44635be8 0040a0e1 mov      r4, r0
44635bec 0150a0e1 mov      r5, r1
44635bf0 0b00009a bls      #0x44635c24
44635bf4 91bcffeb bl       #0x44624e40
44635bf8 000050e3 cmp      r0, #0
44635bfc 0800000a beq      #0x44635c24
44635c00 40309fe5 ldr      r3, [pc, #0x40]
44635c04 40208fe2 add      r2, pc, #0x40
44635c08 3c008fe2 add      r0, pc, #0x3c
44635c0c 0d008de8 stm      sp, {r0, r2, r3}
44635c10 0030a0e3 mov      r3, #0
44635c14 0320a0e1 mov      r2, r3
44635c18 2c108fe2 add      r1, pc, #0x2c
44635c1c 2c008fe2 add      r0, pc, #0x2c
44635c20 4f9f05eb bl       #0x4479d964
44635c24 08009fe5 ldr      r0, [pc, #8]
44635c28 0450c0e7 strb     r5, [r0, r4]
44635c2c 0cd08de2 add      sp, sp, #0xc
44635c30 3080bde8 pop      {r4, r5, pc}
44635c34 d49f8e44 strmi    sb, [lr], #0xfd4
44635c38 76020000 andeq    r0, r0, r6, ror r2
44635c3c cec88344 strmi    ip, [r3], #0x8ce
44635c40 ab020000 andeq    r0, r0, fp, lsr #5
44635c44 ed020000 andeq    r0, r0, sp, ror #5
44635c48 ff020000 strdeq   r0, r1, [r0], -pc
44635c4c 00000000 andeq    r0, r0, r0
44635c50 30000000 andeq    r0, r0, r0, lsr r0
44635c54 70402de9 push     {r4, r5, r6, lr}
44635c58 0160a0e3 mov      r6, #1
44635c5c 0040a0e3 mov      r4, #0
44635c60 410300eb bl       #0x4463696c
44635c64 000050e3 cmp      r0, #0
44635c68 3c501f85 ldrhi    r5, [pc, #-0x3c]
44635c6c 0700009a bls      #0x44635c90
44635c70 0400d5e7 ldrb     r0, [r5, r4]
44635c74 010050e3 cmp      r0, #1
44635c78 0600000a beq      #0x44635c98
44635c7c 010084e2 add      r0, r4, #1
44635c80 ff4000e2 and      r4, r0, #0xff
44635c84 380300eb bl       #0x4463696c
44635c88 040050e1 cmp      r0, r4
44635c8c f7ffff8a bhi      #0x44635c70
44635c90 0600a0e1 mov      r0, r6
44635c94 7080bde8 pop      {r4, r5, r6, pc}
44635c98 0060a0e3 mov      r6, #0
44635c9c fbffffea b        #0x44635c90
44635ca0 70402de9 push     {r4, r5, r6, lr}
44635ca4 0050a0e1 mov      r5, r0
44635ca8 0040a0e3 mov      r4, #0
44635cac 320300eb bl       #0x4463697c
44635cb0 000050e3 cmp      r0, #0
44635cb4 ec641f85 ldrhi    r6, [pc, #-0x4ec]
44635cb8 7080bd98 popls    {r4, r5, r6, pc}
44635cbc 040196e7 ldr      r0, [r6, r4, lsl #2]
44635cc0 040185e7 str      r0, [r5, r4, lsl #2]
44635cc4 010084e2 add      r0, r4, #1
44635cc8 ff4000e2 and      r4, r0, #0xff
44635ccc 2a0300eb bl       #0x4463697c
44635cd0 040050e1 cmp      r0, r4
44635cd4 f8ffff8a bhi      #0x44635cbc
44635cd8 7080bde8 pop      {r4, r5, r6, pc}
44635cdc 70402de9 push     {r4, r5, r6, lr}
44635ce0 0050a0e1 mov      r5, r0
44635ce4 0040a0e3 mov      r4, #0
44635ce8 230300eb bl       #0x4463697c
44635cec 000050e3 cmp      r0, #0
44635cf0 28651f85 ldrhi    r6, [pc, #-0x528]
44635cf4 7080bd98 popls    {r4, r5, r6, pc}
44635cf8 040195e7 ldr      r0, [r5, r4, lsl #2]
44635cfc 040186e7 str      r0, [r6, r4, lsl #2]
44635d00 010084e2 add      r0, r4, #1
44635d04 ff4000e2 and      r4, r0, #0xff
44635d08 1b0300eb bl       #0x4463697c
44635d0c 040050e1 cmp      r0, r4
44635d10 f8ffff8a bhi      #0x44635cf8
44635d14 7080bde8 pop      {r4, r5, r6, pc}
44635d18 0100a0e3 mov      r0, #1
44635d1c 1eff2fe1 bx       lr
44635d20 10402de9 push     {r4, lr}
44635d24 000050e3 cmp      r0, #0
44635d28 0010a0e3 mov      r1, #0
44635d2c 0200000a beq      #0x44635d3c
44635d30 010050e3 cmp      r0, #1
44635d34 0700001a bne      #0x44635d58
44635d38 030000ea b        #0x44635d4c
44635d3c 0100a0e3 mov      r0, #1
44635d40 240704eb bl       #0x447379d8
44635d44 0010a0e1 mov      r1, r0
44635d48 020000ea b        #0x44635d58
44635d4c 0000a0e3 mov      r0, #0
44635d50 200704eb bl       #0x447379d8
44635d54 0010a0e1 mov      r1, r0
44635d58 0100a0e1 mov      r0, r1
44635d5c 1080bde8 pop      {r4, pc}
44635d60 70402de9 push     {r4, r5, r6, lr}
44635d64 0040a0e3 mov      r4, #0
44635d68 0400a0e1 mov      r0, r4
44635d6c ebffffeb bl       #0x44635d20
44635d70 0050a0e1 mov      r5, r0
44635d74 0100a0e3 mov      r0, #1
44635d78 e8ffffeb bl       #0x44635d20
44635d7c 010055e3 cmp      r5, #1
44635d80 01005013 cmpne    r0, #1
44635d84 0140a003 moveq    r4, #1
44635d88 0400a0e1 mov      r0, r4
44635d8c 7080bde8 pop      {r4, r5, r6, pc}
44635d90 10402de9 push     {r4, lr}
44635d94 000050e3 cmp      r0, #0
44635d98 10d04de2 sub      sp, sp, #0x10
44635d9c 0040a0e3 mov      r4, #0
44635da0 1000000a beq      #0x44635de8
44635da4 010050e3 cmp      r0, #1
44635da8 1200000a beq      #0x44635df8
44635dac 23bcffeb bl       #0x44624e40
44635db0 000050e3 cmp      r0, #0
44635db4 0800000a beq      #0x44635ddc
44635db8 7720a0e3 mov      r2, #0x77
44635dbc 44108fe2 add      r1, pc, #0x44
44635dc0 40008fe2 add      r0, pc, #0x40
44635dc4 07008de8 stm      sp, {r0, r1, r2}
44635dc8 0030a0e3 mov      r3, #0
44635dcc 0320a0e1 mov      r2, r3
44635dd0 30108fe2 add      r1, pc, #0x30
44635dd4 30008fe2 add      r0, pc, #0x30
44635dd8 e19e05eb bl       #0x4479d964
44635ddc 0400a0e1 mov      r0, r4
44635de0 10d08de2 add      sp, sp, #0x10
44635de4 1080bde8 pop      {r4, pc}
44635de8 0100a0e3 mov      r0, #1
44635dec f90604eb bl       #0x447379d8
44635df0 0040a0e1 mov      r4, r0
44635df4 f8ffffea b        #0x44635ddc
44635df8 0200a0e3 mov      r0, #2
44635dfc f50604eb bl       #0x447379d8
44635e00 0040a0e1 mov      r4, r0
44635e04 f4ffffea b        #0x44635ddc
44635e08 00000000 andeq    r0, r0, r0
44635e0c 30000000 andeq    r0, r0, r0, lsr r0
44635e10 2c109fe5 ldr      r1, [pc, #0x2c]
44635e14 04e02de5 str      lr, [sp, #-4]!
44635e18 0c0091e8 ldm      r1, {r2, r3}
44635e1c 081091e5 ldr      r1, [r1, #8]
44635e20 0cd04de2 sub      sp, sp, #0xc
44635e24 f020cde1 strd     r2, r3, [sp]
44635e28 08108de5 str      r1, [sp, #8]
44635e2c 0000dde7 ldrb     r0, [sp, r0]
44635e30 e80604eb bl       #0x447379d8
44635e34 0cd08de2 add      sp, sp, #0xc
44635e38 04f09de4 pop      {pc}
44635e3c 0000a0e3 mov      r0, #0
44635e40 1eff2fe1 bx       lr
44635e44 18c98344 strmi    ip, [r3], #0x918
44635e48 10402de9 push     {r4, lr}
44635e4c 0a0050e3 cmp      r0, #0xa
44635e50 10d04de2 sub      sp, sp, #0x10
44635e54 0040a0e1 mov      r4, r0
44635e58 0b00003a blo      #0x44635e8c
44635e5c f7bbffeb bl       #0x44624e40
44635e60 000050e3 cmp      r0, #0
44635e64 0800000a beq      #0x44635e8c
44635e68 7120a0e3 mov      r2, #0x71
44635e6c 28108fe2 add      r1, pc, #0x28
44635e70 24008fe2 add      r0, pc, #0x24
44635e74 07008de8 stm      sp, {r0, r1, r2}
44635e78 0030a0e3 mov      r3, #0
44635e7c 0320a0e1 mov      r2, r3
44635e80 14108fe2 add      r1, pc, #0x14
44635e84 14008fe2 add      r0, pc, #0x14
44635e88 b59e05eb bl       #0x4479d964
44635e8c 10009fe5 ldr      r0, [pc, #0x10]
44635e90 040290e7 ldr      r0, [r0, r4, lsl #4]
44635e94 10d08de2 add      sp, sp, #0x10
44635e98 1080bde8 pop      {r4, pc}
44635e9c 00000000 andeq    r0, r0, r0
44635ea0 30000000 andeq    r0, r0, r0, lsr r0
44635ea4 dc9f8e44 strmi    sb, [lr], #0xfdc
44635ea8 10402de9 push     {r4, lr}
44635eac 0a0050e3 cmp      r0, #0xa
44635eb0 10d04de2 sub      sp, sp, #0x10
44635eb4 0040a0e1 mov      r4, r0
44635eb8 0b00003a blo      #0x44635eec
44635ebc dfbbffeb bl       #0x44624e40
44635ec0 000050e3 cmp      r0, #0
44635ec4 0800000a beq      #0x44635eec
44635ec8 8220a0e3 mov      r2, #0x82
44635ecc 38104fe2 sub      r1, pc, #0x38
44635ed0 3c004fe2 sub      r0, pc, #0x3c
44635ed4 07008de8 stm      sp, {r0, r1, r2}
44635ed8 0030a0e3 mov      r3, #0
44635edc 0320a0e1 mov      r2, r3
44635ee0 4c104fe2 sub      r1, pc, #0x4c
44635ee4 4c004fe2 sub      r0, pc, #0x4c
44635ee8 9d9e05eb bl       #0x4479d964
44635eec 50001fe5 ldr      r0, [pc, #-0x50]
44635ef0 040280e0 add      r0, r0, r4, lsl #4
44635ef4 040090e5 ldr      r0, [r0, #4]
44635ef8 10d08de2 add      sp, sp, #0x10
44635efc 1080bde8 pop      {r4, pc}
44635f00 74109fe5 ldr      r1, [pc, #0x74]
44635f04 04402de5 str      r4, [sp, #-4]!
44635f08 1c1091e8 ldm      r1, {r2, r3, r4, ip}
44635f0c 2cd04de2 sub      sp, sp, #0x2c
44635f10 1c108de8 stm      sp, {r2, r3, r4, ip}
44635f14 102081e2 add      r2, r1, #0x10
44635f18 1c1092e8 ldm      r2, {r2, r3, r4, ip}
44635f1c f021cde1 strd     r2, r3, [sp, #0x10]
44635f20 18208de2 add      r2, sp, #0x18
44635f24 101082e8 stm      r2, {r4, ip}
44635f28 242091e5 ldr      r2, [r1, #0x24]
44635f2c 201091e5 ldr      r1, [r1, #0x20]
44635f30 0a0050e3 cmp      r0, #0xa
44635f34 20108de5 str      r1, [sp, #0x20]
44635f38 0010a0e3 mov      r1, #0
44635f3c 24208de5 str      r2, [sp, #0x24]
44635f40 00119d37 ldrlo    r1, [sp, r0, lsl #2]
44635f44 2cd08de2 add      sp, sp, #0x2c
44635f48 04409de4 pop      {r4}
44635f4c 0100a0e1 mov      r0, r1
44635f50 1eff2fe1 bx       lr
44635f54 24108fe2 add      r1, pc, #0x24
44635f58 001091e5 ldr      r1, [r1]
44635f5c 04d04de2 sub      sp, sp, #4
44635f60 00108de5 str      r1, [sp]
44635f64 020050e3 cmp      r0, #2
44635f68 0010a0e3 mov      r1, #0
44635f6c 0010dd37 ldrblo   r1, [sp, r0]
44635f70 04d08de2 add      sp, sp, #4
44635f74 0100a0e1 mov      r0, r1
44635f78 1eff2fe1 bx       lr
44635f7c 24c98344 strmi    ip, [r3], #0x924
44635f80 01020000 andeq    r0, r0, r1, lsl #4
44635f84 28139fe5 ldr      r1, [pc, #0x328]
44635f88 000081e5 str      r0, [r1]
44635f8c 1eff2fe1 bx       lr
44635f90 30402de9 push     {r4, r5, lr}
44635f94 0a0050e3 cmp      r0, #0xa
44635f98 0cd04de2 sub      sp, sp, #0xc
44635f9c 0040a0e1 mov      r4, r0
44635fa0 0150a0e1 mov      r5, r1
44635fa4 0b00003a blo      #0x44635fd8
44635fa8 a4bbffeb bl       #0x44624e40
44635fac 000050e3 cmp      r0, #0
44635fb0 0800000a beq      #0x44635fd8
44635fb4 db30a0e3 mov      r3, #0xdb
44635fb8 492f4fe2 sub      r2, pc, #0x124
44635fbc 4a0f4fe2 sub      r0, pc, #0x128
44635fc0 0d008de8 stm      sp, {r0, r2, r3}
44635fc4 0030a0e3 mov      r3, #0
44635fc8 0320a0e1 mov      r2, r3
44635fcc 4e1f4fe2 sub      r1, pc, #0x138
44635fd0 4e0f4fe2 sub      r0, pc, #0x138
44635fd4 629e05eb bl       #0x4479d964
44635fd8 3c011fe5 ldr      r0, [pc, #-0x13c]
44635fdc 040280e0 add      r0, r0, r4, lsl #4
44635fe0 085080e5 str      r5, [r0, #8]
44635fe4 0cd08de2 add      sp, sp, #0xc
44635fe8 3080bde8 pop      {r4, r5, pc}
44635fec 30402de9 push     {r4, r5, lr}
44635ff0 0a0050e3 cmp      r0, #0xa
44635ff4 0cd04de2 sub      sp, sp, #0xc
44635ff8 0040a0e1 mov      r4, r0
44635ffc 0150a0e1 mov      r5, r1
44636000 0b00003a blo      #0x44636034
44636004 8dbbffeb bl       #0x44624e40
44636008 000050e3 cmp      r0, #0
4463600c 0800000a beq      #0x44636034
44636010 ed30a0e3 mov      r3, #0xed
44636014 062d4fe2 sub      r2, pc, #0x180
44636018 610f4fe2 sub      r0, pc, #0x184
4463601c 0d008de8 stm      sp, {r0, r2, r3}
44636020 0030a0e3 mov      r3, #0
44636024 0320a0e1 mov      r2, r3
44636028 651f4fe2 sub      r1, pc, #0x194
4463602c 650f4fe2 sub      r0, pc, #0x194
44636030 4b9e05eb bl       #0x4479d964
44636034 98011fe5 ldr      r0, [pc, #-0x198]
44636038 040280e0 add      r0, r0, r4, lsl #4
4463603c 0c5080e5 str      r5, [r0, #0xc]
44636040 0cd08de2 add      sp, sp, #0xc
44636044 3080bde8 pop      {r4, r5, pc}
44636048 64029fe5 ldr      r0, [pc, #0x264]
4463604c 000090e5 ldr      r0, [r0]
44636050 1eff2fe1 bx       lr
44636054 10402de9 push     {r4, lr}
44636058 0a0050e3 cmp      r0, #0xa
4463605c 10d04de2 sub      sp, sp, #0x10
44636060 0040a0e1 mov      r4, r0
44636064 0b00003a blo      #0x44636098
44636068 74bbffeb bl       #0x44624e40
4463606c 000050e3 cmp      r0, #0
44636070 0800000a beq      #0x44636098
44636074 3c229fe5 ldr      r2, [pc, #0x23c]
44636078 791f4fe2 sub      r1, pc, #0x1e4
4463607c 7a0f4fe2 sub      r0, pc, #0x1e8
44636080 07008de8 stm      sp, {r0, r1, r2}
44636084 0030a0e3 mov      r3, #0
44636088 0320a0e1 mov      r2, r3
4463608c 7e1f4fe2 sub      r1, pc, #0x1f8
44636090 7e0f4fe2 sub      r0, pc, #0x1f8
44636094 329e05eb bl       #0x4479d964
44636098 fc011fe5 ldr      r0, [pc, #-0x1fc]
4463609c 040280e0 add      r0, r0, r4, lsl #4
446360a0 080090e5 ldr      r0, [r0, #8]
446360a4 10d08de2 add      sp, sp, #0x10
446360a8 1080bde8 pop      {r4, pc}
446360ac 10402de9 push     {r4, lr}
446360b0 0a0050e3 cmp      r0, #0xa
446360b4 10d04de2 sub      sp, sp, #0x10
446360b8 0040a0e1 mov      r4, r0
446360bc 0b00003a blo      #0x446360f0
446360c0 5ebbffeb bl       #0x44624e40
446360c4 000050e3 cmp      r0, #0
446360c8 0800000a beq      #0x446360f0
446360cc e8219fe5 ldr      r2, [pc, #0x1e8]
446360d0 8f1f4fe2 sub      r1, pc, #0x23c
446360d4 090d4fe2 sub      r0, pc, #0x240
446360d8 07008de8 stm      sp, {r0, r1, r2}
446360dc 0030a0e3 mov      r3, #0
446360e0 0320a0e1 mov      r2, r3
446360e4 251e4fe2 sub      r1, pc, #0x250
446360e8 250e4fe2 sub      r0, pc, #0x250
446360ec 1c9e05eb bl       #0x4479d964
446360f0 54021fe5 ldr      r0, [pc, #-0x254]
446360f4 040280e0 add      r0, r0, r4, lsl #4
446360f8 0c0090e5 ldr      r0, [r0, #0xc]
446360fc 10d08de2 add      sp, sp, #0x10
44636100 1080bde8 pop      {r4, pc}
44636104 10402de9 push     {r4, lr}
44636108 10d04de2 sub      sp, sp, #0x10
4463610c 7bffffeb bl       #0x44635f00
44636110 a8119fe5 ldr      r1, [pc, #0x1a8]
44636114 200050e3 cmp      r0, #0x20
44636118 0040a0e3 mov      r4, #0
4463611c 19408102 addeq    r4, r1, #0x19
44636120 2a00000a beq      #0x446361d0
44636124 110000ca bgt      #0x44636170
44636128 040050e3 cmp      r0, #4
4463612c 0a408102 addeq    r4, r1, #0xa
44636130 2600000a beq      #0x446361d0
44636134 060000ca bgt      #0x44636154
44636138 010050e3 cmp      r0, #1
4463613c 7c419f05 ldreq    r4, [pc, #0x17c]
44636140 2200000a beq      #0x446361d0
44636144 020050e3 cmp      r0, #2
44636148 05408102 addeq    r4, r1, #5
4463614c 1f00000a beq      #0x446361d0
44636150 120000ea b        #0x446361a0
44636154 080050e3 cmp      r0, #8
44636158 0f408102 addeq    r4, r1, #0xf
4463615c 1b00000a beq      #0x446361d0
44636160 100050e3 cmp      r0, #0x10
44636164 14408102 addeq    r4, r1, #0x14
44636168 1800000a beq      #0x446361d0
4463616c 0b0000ea b        #0x446361a0
44636170 400050e3 cmp      r0, #0x40
44636174 1e408102 addeq    r4, r1, #0x1e
44636178 1400000a beq      #0x446361d0
4463617c 800050e3 cmp      r0, #0x80
44636180 23408102 addeq    r4, r1, #0x23
44636184 1100000a beq      #0x446361d0
44636188 010c50e3 cmp      r0, #0x100
4463618c 28408102 addeq    r4, r1, #0x28
44636190 0e00000a beq      #0x446361d0
44636194 020c50e3 cmp      r0, #0x200
44636198 2d408102 addeq    r4, r1, #0x2d
4463619c 0b00000a beq      #0x446361d0
446361a0 26bbffeb bl       #0x44624e40
446361a4 000050e3 cmp      r0, #0
446361a8 0800000a beq      #0x446361d0
446361ac 10219fe5 ldr      r2, [pc, #0x110]
446361b0 c71f4fe2 sub      r1, pc, #0x31c
446361b4 320e4fe2 sub      r0, pc, #0x320
446361b8 07008de8 stm      sp, {r0, r1, r2}
446361bc 0030a0e3 mov      r3, #0
446361c0 0320a0e1 mov      r2, r3
446361c4 331e4fe2 sub      r1, pc, #0x330
446361c8 330e4fe2 sub      r0, pc, #0x330
446361cc e49d05eb bl       #0x4479d964
446361d0 0400a0e1 mov      r0, r4
446361d4 10d08de2 add      sp, sp, #0x10
446361d8 1080bde8 pop      {r4, pc}
446361dc 10402de9 push     {r4, lr}
446361e0 10d04de2 sub      sp, sp, #0x10
446361e4 45ffffeb bl       #0x44635f00
446361e8 d8109fe5 ldr      r1, [pc, #0xd8]
446361ec 200050e3 cmp      r0, #0x20
446361f0 0040a0e3 mov      r4, #0
446361f4 05408102 addeq    r4, r1, #5
446361f8 2a00000a beq      #0x446362a8
446361fc 110000ca bgt      #0x44636248
44636200 040050e3 cmp      r0, #4
44636204 02408102 addeq    r4, r1, #2
44636208 2600000a beq      #0x446362a8
4463620c 060000ca bgt      #0x4463622c
44636210 010050e3 cmp      r0, #1
44636214 ac409f05 ldreq    r4, [pc, #0xac]
44636218 2200000a beq      #0x446362a8
4463621c 020050e3 cmp      r0, #2
44636220 01408102 addeq    r4, r1, #1
44636224 1f00000a beq      #0x446362a8
44636228 120000ea b        #0x44636278
4463622c 080050e3 cmp      r0, #8
44636230 03408102 addeq    r4, r1, #3
44636234 1b00000a beq      #0x446362a8
44636238 100050e3 cmp      r0, #0x10
4463623c 04408102 addeq    r4, r1, #4
44636240 1800000a beq      #0x446362a8
44636244 0b0000ea b        #0x44636278
44636248 400050e3 cmp      r0, #0x40
4463624c 06408102 addeq    r4, r1, #6
44636250 1400000a beq      #0x446362a8
44636254 800050e3 cmp      r0, #0x80
44636258 07408102 addeq    r4, r1, #7
4463625c 1100000a beq      #0x446362a8
44636260 010c50e3 cmp      r0, #0x100
44636264 08408102 addeq    r4, r1, #8
44636268 0e00000a beq      #0x446362a8
4463626c 020c50e3 cmp      r0, #0x200
44636270 09408102 addeq    r4, r1, #9
44636274 0b00000a beq      #0x446362a8
44636278 f0baffeb bl       #0x44624e40
4463627c 000050e3 cmp      r0, #0
44636280 0800000a beq      #0x446362a8
44636284 572fa0e3 mov      r2, #0x15c
44636288 fd1f4fe2 sub      r1, pc, #0x3f4
4463628c fe0f4fe2 sub      r0, pc, #0x3f8
44636290 07008de8 stm      sp, {r0, r1, r2}
44636294 0030a0e3 mov      r3, #0
44636298 0320a0e1 mov      r2, r3
4463629c 28108fe2 add      r1, pc, #0x28
446362a0 28008fe2 add      r0, pc, #0x28
446362a4 ae9d05eb bl       #0x4479d964
446362a8 0400a0e1 mov      r0, r4
446362ac 10d08de2 add      sp, sp, #0x10
446362b0 1080bde8 pop      {r4, pc}
446362b4 d89f8e44 strmi    sb, [lr], #0xfd8
446362b8 0e010000 andeq    r0, r0, lr, lsl #2
446362bc 1f010000 andeq    r0, r0, pc, lsl r1
446362c0 7ca08e44 strmi    sl, [lr], #0x7c
446362c4 3d010000 andeq    r0, r0, sp, lsr r1
446362c8 a4b89844 ldrmi    fp, [r8], #0x8a4
446362cc 00000000 andeq    r0, r0, r0
446362d0 30000000 andeq    r0, r0, r0, lsr r0
446362d4 10402de9 push     {r4, lr}
446362d8 10d04de2 sub      sp, sp, #0x10
446362dc 07ffffeb bl       #0x44635f00
446362e0 200050e3 cmp      r0, #0x20
446362e4 0040a0e3 mov      r4, #0
446362e8 28129fe5 ldr      r1, [pc, #0x228]
446362ec 28429f05 ldreq    r4, [pc, #0x228]
446362f0 2a00000a beq      #0x446363a0
446362f4 110000ca bgt      #0x44636340
446362f8 040050e3 cmp      r0, #4
446362fc 96408102 addeq    r4, r1, #0x96
44636300 2600000a beq      #0x446363a0
44636304 060000ca bgt      #0x44636324
44636308 010050e3 cmp      r0, #1
4463630c 04429f05 ldreq    r4, [pc, #0x204]
44636310 2200000a beq      #0x446363a0
44636314 020050e3 cmp      r0, #2
44636318 4b408102 addeq    r4, r1, #0x4b
4463631c 1f00000a beq      #0x446363a0
44636320 120000ea b        #0x44636370
44636324 080050e3 cmp      r0, #8
44636328 e1408102 addeq    r4, r1, #0xe1
4463632c 1b00000a beq      #0x446363a0
44636330 100050e3 cmp      r0, #0x10
44636334 4b4f8102 addeq    r4, r1, #0x12c
44636338 1800000a beq      #0x446363a0
4463633c 0b0000ea b        #0x44636370
44636340 400050e3 cmp      r0, #0x40
44636344 d4419f05 ldreq    r4, [pc, #0x1d4]
44636348 1400000a beq      #0x446363a0
4463634c 800050e3 cmp      r0, #0x80
44636350 cc419f05 ldreq    r4, [pc, #0x1cc]
44636354 1100000a beq      #0x446363a0
44636358 010c50e3 cmp      r0, #0x100
4463635c 964f8102 addeq    r4, r1, #0x258
44636360 0e00000a beq      #0x446363a0
44636364 020c50e3 cmp      r0, #0x200
44636368 b8419f05 ldreq    r4, [pc, #0x1b8]
4463636c 0b00000a beq      #0x446363a0
44636370 b2baffeb bl       #0x44624e40
44636374 000050e3 cmp      r0, #0
44636378 0800000a beq      #0x446363a0
4463637c a8219fe5 ldr      r2, [pc, #0x1a8]
44636380 bc104fe2 sub      r1, pc, #0xbc
44636384 c0004fe2 sub      r0, pc, #0xc0
44636388 07008de8 stm      sp, {r0, r1, r2}
4463638c 0030a0e3 mov      r3, #0
44636390 0320a0e1 mov      r2, r3
44636394 d0104fe2 sub      r1, pc, #0xd0
44636398 d0004fe2 sub      r0, pc, #0xd0
4463639c 709d05eb bl       #0x4479d964
446363a0 0400a0e1 mov      r0, r4
446363a4 10d08de2 add      sp, sp, #0x10
446363a8 1080bde8 pop      {r4, pc}
446363ac 10402de9 push     {r4, lr}
446363b0 10d04de2 sub      sp, sp, #0x10
446363b4 d1feffeb bl       #0x44635f00
446363b8 200050e3 cmp      r0, #0x20
446363bc 0040a0e3 mov      r4, #0
446363c0 68419f05 ldreq    r4, [pc, #0x168]
446363c4 2a00000a beq      #0x44636474
446363c8 110000ca bgt      #0x44636414
446363cc 040050e3 cmp      r0, #4
446363d0 5c419f05 ldreq    r4, [pc, #0x15c]
446363d4 2600000a beq      #0x44636474
446363d8 060000ca bgt      #0x446363f8
446363dc 010050e3 cmp      r0, #1
446363e0 50419f05 ldreq    r4, [pc, #0x150]
446363e4 2200000a beq      #0x44636474
446363e8 020050e3 cmp      r0, #2
446363ec 48419f05 ldreq    r4, [pc, #0x148]
446363f0 1f00000a beq      #0x44636474
446363f4 120000ea b        #0x44636444
446363f8 080050e3 cmp      r0, #8
446363fc 3c419f05 ldreq    r4, [pc, #0x13c]
44636400 1b00000a beq      #0x44636474
44636404 100050e3 cmp      r0, #0x10
44636408 34419f05 ldreq    r4, [pc, #0x134]
4463640c 1800000a beq      #0x44636474
44636410 0b0000ea b        #0x44636444
44636414 400050e3 cmp      r0, #0x40
44636418 28419f05 ldreq    r4, [pc, #0x128]
4463641c 1400000a beq      #0x44636474
44636420 800050e3 cmp      r0, #0x80
44636424 20419f05 ldreq    r4, [pc, #0x120]
44636428 1100000a beq      #0x44636474
4463642c 010c50e3 cmp      r0, #0x100
44636430 18419f05 ldreq    r4, [pc, #0x118]
44636434 0e00000a beq      #0x44636474
44636438 020c50e3 cmp      r0, #0x200
4463643c 10419f05 ldreq    r4, [pc, #0x110]
44636440 0b00000a beq      #0x44636474
44636444 7dbaffeb bl       #0x44624e40
44636448 000050e3 cmp      r0, #0
4463644c 0800000a beq      #0x44636474
44636450 00219fe5 ldr      r2, [pc, #0x100]
44636454 191e4fe2 sub      r1, pc, #0x190
44636458 650f4fe2 sub      r0, pc, #0x194
4463645c 07008de8 stm      sp, {r0, r1, r2}
44636460 0030a0e3 mov      r3, #0
44636464 0320a0e1 mov      r2, r3
44636468 691f4fe2 sub      r1, pc, #0x1a4
4463646c 690f4fe2 sub      r0, pc, #0x1a4
44636470 3b9d05eb bl       #0x4479d964
44636474 0400a0e1 mov      r0, r4
44636478 10d08de2 add      sp, sp, #0x10
4463647c 1080bde8 pop      {r4, pc}
44636480 f8432de9 push     {r3, r4, r5, r6, r7, r8, sb, lr}
44636484 0170a0e1 mov      r7, r1
44636488 0050a0e1 mov      r5, r0
4463648c 0040a0e3 mov      r4, #0
44636490 77fcffeb bl       #0x44635674
44636494 0060a0e1 mov      r6, r0
44636498 0000a0e3 mov      r0, #0
4463649c 74fcffeb bl       #0x44635674
446364a0 0080a0e1 mov      r8, r0
446364a4 0500a0e1 mov      r0, r5
446364a8 7afcffeb bl       #0x44635698
446364ac 0010a0e3 mov      r1, #0
446364b0 090056e3 cmp      r6, #9
446364b4 0010cde5 strb     r1, [sp]
446364b8 0400000a beq      #0x446364d0
446364bc 000050e3 cmp      r0, #0
446364c0 0140a013 movne    r4, #1
446364c4 010055e3 cmp      r5, #1
446364c8 0700000a beq      #0x446364ec
446364cc 0d0000ea b        #0x44636508
446364d0 000055e3 cmp      r5, #0
446364d4 0240a0e3 mov      r4, #2
446364d8 0a00000a beq      #0x44636508
446364dc 090058e3 cmp      r8, #9
446364e0 0340a0e3 mov      r4, #3
446364e4 00108715 strne    r1, [r7]
446364e8 f5ffffea b        #0x446364c4
446364ec 090056e3 cmp      r6, #9
446364f0 0100a003 moveq    r0, #1
446364f4 0000cd05 strbeq   r0, [sp]
446364f8 5c009fe5 ldr      r0, [pc, #0x5c]
446364fc 0d20a0e1 mov      r2, sp
44636500 0110a0e3 mov      r1, #1
44636504 1f5303eb bl       #0x4470b188
44636508 0400a0e1 mov      r0, r4
4463650c f883bde8 pop      {r3, r4, r5, r6, r7, r8, sb, pc}
44636510 0100a0e3 mov      r0, #1
44636514 1eff2fe1 bx       lr
44636518 aeb89844 ldrmi    fp, [r8], #0x8ae
4463651c 25ba9844 ldrmi    fp, [r8], #0xa25
44636520 70ba9844 ldrmi    fp, [r8], #0xa70
44636524 bbba9844 ldrmi    fp, [r8], #0xabb
44636528 51bb9844 ldrmi    fp, [r8], #0xb51
4463652c 7b010000 andeq    r0, r0, fp, ror r1
44636530 53380000 andeq    r3, r0, r3, asr r8
44636534 50380000 andeq    r3, r0, r0, asr r8
44636538 56380000 andeq    r3, r0, r6, asr r8
4463653c 55380000 andeq    r3, r0, r5, asr r8
44636540 5a380000 andeq    r3, r0, sl, asr r8
44636544 49380000 andeq    r3, r0, sb, asr #16
44636548 5b380000 andeq    r3, r0, fp, asr r8
4463654c 52380000 andeq    r3, r0, r2, asr r8
44636550 54380000 andeq    r3, r0, r4, asr r8
44636554 58380000 andeq    r3, r0, r8, asr r8
44636558 9a010000 muleq    r0, sl, r1
4463655c 0df00000 andeq    pc, r0, sp
44636560 f0039fe5 ldr      r0, [pc, #0x3f0]
44636564 000390e5 ldr      r0, [r0, #0x300]
44636568 800ea0e1 lsl      r0, r0, #0x1d
4463656c a00fa0e1 lsr      r0, r0, #0x1f
44636570 1eff2fe1 bx       lr
44636574 dc139fe5 ldr      r1, [pc, #0x3dc]
44636578 000050e3 cmp      r0, #0
4463657c 0420a0e3 mov      r2, #4
44636580 18238105 streq    r2, [r1, #0x318]
44636584 14238115 strne    r2, [r1, #0x314]
44636588 1eff2fe1 bx       lr
4463658c c4139fe5 ldr      r1, [pc, #0x3c4]
44636590 000050e3 cmp      r0, #0
44636594 0420a0e3 mov      r2, #4
44636598 28238105 streq    r2, [r1, #0x328]
4463659c 24238115 strne    r2, [r1, #0x324]
446365a0 1eff2fe1 bx       lr
446365a4 ac139fe5 ldr      r1, [pc, #0x3ac]
446365a8 000050e3 cmp      r0, #0
446365ac 0125a0e3 mov      r2, #0x400000
446365b0 98218105 streq    r2, [r1, #0x198]
446365b4 94218115 strne    r2, [r1, #0x194]
446365b8 1eff2fe1 bx       lr
446365bc 94139fe5 ldr      r1, [pc, #0x394]
446365c0 000050e3 cmp      r0, #0
446365c4 0125a0e3 mov      r2, #0x400000
446365c8 a8218105 streq    r2, [r1, #0x1a8]
446365cc a4218115 strne    r2, [r1, #0x1a4]
446365d0 1eff2fe1 bx       lr
446365d4 7c139fe5 ldr      r1, [pc, #0x37c]
446365d8 000050e3 cmp      r0, #0
446365dc 0220a0e3 mov      r2, #2
446365e0 18238105 streq    r2, [r1, #0x318]
446365e4 14238115 strne    r2, [r1, #0x314]
446365e8 1eff2fe1 bx       lr
446365ec 000050e3 cmp      r0, #0
446365f0 64039f05 ldreq    r0, [pc, #0x364]
446365f4 64039f15 ldrne    r0, [pc, #0x364]
446365f8 0110a0e3 mov      r1, #1
446365fc 001080e5 str      r1, [r0]
44636600 1eff2fe1 bx       lr
44636604 000050e3 cmp      r0, #0
44636608 54039f05 ldreq    r0, [pc, #0x354]
4463660c 54039f15 ldrne    r0, [pc, #0x354]
44636610 0410a0e3 mov      r1, #4
44636614 001080e5 str      r1, [r0]
44636618 1eff2fe1 bx       lr
4463661c 000050e3 cmp      r0, #0
44636620 3c039f05 ldreq    r0, [pc, #0x33c]
44636624 3c039f15 ldrne    r0, [pc, #0x33c]
44636628 0810a0e3 mov      r1, #8
4463662c 001080e5 str      r1, [r0]
44636630 1eff2fe1 bx       lr
44636634 1c139fe5 ldr      r1, [pc, #0x31c]
44636638 000050e3 cmp      r0, #0
4463663c 0227a0e3 mov      r2, #0x80000
44636640 98218105 streq    r2, [r1, #0x198]
44636644 94218115 strne    r2, [r1, #0x194]
44636648 1eff2fe1 bx       lr
4463664c 04139fe5 ldr      r1, [pc, #0x304]
44636650 000050e3 cmp      r0, #0
44636654 0126a0e3 mov      r2, #0x100000
44636658 98218105 streq    r2, [r1, #0x198]
4463665c 94218115 strne    r2, [r1, #0x194]
44636660 1eff2fe1 bx       lr
44636664 ec129fe5 ldr      r1, [pc, #0x2ec]
44636668 000050e3 cmp      r0, #0
4463666c 0226a0e3 mov      r2, #0x200000
44636670 98218105 streq    r2, [r1, #0x198]
44636674 94218115 strne    r2, [r1, #0x194]
44636678 1eff2fe1 bx       lr
4463667c d4129fe5 ldr      r1, [pc, #0x2d4]
44636680 000050e3 cmp      r0, #0
44636684 0226a0e3 mov      r2, #0x200000
44636688 98208105 streq    r2, [r1, #0x98]
4463668c 94208115 strne    r2, [r1, #0x94]
44636690 1eff2fe1 bx       lr
44636694 bc029fe5 ldr      r0, [pc, #0x2bc]
44636698 800090e5 ldr      r0, [r0, #0x80]
4463669c 8009a0e1 lsl      r0, r0, #0x13
446366a0 a00fa0e1 lsr      r0, r0, #0x1f
446366a4 1eff2fe1 bx       lr
446366a8 a8029fe5 ldr      r0, [pc, #0x2a8]
446366ac 800090e5 ldr      r0, [r0, #0x80]
446366b0 800ba0e1 lsl      r0, r0, #0x17
446366b4 a00fa0e1 lsr      r0, r0, #0x1f
446366b8 1eff2fe1 bx       lr
446366bc 94029fe5 ldr      r0, [pc, #0x294]
446366c0 000390e5 ldr      r0, [r0, #0x300]
446366c4 800ea0e1 lsl      r0, r0, #0x1d
446366c8 a00fa0e1 lsr      r0, r0, #0x1f
446366cc 1eff2fe1 bx       lr
446366d0 80129fe5 ldr      r1, [pc, #0x280]
446366d4 000050e3 cmp      r0, #0
446366d8 0420a0e3 mov      r2, #4
446366dc 18238105 streq    r2, [r1, #0x318]
446366e0 14238115 strne    r2, [r1, #0x314]
446366e4 1eff2fe1 bx       lr
446366e8 68129fe5 ldr      r1, [pc, #0x268]
446366ec 000050e3 cmp      r0, #0
446366f0 0420a0e3 mov      r2, #4
446366f4 28238105 streq    r2, [r1, #0x328]
446366f8 24238115 strne    r2, [r1, #0x324]
446366fc 1eff2fe1 bx       lr
44636700 50129fe5 ldr      r1, [pc, #0x250]
44636704 000050e3 cmp      r0, #0
44636708 0125a0e3 mov      r2, #0x400000
4463670c 98218105 streq    r2, [r1, #0x198]
44636710 94218115 strne    r2, [r1, #0x194]
44636714 1eff2fe1 bx       lr
44636718 38129fe5 ldr      r1, [pc, #0x238]
4463671c 000050e3 cmp      r0, #0
44636720 0125a0e3 mov      r2, #0x400000
44636724 a8218105 streq    r2, [r1, #0x1a8]
44636728 a4218115 strne    r2, [r1, #0x1a4]
4463672c 1eff2fe1 bx       lr
44636730 20129fe5 ldr      r1, [pc, #0x220]
44636734 000050e3 cmp      r0, #0
44636738 0220a0e3 mov      r2, #2
4463673c 18238105 streq    r2, [r1, #0x318]
44636740 14238115 strne    r2, [r1, #0x314]
44636744 1eff2fe1 bx       lr
44636748 000050e3 cmp      r0, #0
4463674c 08029f05 ldreq    r0, [pc, #0x208]
44636750 08029f15 ldrne    r0, [pc, #0x208]
44636754 0110a0e3 mov      r1, #1
44636758 001080e5 str      r1, [r0]
4463675c 1eff2fe1 bx       lr
44636760 000050e3 cmp      r0, #0
44636764 f8019f05 ldreq    r0, [pc, #0x1f8]
44636768 f8019f15 ldrne    r0, [pc, #0x1f8]
4463676c 0410a0e3 mov      r1, #4
44636770 001080e5 str      r1, [r0]
44636774 1eff2fe1 bx       lr
44636778 000050e3 cmp      r0, #0
4463677c e0019f05 ldreq    r0, [pc, #0x1e0]
44636780 e0019f15 ldrne    r0, [pc, #0x1e0]
44636784 0810a0e3 mov      r1, #8
44636788 001080e5 str      r1, [r0]
4463678c 1eff2fe1 bx       lr
44636790 c0119fe5 ldr      r1, [pc, #0x1c0]
44636794 000050e3 cmp      r0, #0
44636798 0227a0e3 mov      r2, #0x80000
4463679c 98218105 streq    r2, [r1, #0x198]
446367a0 94218115 strne    r2, [r1, #0x194]
446367a4 1eff2fe1 bx       lr
446367a8 a8119fe5 ldr      r1, [pc, #0x1a8]
446367ac 000050e3 cmp      r0, #0
446367b0 0126a0e3 mov      r2, #0x100000
446367b4 98218105 streq    r2, [r1, #0x198]
446367b8 94218115 strne    r2, [r1, #0x194]
446367bc 1eff2fe1 bx       lr
446367c0 90119fe5 ldr      r1, [pc, #0x190]
446367c4 000050e3 cmp      r0, #0
446367c8 0226a0e3 mov      r2, #0x200000
446367cc 98218105 streq    r2, [r1, #0x198]
446367d0 94218115 strne    r2, [r1, #0x194]
446367d4 1eff2fe1 bx       lr
446367d8 78119fe5 ldr      r1, [pc, #0x178]
446367dc 000050e3 cmp      r0, #0
446367e0 0226a0e3 mov      r2, #0x200000
446367e4 98208105 streq    r2, [r1, #0x98]
446367e8 94208115 strne    r2, [r1, #0x94]
446367ec 1eff2fe1 bx       lr
446367f0 60019fe5 ldr      r0, [pc, #0x160]
446367f4 800090e5 ldr      r0, [r0, #0x80]
446367f8 0009a0e1 lsl      r0, r0, #0x12
446367fc a00fa0e1 lsr      r0, r0, #0x1f
44636800 1eff2fe1 bx       lr
44636804 4c019fe5 ldr      r0, [pc, #0x14c]
44636808 800090e5 ldr      r0, [r0, #0x80]
4463680c 000ba0e1 lsl      r0, r0, #0x16
44636810 a00fa0e1 lsr      r0, r0, #0x1f
44636814 1eff2fe1 bx       lr
44636818 38019fe5 ldr      r0, [pc, #0x138]
4463681c 000390e5 ldr      r0, [r0, #0x300]
44636820 000ea0e1 lsl      r0, r0, #0x1c
44636824 a00fa0e1 lsr      r0, r0, #0x1f
44636828 1eff2fe1 bx       lr
4463682c 24019fe5 ldr      r0, [pc, #0x124]
44636830 800090e5 ldr      r0, [r0, #0x80]
44636834 800ea0e1 lsl      r0, r0, #0x1d
44636838 a00fa0e1 lsr      r0, r0, #0x1f
4463683c 1eff2fe1 bx       lr
44636840 10119fe5 ldr      r1, [pc, #0x110]
44636844 000050e3 cmp      r0, #0
44636848 0820a0e3 mov      r2, #8
4463684c 18238105 streq    r2, [r1, #0x318]
44636850 14238115 strne    r2, [r1, #0x314]
44636854 1eff2fe1 bx       lr
44636858 f8109fe5 ldr      r1, [pc, #0xf8]
4463685c 000050e3 cmp      r0, #0
44636860 0128a0e3 mov      r2, #0x10000
44636864 98218105 streq    r2, [r1, #0x198]
44636868 94218115 strne    r2, [r1, #0x194]
4463686c 1eff2fe1 bx       lr
44636870 e0109fe5 ldr      r1, [pc, #0xe0]
44636874 000050e3 cmp      r0, #0
44636878 0228a0e3 mov      r2, #0x20000
4463687c 98218105 streq    r2, [r1, #0x198]
44636880 94218115 strne    r2, [r1, #0x194]
44636884 1eff2fe1 bx       lr
44636888 c8109fe5 ldr      r1, [pc, #0xc8]
4463688c 000050e3 cmp      r0, #0
44636890 0127a0e3 mov      r2, #0x40000
44636894 94218105 streq    r2, [r1, #0x194]
44636898 98218115 strne    r2, [r1, #0x198]
4463689c 1eff2fe1 bx       lr
446368a0 b0109fe5 ldr      r1, [pc, #0xb0]
446368a4 000050e3 cmp      r0, #0
446368a8 0820a0e3 mov      r2, #8
446368ac 28238105 streq    r2, [r1, #0x328]
446368b0 24238115 strne    r2, [r1, #0x324]
446368b4 1eff2fe1 bx       lr
446368b8 98009fe5 ldr      r0, [pc, #0x98]
446368bc 000390e5 ldr      r0, [r0, #0x300]
446368c0 800da0e1 lsl      r0, r0, #0x1b
446368c4 a00fa0e1 lsr      r0, r0, #0x1f
446368c8 1eff2fe1 bx       lr
446368cc 84009fe5 ldr      r0, [pc, #0x84]
446368d0 800090e5 ldr      r0, [r0, #0x80]
446368d4 000ea0e1 lsl      r0, r0, #0x1c
446368d8 a00fa0e1 lsr      r0, r0, #0x1f
446368dc 1eff2fe1 bx       lr
446368e0 70109fe5 ldr      r1, [pc, #0x70]
446368e4 000050e3 cmp      r0, #0
446368e8 1020a0e3 mov      r2, #0x10
446368ec 18238105 streq    r2, [r1, #0x318]
446368f0 14238115 strne    r2, [r1, #0x314]
446368f4 1eff2fe1 bx       lr
446368f8 58109fe5 ldr      r1, [pc, #0x58]
446368fc 000050e3 cmp      r0, #0
44636900 0128a0e3 mov      r2, #0x10000
44636904 98218105 streq    r2, [r1, #0x198]
44636908 94218115 strne    r2, [r1, #0x194]
4463690c 1eff2fe1 bx       lr
44636910 40109fe5 ldr      r1, [pc, #0x40]
44636914 000050e3 cmp      r0, #0
44636918 0228a0e3 mov      r2, #0x20000
4463691c 98218105 streq    r2, [r1, #0x198]
44636920 94218115 strne    r2, [r1, #0x194]
44636924 1eff2fe1 bx       lr
44636928 28109fe5 ldr      r1, [pc, #0x28]
4463692c 000050e3 cmp      r0, #0
44636930 0127a0e3 mov      r2, #0x40000
44636934 94218105 streq    r2, [r1, #0x194]
44636938 98218115 strne    r2, [r1, #0x198]
4463693c 1eff2fe1 bx       lr
44636940 10109fe5 ldr      r1, [pc, #0x10]
44636944 000050e3 cmp      r0, #0
44636948 1020a0e3 mov      r2, #0x10
4463694c 28238105 streq    r2, [r1, #0x328]
44636950 24238115 strne    r2, [r1, #0x324]
44636954 1eff2fe1 bx       lr
44636958 00000920 andhs    r0, sb, r0
4463695c 18050920 andhs    r0, sb, r8, lsl r5
44636960 14050920 andhs    r0, sb, r4, lsl r5
44636964 18060920 andhs    r0, sb, r8, lsl r6
44636968 14060920 andhs    r0, sb, r4, lsl r6
4463696c 0200a0e3 mov      r0, #2
44636970 1eff2fe1 bx       lr
44636974 0200a0e3 mov      r0, #2
44636978 1eff2fe1 bx       lr
4463697c 0200a0e3 mov      r0, #2
44636980 1eff2fe1 bx       lr
44636984 0a00a0e3 mov      r0, #0xa
44636988 1eff2fe1 bx       lr
4463698c f0402de9 push     {r4, r5, r6, r7, lr}
44636990 0cd04de2 sub      sp, sp, #0xc
44636994 faffffeb bl       #0x44636984
44636998 0040a0e1 mov      r4, r0
4463699c f6ffffeb bl       #0x4463697c
446369a0 0050a0e1 mov      r5, r0
446369a4 f2ffffeb bl       #0x44636974
446369a8 0060a0e1 mov      r6, r0
446369ac eeffffeb bl       #0x4463696c
446369b0 0070a0e1 mov      r7, r0
446369b4 0c0054e3 cmp      r4, #0xc
446369b8 0100a0e3 mov      r0, #1
446369bc 0c00009a bls      #0x446369f4
446369c0 1eb9ffeb bl       #0x44624e40
446369c4 000050e3 cmp      r0, #0
446369c8 0800000a beq      #0x446369f0
446369cc 4f20a0e3 mov      r2, #0x4f
446369d0 dc108fe2 add      r1, pc, #0xdc
446369d4 d8008fe2 add      r0, pc, #0xd8
446369d8 07008de8 stm      sp, {r0, r1, r2}
446369dc 0030a0e3 mov      r3, #0
446369e0 0320a0e1 mov      r2, r3
446369e4 c8108fe2 add      r1, pc, #0xc8
446369e8 c8008fe2 add      r0, pc, #0xc8
446369ec dc9b05eb bl       #0x4479d964
446369f0 0000a0e3 mov      r0, #0
446369f4 040055e3 cmp      r5, #4
446369f8 0c00009a bls      #0x44636a30
446369fc 0fb9ffeb bl       #0x44624e40
44636a00 000050e3 cmp      r0, #0
44636a04 0800000a beq      #0x44636a2c
44636a08 5520a0e3 mov      r2, #0x55
44636a0c a0108fe2 add      r1, pc, #0xa0
44636a10 9c008fe2 add      r0, pc, #0x9c
44636a14 07008de8 stm      sp, {r0, r1, r2}
44636a18 0030a0e3 mov      r3, #0
44636a1c 0320a0e1 mov      r2, r3
44636a20 8c108fe2 add      r1, pc, #0x8c
44636a24 8c008fe2 add      r0, pc, #0x8c
44636a28 cd9b05eb bl       #0x4479d964
44636a2c 0000a0e3 mov      r0, #0
44636a30 040056e1 cmp      r6, r4
44636a34 0c00009a bls      #0x44636a6c
44636a38 00b9ffeb bl       #0x44624e40
44636a3c 000050e3 cmp      r0, #0
44636a40 0800000a beq      #0x44636a68
44636a44 5b20a0e3 mov      r2, #0x5b
44636a48 64108fe2 add      r1, pc, #0x64
44636a4c 60008fe2 add      r0, pc, #0x60
44636a50 07008de8 stm      sp, {r0, r1, r2}
44636a54 0030a0e3 mov      r3, #0
44636a58 0320a0e1 mov      r2, r3
44636a5c 50108fe2 add      r1, pc, #0x50
44636a60 50008fe2 add      r0, pc, #0x50
44636a64 be9b05eb bl       #0x4479d964
44636a68 0000a0e3 mov      r0, #0
44636a6c 050057e1 cmp      r7, r5
44636a70 0cd08d92 addls    sp, sp, #0xc
44636a74 f080bd98 popls    {r4, r5, r6, r7, pc}
44636a78 f0b8ffeb bl       #0x44624e40
44636a7c 000050e3 cmp      r0, #0
44636a80 0800000a beq      #0x44636aa8
44636a84 6120a0e3 mov      r2, #0x61
44636a88 24108fe2 add      r1, pc, #0x24
44636a8c 20008fe2 add      r0, pc, #0x20
44636a90 07008de8 stm      sp, {r0, r1, r2}
44636a94 0030a0e3 mov      r3, #0
44636a98 0320a0e1 mov      r2, r3
44636a9c 10108fe2 add      r1, pc, #0x10
44636aa0 10008fe2 add      r0, pc, #0x10
44636aa4 ae9b05eb bl       #0x4479d964
44636aa8 0000a0e3 mov      r0, #0
44636aac 0cd08de2 add      sp, sp, #0xc
44636ab0 f080bde8 pop      {r4, r5, r6, r7, pc}
44636ab4 00000000 andeq    r0, r0, r0
44636ab8 30000000 andeq    r0, r0, r0, lsr r0
44636abc 010050e3 cmp      r0, #1
44636ac0 02005013 cmpne    r0, #2
44636ac4 0010a0e3 mov      r1, #0
44636ac8 0110a003 moveq    r1, #1
44636acc 0100a0e1 mov      r0, r1
44636ad0 1eff2fe1 bx       lr
44636ad4 f0432de9 push     {r4, r5, r6, r7, r8, sb, lr}
44636ad8 0cd04de2 sub      sp, sp, #0xc
44636adc 0070a0e1 mov      r7, r0
44636ae0 0040a0e3 mov      r4, #0
44636ae4 380300eb bl       #0x446377cc
44636ae8 000050e3 cmp      r0, #0
44636aec 0110a013 movne    r1, #1
44636af0 b0009f05 ldreq    r0, [pc, #0xb0]
44636af4 1100a011 lslne    r0, r1, r0
44636af8 b0c09fe5 ldr      ip, [pc, #0xb0]
44636afc 0038a0e1 lsl      r3, r0, #0x10
44636b00 a4909fe5 ldr      sb, [pc, #0xa4]
44636b04 2338a0e1 lsr      r3, r3, #0x10
44636b08 0000e0e3 mvn      r0, #0
44636b0c 0360a0e3 mov      r6, #3
44636b10 18804ce2 sub      r8, ip, #0x18
44636b14 841084e0 add      r1, r4, r4, lsl #1
44636b18 01118ce0 add      r1, ip, r1, lsl #2
44636b1c b220d1e1 ldrh     r2, [r1, #2]
44636b20 030012e1 tst      r2, r3
44636b24 0a00000a beq      #0x44636b54
44636b28 0720d9e7 ldrb     r2, [sb, r7]
44636b2c 0750d1e5 ldrb     r5, [r1, #7]
44636b30 050052e1 cmp      r2, r5
44636b34 0600001a bne      #0x44636b54
44636b38 0650d1e5 ldrb     r5, [r1, #6]
44636b3c 851085e0 add      r1, r5, r5, lsl #1
44636b40 011188e0 add      r1, r8, r1, lsl #2
44636b44 082091e5 ldr      r2, [r1, #8]
44636b48 000052e1 cmp      r2, r0
44636b4c 0200a031 movlo    r0, r2
44636b50 0560a031 movlo    r6, r5
44636b54 011084e2 add      r1, r4, #1
44636b58 0148c1e3 bic      r4, r1, #0x10000
44636b5c 510054e3 cmp      r4, #0x51
44636b60 ebffff3a blo      #0x44636b14
44636b64 030056e3 cmp      r6, #3
44636b68 0b00001a bne      #0x44636b9c
44636b6c b3b8ffeb bl       #0x44624e40
44636b70 000050e3 cmp      r0, #0
44636b74 0800000a beq      #0x44636b9c
44636b78 34209fe5 ldr      r2, [pc, #0x34]
44636b7c 34108fe2 add      r1, pc, #0x34
44636b80 30008fe2 add      r0, pc, #0x30
44636b84 07008de8 stm      sp, {r0, r1, r2}
44636b88 0030a0e3 mov      r3, #0
44636b8c 0320a0e1 mov      r2, r3
44636b90 20108fe2 add      r1, pc, #0x20
44636b94 20008fe2 add      r0, pc, #0x20
44636b98 719b05eb bl       #0x4479d964
44636b9c 0600a0e1 mov      r0, r6
44636ba0 0cd08de2 add      sp, sp, #0xc
44636ba4 f083bde8 pop      {r4, r5, r6, r7, r8, sb, pc}
44636ba8 ffff0000 .byte    0xff, 0xff, 0x00, 0x00
44636bac b4bb9844 ldrmi    fp, [r8], #0xbb4
44636bb0 b0c98344 strmi    ip, [r3], #0x9b0
44636bb4 79020000 andeq    r0, r0, sb, ror r2
44636bb8 00000000 andeq    r0, r0, r0
44636bbc 30000000 andeq    r0, r0, r0, lsr r0
44636bc0 30402de9 push     {r4, r5, lr}
44636bc4 94149fe5 ldr      r1, [pc, #0x494]
44636bc8 0050a0e1 mov      r5, r0
44636bcc 600081e2 add      r0, r1, #0x60
44636bd0 0d1090e8 ldm      r0, {r0, r2, r3, ip}
44636bd4 34d04de2 sub      sp, sp, #0x34
44636bd8 0ce08de2 add      lr, sp, #0xc
44636bdc 0d108ee8 stm      lr, {r0, r2, r3, ip}
44636be0 700081e2 add      r0, r1, #0x70
44636be4 0d1090e8 ldm      r0, {r0, r2, r3, ip}
44636be8 1ce08de2 add      lr, sp, #0x1c
44636bec 0d108ee8 stm      lr, {r0, r2, r3, ip}
44636bf0 800091e5 ldr      r0, [r1, #0x80]
44636bf4 0040a0e3 mov      r4, #0
44636bf8 2c008de5 str      r0, [sp, #0x2c]
44636bfc 60049fe5 ldr      r0, [pc, #0x460]
44636c00 0000d0e5 ldrb     r0, [r0]
44636c04 010050e3 cmp      r0, #1
44636c08 0b00000a beq      #0x44636c3c
44636c0c 8bb8ffeb bl       #0x44624e40
44636c10 000050e3 cmp      r0, #0
44636c14 0800000a beq      #0x44636c3c
44636c18 48249fe5 ldr      r2, [pc, #0x448]
44636c1c 6c104fe2 sub      r1, pc, #0x6c
44636c20 70004fe2 sub      r0, pc, #0x70
44636c24 07008de8 stm      sp, {r0, r1, r2}
44636c28 0030a0e3 mov      r3, #0
44636c2c 0320a0e1 mov      r2, r3
44636c30 80104fe2 sub      r1, pc, #0x80
44636c34 80004fe2 sub      r0, pc, #0x80
44636c38 499b05eb bl       #0x4479d964
44636c3c 851085e0 add      r1, r5, r5, lsl #1
44636c40 0c008de2 add      r0, sp, #0xc
44636c44 010080e0 add      r0, r0, r1
44636c48 0010d0e5 ldrb     r1, [r0]
44636c4c 000051e3 cmp      r1, #0
44636c50 0600000a beq      #0x44636c70
44636c54 10149fe5 ldr      r1, [pc, #0x410]
44636c58 0510d1e7 ldrb     r1, [r1, r5]
44636c5c 010051e3 cmp      r1, #1
44636c60 0140a003 moveq    r4, #1
44636c64 0100000a beq      #0x44636c70
44636c68 020051e3 cmp      r1, #2
44636c6c 0240a003 moveq    r4, #2
44636c70 f8139fe5 ldr      r1, [pc, #0x3f8]
44636c74 0540c1e7 strb     r4, [r1, r5]
44636c78 0400d0e7 ldrb     r0, [r0, r4]
44636c7c 0c1081e2 add      r1, r1, #0xc
44636c80 0500c1e7 strb     r0, [r1, r5]
44636c84 34d08de2 add      sp, sp, #0x34
44636c88 3080bde8 pop      {r4, r5, pc}
44636c8c f0412de9 push     {r4, r5, r6, r7, r8, lr}
44636c90 0180a0e3 mov      r8, #1
44636c94 6a0200eb bl       #0x44637644
44636c98 c4139fe5 ldr      r1, [pc, #0x3c4]
44636c9c 0100a0e3 mov      r0, #1
44636ca0 0040a0e3 mov      r4, #0
44636ca4 0000c1e5 strb     r0, [r1]
44636ca8 35ffffeb bl       #0x44636984
44636cac 000050e3 cmp      r0, #0
44636cb0 0d00009a bls      #0x44636cec
44636cb4 b0639fe5 ldr      r6, [pc, #0x3b0]
44636cb8 0050a0e3 mov      r5, #0
44636cbc 0c7046e2 sub      r7, r6, #0xc
44636cc0 0400a0e1 mov      r0, r4
44636cc4 0450c6e7 strb     r5, [r6, r4]
44636cc8 bcffffeb bl       #0x44636bc0
44636ccc 0400a0e1 mov      r0, r4
44636cd0 7fffffeb bl       #0x44636ad4
44636cd4 0400c7e7 strb     r0, [r7, r4]
44636cd8 010084e2 add      r0, r4, #1
44636cdc ff4000e2 and      r4, r0, #0xff
44636ce0 27ffffeb bl       #0x44636984
44636ce4 040050e1 cmp      r0, r4
44636ce8 f4ffff8a bhi      #0x44636cc0
44636cec 130300eb bl       #0x44637940
44636cf0 640300eb bl       #0x44637a88
44636cf4 0800a0e1 mov      r0, r8
44636cf8 f081bde8 pop      {r4, r5, r6, r7, r8, pc}
44636cfc 58111fe5 ldr      r1, [pc, #-0x158]
44636d00 0000d1e7 ldrb     r0, [r1, r0]
44636d04 68139fe5 ldr      r1, [pc, #0x368]
44636d08 0001d1e7 ldrb     r0, [r1, r0, lsl #2]
44636d0c 1eff2fe1 bx       lr
44636d10 0020a0e1 mov      r2, r0
44636d14 000051e3 cmp      r1, #0
44636d18 0000a0e3 mov      r0, #0
44636d1c 0200000a beq      #0x44636d2c
44636d20 010051e3 cmp      r1, #1
44636d24 fb00a003 moveq    r0, #0xfb
44636d28 1eff2fe1 bx       lr
44636d2c 44039fe5 ldr      r0, [pc, #0x344]
44636d30 3c139fe5 ldr      r1, [pc, #0x33c]
44636d34 0200d0e7 ldrb     r0, [r0, r2]
44636d38 0001d1e7 ldrb     r0, [r1, r0, lsl #2]
44636d3c 1eff2fe1 bx       lr
44636d40 10402de9 push     {r4, lr}
44636d44 0b0050e3 cmp      r0, #0xb
44636d48 10d04de2 sub      sp, sp, #0x10
44636d4c 0040a0e3 mov      r4, #0
44636d50 00f19f37 ldrlo    pc, [pc, r0, lsl #2]
44636d54 200000ea b        #0x44636ddc
44636d58 846d6344 strbtmi  r6, [r3], #-0xd84
44636d5c 8c6d6344 strbtmi  r6, [r3], #-0xd8c
44636d60 946d6344 strbtmi  r6, [r3], #-0xd94
44636d64 9c6d6344 strbtmi  r6, [r3], #-0xd9c
44636d68 a46d6344 strbtmi  r6, [r3], #-0xda4
44636d6c ac6d6344 strbtmi  r6, [r3], #-0xdac
44636d70 b46d6344 strbtmi  r6, [r3], #-0xdb4
44636d74 bc6d6344 strbtmi  r6, [r3], #-0xdbc
44636d78 c46d6344 strbtmi  r6, [r3], #-0xdc4
44636d7c cc6d6344 strbtmi  r6, [r3], #-0xdcc
44636d80 d46d6344 strbtmi  r6, [r3], #-0xdd4
44636d84 0140a0e3 mov      r4, #1
44636d88 1f0000ea b        #0x44636e0c
44636d8c 0240a0e3 mov      r4, #2
44636d90 1d0000ea b        #0x44636e0c
44636d94 0340a0e3 mov      r4, #3
44636d98 1b0000ea b        #0x44636e0c
44636d9c 0440a0e3 mov      r4, #4
44636da0 190000ea b        #0x44636e0c
44636da4 0540a0e3 mov      r4, #5
44636da8 170000ea b        #0x44636e0c
44636dac 0640a0e3 mov      r4, #6
44636db0 150000ea b        #0x44636e0c
44636db4 0740a0e3 mov      r4, #7
44636db8 130000ea b        #0x44636e0c
44636dbc 0840a0e3 mov      r4, #8
44636dc0 110000ea b        #0x44636e0c
44636dc4 0940a0e3 mov      r4, #9
44636dc8 0f0000ea b        #0x44636e0c
44636dcc 0a40a0e3 mov      r4, #0xa
44636dd0 0d0000ea b        #0x44636e0c
44636dd4 0b40a0e3 mov      r4, #0xb
44636dd8 0b0000ea b        #0x44636e0c
44636ddc 17b8ffeb bl       #0x44624e40
44636de0 000050e3 cmp      r0, #0
44636de4 0800000a beq      #0x44636e0c
44636de8 8c229fe5 ldr      r2, [pc, #0x28c]
44636dec 8f1f4fe2 sub      r1, pc, #0x23c
44636df0 090d4fe2 sub      r0, pc, #0x240
44636df4 07008de8 stm      sp, {r0, r1, r2}
44636df8 0030a0e3 mov      r3, #0
44636dfc 0320a0e1 mov      r2, r3
44636e00 251e4fe2 sub      r1, pc, #0x250
44636e04 250e4fe2 sub      r0, pc, #0x250
44636e08 d59a05eb bl       #0x4479d964
44636e0c 60029fe5 ldr      r0, [pc, #0x260]
44636e10 040180e0 add      r0, r0, r4, lsl #2
44636e14 b200d0e1 ldrh     r0, [r0, #2]
44636e18 10d08de2 add      sp, sp, #0x10
44636e1c 1080bde8 pop      {r4, pc}
44636e20 58129fe5 ldr      r1, [pc, #0x258]
44636e24 800081e0 add      r0, r1, r0, lsl #1
44636e28 b000d0e1 ldrh     r0, [r0]
44636e2c 510050e3 cmp      r0, #0x51
44636e30 0100a033 movlo    r0, #1
44636e34 0000a023 movhs    r0, #0
44636e38 1eff2fe1 bx       lr
44636e3c 0020a0e1 mov      r2, r0
44636e40 04e02de5 str      lr, [sp, #-4]!
44636e44 f5ffffeb bl       #0x44636e20
44636e48 000050e3 cmp      r0, #0
44636e4c 04f09d04 popeq    {pc}
44636e50 28029fe5 ldr      r0, [pc, #0x228]
44636e54 ac121fe5 ldr      r1, [pc, #-0x2ac]
44636e58 820080e0 add      r0, r0, r2, lsl #1
44636e5c b000d0e1 ldrh     r0, [r0]
44636e60 800080e0 add      r0, r0, r0, lsl #1
44636e64 000181e0 add      r0, r1, r0, lsl #2
44636e68 080090e5 ldr      r0, [r0, #8]
44636e6c 04f09de4 pop      {pc}
44636e70 30402de9 push     {r4, r5, lr}
44636e74 0cd04de2 sub      sp, sp, #0xc
44636e78 0050a0e1 mov      r5, r0
44636e7c 0040a0e3 mov      r4, #0
44636e80 bffeffeb bl       #0x44636984
44636e84 050050e1 cmp      r0, r5
44636e88 0b00008a bhi      #0x44636ebc
44636e8c ebb7ffeb bl       #0x44624e40
44636e90 000050e3 cmp      r0, #0
44636e94 0800000a beq      #0x44636ebc
44636e98 e4219fe5 ldr      r2, [pc, #0x1e4]
44636e9c bb1f4fe2 sub      r1, pc, #0x2ec
44636ea0 2f0e4fe2 sub      r0, pc, #0x2f0
44636ea4 07008de8 stm      sp, {r0, r1, r2}
44636ea8 0030a0e3 mov      r3, #0
44636eac 0320a0e1 mov      r2, r3
44636eb0 031c4fe2 sub      r1, pc, #0x300
44636eb4 030c4fe2 sub      r0, pc, #0x300
44636eb8 a99a05eb bl       #0x4479d964
44636ebc 18031fe5 ldr      r0, [pc, #-0x318]
44636ec0 0500d0e7 ldrb     r0, [r0, r5]
44636ec4 0c0050e3 cmp      r0, #0xc
44636ec8 00f19f37 ldrlo    pc, [pc, r0, lsl #2]
44636ecc 1f0000ea b        #0x44636f50
44636ed0 506f6344 strbtmi  r6, [r3], #-0xf50
44636ed4 806f6344 strbtmi  r6, [r3], #-0xf80
44636ed8 006f6344 strbtmi  r6, [r3], #-0xf00
44636edc 086f6344 strbtmi  r6, [r3], #-0xf08
44636ee0 106f6344 strbtmi  r6, [r3], #-0xf10
44636ee4 186f6344 strbtmi  r6, [r3], #-0xf18
44636ee8 206f6344 strbtmi  r6, [r3], #-0xf20
44636eec 286f6344 strbtmi  r6, [r3], #-0xf28
44636ef0 306f6344 strbtmi  r6, [r3], #-0xf30
44636ef4 386f6344 strbtmi  r6, [r3], #-0xf38
44636ef8 406f6344 strbtmi  r6, [r3], #-0xf40
44636efc 486f6344 strbtmi  r6, [r3], #-0xf48
44636f00 0140a0e3 mov      r4, #1
44636f04 1d0000ea b        #0x44636f80
44636f08 0240a0e3 mov      r4, #2
44636f0c 1b0000ea b        #0x44636f80
44636f10 0340a0e3 mov      r4, #3
44636f14 190000ea b        #0x44636f80
44636f18 0440a0e3 mov      r4, #4
44636f1c 170000ea b        #0x44636f80
44636f20 0540a0e3 mov      r4, #5
44636f24 150000ea b        #0x44636f80
44636f28 0640a0e3 mov      r4, #6
44636f2c 130000ea b        #0x44636f80
44636f30 0740a0e3 mov      r4, #7
44636f34 110000ea b        #0x44636f80
44636f38 0840a0e3 mov      r4, #8
44636f3c 0f0000ea b        #0x44636f80
44636f40 0940a0e3 mov      r4, #9
44636f44 0d0000ea b        #0x44636f80
44636f48 0a40a0e3 mov      r4, #0xa
44636f4c 0b0000ea b        #0x44636f80
44636f50 bab7ffeb bl       #0x44624e40
44636f54 000050e3 cmp      r0, #0
44636f58 0800000a beq      #0x44636f80
44636f5c 812fa0e3 mov      r2, #0x204
44636f60 3b1e4fe2 sub      r1, pc, #0x3b0
44636f64 ed0f4fe2 sub      r0, pc, #0x3b4
44636f68 07008de8 stm      sp, {r0, r1, r2}
44636f6c 0030a0e3 mov      r3, #0
44636f70 0320a0e1 mov      r2, r3
44636f74 f11f4fe2 sub      r1, pc, #0x3c4
44636f78 f10f4fe2 sub      r0, pc, #0x3c4
44636f7c 789a05eb bl       #0x4479d964
44636f80 0400a0e1 mov      r0, r4
44636f84 0cd08de2 add      sp, sp, #0xc
44636f88 3080bde8 pop      {r4, r5, pc}
44636f8c 1eff2fe1 bx       lr
44636f90 1eff2fe1 bx       lr
44636f94 f0412de9 push     {r4, r5, r6, r7, r8, lr}
44636f98 10d04de2 sub      sp, sp, #0x10
44636f9c 0060a0e1 mov      r6, r0
44636fa0 0040a0e3 mov      r4, #0
44636fa4 080200eb bl       #0x446377cc
44636fa8 000050e3 cmp      r0, #0
44636fac 0110a013 movne    r1, #1
44636fb0 1100a011 lslne    r0, r1, r0
44636fb4 14041f05 ldreq    r0, [pc, #-0x414]
44636fb8 10241fe5 ldr      r2, [pc, #-0x410]
44636fbc 18c41fe5 ldr      ip, [pc, #-0x418]
44636fc0 0038a0e1 lsl      r3, r0, #0x10
44636fc4 2338a0e1 lsr      r3, r3, #0x10
44636fc8 0050a0e3 mov      r5, #0
44636fcc 181042e2 sub      r1, r2, #0x18
44636fd0 840084e0 add      r0, r4, r4, lsl #1
44636fd4 000182e0 add      r0, r2, r0, lsl #2
44636fd8 b270d0e1 ldrh     r7, [r0, #2]
44636fdc 030017e1 tst      r7, r3
44636fe0 0900000a beq      #0x4463700c
44636fe4 0670dce7 ldrb     r7, [ip, r6]
44636fe8 0780d0e5 ldrb     r8, [r0, #7]
44636fec 080057e1 cmp      r7, r8
44636ff0 0500001a bne      #0x4463700c
44636ff4 0600d0e5 ldrb     r0, [r0, #6]
44636ff8 800080e0 add      r0, r0, r0, lsl #1
44636ffc 000181e0 add      r0, r1, r0, lsl #2
44637000 b000d0e1 ldrh     r0, [r0]
44637004 050050e1 cmp      r0, r5
44637008 0050a081 movhi    r5, r0
4463700c 010084e2 add      r0, r4, #1
44637010 0148c0e3 bic      r4, r0, #0x10000
44637014 510054e3 cmp      r4, #0x51
44637018 ecffff3a blo      #0x44636fd0
4463701c 000055e3 cmp      r5, #0
44637020 0b00001a bne      #0x44637054
44637024 85b7ffeb bl       #0x44624e40
44637028 000050e3 cmp      r0, #0
4463702c 0800000a beq      #0x44637054
44637030 2f2ea0e3 mov      r2, #0x2f0
44637034 4c108fe2 add      r1, pc, #0x4c
44637038 48008fe2 add      r0, pc, #0x48
4463703c 07008de8 stm      sp, {r0, r1, r2}
44637040 0030a0e3 mov      r3, #0
44637044 0320a0e1 mov      r2, r3
44637048 38108fe2 add      r1, pc, #0x38
4463704c 38008fe2 add      r0, pc, #0x38
44637050 439a05eb bl       #0x4479d964
44637054 0500a0e1 mov      r0, r5
44637058 10d08de2 add      sp, sp, #0x10
4463705c f081bde8 pop      {r4, r5, r6, r7, r8, pc}
44637060 4ccd8344 strmi    ip, [r3], #0xd4c
44637064 aea08e44 strmi    sl, [lr], #0xae
44637068 41020000 andeq    r0, r0, r1, asr #4
4463706c fcbb9844 ldrmi    fp, [r8], #0xbfc
44637070 a8bb9844 ldrmi    fp, [r8], #0xba8
44637074 66c98344 strmi    ip, [r3], #0x966
44637078 afa08e44 strmi    sl, [lr], #0xaf
4463707c cf010000 andeq    r0, r0, pc, asr #3
44637080 c0bb9844 ldrmi    fp, [r8], #0xbc0
44637084 f6010000 strdeq   r0, r1, [r0], -r6
44637088 00000000 andeq    r0, r0, r0
4463708c 30000000 andeq    r0, r0, r0, lsr r0
44637090 30402de9 push     {r4, r5, lr}
44637094 0cd04de2 sub      sp, sp, #0xc
44637098 0040a0e3 mov      r4, #0
4463709c ca0100eb bl       #0x446377cc
446370a0 000050e3 cmp      r0, #0
446370a4 0110a013 movne    r1, #1
446370a8 1100a011 lslne    r0, r1, r0
446370ac 0c051f05 ldreq    r0, [pc, #-0x50c]
446370b0 08151fe5 ldr      r1, [pc, #-0x508]
446370b4 0038a0e1 lsl      r3, r0, #0x10
446370b8 2338a0e1 lsr      r3, r3, #0x10
446370bc 0050a0e3 mov      r5, #0
446370c0 182041e2 sub      r2, r1, #0x18
446370c4 840084e0 add      r0, r4, r4, lsl #1
446370c8 000181e0 add      r0, r1, r0, lsl #2
446370cc b2c0d0e1 ldrh     ip, [r0, #2]
446370d0 03001ce1 tst      ip, r3
446370d4 0500000a beq      #0x446370f0
446370d8 0600d0e5 ldrb     r0, [r0, #6]
446370dc 800080e0 add      r0, r0, r0, lsl #1
446370e0 000182e0 add      r0, r2, r0, lsl #2
446370e4 b000d0e1 ldrh     r0, [r0]
446370e8 050050e1 cmp      r0, r5
446370ec 0050a081 movhi    r5, r0
446370f0 010084e2 add      r0, r4, #1
446370f4 0148c0e3 bic      r4, r0, #0x10000
446370f8 510054e3 cmp      r4, #0x51
446370fc f0ffff3a blo      #0x446370c4
44637100 000055e3 cmp      r5, #0
44637104 0b00001a bne      #0x44637138
44637108 4cb7ffeb bl       #0x44624e40
4463710c 000050e3 cmp      r0, #0
44637110 0800000a beq      #0x44637138
44637114 312ea0e3 mov      r2, #0x310
44637118 98104fe2 sub      r1, pc, #0x98
4463711c 9c004fe2 sub      r0, pc, #0x9c
44637120 07008de8 stm      sp, {r0, r1, r2}
44637124 0030a0e3 mov      r3, #0
44637128 0320a0e1 mov      r2, r3
4463712c ac104fe2 sub      r1, pc, #0xac
44637130 ac004fe2 sub      r0, pc, #0xac
44637134 0a9a05eb bl       #0x4479d964
44637138 0500a0e1 mov      r0, r5
4463713c 0cd08de2 add      sp, sp, #0xc
44637140 3080bde8 pop      {r4, r5, pc}
44637144 f0412de9 push     {r4, r5, r6, r7, r8, lr}
44637148 0040a0e1 mov      r4, r0
4463714c 0150a0e1 mov      r5, r1
44637150 0060a0e3 mov      r6, #0
44637154 9c0100eb bl       #0x446377cc
44637158 f0201fe5 ldr      r2, [pc, #-0xf0]
4463715c 0110a0e3 mov      r1, #1
44637160 1100a0e1 lsl      r0, r1, r0
44637164 0420d2e7 ldrb     r2, [r2, r4]
44637168 c0c51fe5 ldr      ip, [pc, #-0x5c0]
4463716c 0008a0e1 lsl      r0, r0, #0x10
44637170 1112a0e1 lsl      r1, r1, r2
44637174 fc201fe5 ldr      r2, [pc, #-0xfc]
44637178 0118a0e1 lsl      r1, r1, #0x10
4463717c 847082e0 add      r7, r2, r4, lsl #1
44637180 0030e0e3 mvn      r3, #0
44637184 2008a0e1 lsr      r0, r0, #0x10
44637188 2118a0e1 lsr      r1, r1, #0x10
4463718c 0020a0e3 mov      r2, #0
44637190 b030c7e1 strh     r3, [r7]
44637194 823082e0 add      r3, r2, r2, lsl #1
44637198 03318ce0 add      r3, ip, r3, lsl #2
4463719c b080d3e1 ldrh     r8, [r3]
446371a0 050058e1 cmp      r8, r5
446371a4 0800001a bne      #0x446371cc
446371a8 b280d3e1 ldrh     r8, [r3, #2]
446371ac 000018e1 tst      r8, r0
446371b0 0500000a beq      #0x446371cc
446371b4 b430d3e1 ldrh     r3, [r3, #4]
446371b8 010013e1 tst      r3, r1
446371bc 0200000a beq      #0x446371cc
446371c0 0160a0e3 mov      r6, #1
446371c4 b020c7e1 strh     r2, [r7]
446371c8 030000ea b        #0x446371dc
446371cc 012082e2 add      r2, r2, #1
446371d0 0128c2e3 bic      r2, r2, #0x10000
446371d4 510052e3 cmp      r2, #0x51
446371d8 edffff3a blo      #0x44637194
446371dc 78039fe5 ldr      r0, [pc, #0x378]
446371e0 840080e0 add      r0, r0, r4, lsl #1
446371e4 b050c0e1 strh     r5, [r0]
446371e8 0600a0e1 mov      r0, r6
446371ec f081bde8 pop      {r4, r5, r6, r7, r8, pc}
446371f0 01c0a0e1 mov      ip, r1
446371f4 0020a0e1 mov      r2, r0
446371f8 04e02de5 str      lr, [sp, #-4]!
446371fc 07ffffeb bl       #0x44636e20
44637200 0030b0e1 movs     r3, r0
44637204 54039f05 ldreq    r0, [pc, #0x354]
44637208 0200d007 ldrbeq   r0, [r0, r2]
4463720c 0600000a beq      #0x4463722c
44637210 98011fe5 ldr      r0, [pc, #-0x198]
44637214 6c161fe5 ldr      r1, [pc, #-0x66c]
44637218 820080e0 add      r0, r0, r2, lsl #1
4463721c b000d0e1 ldrh     r0, [r0]
44637220 800080e0 add      r0, r0, r0, lsl #1
44637224 000181e0 add      r0, r1, r0, lsl #2
44637228 0600d0e5 ldrb     r0, [r0, #6]
4463722c 30139fe5 ldr      r1, [pc, #0x330]
44637230 800080e0 add      r0, r0, r0, lsl #1
44637234 000181e0 add      r0, r1, r0, lsl #2
44637238 00008ce5 str      r0, [ip]
4463723c 0300a0e1 mov      r0, r3
44637240 04f09de4 pop      {pc}
44637244 0130a0e1 mov      r3, r1
44637248 0020a0e1 mov      r2, r0
4463724c 04e02de5 str      lr, [sp, #-4]!
44637250 f2feffeb bl       #0x44636e20
44637254 000050e3 cmp      r0, #0
44637258 00039f05 ldreq    r0, [pc, #0x300]
4463725c 0200d007 ldrbeq   r0, [r0, r2]
44637260 0600000a beq      #0x44637280
44637264 ec011fe5 ldr      r0, [pc, #-0x1ec]
44637268 c0161fe5 ldr      r1, [pc, #-0x6c0]
4463726c 820080e0 add      r0, r0, r2, lsl #1
44637270 b000d0e1 ldrh     r0, [r0]
44637274 800080e0 add      r0, r0, r0, lsl #1
44637278 000181e0 add      r0, r1, r0, lsl #2
4463727c 0600d0e5 ldrb     r0, [r0, #6]
44637280 e0129fe5 ldr      r1, [pc, #0x2e0]
44637284 000181e0 add      r0, r1, r0, lsl #2
44637288 000083e5 str      r0, [r3]
4463728c 04f09de4 pop      {pc}
44637290 d4229fe5 ldr      r2, [pc, #0x2d4]
44637294 0000d2e7 ldrb     r0, [r2, r0]
44637298 102082e2 add      r2, r2, #0x10
4463729c 000182e0 add      r0, r2, r0, lsl #2
446372a0 000081e5 str      r0, [r1]
446372a4 1eff2fe1 bx       lr
446372a8 04171fe5 ldr      r1, [pc, #-0x704]
446372ac 0000d1e7 ldrb     r0, [r1, r0]
446372b0 44121fe5 ldr      r1, [pc, #-0x244]
446372b4 000181e0 add      r0, r1, r0, lsl #2
446372b8 0100d0e5 ldrb     r0, [r0, #1]
446372bc 1eff2fe1 bx       lr
446372c0 5c121fe5 ldr      r1, [pc, #-0x25c]
446372c4 0000d1e7 ldrb     r0, [r1, r0]
446372c8 1eff2fe1 bx       lr
446372cc 68221fe5 ldr      r2, [pc, #-0x268]
446372d0 0030d2e7 ldrb     r3, [r2, r0]
446372d4 010053e1 cmp      r3, r1
446372d8 1eff2f01 bxeq     lr
446372dc 0010c2e7 strb     r1, [r2, r0]
446372e0 36feffea b        #0x44636bc0
446372e4 40171fe5 ldr      r1, [pc, #-0x740]
446372e8 0000d1e7 ldrb     r0, [r1, r0]
446372ec 000050e3 cmp      r0, #0
446372f0 0100a013 movne    r0, #1
446372f4 1eff2fe1 bx       lr
446372f8 54171fe5 ldr      r1, [pc, #-0x754]
446372fc 0000d1e7 ldrb     r0, [r1, r0]
44637300 0b0050e3 cmp      r0, #0xb
44637304 0100a003 moveq    r0, #1
44637308 0000a013 movne    r0, #0
4463730c 1eff2fe1 bx       lr
44637310 30402de9 push     {r4, r5, lr}
44637314 0cd04de2 sub      sp, sp, #0xc
44637318 0050a0e1 mov      r5, r0
4463731c 98fdffeb bl       #0x44636984
44637320 0a0055e3 cmp      r5, #0xa
44637324 0040a0e1 mov      r4, r0
44637328 05f19f37 ldrlo    pc, [pc, r5, lsl #2]
4463732c 1d0000ea b        #0x446373a8
44637330 58736344 strbtmi  r7, [r3], #-0x358
44637334 60736344 strbtmi  r7, [r3], #-0x360
44637338 68736344 strbtmi  r7, [r3], #-0x368
4463733c 70736344 strbtmi  r7, [r3], #-0x370
44637340 78736344 strbtmi  r7, [r3], #-0x378
44637344 80736344 strbtmi  r7, [r3], #-0x380
44637348 88736344 strbtmi  r7, [r3], #-0x388
4463734c 90736344 strbtmi  r7, [r3], #-0x390
44637350 98736344 strbtmi  r7, [r3], #-0x398
44637354 a0736344 strbtmi  r7, [r3], #-0x3a0
44637358 0040a0e3 mov      r4, #0
4463735c 1d0000ea b        #0x446373d8
44637360 0140a0e3 mov      r4, #1
44637364 1b0000ea b        #0x446373d8
44637368 0240a0e3 mov      r4, #2
4463736c 190000ea b        #0x446373d8
44637370 0340a0e3 mov      r4, #3
44637374 170000ea b        #0x446373d8
44637378 0440a0e3 mov      r4, #4
4463737c 150000ea b        #0x446373d8
44637380 0540a0e3 mov      r4, #5
44637384 130000ea b        #0x446373d8
44637388 0640a0e3 mov      r4, #6
4463738c 110000ea b        #0x446373d8
44637390 0740a0e3 mov      r4, #7
44637394 0f0000ea b        #0x446373d8
44637398 0840a0e3 mov      r4, #8
4463739c 0d0000ea b        #0x446373d8
446373a0 0940a0e3 mov      r4, #9
446373a4 0b0000ea b        #0x446373d8
446373a8 a4b6ffeb bl       #0x44624e40
446373ac 000050e3 cmp      r0, #0
446373b0 0800000a beq      #0x446373d8
446373b4 fe2fa0e3 mov      r2, #0x3f8
446373b8 ce1f4fe2 sub      r1, pc, #0x338
446373bc cf0f4fe2 sub      r0, pc, #0x33c
446373c0 07008de8 stm      sp, {r0, r1, r2}
446373c4 0030a0e3 mov      r3, #0
446373c8 0320a0e1 mov      r2, r3
446373cc d31f4fe2 sub      r1, pc, #0x34c
446373d0 d30f4fe2 sub      r0, pc, #0x34c
446373d4 629905eb bl       #0x4479d964
446373d8 0400a0e1 mov      r0, r4
446373dc 0cd08de2 add      sp, sp, #0xc
446373e0 3080bde8 pop      {r4, r5, pc}
446373e4 10402de9 push     {r4, lr}
446373e8 8c131fe5 ldr      r1, [pc, #-0x38c]
446373ec 0040a0e3 mov      r4, #0
446373f0 0000c1e5 strb     r0, [r1]
446373f4 62fdffeb bl       #0x44636984
446373f8 000050e3 cmp      r0, #0
446373fc 1080bd98 popls    {r4, pc}
44637400 0400a0e1 mov      r0, r4
44637404 edfdffeb bl       #0x44636bc0
44637408 010084e2 add      r0, r4, #1
4463740c ff4000e2 and      r4, r0, #0xff
44637410 5bfdffeb bl       #0x44636984
44637414 040050e1 cmp      r0, r4
44637418 f8ffff8a bhi      #0x44637400
4463741c 1080bde8 pop      {r4, pc}
44637420 34319fe5 ldr      r3, [pc, #0x134]
44637424 0020a0e1 mov      r2, r0
44637428 822083e0 add      r2, r3, r2, lsl #1
4463742c b020d2e1 ldrh     r2, [r2]
44637430 38319fe5 ldr      r3, [pc, #0x138]
44637434 0000a0e3 mov      r0, #0
44637438 0010a0e1 mov      r1, r0
4463743c 81c083e0 add      ip, r3, r1, lsl #1
44637440 b0c0dce1 ldrh     ip, [ip]
44637444 0c0052e1 cmp      r2, ip
44637448 0100001a bne      #0x44637454
4463744c 0100a0e3 mov      r0, #1
44637450 1eff2fe1 bx       lr
44637454 011081e2 add      r1, r1, #1
44637458 0118d1e3 bics     r1, r1, #0x10000
4463745c f6ffff0a beq      #0x4463743c
44637460 1eff2fe1 bx       lr
44637464 08319fe5 ldr      r3, [pc, #0x108]
44637468 0000a0e3 mov      r0, #0
4463746c 0020a0e1 mov      r2, r0
44637470 82c083e0 add      ip, r3, r2, lsl #1
44637474 b0c0dce1 ldrh     ip, [ip]
44637478 01005ce1 cmp      ip, r1
4463747c 0100001a bne      #0x44637488
44637480 0100a0e3 mov      r0, #1
44637484 1eff2fe1 bx       lr
44637488 012082e2 add      r2, r2, #1
4463748c 0128c2e3 bic      r2, r2, #0x10000
44637490 020052e3 cmp      r2, #2
44637494 f5ffff3a blo      #0x44637470
44637498 1eff2fe1 bx       lr
4463749c c8109fe5 ldr      r1, [pc, #0xc8]
446374a0 0000d1e7 ldrb     r0, [r1, r0]
446374a4 cc109fe5 ldr      r1, [pc, #0xcc]
446374a8 800080e0 add      r0, r0, r0, lsl #1
446374ac 000181e0 add      r0, r1, r0, lsl #2
446374b0 b000d0e1 ldrh     r0, [r0]
446374b4 1eff2fe1 bx       lr
446374b8 ac309fe5 ldr      r3, [pc, #0xac]
446374bc 0000d3e7 ldrb     r0, [r3, r0]
446374c0 803080e0 add      r3, r0, r0, lsl #1
446374c4 ac009fe5 ldr      r0, [pc, #0xac]
446374c8 030180e0 add      r0, r0, r3, lsl #2
446374cc 043090e5 ldr      r3, [r0, #4]
446374d0 b030c1e1 strh     r3, [r1]
446374d4 080090e5 ldr      r0, [r0, #8]
446374d8 b000c2e1 strh     r0, [r2]
446374dc 1eff2fe1 bx       lr
446374e0 fa00a0e3 mov      r0, #0xfa
446374e4 1eff2fe1 bx       lr
446374e8 70402de9 push     {r4, r5, r6, lr}
446374ec 0050a0e1 mov      r5, r0
446374f0 0240a0e3 mov      r4, #2
446374f4 20fdffeb bl       #0x4463697c
446374f8 050050e1 cmp      r0, r5
446374fc 0040a083 movhi    r4, #0
44637500 0400a0e1 mov      r0, r4
44637504 7080bde8 pop      {r4, r5, r6, pc}
44637508 0000a0e3 mov      r0, #0
4463750c 1eff2fe1 bx       lr
44637510 64009fe5 ldr      r0, [pc, #0x64]
44637514 1eff2fe1 bx       lr
44637518 04e02de5 str      lr, [sp, #-4]!
4463751c 0cd04de2 sub      sp, sp, #0xc
44637520 46b6ffeb bl       #0x44624e40
44637524 000050e3 cmp      r0, #0
44637528 0800000a beq      #0x44637550
4463752c 4c209fe5 ldr      r2, [pc, #0x4c]
44637530 4c108fe2 add      r1, pc, #0x4c
44637534 48008fe2 add      r0, pc, #0x48
44637538 07008de8 stm      sp, {r0, r1, r2}
4463753c 0030a0e3 mov      r3, #0
44637540 0320a0e1 mov      r2, r3
44637544 38108fe2 add      r1, pc, #0x38
44637548 38008fe2 add      r0, pc, #0x38
4463754c 049905eb bl       #0x4479d964
44637550 0000a0e3 mov      r0, #0
44637554 0cd08de2 add      sp, sp, #0xc
44637558 04f09de4 pop      {pc}
4463755c d8bb9844 ldrmi    fp, [r8], #0xbd8
44637560 f0bb9844 ldrmi    fp, [r8], #0xbf0
44637564 98c98344 strmi    ip, [r3], #0x998
44637568 56c98344 strmi    ip, [r3], #0x956
4463756c 4ec98344 strmi    ip, [r3], #0x94e
44637570 4cc98344 strmi    ip, [r3], #0x94c
44637574 52c98344 strmi    ip, [r3], #0x952
44637578 7ccd8344 strmi    ip, [r3], #0xd7c
4463757c 8be22609 stmdbeq  r6!, {r0, r1, r3, r7, sb, sp, lr, pc}
44637580 b5040000 strheq   r0, [r0], -r5
44637584 00000000 andeq    r0, r0, r0
44637588 30000000 andeq    r0, r0, r0, lsr r0
4463758c 0010b0e1 movs     r1, r0
44637590 0100a0e3 mov      r0, #1
44637594 0000a013 movne    r0, #0
44637598 1eff2fe1 bx       lr
4463759c 0000a0e3 mov      r0, #0
446375a0 1eff2fe1 bx       lr
446375a4 0000a0e3 mov      r0, #0
446375a8 1eff2fe1 bx       lr
446375ac 10402de9 push     {r4, lr}
446375b0 0040a0e1 mov      r4, r0
446375b4 f2fcffeb bl       #0x44636984
446375b8 031044e2 sub      r1, r4, #3
446375bc 060051e3 cmp      r1, #6
446375c0 01f19f37 ldrlo    pc, [pc, r1, lsl #2]
446375c4 1080bde8 pop      {r4, pc}
446375c8 e0756344 strbtmi  r7, [r3], #-0x5e0
446375cc e8756344 strbtmi  r7, [r3], #-0x5e8
446375d0 e8756344 strbtmi  r7, [r3], #-0x5e8
446375d4 e0756344 strbtmi  r7, [r3], #-0x5e0
446375d8 e0756344 strbtmi  r7, [r3], #-0x5e0
446375dc e8756344 strbtmi  r7, [r3], #-0x5e8
446375e0 0000a0e3 mov      r0, #0
446375e4 1080bde8 pop      {r4, pc}
446375e8 0100a0e3 mov      r0, #1
446375ec 1080bde8 pop      {r4, pc}
446375f0 1eff2fe1 bx       lr
446375f4 1eff2fe1 bx       lr
446375f8 0100a0e3 mov      r0, #1
446375fc 1eff2fe1 bx       lr
44637600 1eff2fe1 bx       lr
44637604 1eff2fe1 bx       lr
44637608 0000a0e3 mov      r0, #0
4463760c 1eff2fe1 bx       lr
44637610 20209fe5 ldr      r2, [pc, #0x20]
44637614 0010c2e7 strb     r1, [r2, r0]
44637618 1eff2fe1 bx       lr
4463761c 14109fe5 ldr      r1, [pc, #0x14]
44637620 0000d1e7 ldrb     r0, [r1, r0]
44637624 1eff2fe1 bx       lr
44637628 0c009fe5 ldr      r0, [pc, #0xc]
4463762c 1eff2fe1 bx       lr
44637630 08009fe5 ldr      r0, [pc, #8]
44637634 1eff2fe1 bx       lr
44637638 9cbb9844 ldrmi    fp, [r8], #0xb9c
4463763c 94cd8344 strmi    ip, [r3], #0xd94
44637640 a0cd8344 strmi    ip, [r3], #0xda0
44637644 70402de9 push     {r4, r5, r6, lr}
44637648 0010a0e3 mov      r1, #0
4463764c 3d00a0e3 mov      r0, #0x3d
44637650 fe7fffeb bl       #0x44617650
44637654 0050a0e1 mov      r5, r0
44637658 0010a0e3 mov      r1, #0
4463765c 3e00a0e3 mov      r0, #0x3e
44637660 fa7fffeb bl       #0x44617650
44637664 0040a0e1 mov      r4, r0
44637668 0010a0e3 mov      r1, #0
4463766c 3f00a0e3 mov      r0, #0x3f
44637670 f67fffeb bl       #0x44617650
44637674 c0129fe5 ldr      r1, [pc, #0x2c0]
44637678 020055e3 cmp      r5, #2
4463767c 0060a0e3 mov      r6, #0
44637680 0120a0e3 mov      r2, #1
44637684 04608105 streq    r6, [r1, #4]
44637688 04208115 strne    r2, [r1, #4]
4463768c 080054e3 cmp      r4, #8
44637690 0230a0e3 mov      r3, #2
44637694 03c0a0e3 mov      ip, #3
44637698 0450a0e3 mov      r5, #4
4463769c 04f19f37 ldrlo    pc, [pc, r4, lsl #2]
446376a0 170000ea b        #0x44637704
446376a4 04776344 strbtmi  r7, [r3], #-0x704
446376a8 c4766344 strbtmi  r7, [r3], #-0x6c4
446376ac cc766344 strbtmi  r7, [r3], #-0x6cc
446376b0 d4766344 strbtmi  r7, [r3], #-0x6d4
446376b4 dc766344 strbtmi  r7, [r3], #-0x6dc
446376b8 e4766344 strbtmi  r7, [r3], #-0x6e4
446376bc ec766344 strbtmi  r7, [r3], #-0x6ec
446376c0 f8766344 strbtmi  r7, [r3], #-0x6f8
446376c4 0020c1e5 strb     r2, [r1]
446376c8 0e0000ea b        #0x44637708
446376cc 0030c1e5 strb     r3, [r1]
446376d0 0c0000ea b        #0x44637708
446376d4 00c0c1e5 strb     ip, [r1]
446376d8 0a0000ea b        #0x44637708
446376dc 0050c1e5 strb     r5, [r1]
446376e0 080000ea b        #0x44637708
446376e4 0540a0e3 mov      r4, #5
446376e8 000000ea b        #0x446376f0
446376ec 0640a0e3 mov      r4, #6
446376f0 0040c1e5 strb     r4, [r1]
446376f4 030000ea b        #0x44637708
446376f8 0740a0e3 mov      r4, #7
446376fc 0040c1e5 strb     r4, [r1]
44637700 000000ea b        #0x44637708
44637704 0060c1e5 strb     r6, [r1]
44637708 010050e3 cmp      r0, #1
4463770c 0120c105 strbeq   r2, [r1, #1]
44637710 7080bd08 popeq    {r4, r5, r6, pc}
44637714 020050e3 cmp      r0, #2
44637718 0130c105 strbeq   r3, [r1, #1]
4463771c 7080bd08 popeq    {r4, r5, r6, pc}
44637720 030050e3 cmp      r0, #3
44637724 01c0c105 strbeq   ip, [r1, #1]
44637728 7080bd08 popeq    {r4, r5, r6, pc}
4463772c 040050e3 cmp      r0, #4
44637730 0160c115 strbne   r6, [r1, #1]
44637734 0150c105 strbeq   r5, [r1, #1]
44637738 7080bde8 pop      {r4, r5, r6, pc}
4463773c 10402de9 push     {r4, lr}
44637740 0040a0e3 mov      r4, #0
44637744 0410a0e1 mov      r1, r4
44637748 3d00a0e3 mov      r0, #0x3d
4463774c bf7fffeb bl       #0x44617650
44637750 000050e3 cmp      r0, #0
44637754 0900001a bne      #0x44637780
44637758 0010a0e3 mov      r1, #0
4463775c 3e00a0e3 mov      r0, #0x3e
44637760 ba7fffeb bl       #0x44617650
44637764 000050e3 cmp      r0, #0
44637768 0400001a bne      #0x44637780
4463776c 0010a0e3 mov      r1, #0
44637770 3f00a0e3 mov      r0, #0x3f
44637774 b57fffeb bl       #0x44617650
44637778 000050e3 cmp      r0, #0
4463777c 0140a003 moveq    r4, #1
44637780 0400a0e1 mov      r0, r4
44637784 1080bde8 pop      {r4, pc}
44637788 0020a0e3 mov      r2, #0
4463778c 10402de9 push     {r4, lr}
44637790 0210a0e1 mov      r1, r2
44637794 3d00a0e3 mov      r0, #0x3d
44637798 d57fffeb bl       #0x446176f4
4463779c 0020a0e3 mov      r2, #0
446377a0 0210a0e1 mov      r1, r2
446377a4 3e00a0e3 mov      r0, #0x3e
446377a8 d17fffeb bl       #0x446176f4
446377ac 1040bde8 pop      {r4, lr}
446377b0 0020a0e3 mov      r2, #0
446377b4 0210a0e1 mov      r1, r2
446377b8 3f00a0e3 mov      r0, #0x3f
446377bc cc7fffea b        #0x446176f4
446377c0 74019fe5 ldr      r0, [pc, #0x174]
446377c4 040090e5 ldr      r0, [r0, #4]
446377c8 1eff2fe1 bx       lr
446377cc 68019fe5 ldr      r0, [pc, #0x168]
446377d0 0000d0e5 ldrb     r0, [r0]
446377d4 1eff2fe1 bx       lr
446377d8 5c019fe5 ldr      r0, [pc, #0x15c]
446377dc 0000d0e5 ldrb     r0, [r0]
446377e0 030050e3 cmp      r0, #3
446377e4 0100a003 moveq    r0, #1
446377e8 0000a013 movne    r0, #0
446377ec 1eff2fe1 bx       lr
446377f0 44119fe5 ldr      r1, [pc, #0x144]
446377f4 0000a0e3 mov      r0, #0
446377f8 0110d1e5 ldrb     r1, [r1, #1]
446377fc 020051e3 cmp      r1, #2
44637800 03005113 cmpne    r1, #3
44637804 0100a003 moveq    r0, #1
44637808 1eff2fe1 bx       lr
4463780c f1ffffea b        #0x446377d8
44637810 24019fe5 ldr      r0, [pc, #0x124]
44637814 0100d0e5 ldrb     r0, [r0, #1]
44637818 000050e3 cmp      r0, #0
4463781c 0100a013 movne    r0, #1
44637820 1eff2fe1 bx       lr
44637824 10119fe5 ldr      r1, [pc, #0x110]
44637828 0000a0e3 mov      r0, #0
4463782c 0110d1e5 ldrb     r1, [r1, #1]
44637830 010051e3 cmp      r1, #1
44637834 02005113 cmpne    r1, #2
44637838 04005113 cmpne    r1, #4
4463783c 0100a003 moveq    r0, #1
44637840 1eff2fe1 bx       lr
44637844 f0109fe5 ldr      r1, [pc, #0xf0]
44637848 0000a0e3 mov      r0, #0
4463784c 0110d1e5 ldrb     r1, [r1, #1]
44637850 020051e3 cmp      r1, #2
44637854 03005113 cmpne    r1, #3
44637858 0100a003 moveq    r0, #1
4463785c 1eff2fe1 bx       lr
44637860 d4109fe5 ldr      r1, [pc, #0xd4]
44637864 0000a0e3 mov      r0, #0
44637868 0110d1e5 ldrb     r1, [r1, #1]
4463786c 020051e3 cmp      r1, #2
44637870 03005113 cmpne    r1, #3
44637874 04005113 cmpne    r1, #4
44637878 0100a003 moveq    r0, #1
4463787c 1eff2fe1 bx       lr
44637880 10402de9 push     {r4, lr}
44637884 0040a0e3 mov      r4, #0
44637888 0410a0e1 mov      r1, r4
4463788c 4000a0e3 mov      r0, #0x40
44637890 6b82ffeb bl       #0x44618244
44637894 000050e3 cmp      r0, #0
44637898 0140a013 movne    r4, #1
4463789c 0400a0e1 mov      r0, r4
446378a0 1080bde8 pop      {r4, pc}
446378a4 10402de9 push     {r4, lr}
446378a8 0040a0e3 mov      r4, #0
446378ac 0110a0e3 mov      r1, #1
446378b0 4000a0e3 mov      r0, #0x40
446378b4 6282ffeb bl       #0x44618244
446378b8 000050e3 cmp      r0, #0
446378bc 0140a013 movne    r4, #1
446378c0 0400a0e1 mov      r0, r4
446378c4 1080bde8 pop      {r4, pc}
446378c8 10402de9 push     {r4, lr}
446378cc 0040a0e3 mov      r4, #0
446378d0 0210a0e3 mov      r1, #2
446378d4 4000a0e3 mov      r0, #0x40
446378d8 5982ffeb bl       #0x44618244
446378dc 000050e3 cmp      r0, #0
446378e0 0140a013 movne    r4, #1
446378e4 0400a0e1 mov      r0, r4
446378e8 1080bde8 pop      {r4, pc}
446378ec 0100a0e3 mov      r0, #1
446378f0 1eff2fe1 bx       lr
446378f4 10402de9 push     {r4, lr}
446378f8 0040a0e3 mov      r4, #0
446378fc 0310a0e3 mov      r1, #3
44637900 4000a0e3 mov      r0, #0x40
44637904 4e82ffeb bl       #0x44618244
44637908 000050e3 cmp      r0, #0
4463790c 0140a013 movne    r4, #1
44637910 0400a0e1 mov      r0, r4
44637914 1080bde8 pop      {r4, pc}
44637918 10402de9 push     {r4, lr}
4463791c 0040a0e3 mov      r4, #0
44637920 0410a0e3 mov      r1, #4
44637924 4000a0e3 mov      r0, #0x40
44637928 4582ffeb bl       #0x44618244
4463792c 000050e3 cmp      r0, #0
44637930 0140a013 movne    r4, #1
44637934 0400a0e1 mov      r0, r4
44637938 1080bde8 pop      {r4, pc}
4463793c bca08e44 strmi    sl, [lr], #0xbc
44637940 70402de9 push     {r4, r5, r6, lr}
44637944 10d04de2 sub      sp, sp, #0x10
44637948 0dfcffeb bl       #0x44636984
4463794c 0060a0e1 mov      r6, r0
44637950 09fcffeb bl       #0x4463697c
44637954 1cc19fe5 ldr      ip, [pc, #0x11c]
44637958 0040a0e1 mov      r4, r0
4463795c 0020a0e3 mov      r2, #0
44637960 0c504ce2 sub      r5, ip, #0xc
44637964 820082e0 add      r0, r2, r2, lsl #1
44637968 0010a0e3 mov      r1, #0
4463796c 00328ce0 add      r3, ip, r0, lsl #4
44637970 010193e7 ldr      r0, [r3, r1, lsl #2]
44637974 000050e3 cmp      r0, #0
44637978 0300000a beq      #0x4463798c
4463797c 010081e2 add      r0, r1, #1
44637980 ff1000e2 and      r1, r0, #0xff
44637984 0c0051e3 cmp      r1, #0xc
44637988 f8ffff3a blo      #0x44637970
4463798c 060051e1 cmp      r1, r6
44637990 0100001a bne      #0x4463799c
44637994 0020c5e5 strb     r2, [r5]
44637998 020000ea b        #0x446379a8
4463799c 010082e2 add      r0, r2, #1
446379a0 ff2010e2 ands     r2, r0, #0xff
446379a4 eeffff0a beq      #0x44637964
446379a8 0000d5e5 ldrb     r0, [r5]
446379ac 020050e1 cmp      r0, r2
446379b0 0b00009a bls      #0x446379e4
446379b4 21b5ffeb bl       #0x44624e40
446379b8 000050e3 cmp      r0, #0
446379bc 0800000a beq      #0x446379e4
446379c0 dc20a0e3 mov      r2, #0xdc
446379c4 b0108fe2 add      r1, pc, #0xb0
446379c8 ac008fe2 add      r0, pc, #0xac
446379cc 07008de8 stm      sp, {r0, r1, r2}
446379d0 0030a0e3 mov      r3, #0
446379d4 0320a0e1 mov      r2, r3
446379d8 9c108fe2 add      r1, pc, #0x9c
446379dc 9c008fe2 add      r0, pc, #0x9c
446379e0 df9705eb bl       #0x4479d964
446379e4 98c09fe5 ldr      ip, [pc, #0x98]
446379e8 0020a0e3 mov      r2, #0
446379ec 0010a0e3 mov      r1, #0
446379f0 02328ce0 add      r3, ip, r2, lsl #4
446379f4 010193e7 ldr      r0, [r3, r1, lsl #2]
446379f8 000050e3 cmp      r0, #0
446379fc 0300000a beq      #0x44637a10
44637a00 010081e2 add      r0, r1, #1
44637a04 ff1000e2 and      r1, r0, #0xff
44637a08 040051e3 cmp      r1, #4
44637a0c f8ffff3a blo      #0x446379f4
44637a10 040051e1 cmp      r1, r4
44637a14 0100001a bne      #0x44637a20
44637a18 0120c5e5 strb     r2, [r5, #1]
44637a1c 020000ea b        #0x44637a2c
44637a20 010082e2 add      r0, r2, #1
44637a24 ff2010e2 ands     r2, r0, #0xff
44637a28 efffff0a beq      #0x446379ec
44637a2c 0100d5e5 ldrb     r0, [r5, #1]
44637a30 020050e1 cmp      r0, r2
44637a34 10d08d92 addls    sp, sp, #0x10
44637a38 7080bd98 popls    {r4, r5, r6, pc}
44637a3c ffb4ffeb bl       #0x44624e40
44637a40 000050e3 cmp      r0, #0
44637a44 10d08d02 addeq    sp, sp, #0x10
44637a48 7080bd08 popeq    {r4, r5, r6, pc}
44637a4c ef20a0e3 mov      r2, #0xef
44637a50 24108fe2 add      r1, pc, #0x24
44637a54 20008fe2 add      r0, pc, #0x20
44637a58 07008de8 stm      sp, {r0, r1, r2}
44637a5c 0030a0e3 mov      r3, #0
44637a60 0320a0e1 mov      r2, r3
44637a64 10108fe2 add      r1, pc, #0x10
44637a68 10008fe2 add      r0, pc, #0x10
44637a6c bc9705eb bl       #0x4479d964
44637a70 10d08de2 add      sp, sp, #0x10
44637a74 7080bde8 pop      {r4, r5, r6, pc}
44637a78 d0a08e44 strmi    sl, [lr], #0xd0
44637a7c 00000000 andeq    r0, r0, r0
44637a80 30000000 andeq    r0, r0, r0, lsr r0
44637a84 00a18e44 strmi    sl, [lr], #0x100
44637a88 f0432de9 push     {r4, r5, r6, r7, r8, sb, lr}
44637a8c 0cd04de2 sub      sp, sp, #0xc
44637a90 bbfbffeb bl       #0x44636984
44637a94 0040a0e1 mov      r4, r0
44637a98 b7fbffeb bl       #0x4463697c
44637a9c 2c301fe5 ldr      r3, [pc, #-0x2c]
44637aa0 0010a0e3 mov      r1, #0
44637aa4 0c5043e2 sub      r5, r3, #0xc
44637aa8 0020d5e5 ldrb     r2, [r5]
44637aac 047085e2 add      r7, r5, #4
44637ab0 0180a0e1 mov      r8, r1
44637ab4 822082e0 add      r2, r2, r2, lsl #1
44637ab8 02c283e0 add      ip, r3, r2, lsl #4
44637abc 0120d5e5 ldrb     r2, [r5, #1]
44637ac0 3c3085e2 add      r3, r5, #0x3c
44637ac4 049087e2 add      sb, r7, #4
44637ac8 026283e0 add      r6, r3, r2, lsl #4
44637acc 000054e3 cmp      r4, #0
44637ad0 0020a0e3 mov      r2, #0
44637ad4 0180c7e7 strb     r8, [r7, r1]
44637ad8 0a00009a bls      #0x44637b08
44637adc 02319ce7 ldr      r3, [ip, r2, lsl #2]
44637ae0 0030d3e5 ldrb     r3, [r3]
44637ae4 010053e1 cmp      r3, r1
44637ae8 0200001a bne      #0x44637af8
44637aec 0130d7e7 ldrb     r3, [r7, r1]
44637af0 013083e2 add      r3, r3, #1
44637af4 0130c7e7 strb     r3, [r7, r1]
44637af8 012082e2 add      r2, r2, #1
44637afc ff2002e2 and      r2, r2, #0xff
44637b00 040052e1 cmp      r2, r4
44637b04 f4ffff3a blo      #0x44637adc
44637b08 000050e3 cmp      r0, #0
44637b0c 0020a0e3 mov      r2, #0
44637b10 0180c9e7 strb     r8, [sb, r1]
44637b14 0a00009a bls      #0x44637b44
44637b18 023196e7 ldr      r3, [r6, r2, lsl #2]
44637b1c 0030d3e5 ldrb     r3, [r3]
44637b20 010053e1 cmp      r3, r1
44637b24 0200001a bne      #0x44637b34
44637b28 0130d9e7 ldrb     r3, [sb, r1]
44637b2c 013083e2 add      r3, r3, #1
44637b30 0130c9e7 strb     r3, [sb, r1]
44637b34 012082e2 add      r2, r2, #1
44637b38 ff2002e2 and      r2, r2, #0xff
44637b3c 000052e1 cmp      r2, r0
44637b40 f4ffff3a blo      #0x44637b18
44637b44 011081e2 add      r1, r1, #1
44637b48 ff1001e2 and      r1, r1, #0xff
44637b4c 040051e3 cmp      r1, #4
44637b50 ddffff3a blo      #0x44637acc
44637b54 54649fe5 ldr      r6, [pc, #0x454]
44637b58 00c0a0e3 mov      ip, #0
44637b5c 0020a0e3 mov      r2, #0
44637b60 0210a0e1 mov      r1, r2
44637b64 0c8186e0 add      r8, r6, ip, lsl #2
44637b68 0130d8e7 ldrb     r3, [r8, r1]
44637b6c 050053e3 cmp      r3, #5
44637b70 0200000a beq      #0x44637b80
44637b74 0330d7e7 ldrb     r3, [r7, r3]
44637b78 032082e0 add      r2, r2, r3
44637b7c ff2002e2 and      r2, r2, #0xff
44637b80 011081e2 add      r1, r1, #1
44637b84 ff1001e2 and      r1, r1, #0xff
44637b88 040051e3 cmp      r1, #4
44637b8c f5ffff3a blo      #0x44637b68
44637b90 020054e1 cmp      r4, r2
44637b94 0020a003 moveq    r2, #0
44637b98 0210a001 moveq    r1, r2
44637b9c 0d00001a bne      #0x44637bd8
44637ba0 0130d8e7 ldrb     r3, [r8, r1]
44637ba4 050053e3 cmp      r3, #5
44637ba8 0200000a beq      #0x44637bb8
44637bac 0330d9e7 ldrb     r3, [sb, r3]
44637bb0 032082e0 add      r2, r2, r3
44637bb4 ff2002e2 and      r2, r2, #0xff
44637bb8 011081e2 add      r1, r1, #1
44637bbc ff1001e2 and      r1, r1, #0xff
44637bc0 040051e3 cmp      r1, #4
44637bc4 f5ffff3a blo      #0x44637ba0
44637bc8 020050e1 cmp      r0, r2
44637bcc 0100001a bne      #0x44637bd8
44637bd0 02c0c5e5 strb     ip, [r5, #2]
44637bd4 020000ea b        #0x44637be4
44637bd8 01108ce2 add      r1, ip, #1
44637bdc ffc011e2 ands     ip, r1, #0xff
44637be0 ddffff0a beq      #0x44637b5c
44637be4 0200d5e5 ldrb     r0, [r5, #2]
44637be8 0c0050e1 cmp      r0, ip
44637bec 0b00009a bls      #0x44637c20
44637bf0 92b4ffeb bl       #0x44624e40
44637bf4 000050e3 cmp      r0, #0
44637bf8 0800000a beq      #0x44637c20
44637bfc b0239fe5 ldr      r2, [pc, #0x3b0]
44637c00 631f4fe2 sub      r1, pc, #0x18c
44637c04 190e4fe2 sub      r0, pc, #0x190
44637c08 07008de8 stm      sp, {r0, r1, r2}
44637c0c 0030a0e3 mov      r3, #0
44637c10 0320a0e1 mov      r2, r3
44637c14 1a1e4fe2 sub      r1, pc, #0x1a0
44637c18 1a0e4fe2 sub      r0, pc, #0x1a0
44637c1c 509705eb bl       #0x4479d964
44637c20 0210d5e5 ldrb     r1, [r5, #2]
44637c24 0000a0e3 mov      r0, #0
44637c28 011186e0 add      r1, r6, r1, lsl #2
44637c2c 0020d1e7 ldrb     r2, [r1, r0]
44637c30 050052e3 cmp      r2, #5
44637c34 0300000a beq      #0x44637c48
44637c38 010080e2 add      r0, r0, #1
44637c3c ff0000e2 and      r0, r0, #0xff
44637c40 040050e3 cmp      r0, #4
44637c44 f8ffff3a blo      #0x44637c2c
44637c48 040050e3 cmp      r0, #4
44637c4c 0300c5e5 strb     r0, [r5, #3]
44637c50 0cd08d92 addls    sp, sp, #0xc
44637c54 f083bd98 popls    {r4, r5, r6, r7, r8, sb, pc}
44637c58 78b4ffeb bl       #0x44624e40
44637c5c 000050e3 cmp      r0, #0
44637c60 0cd08d02 addeq    sp, sp, #0xc
44637c64 f083bd08 popeq    {r4, r5, r6, r7, r8, sb, pc}
44637c68 0030a0e3 mov      r3, #0
44637c6c 44239fe5 ldr      r2, [pc, #0x344]
44637c70 7f1f4fe2 sub      r1, pc, #0x1fc
44637c74 020c4fe2 sub      r0, pc, #0x200
44637c78 07008de8 stm      sp, {r0, r1, r2}
44637c7c 0320a0e1 mov      r2, r3
44637c80 831f4fe2 sub      r1, pc, #0x20c
44637c84 830f4fe2 sub      r0, pc, #0x20c
44637c88 359705eb bl       #0x4479d964
44637c8c 0cd08de2 add      sp, sp, #0xc
44637c90 f083bde8 pop      {r4, r5, r6, r7, r8, sb, pc}
44637c94 20039fe5 ldr      r0, [pc, #0x320]
44637c98 0300d0e5 ldrb     r0, [r0, #3]
44637c9c 1eff2fe1 bx       lr
44637ca0 14139fe5 ldr      r1, [pc, #0x314]
44637ca4 34221fe5 ldr      r2, [pc, #-0x234]
44637ca8 0010d1e5 ldrb     r1, [r1]
44637cac 811081e0 add      r1, r1, r1, lsl #1
44637cb0 011282e0 add      r1, r2, r1, lsl #4
44637cb4 000191e7 ldr      r0, [r1, r0, lsl #2]
44637cb8 0000d0e5 ldrb     r0, [r0]
44637cbc 1eff2fe1 bx       lr
44637cc0 44121fe5 ldr      r1, [pc, #-0x244]
44637cc4 3c2041e2 sub      r2, r1, #0x3c
44637cc8 0120d2e5 ldrb     r2, [r2, #1]
44637ccc 021281e0 add      r1, r1, r2, lsl #4
44637cd0 000191e7 ldr      r0, [r1, r0, lsl #2]
44637cd4 0000d0e5 ldrb     r0, [r0]
44637cd8 1eff2fe1 bx       lr
44637cdc d8229fe5 ldr      r2, [pc, #0x2d8]
44637ce0 c8129fe5 ldr      r1, [pc, #0x2c8]
44637ce4 0220d2e5 ldrb     r2, [r2, #2]
44637ce8 021181e0 add      r1, r1, r2, lsl #2
44637cec 0000d1e7 ldrb     r0, [r1, r0]
44637cf0 1eff2fe1 bx       lr
44637cf4 c0129fe5 ldr      r1, [pc, #0x2c0]
44637cf8 88221fe5 ldr      r2, [pc, #-0x288]
44637cfc 0010d1e5 ldrb     r1, [r1]
44637d00 811081e0 add      r1, r1, r1, lsl #1
44637d04 011282e0 add      r1, r2, r1, lsl #4
44637d08 000191e7 ldr      r0, [r1, r0, lsl #2]
44637d0c 0100d0e5 ldrb     r0, [r0, #1]
44637d10 1eff2fe1 bx       lr
44637d14 a4129fe5 ldr      r1, [pc, #0x2a4]
44637d18 800080e0 add      r0, r0, r0, lsl #1
44637d1c 0000d1e7 ldrb     r0, [r1, r0]
44637d20 1eff2fe1 bx       lr
44637d24 94129fe5 ldr      r1, [pc, #0x294]
44637d28 800080e0 add      r0, r0, r0, lsl #1
44637d2c 010080e0 add      r0, r0, r1
44637d30 0100d0e5 ldrb     r0, [r0, #1]
44637d34 1eff2fe1 bx       lr
44637d38 80129fe5 ldr      r1, [pc, #0x280]
44637d3c 800080e0 add      r0, r0, r0, lsl #1
44637d40 010080e0 add      r0, r0, r1
44637d44 0200d0e5 ldrb     r0, [r0, #2]
44637d48 1eff2fe1 bx       lr
44637d4c 68129fe5 ldr      r1, [pc, #0x268]
44637d50 e0221fe5 ldr      r2, [pc, #-0x2e0]
44637d54 0010d1e5 ldrb     r1, [r1]
44637d58 811081e0 add      r1, r1, r1, lsl #1
44637d5c 011282e0 add      r1, r2, r1, lsl #4
44637d60 000191e7 ldr      r0, [r1, r0, lsl #2]
44637d64 0200d0e5 ldrb     r0, [r0, #2]
44637d68 1eff2fe1 bx       lr
44637d6c 50129fe5 ldr      r1, [pc, #0x250]
44637d70 50229fe5 ldr      r2, [pc, #0x250]
44637d74 0010d1e7 ldrb     r1, [r1, r0]
44637d78 0000d2e7 ldrb     r0, [r2, r0]
44637d7c 010080e0 add      r0, r0, r1
44637d80 ff0000e2 and      r0, r0, #0xff
44637d84 1eff2fe1 bx       lr
44637d88 34129fe5 ldr      r1, [pc, #0x234]
44637d8c 0000d1e7 ldrb     r0, [r1, r0]
44637d90 000050e3 cmp      r0, #0
44637d94 0100a013 movne    r0, #1
44637d98 1eff2fe1 bx       lr
44637d9c f0402de9 push     {r4, r5, r6, r7, lr}
44637da0 0cd04de2 sub      sp, sp, #0xc
44637da4 0070a0e1 mov      r7, r0
44637da8 0040a0e3 mov      r4, #0
44637dac f2faffeb bl       #0x4463697c
44637db0 000050e3 cmp      r0, #0
44637db4 38531f85 ldrhi    r5, [pc, #-0x338]
44637db8 3c604582 subhi    r6, r5, #0x3c
44637dbc 0a00009a bls      #0x44637dec
44637dc0 0100d6e5 ldrb     r0, [r6, #1]
44637dc4 000285e0 add      r0, r5, r0, lsl #4
44637dc8 040190e7 ldr      r0, [r0, r4, lsl #2]
44637dcc 0000d0e5 ldrb     r0, [r0]
44637dd0 070050e1 cmp      r0, r7
44637dd4 0400000a beq      #0x44637dec
44637dd8 010084e2 add      r0, r4, #1
44637ddc ff4000e2 and      r4, r0, #0xff
44637de0 e5faffeb bl       #0x4463697c
44637de4 040050e1 cmp      r0, r4
44637de8 f4ffff8a bhi      #0x44637dc0
44637dec e2faffeb bl       #0x4463697c
44637df0 000054e1 cmp      r4, r0
44637df4 0c00003a blo      #0x44637e2c
44637df8 10b4ffeb bl       #0x44624e40
44637dfc 000050e3 cmp      r0, #0
44637e00 0800000a beq      #0x44637e28
44637e04 c0219fe5 ldr      r2, [pc, #0x1c0]
44637e08 e51f4fe2 sub      r1, pc, #0x394
44637e0c e60f4fe2 sub      r0, pc, #0x398
44637e10 07008de8 stm      sp, {r0, r1, r2}
44637e14 0030a0e3 mov      r3, #0
44637e18 0320a0e1 mov      r2, r3
44637e1c ea1f4fe2 sub      r1, pc, #0x3a8
44637e20 ea0f4fe2 sub      r0, pc, #0x3a8
44637e24 ce9605eb bl       #0x4479d964
44637e28 0040a0e3 mov      r4, #0
44637e2c 0400a0e1 mov      r0, r4
44637e30 0cd08de2 add      sp, sp, #0xc
44637e34 f080bde8 pop      {r4, r5, r6, r7, pc}
44637e38 7c119fe5 ldr      r1, [pc, #0x17c]
44637e3c cc231fe5 ldr      r2, [pc, #-0x3cc]
44637e40 0010d1e5 ldrb     r1, [r1]
44637e44 811081e0 add      r1, r1, r1, lsl #1
44637e48 011282e0 add      r1, r2, r1, lsl #4
44637e4c 000191e7 ldr      r0, [r1, r0, lsl #2]
44637e50 0300d0e5 ldrb     r0, [r0, #3]
44637e54 1eff2fe1 bx       lr
44637e58 5c119fe5 ldr      r1, [pc, #0x15c]
44637e5c ec231fe5 ldr      r2, [pc, #-0x3ec]
44637e60 0010d1e5 ldrb     r1, [r1]
44637e64 811081e0 add      r1, r1, r1, lsl #1
44637e68 011282e0 add      r1, r2, r1, lsl #4
44637e6c 000191e7 ldr      r0, [r1, r0, lsl #2]
44637e70 0400d0e5 ldrb     r0, [r0, #4]
44637e74 1eff2fe1 bx       lr
44637e78 3c119fe5 ldr      r1, [pc, #0x13c]
44637e7c 0c341fe5 ldr      r3, [pc, #-0x40c]
44637e80 0010d1e5 ldrb     r1, [r1]
44637e84 0020a0e1 mov      r2, r0
44637e88 0000a0e3 mov      r0, #0
44637e8c 811081e0 add      r1, r1, r1, lsl #1
44637e90 011283e0 add      r1, r3, r1, lsl #4
44637e94 021191e7 ldr      r1, [r1, r2, lsl #2]
44637e98 0410d1e5 ldrb     r1, [r1, #4]
44637e9c 020051e3 cmp      r1, #2
44637ea0 0100a003 moveq    r0, #1
44637ea4 1eff2fe1 bx       lr
44637ea8 2c141fe5 ldr      r1, [pc, #-0x42c]
44637eac 3c2041e2 sub      r2, r1, #0x3c
44637eb0 0120d2e5 ldrb     r2, [r2, #1]
44637eb4 021281e0 add      r1, r1, r2, lsl #4
44637eb8 000191e7 ldr      r0, [r1, r0, lsl #2]
44637ebc 0100d0e5 ldrb     r0, [r0, #1]
44637ec0 1eff2fe1 bx       lr
44637ec4 48141fe5 ldr      r1, [pc, #-0x448]
44637ec8 3c2041e2 sub      r2, r1, #0x3c
44637ecc 0120d2e5 ldrb     r2, [r2, #1]
44637ed0 021281e0 add      r1, r1, r2, lsl #4
44637ed4 000191e7 ldr      r0, [r1, r0, lsl #2]
44637ed8 0200d0e5 ldrb     r0, [r0, #2]
44637edc 1eff2fe1 bx       lr
44637ee0 64241fe5 ldr      r2, [pc, #-0x464]
44637ee4 0010a0e1 mov      r1, r0
44637ee8 3c3042e2 sub      r3, r2, #0x3c
44637eec 0130d3e5 ldrb     r3, [r3, #1]
44637ef0 0000a0e3 mov      r0, #0
44637ef4 032282e0 add      r2, r2, r3, lsl #4
44637ef8 011192e7 ldr      r1, [r2, r1, lsl #2]
44637efc 0210d1e5 ldrb     r1, [r1, #2]
44637f00 010051e3 cmp      r1, #1
44637f04 0100a003 moveq    r0, #1
44637f08 1eff2fe1 bx       lr
44637f0c 90141fe5 ldr      r1, [pc, #-0x490]
44637f10 3c2041e2 sub      r2, r1, #0x3c
44637f14 0120d2e5 ldrb     r2, [r2, #1]
44637f18 021281e0 add      r1, r1, r2, lsl #4
44637f1c 000191e7 ldr      r0, [r1, r0, lsl #2]
44637f20 0300d0e5 ldrb     r0, [r0, #3]
44637f24 1eff2fe1 bx       lr
