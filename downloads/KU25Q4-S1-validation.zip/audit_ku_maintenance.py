from pathlib import Path
import struct,json
from capstone import *
P=Path(__file__).resolve().parent;D=(P/'FWCL14TL.rcx-0011412e.decoded.bin').read_bytes();BASE=0x44604000
md=Cs(CS_ARCH_ARM,CS_MODE_ARM);md.skipdata=True
# Branch references to primary add body reused for tiny accounting gates.
refs=[]
for off in range(0,len(D)-4,4):
 w=struct.unpack_from('<I',D,off)[0]
 if w>>25&7==5:
  imm=w&0xffffff;imm=imm-(1<<24) if imm&(1<<23) else imm;t=off+8+imm*4
  if 0x3020c<=t<0x30278:refs.append({'from':hex(off),'to':hex(t),'internal':0x3020c<=off<0x30278})
ptrs=[]
for off in range(0,len(D)-4,4):
 v=struct.unpack_from('<I',D,off)[0]
 if BASE+0x3020c<=v<BASE+0x30278:ptrs.append({'at':hex(off),'value':hex(v)})
print('branch_refs',refs);print('pointers',ptrs)
# Table entries point at 2 x uint32 storage for every targeted counter.
table=0x4483d16c
for idx in (0x1d,0x1e,0x26):print('table',hex(idx),[hex(v) for v in struct.unpack_from('<II',D,table-BASE+idx*8)])
# Record full maintenance and generic accounting disassembly for audit.
for name,lo,hi in [('accounting',0x13000,0x14000),('maintenance',0x2fd00,0x33f28)]:
 (P/f'KU25Q4-{name}.asm').write_text('\n'.join(f'{i.address:08x} {i.bytes.hex():8} {i.mnemonic:8} {i.op_str}' for i in md.disasm(D[lo:hi],BASE+lo))+'\n')
(P/'KU25Q4-accounting-references.json').write_text(json.dumps({'reused_body_branch_references':refs,'reused_body_absolute_pointers':ptrs},indent=2)+'\n')
