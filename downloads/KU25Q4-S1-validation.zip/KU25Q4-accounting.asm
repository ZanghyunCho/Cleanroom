44617000 00308115 strne    r3, [r1]
44617004 1eff2fe1 bx       lr
44617008 558400ea b        #0x44638164
4461700c 30402de9 push     {r4, r5, lr}
44617010 0cd04de2 sub      sp, sp, #0xc
44617014 0040a0e1 mov      r4, r0
44617018 528400eb bl       #0x44638168
4461701c 670054e3 cmp      r4, #0x67
44617020 0050a0e1 mov      r5, r0
44617024 0b00003a blo      #0x44617058
44617028 843700eb bl       #0x44624e40
4461702c 000050e3 cmp      r0, #0
44617030 0800000a beq      #0x44617058
44617034 4220a0e3 mov      r2, #0x42
44617038 24108fe2 add      r1, pc, #0x24
4461703c 20008fe2 add      r0, pc, #0x20
44617040 07008de8 stm      sp, {r0, r1, r2}
44617044 0030a0e3 mov      r3, #0
44617048 0320a0e1 mov      r2, r3
4461704c 10108fe2 add      r1, pc, #0x10
44617050 10008fe2 add      r0, pc, #0x10
44617054 421a06eb bl       #0x4479d964
44617058 840195e7 ldr      r0, [r5, r4, lsl #3]
4461705c 0cd08de2 add      sp, sp, #0xc
44617060 3080bde8 pop      {r4, r5, pc}
44617064 00000000 andeq    r0, r0, r0
44617068 30000000 andeq    r0, r0, r0, lsr r0
4461706c 30402de9 push     {r4, r5, lr}
44617070 0cd04de2 sub      sp, sp, #0xc
44617074 0040a0e1 mov      r4, r0
44617078 3a8400eb bl       #0x44638168
4461707c 670054e3 cmp      r4, #0x67
44617080 0050a0e1 mov      r5, r0
44617084 0b00003a blo      #0x446170b8
44617088 6c3700eb bl       #0x44624e40
4461708c 000050e3 cmp      r0, #0
44617090 0800000a beq      #0x446170b8
44617094 5820a0e3 mov      r2, #0x58
44617098 3c104fe2 sub      r1, pc, #0x3c
4461709c 40004fe2 sub      r0, pc, #0x40
446170a0 07008de8 stm      sp, {r0, r1, r2}
446170a4 0030a0e3 mov      r3, #0
446170a8 0320a0e1 mov      r2, r3
446170ac 50104fe2 sub      r1, pc, #0x50
446170b0 50004fe2 sub      r0, pc, #0x50
446170b4 2a1a06eb bl       #0x4479d964
446170b8 840185e0 add      r0, r5, r4, lsl #3
446170bc 040090e5 ldr      r0, [r0, #4]
446170c0 0cd08de2 add      sp, sp, #0xc
446170c4 3080bde8 pop      {r4, r5, pc}
446170c8 f0432de9 push     {r4, r5, r6, r7, r8, sb, lr}
446170cc 0cd04de2 sub      sp, sp, #0xc
446170d0 0050a0e1 mov      r5, r0
446170d4 0190a0e1 mov      sb, r1
446170d8 228400eb bl       #0x44638168
446170dc 0060a0e1 mov      r6, r0
446170e0 228400eb bl       #0x44638170
446170e4 670055e3 cmp      r5, #0x67
446170e8 0070a0e1 mov      r7, r0
446170ec 0040a0e3 mov      r4, #0
446170f0 0b00003a blo      #0x44617124
446170f4 513700eb bl       #0x44624e40
446170f8 000050e3 cmp      r0, #0
446170fc 0800000a beq      #0x44617124
44617100 7120a0e3 mov      r2, #0x71
44617104 a8104fe2 sub      r1, pc, #0xa8
44617108 ac004fe2 sub      r0, pc, #0xac
4461710c 07008de8 stm      sp, {r0, r1, r2}
44617110 0030a0e3 mov      r3, #0
44617114 0320a0e1 mov      r2, r3
44617118 bc104fe2 sub      r1, pc, #0xbc
4461711c bc004fe2 sub      r0, pc, #0xbc
44617120 0f1a06eb bl       #0x4479d964
44617124 850196e7 ldr      r0, [r6, r5, lsl #3]
44617128 000050e3 cmp      r0, #0
4461712c 0cd08d02 addeq    sp, sp, #0xc
44617130 f083bd08 popeq    {r4, r5, r6, r7, r8, sb, pc}
44617134 858186e0 add      r8, r6, r5, lsl #3
44617138 040098e5 ldr      r0, [r8, #4]
4461713c 000050e3 cmp      r0, #0
44617140 0cd08d02 addeq    sp, sp, #0xc
44617144 f083bd08 popeq    {r4, r5, r6, r7, r8, sb, pc}
44617148 852196e7 ldr      r2, [r6, r5, lsl #3]
4461714c 843197e7 ldr      r3, [r7, r4, lsl #3]
44617150 030052e1 cmp      r2, r3
44617154 0300008a bhi      #0x44617168
44617158 040098e5 ldr      r0, [r8, #4]
4461715c 020080e0 add      r0, r0, r2
44617160 000053e1 cmp      r3, r0
44617164 0600003a blo      #0x44617184
44617168 020053e1 cmp      r3, r2
4461716c 0700008a bhi      #0x44617190
44617170 840187e0 add      r0, r7, r4, lsl #3
44617174 040090e5 ldr      r0, [r0, #4]
44617178 030080e0 add      r0, r0, r3
4461717c 000052e1 cmp      r2, r0
44617180 0200002a bhs      #0x44617190
44617184 ff0004e2 and      r0, r4, #0xff
44617188 0910a0e1 mov      r1, sb
4461718c fc8300eb bl       #0x44638184
44617190 014084e2 add      r4, r4, #1
44617194 5b0054e3 cmp      r4, #0x5b
44617198 eaffff3a blo      #0x44617148
4461719c 0cd08de2 add      sp, sp, #0xc
446171a0 f083bde8 pop      {r4, r5, r6, r7, r8, sb, pc}
446171a4 f0432de9 push     {r4, r5, r6, r7, r8, sb, lr}
446171a8 0cd04de2 sub      sp, sp, #0xc
446171ac 0050a0e1 mov      r5, r0
446171b0 ec8300eb bl       #0x44638168
446171b4 0060a0e1 mov      r6, r0
446171b8 ec8300eb bl       #0x44638170
446171bc 0040a0e3 mov      r4, #0
446171c0 670055e3 cmp      r5, #0x67
446171c4 0070a0e1 mov      r7, r0
446171c8 0490a0e1 mov      sb, r4
446171cc 0b00003a blo      #0x44617200
446171d0 1a3700eb bl       #0x44624e40
446171d4 000050e3 cmp      r0, #0
446171d8 0800000a beq      #0x44617200
446171dc 9a20a0e3 mov      r2, #0x9a
446171e0 611f4fe2 sub      r1, pc, #0x184
446171e4 620f4fe2 sub      r0, pc, #0x188
446171e8 07008de8 stm      sp, {r0, r1, r2}
446171ec 0030a0e3 mov      r3, #0
446171f0 0320a0e1 mov      r2, r3
446171f4 661f4fe2 sub      r1, pc, #0x198
446171f8 660f4fe2 sub      r0, pc, #0x198
446171fc d81906eb bl       #0x4479d964
44617200 850196e7 ldr      r0, [r6, r5, lsl #3]
44617204 000050e3 cmp      r0, #0
44617208 1b00000a beq      #0x4461727c
4461720c 858186e0 add      r8, r6, r5, lsl #3
44617210 040098e5 ldr      r0, [r8, #4]
44617214 000050e3 cmp      r0, #0
44617218 1700000a beq      #0x4461727c
4461721c ff0004e2 and      r0, r4, #0xff
44617220 d48300eb bl       #0x44638178
44617224 000050e3 cmp      r0, #0
44617228 1000000a beq      #0x44617270
4461722c 851196e7 ldr      r1, [r6, r5, lsl #3]
44617230 842197e7 ldr      r2, [r7, r4, lsl #3]
44617234 020051e1 cmp      r1, r2
44617238 0300008a bhi      #0x4461724c
4461723c 040098e5 ldr      r0, [r8, #4]
44617240 010080e0 add      r0, r0, r1
44617244 000052e1 cmp      r2, r0
44617248 0600003a blo      #0x44617268
4461724c 010052e1 cmp      r2, r1
44617250 0600008a bhi      #0x44617270
44617254 840187e0 add      r0, r7, r4, lsl #3
44617258 040090e5 ldr      r0, [r0, #4]
4461725c 020080e0 add      r0, r0, r2
44617260 000051e1 cmp      r1, r0
44617264 0100002a bhs      #0x44617270
44617268 0190a0e3 mov      sb, #1
4461726c 020000ea b        #0x4461727c
44617270 014084e2 add      r4, r4, #1
44617274 5b0054e3 cmp      r4, #0x5b
44617278 e7ffff3a blo      #0x4461721c
4461727c 0900a0e1 mov      r0, sb
44617280 0cd08de2 add      sp, sp, #0xc
44617284 f083bde8 pop      {r4, r5, r6, r7, r8, sb, pc}
44617288 10402de9 push     {r4, lr}
4461728c 0040a0e3 mov      r4, #0
44617290 ff0004e2 and      r0, r4, #0xff
44617294 0010a0e3 mov      r1, #0
44617298 b98300eb bl       #0x44638184
4461729c 014084e2 add      r4, r4, #1
446172a0 5b0054e3 cmp      r4, #0x5b
446172a4 f9ffff3a blo      #0x44617290
446172a8 1080bde8 pop      {r4, pc}
446172ac f0402de9 push     {r4, r5, r6, r7, lr}
446172b0 0cd04de2 sub      sp, sp, #0xc
446172b4 0040a0e1 mov      r4, r0
446172b8 0160a0e1 mov      r6, r1
446172bc 0270a0e1 mov      r7, r2
446172c0 aa8300eb bl       #0x44638170
446172c4 5b0054e3 cmp      r4, #0x5b
446172c8 0050a0e1 mov      r5, r0
446172cc 0b00003a blo      #0x44617300
446172d0 da3600eb bl       #0x44624e40
446172d4 000050e3 cmp      r0, #0
446172d8 0800000a beq      #0x44617300
446172dc dc20a0e3 mov      r2, #0xdc
446172e0 a11f4fe2 sub      r1, pc, #0x284
446172e4 a20f4fe2 sub      r0, pc, #0x288
446172e8 07008de8 stm      sp, {r0, r1, r2}
446172ec 0030a0e3 mov      r3, #0
446172f0 0320a0e1 mov      r2, r3
446172f4 a61f4fe2 sub      r1, pc, #0x298
446172f8 a60f4fe2 sub      r0, pc, #0x298
446172fc 981906eb bl       #0x4479d964
44617300 000056e3 cmp      r6, #0
44617304 0b00001a bne      #0x44617338
44617308 cc3600eb bl       #0x44624e40
4461730c 000050e3 cmp      r0, #0
44617310 0800000a beq      #0x44617338
44617314 dd20a0e3 mov      r2, #0xdd
44617318 af1f4fe2 sub      r1, pc, #0x2bc
4461731c 0b0d4fe2 sub      r0, pc, #0x2c0
44617320 07008de8 stm      sp, {r0, r1, r2}
44617324 0030a0e3 mov      r3, #0
44617328 0320a0e1 mov      r2, r3
4461732c 2d1e4fe2 sub      r1, pc, #0x2d0
44617330 2d0e4fe2 sub      r0, pc, #0x2d0
44617334 8a1906eb bl       #0x4479d964
44617338 840185e0 add      r0, r5, r4, lsl #3
4461733c 040090e5 ldr      r0, [r0, #4]
44617340 070050e1 cmp      r0, r7
44617344 0b00002a bhs      #0x44617378
44617348 bc3600eb bl       #0x44624e40
4461734c 000050e3 cmp      r0, #0
44617350 0800000a beq      #0x44617378
44617354 de20a0e3 mov      r2, #0xde
44617358 bf1f4fe2 sub      r1, pc, #0x2fc
4461735c 030c4fe2 sub      r0, pc, #0x300
44617360 07008de8 stm      sp, {r0, r1, r2}
44617364 0030a0e3 mov      r3, #0
44617368 0320a0e1 mov      r2, r3
4461736c 311e4fe2 sub      r1, pc, #0x310
44617370 310e4fe2 sub      r0, pc, #0x310
44617374 7a1906eb bl       #0x4479d964
44617378 841195e7 ldr      r1, [r5, r4, lsl #3]
4461737c 0720a0e1 mov      r2, r7
44617380 0600a0e1 mov      r0, r6
44617384 0cd08de2 add      sp, sp, #0xc
44617388 f040bde8 pop      {r4, r5, r6, r7, lr}
4461738c a01b08ea b        #0x4481e214
44617390 f0402de9 push     {r4, r5, r6, r7, lr}
44617394 0cd04de2 sub      sp, sp, #0xc
44617398 0040a0e1 mov      r4, r0
4461739c 0160a0e1 mov      r6, r1
446173a0 0270a0e1 mov      r7, r2
446173a4 718300eb bl       #0x44638170
446173a8 5b0054e3 cmp      r4, #0x5b
446173ac 0050a0e1 mov      r5, r0
446173b0 0b00003a blo      #0x446173e4
446173b4 a13600eb bl       #0x44624e40
446173b8 000050e3 cmp      r0, #0
446173bc 0800000a beq      #0x446173e4
446173c0 f620a0e3 mov      r2, #0xf6
446173c4 da1f4fe2 sub      r1, pc, #0x368
446173c8 db0f4fe2 sub      r0, pc, #0x36c
446173cc 07008de8 stm      sp, {r0, r1, r2}
446173d0 0030a0e3 mov      r3, #0
446173d4 0320a0e1 mov      r2, r3
446173d8 df1f4fe2 sub      r1, pc, #0x37c
446173dc df0f4fe2 sub      r0, pc, #0x37c
446173e0 5f1906eb bl       #0x4479d964
446173e4 000056e3 cmp      r6, #0
446173e8 0b00001a bne      #0x4461741c
446173ec 933600eb bl       #0x44624e40
446173f0 000050e3 cmp      r0, #0
446173f4 0800000a beq      #0x4461741c
446173f8 f720a0e3 mov      r2, #0xf7
446173fc 3a1e4fe2 sub      r1, pc, #0x3a0
44617400 e90f4fe2 sub      r0, pc, #0x3a4
44617404 07008de8 stm      sp, {r0, r1, r2}
44617408 0030a0e3 mov      r3, #0
4461740c 0320a0e1 mov      r2, r3
44617410 ed1f4fe2 sub      r1, pc, #0x3b4
44617414 ed0f4fe2 sub      r0, pc, #0x3b4
44617418 511906eb bl       #0x4479d964
4461741c 840185e0 add      r0, r5, r4, lsl #3
44617420 040090e5 ldr      r0, [r0, #4]
44617424 070050e1 cmp      r0, r7
44617428 0b00002a bhs      #0x4461745c
4461742c 833600eb bl       #0x44624e40
44617430 000050e3 cmp      r0, #0
44617434 0800000a beq      #0x4461745c
44617438 f820a0e3 mov      r2, #0xf8
4461743c 3e1e4fe2 sub      r1, pc, #0x3e0
44617440 f90f4fe2 sub      r0, pc, #0x3e4
44617444 07008de8 stm      sp, {r0, r1, r2}
44617448 0030a0e3 mov      r3, #0
4461744c 0320a0e1 mov      r2, r3
44617450 fd1f4fe2 sub      r1, pc, #0x3f4
44617454 fd0f4fe2 sub      r0, pc, #0x3f4
44617458 411906eb bl       #0x4479d964
4461745c 840195e7 ldr      r0, [r5, r4, lsl #3]
44617460 0720a0e1 mov      r2, r7
44617464 0610a0e1 mov      r1, r6
44617468 0a1b08fa blx      #0x4481e098
4461746c 000050e3 cmp      r0, #0
44617470 0cd08d02 addeq    sp, sp, #0xc
44617474 f080bd08 popeq    {r4, r5, r6, r7, pc}
44617478 840195e7 ldr      r0, [r5, r4, lsl #3]
4461747c 0720a0e1 mov      r2, r7
44617480 0610a0e1 mov      r1, r6
44617484 621b08eb bl       #0x4481e214
44617488 0400a0e1 mov      r0, r4
4461748c 0cd08de2 add      sp, sp, #0xc
44617490 f040bde8 pop      {r4, r5, r6, r7, lr}
44617494 0110a0e3 mov      r1, #1
44617498 398300ea b        #0x44638184
4461749c f0412de9 push     {r4, r5, r6, r7, r8, lr}
446174a0 10d04de2 sub      sp, sp, #0x10
446174a4 0040a0e1 mov      r4, r0
446174a8 0180a0e1 mov      r8, r1
446174ac 0250a0e1 mov      r5, r2
446174b0 0360a0e1 mov      r6, r3
446174b4 2d8300eb bl       #0x44638170
446174b8 5b0054e3 cmp      r4, #0x5b
446174bc 0070a0e1 mov      r7, r0
446174c0 0b00003a blo      #0x446174f4
446174c4 5d3600eb bl       #0x44624e40
446174c8 000050e3 cmp      r0, #0
446174cc 0800000a beq      #0x446174f4
446174d0 80209fe5 ldr      r2, [pc, #0x80]
446174d4 80108fe2 add      r1, pc, #0x80
446174d8 7c008fe2 add      r0, pc, #0x7c
446174dc 07008de8 stm      sp, {r0, r1, r2}
446174e0 0030a0e3 mov      r3, #0
446174e4 0320a0e1 mov      r2, r3
446174e8 6c108fe2 add      r1, pc, #0x6c
446174ec 6c008fe2 add      r0, pc, #0x6c
446174f0 1b1906eb bl       #0x4479d964
446174f4 010086e2 add      r0, r6, #1
446174f8 950000e0 mul      r0, r5, r0
446174fc 841187e0 add      r1, r7, r4, lsl #3
44617500 041091e5 ldr      r1, [r1, #4]
44617504 010050e1 cmp      r0, r1
44617508 0b00009a bls      #0x4461753c
4461750c 4b3600eb bl       #0x44624e40
44617510 000050e3 cmp      r0, #0
44617514 0800000a beq      #0x4461753c
44617518 44209fe5 ldr      r2, [pc, #0x44]
4461751c 38108fe2 add      r1, pc, #0x38
44617520 34008fe2 add      r0, pc, #0x34
44617524 07008de8 stm      sp, {r0, r1, r2}
44617528 0030a0e3 mov      r3, #0
4461752c 0320a0e1 mov      r2, r3
44617530 24108fe2 add      r1, pc, #0x24
44617534 24008fe2 add      r0, pc, #0x24
44617538 091906eb bl       #0x4479d964
4461753c 840197e7 ldr      r0, [r7, r4, lsl #3]
44617540 0520a0e1 mov      r2, r5
44617544 960521e0 mla      r1, r6, r5, r0
44617548 0800a0e1 mov      r0, r8
4461754c 10d08de2 add      sp, sp, #0x10
44617550 f041bde8 pop      {r4, r5, r6, r7, r8, lr}
44617554 2e1b08ea b        #0x4481e214
44617558 15010000 andeq    r0, r0, r5, lsl r1
4461755c 00000000 andeq    r0, r0, r0
44617560 30000000 andeq    r0, r0, r0, lsr r0
44617564 16010000 andeq    r0, r0, r6, lsl r1
44617568 f0412de9 push     {r4, r5, r6, r7, r8, lr}
4461756c 10d04de2 sub      sp, sp, #0x10
44617570 0040a0e1 mov      r4, r0
44617574 0180a0e1 mov      r8, r1
44617578 0250a0e1 mov      r5, r2
4461757c 0360a0e1 mov      r6, r3
44617580 fa8200eb bl       #0x44638170
44617584 5b0054e3 cmp      r4, #0x5b
44617588 0070a0e1 mov      r7, r0
4461758c 0b00003a blo      #0x446175c0
44617590 2a3600eb bl       #0x44624e40
44617594 000050e3 cmp      r0, #0
44617598 0800000a beq      #0x446175c0
4461759c 132ea0e3 mov      r2, #0x130
446175a0 4c104fe2 sub      r1, pc, #0x4c
446175a4 50004fe2 sub      r0, pc, #0x50
446175a8 07008de8 stm      sp, {r0, r1, r2}
446175ac 0030a0e3 mov      r3, #0
446175b0 0320a0e1 mov      r2, r3
446175b4 60104fe2 sub      r1, pc, #0x60
446175b8 60004fe2 sub      r0, pc, #0x60
446175bc e81806eb bl       #0x4479d964
446175c0 010086e2 add      r0, r6, #1
446175c4 950000e0 mul      r0, r5, r0
446175c8 841187e0 add      r1, r7, r4, lsl #3
446175cc 041091e5 ldr      r1, [r1, #4]
446175d0 010050e1 cmp      r0, r1
446175d4 0b00009a bls      #0x44617608
446175d8 183600eb bl       #0x44624e40
446175dc 000050e3 cmp      r0, #0
446175e0 0800000a beq      #0x44617608
446175e4 08249fe5 ldr      r2, [pc, #0x408]
446175e8 94104fe2 sub      r1, pc, #0x94
446175ec 98004fe2 sub      r0, pc, #0x98
446175f0 07008de8 stm      sp, {r0, r1, r2}
446175f4 0030a0e3 mov      r3, #0
446175f8 0320a0e1 mov      r2, r3
446175fc a8104fe2 sub      r1, pc, #0xa8
44617600 a8004fe2 sub      r0, pc, #0xa8
44617604 d61806eb bl       #0x4479d964
44617608 840197e7 ldr      r0, [r7, r4, lsl #3]
4461760c 0520a0e1 mov      r2, r5
44617610 960520e0 mla      r0, r6, r5, r0
44617614 0810a0e1 mov      r1, r8
44617618 9e1a08fa blx      #0x4481e098
4461761c 000050e3 cmp      r0, #0
44617620 10d08d02 addeq    sp, sp, #0x10
44617624 f081bd08 popeq    {r4, r5, r6, r7, r8, pc}
44617628 840197e7 ldr      r0, [r7, r4, lsl #3]
4461762c 0520a0e1 mov      r2, r5
44617630 960520e0 mla      r0, r6, r5, r0
44617634 0810a0e1 mov      r1, r8
44617638 f51a08eb bl       #0x4481e214
4461763c 0400a0e1 mov      r0, r4
44617640 10d08de2 add      sp, sp, #0x10
44617644 f041bde8 pop      {r4, r5, r6, r7, r8, lr}
44617648 0110a0e3 mov      r1, #1
4461764c cc8200ea b        #0x44638184
44617650 70402de9 push     {r4, r5, r6, lr}
44617654 10d04de2 sub      sp, sp, #0x10
44617658 0040a0e1 mov      r4, r0
4461765c 0150a0e1 mov      r5, r1
44617660 c28200eb bl       #0x44638170
44617664 5b0054e3 cmp      r4, #0x5b
44617668 0060a0e1 mov      r6, r0
4461766c 0b00003a blo      #0x446176a0
44617670 f23500eb bl       #0x44624e40
44617674 000050e3 cmp      r0, #0
44617678 0800000a beq      #0x446176a0
4461767c 532fa0e3 mov      r2, #0x14c
44617680 4b1f4fe2 sub      r1, pc, #0x12c
44617684 130e4fe2 sub      r0, pc, #0x130
44617688 07008de8 stm      sp, {r0, r1, r2}
4461768c 0030a0e3 mov      r3, #0
44617690 0320a0e1 mov      r2, r3
44617694 051d4fe2 sub      r1, pc, #0x140
44617698 050d4fe2 sub      r0, pc, #0x140
4461769c b01806eb bl       #0x4479d964
446176a0 840186e0 add      r0, r6, r4, lsl #3
446176a4 040090e5 ldr      r0, [r0, #4]
446176a8 011085e2 add      r1, r5, #1
446176ac 010050e1 cmp      r0, r1
446176b0 0b00002a bhs      #0x446176e4
446176b4 e13500eb bl       #0x44624e40
446176b8 000050e3 cmp      r0, #0
446176bc 0800000a beq      #0x446176e4
446176c0 30239fe5 ldr      r2, [pc, #0x330]
446176c4 171e4fe2 sub      r1, pc, #0x170
446176c8 5d0f4fe2 sub      r0, pc, #0x174
446176cc 07008de8 stm      sp, {r0, r1, r2}
446176d0 0030a0e3 mov      r3, #0
446176d4 0320a0e1 mov      r2, r3
446176d8 611f4fe2 sub      r1, pc, #0x184
446176dc 610f4fe2 sub      r0, pc, #0x184
446176e0 9f1806eb bl       #0x4479d964
446176e4 840196e7 ldr      r0, [r6, r4, lsl #3]
446176e8 0500d0e7 ldrb     r0, [r0, r5]
446176ec 10d08de2 add      sp, sp, #0x10
446176f0 7080bde8 pop      {r4, r5, r6, pc}
446176f4 f0402de9 push     {r4, r5, r6, r7, lr}
446176f8 0cd04de2 sub      sp, sp, #0xc
446176fc 0040a0e1 mov      r4, r0
44617700 0150a0e1 mov      r5, r1
44617704 0260a0e1 mov      r6, r2
44617708 988200eb bl       #0x44638170
4461770c 5b0054e3 cmp      r4, #0x5b
44617710 0070a0e1 mov      r7, r0
44617714 0b00003a blo      #0x44617748
44617718 c83500eb bl       #0x44624e40
4461771c 000050e3 cmp      r0, #0
44617720 0800000a beq      #0x44617748
44617724 d0229fe5 ldr      r2, [pc, #0x2d0]
44617728 751f4fe2 sub      r1, pc, #0x1d4
4461772c 760f4fe2 sub      r0, pc, #0x1d8
44617730 07008de8 stm      sp, {r0, r1, r2}
44617734 0030a0e3 mov      r3, #0
44617738 0320a0e1 mov      r2, r3
4461773c 7a1f4fe2 sub      r1, pc, #0x1e8
44617740 7a0f4fe2 sub      r0, pc, #0x1e8
44617744 861806eb bl       #0x4479d964
44617748 840187e0 add      r0, r7, r4, lsl #3
4461774c 040090e5 ldr      r0, [r0, #4]
44617750 011085e2 add      r1, r5, #1
44617754 010050e1 cmp      r0, r1
44617758 0b00002a bhs      #0x4461778c
4461775c b73500eb bl       #0x44624e40
44617760 000050e3 cmp      r0, #0
44617764 0800000a beq      #0x4461778c
44617768 90229fe5 ldr      r2, [pc, #0x290]
4461776c 861f4fe2 sub      r1, pc, #0x218
44617770 870f4fe2 sub      r0, pc, #0x21c
44617774 07008de8 stm      sp, {r0, r1, r2}
44617778 0030a0e3 mov      r3, #0
4461777c 0320a0e1 mov      r2, r3
44617780 8b1f4fe2 sub      r1, pc, #0x22c
44617784 8b0f4fe2 sub      r0, pc, #0x22c
44617788 751806eb bl       #0x4479d964
4461778c 840197e7 ldr      r0, [r7, r4, lsl #3]
44617790 0510d0e7 ldrb     r1, [r0, r5]
44617794 060051e1 cmp      r1, r6
44617798 0cd08d02 addeq    sp, sp, #0xc
4461779c f080bd08 popeq    {r4, r5, r6, r7, pc}
446177a0 0560c0e7 strb     r6, [r0, r5]
446177a4 0400a0e1 mov      r0, r4
446177a8 0cd08de2 add      sp, sp, #0xc
446177ac f040bde8 pop      {r4, r5, r6, r7, lr}
446177b0 0110a0e3 mov      r1, #1
446177b4 728200ea b        #0x44638184
446177b8 70402de9 push     {r4, r5, r6, lr}
446177bc 10d04de2 sub      sp, sp, #0x10
446177c0 0040a0e1 mov      r4, r0
446177c4 0150a0e1 mov      r5, r1
446177c8 688200eb bl       #0x44638170
446177cc 5b0054e3 cmp      r4, #0x5b
446177d0 0060a0e1 mov      r6, r0
446177d4 0b00003a blo      #0x44617808
446177d8 983500eb bl       #0x44624e40
446177dc 000050e3 cmp      r0, #0
446177e0 0800000a beq      #0x44617808
446177e4 18229fe5 ldr      r2, [pc, #0x218]
446177e8 a51f4fe2 sub      r1, pc, #0x294
446177ec a60f4fe2 sub      r0, pc, #0x298
446177f0 07008de8 stm      sp, {r0, r1, r2}
446177f4 0030a0e3 mov      r3, #0
446177f8 0320a0e1 mov      r2, r3
446177fc aa1f4fe2 sub      r1, pc, #0x2a8
44617800 aa0f4fe2 sub      r0, pc, #0x2a8
44617804 561806eb bl       #0x4479d964
44617808 840186e0 add      r0, r6, r4, lsl #3
4461780c 040090e5 ldr      r0, [r0, #4]
44617810 011085e2 add      r1, r5, #1
44617814 010050e1 cmp      r0, r1
44617818 0b00002a bhs      #0x4461784c
4461781c 873500eb bl       #0x44624e40
44617820 000050e3 cmp      r0, #0
44617824 0800000a beq      #0x4461784c
44617828 612fa0e3 mov      r2, #0x184
4461782c b61f4fe2 sub      r1, pc, #0x2d8
44617830 b70f4fe2 sub      r0, pc, #0x2dc
44617834 07008de8 stm      sp, {r0, r1, r2}
44617838 0030a0e3 mov      r3, #0
4461783c 0320a0e1 mov      r2, r3
44617840 bb1f4fe2 sub      r1, pc, #0x2ec
44617844 bb0f4fe2 sub      r0, pc, #0x2ec
44617848 451806eb bl       #0x4479d964
4461784c 840196e7 ldr      r0, [r6, r4, lsl #3]
44617850 0510d0e7 ldrb     r1, [r0, r5]
44617854 ff0051e3 cmp      r1, #0xff
44617858 10d08d22 addhs    sp, sp, #0x10
4461785c 7080bd28 pophs    {r4, r5, r6, pc}
44617860 011081e2 add      r1, r1, #1
44617864 0510c0e7 strb     r1, [r0, r5]
44617868 0400a0e1 mov      r0, r4
4461786c 10d08de2 add      sp, sp, #0x10
44617870 7040bde8 pop      {r4, r5, r6, lr}
44617874 0110a0e3 mov      r1, #1
44617878 418200ea b        #0x44638184
4461787c 70402de9 push     {r4, r5, r6, lr}
44617880 10d04de2 sub      sp, sp, #0x10
44617884 0040a0e1 mov      r4, r0
44617888 0150a0e1 mov      r5, r1
4461788c 378200eb bl       #0x44638170
44617890 5b0054e3 cmp      r4, #0x5b
44617894 0060a0e1 mov      r6, r0
44617898 0b00003a blo      #0x446178cc
4461789c 673500eb bl       #0x44624e40
446178a0 000050e3 cmp      r0, #0
446178a4 0800000a beq      #0x446178cc
446178a8 58219fe5 ldr      r2, [pc, #0x158]
446178ac d61f4fe2 sub      r1, pc, #0x358
446178b0 d70f4fe2 sub      r0, pc, #0x35c
446178b4 07008de8 stm      sp, {r0, r1, r2}
446178b8 0030a0e3 mov      r3, #0
446178bc 0320a0e1 mov      r2, r3
446178c0 db1f4fe2 sub      r1, pc, #0x36c
446178c4 db0f4fe2 sub      r0, pc, #0x36c
446178c8 251806eb bl       #0x4479d964
446178cc 841186e0 add      r1, r6, r4, lsl #3
446178d0 041091e5 ldr      r1, [r1, #4]
446178d4 8500a0e1 lsl      r0, r5, #1
446178d8 020080e2 add      r0, r0, #2
446178dc 010050e1 cmp      r0, r1
446178e0 0b00009a bls      #0x44617914
446178e4 553500eb bl       #0x44624e40
446178e8 000050e3 cmp      r0, #0
446178ec 0800000a beq      #0x44617914
446178f0 14219fe5 ldr      r2, [pc, #0x114]
446178f4 3a1e4fe2 sub      r1, pc, #0x3a0
446178f8 e90f4fe2 sub      r0, pc, #0x3a4
446178fc 07008de8 stm      sp, {r0, r1, r2}
44617900 0030a0e3 mov      r3, #0
44617904 0320a0e1 mov      r2, r3
44617908 ed1f4fe2 sub      r1, pc, #0x3b4
4461790c ed0f4fe2 sub      r0, pc, #0x3b4
44617910 131806eb bl       #0x4479d964
44617914 840196e7 ldr      r0, [r6, r4, lsl #3]
44617918 850080e0 add      r0, r0, r5, lsl #1
4461791c b000d0e1 ldrh     r0, [r0]
44617920 10d08de2 add      sp, sp, #0x10
44617924 7080bde8 pop      {r4, r5, r6, pc}
44617928 f0402de9 push     {r4, r5, r6, r7, lr}
4461792c 0cd04de2 sub      sp, sp, #0xc
44617930 0040a0e1 mov      r4, r0
44617934 0160a0e1 mov      r6, r1
44617938 0250a0e1 mov      r5, r2
4461793c 0b8200eb bl       #0x44638170
44617940 5b0054e3 cmp      r4, #0x5b
44617944 0070a0e1 mov      r7, r0
44617948 0b00003a blo      #0x4461797c
4461794c 3b3500eb bl       #0x44624e40
44617950 000050e3 cmp      r0, #0
44617954 0800000a beq      #0x4461797c
44617958 6f2fa0e3 mov      r2, #0x1bc
4461795c ac108fe2 add      r1, pc, #0xac
44617960 a8008fe2 add      r0, pc, #0xa8
44617964 07008de8 stm      sp, {r0, r1, r2}
44617968 0030a0e3 mov      r3, #0
4461796c 0320a0e1 mov      r2, r3
44617970 98108fe2 add      r1, pc, #0x98
44617974 98008fe2 add      r0, pc, #0x98
44617978 f91706eb bl       #0x4479d964
4461797c 841187e0 add      r1, r7, r4, lsl #3
44617980 041091e5 ldr      r1, [r1, #4]
44617984 8600a0e1 lsl      r0, r6, #1
44617988 020080e2 add      r0, r0, #2
4461798c 010050e1 cmp      r0, r1
44617990 0b00009a bls      #0x446179c4
44617994 293500eb bl       #0x44624e40
44617998 000050e3 cmp      r0, #0
4461799c 0800000a beq      #0x446179c4
446179a0 70209fe5 ldr      r2, [pc, #0x70]
446179a4 64108fe2 add      r1, pc, #0x64
446179a8 60008fe2 add      r0, pc, #0x60
446179ac 07008de8 stm      sp, {r0, r1, r2}
446179b0 0030a0e3 mov      r3, #0
446179b4 0320a0e1 mov      r2, r3
446179b8 50108fe2 add      r1, pc, #0x50
446179bc 50008fe2 add      r0, pc, #0x50
446179c0 e71706eb bl       #0x4479d964
446179c4 840197e7 ldr      r0, [r7, r4, lsl #3]
446179c8 860080e0 add      r0, r0, r6, lsl #1
446179cc b010d0e1 ldrh     r1, [r0]
446179d0 050051e1 cmp      r1, r5
446179d4 0cd08d02 addeq    sp, sp, #0xc
446179d8 f080bd08 popeq    {r4, r5, r6, r7, pc}
446179dc b050c0e1 strh     r5, [r0]
446179e0 0400a0e1 mov      r0, r4
446179e4 0cd08de2 add      sp, sp, #0xc
446179e8 f040bde8 pop      {r4, r5, r6, r7, lr}
446179ec 0110a0e3 mov      r1, #1
446179f0 e38100ea b        #0x44638184
446179f4 31010000 andeq    r0, r0, r1, lsr r1
446179f8 4d010000 andeq    r0, r0, sp, asr #2
446179fc 66010000 andeq    r0, r0, r6, ror #2
44617a00 67010000 andeq    r0, r0, r7, ror #2
44617a04 83010000 andeq    r0, r0, r3, lsl #3
44617a08 a2010000 andeq    r0, r0, r2, lsr #3
44617a0c a3010000 andeq    r0, r0, r3, lsr #3
44617a10 00000000 andeq    r0, r0, r0
44617a14 30000000 andeq    r0, r0, r0, lsr r0
44617a18 bd010000 strheq   r0, [r0], -sp
44617a1c 70402de9 push     {r4, r5, r6, lr}
44617a20 10d04de2 sub      sp, sp, #0x10
44617a24 0040a0e1 mov      r4, r0
44617a28 0150a0e1 mov      r5, r1
44617a2c cf8100eb bl       #0x44638170
44617a30 5b0054e3 cmp      r4, #0x5b
44617a34 0060a0e1 mov      r6, r0
44617a38 0b00003a blo      #0x44617a6c
44617a3c ff3400eb bl       #0x44624e40
44617a40 000050e3 cmp      r0, #0
44617a44 0800000a beq      #0x44617a6c
44617a48 d0249fe5 ldr      r2, [pc, #0x4d0]
44617a4c 44104fe2 sub      r1, pc, #0x44
44617a50 48004fe2 sub      r0, pc, #0x48
44617a54 07008de8 stm      sp, {r0, r1, r2}
44617a58 0030a0e3 mov      r3, #0
44617a5c 0320a0e1 mov      r2, r3
44617a60 58104fe2 sub      r1, pc, #0x58
44617a64 58004fe2 sub      r0, pc, #0x58
44617a68 bd1706eb bl       #0x4479d964
44617a6c 841186e0 add      r1, r6, r4, lsl #3
44617a70 041091e5 ldr      r1, [r1, #4]
44617a74 8500a0e1 lsl      r0, r5, #1
44617a78 020080e2 add      r0, r0, #2
44617a7c 010050e1 cmp      r0, r1
44617a80 0b00009a bls      #0x44617ab4
44617a84 ed3400eb bl       #0x44624e40
44617a88 000050e3 cmp      r0, #0
44617a8c 0800000a beq      #0x44617ab4
44617a90 8c249fe5 ldr      r2, [pc, #0x48c]
44617a94 8c104fe2 sub      r1, pc, #0x8c
44617a98 90004fe2 sub      r0, pc, #0x90
44617a9c 07008de8 stm      sp, {r0, r1, r2}
44617aa0 0030a0e3 mov      r3, #0
44617aa4 0320a0e1 mov      r2, r3
44617aa8 a0104fe2 sub      r1, pc, #0xa0
44617aac a0004fe2 sub      r0, pc, #0xa0
44617ab0 ab1706eb bl       #0x4479d964
44617ab4 840196e7 ldr      r0, [r6, r4, lsl #3]
44617ab8 68249fe5 ldr      r2, [pc, #0x468]
44617abc 850080e0 add      r0, r0, r5, lsl #1
44617ac0 b010d0e1 ldrh     r1, [r0]
44617ac4 020051e1 cmp      r1, r2
44617ac8 10d08d22 addhs    sp, sp, #0x10
44617acc 7080bd28 pophs    {r4, r5, r6, pc}
44617ad0 011081e2 add      r1, r1, #1
44617ad4 b010c0e1 strh     r1, [r0]
44617ad8 0400a0e1 mov      r0, r4
44617adc 10d08de2 add      sp, sp, #0x10
44617ae0 7040bde8 pop      {r4, r5, r6, lr}
44617ae4 0110a0e3 mov      r1, #1
44617ae8 a58100ea b        #0x44638184
44617aec 70402de9 push     {r4, r5, r6, lr}
44617af0 10d04de2 sub      sp, sp, #0x10
44617af4 0040a0e1 mov      r4, r0
44617af8 0150a0e1 mov      r5, r1
44617afc 9b8100eb bl       #0x44638170
44617b00 5b0054e3 cmp      r4, #0x5b
44617b04 0060a0e1 mov      r6, r0
44617b08 0b00003a blo      #0x44617b3c
44617b0c cb3400eb bl       #0x44624e40
44617b10 000050e3 cmp      r0, #0
44617b14 0800000a beq      #0x44617b3c
44617b18 7e2fa0e3 mov      r2, #0x1f8
44617b1c 451f4fe2 sub      r1, pc, #0x114
44617b20 460f4fe2 sub      r0, pc, #0x118
44617b24 07008de8 stm      sp, {r0, r1, r2}
44617b28 0030a0e3 mov      r3, #0
44617b2c 0320a0e1 mov      r2, r3
44617b30 4a1f4fe2 sub      r1, pc, #0x128
44617b34 4a0f4fe2 sub      r0, pc, #0x128
44617b38 891706eb bl       #0x4479d964
44617b3c 841186e0 add      r1, r6, r4, lsl #3
44617b40 041091e5 ldr      r1, [r1, #4]
44617b44 0501a0e1 lsl      r0, r5, #2
44617b48 040080e2 add      r0, r0, #4
44617b4c 010050e1 cmp      r0, r1
44617b50 0b00009a bls      #0x44617b84
44617b54 b93400eb bl       #0x44624e40
44617b58 000050e3 cmp      r0, #0
44617b5c 0800000a beq      #0x44617b84
44617b60 c4239fe5 ldr      r2, [pc, #0x3c4]
44617b64 571f4fe2 sub      r1, pc, #0x15c
44617b68 160e4fe2 sub      r0, pc, #0x160
44617b6c 07008de8 stm      sp, {r0, r1, r2}
44617b70 0030a0e3 mov      r3, #0
44617b74 0320a0e1 mov      r2, r3
44617b78 171e4fe2 sub      r1, pc, #0x170
44617b7c 170e4fe2 sub      r0, pc, #0x170
44617b80 771706eb bl       #0x4479d964
44617b84 840196e7 ldr      r0, [r6, r4, lsl #3]
44617b88 050190e7 ldr      r0, [r0, r5, lsl #2]
44617b8c 10d08de2 add      sp, sp, #0x10
44617b90 7080bde8 pop      {r4, r5, r6, pc}
44617b94 f0402de9 push     {r4, r5, r6, r7, lr}
44617b98 0cd04de2 sub      sp, sp, #0xc
44617b9c 0040a0e1 mov      r4, r0
44617ba0 0150a0e1 mov      r5, r1
44617ba4 0260a0e1 mov      r6, r2
44617ba8 708100eb bl       #0x44638170
44617bac 5b0054e3 cmp      r4, #0x5b
44617bb0 0070a0e1 mov      r7, r0
44617bb4 0b00003a blo      #0x44617be8
44617bb8 a03400eb bl       #0x44624e40
44617bbc 000050e3 cmp      r0, #0
44617bc0 0800000a beq      #0x44617be8
44617bc4 64239fe5 ldr      r2, [pc, #0x364]
44617bc8 071d4fe2 sub      r1, pc, #0x1c0
44617bcc 710f4fe2 sub      r0, pc, #0x1c4
44617bd0 07008de8 stm      sp, {r0, r1, r2}
44617bd4 0030a0e3 mov      r3, #0
44617bd8 0320a0e1 mov      r2, r3
44617bdc 751f4fe2 sub      r1, pc, #0x1d4
44617be0 750f4fe2 sub      r0, pc, #0x1d4
44617be4 5e1706eb bl       #0x4479d964
44617be8 841187e0 add      r1, r7, r4, lsl #3
44617bec 041091e5 ldr      r1, [r1, #4]
44617bf0 0501a0e1 lsl      r0, r5, #2
44617bf4 040080e2 add      r0, r0, #4
44617bf8 010050e1 cmp      r0, r1
44617bfc 0b00009a bls      #0x44617c30
44617c00 8e3400eb bl       #0x44624e40
44617c04 000050e3 cmp      r0, #0
44617c08 0800000a beq      #0x44617c30
44617c0c 20239fe5 ldr      r2, [pc, #0x320]
44617c10 821f4fe2 sub      r1, pc, #0x208
44617c14 830f4fe2 sub      r0, pc, #0x20c
44617c18 07008de8 stm      sp, {r0, r1, r2}
44617c1c 0030a0e3 mov      r3, #0
44617c20 0320a0e1 mov      r2, r3
44617c24 871f4fe2 sub      r1, pc, #0x21c
44617c28 870f4fe2 sub      r0, pc, #0x21c
44617c2c 4c1706eb bl       #0x4479d964
44617c30 840197e7 ldr      r0, [r7, r4, lsl #3]
44617c34 051190e7 ldr      r1, [r0, r5, lsl #2]
44617c38 060051e1 cmp      r1, r6
44617c3c 0cd08d02 addeq    sp, sp, #0xc
44617c40 f080bd08 popeq    {r4, r5, r6, r7, pc}
44617c44 056180e7 str      r6, [r0, r5, lsl #2]
44617c48 0400a0e1 mov      r0, r4
44617c4c 0cd08de2 add      sp, sp, #0xc
44617c50 f040bde8 pop      {r4, r5, r6, r7, lr}
44617c54 0110a0e3 mov      r1, #1
44617c58 498100ea b        #0x44638184
44617c5c 70402de9 push     {r4, r5, r6, lr}
44617c60 10d04de2 sub      sp, sp, #0x10
44617c64 0040a0e1 mov      r4, r0
44617c68 0150a0e1 mov      r5, r1
44617c6c 3f8100eb bl       #0x44638170
44617c70 5b0054e3 cmp      r4, #0x5b
44617c74 0060a0e1 mov      r6, r0
44617c78 0b00003a blo      #0x44617cac
44617c7c 6f3400eb bl       #0x44624e40
44617c80 000050e3 cmp      r0, #0
44617c84 0800000a beq      #0x44617cac
44617c88 a8229fe5 ldr      r2, [pc, #0x2a8]
44617c8c a11f4fe2 sub      r1, pc, #0x284
44617c90 a20f4fe2 sub      r0, pc, #0x288
44617c94 07008de8 stm      sp, {r0, r1, r2}
44617c98 0030a0e3 mov      r3, #0
44617c9c 0320a0e1 mov      r2, r3
44617ca0 a61f4fe2 sub      r1, pc, #0x298
44617ca4 a60f4fe2 sub      r0, pc, #0x298
44617ca8 2d1706eb bl       #0x4479d964
44617cac 841186e0 add      r1, r6, r4, lsl #3
44617cb0 041091e5 ldr      r1, [r1, #4]
44617cb4 0501a0e1 lsl      r0, r5, #2
44617cb8 040080e2 add      r0, r0, #4
44617cbc 010050e1 cmp      r0, r1
44617cc0 0b00009a bls      #0x44617cf4
44617cc4 5d3400eb bl       #0x44624e40
44617cc8 000050e3 cmp      r0, #0
44617ccc 0800000a beq      #0x44617cf4
44617cd0 232ea0e3 mov      r2, #0x230
44617cd4 b31f4fe2 sub      r1, pc, #0x2cc
44617cd8 2d0e4fe2 sub      r0, pc, #0x2d0
44617cdc 07008de8 stm      sp, {r0, r1, r2}
44617ce0 0030a0e3 mov      r3, #0
44617ce4 0320a0e1 mov      r2, r3
44617ce8 2e1e4fe2 sub      r1, pc, #0x2e0
44617cec 2e0e4fe2 sub      r0, pc, #0x2e0
44617cf0 1b1706eb bl       #0x4479d964
44617cf4 840196e7 ldr      r0, [r6, r4, lsl #3]
44617cf8 051190e7 ldr      r1, [r0, r5, lsl #2]
44617cfc 010071e3 cmn      r1, #1
44617d00 10d08d02 addeq    sp, sp, #0x10
44617d04 7080bd08 popeq    {r4, r5, r6, pc}
44617d08 011081e2 add      r1, r1, #1
44617d0c 051180e7 str      r1, [r0, r5, lsl #2]
44617d10 0400a0e1 mov      r0, r4
44617d14 10d08de2 add      sp, sp, #0x10
44617d18 7040bde8 pop      {r4, r5, r6, lr}
44617d1c 0110a0e3 mov      r1, #1
44617d20 178100ea b        #0x44638184
44617d24 f0402de9 push     {r4, r5, r6, r7, lr}
44617d28 0cd04de2 sub      sp, sp, #0xc
44617d2c 0040a0e1 mov      r4, r0
44617d30 0150a0e1 mov      r5, r1
44617d34 0260a0e1 mov      r6, r2
44617d38 0c8100eb bl       #0x44638170
44617d3c 5b0054e3 cmp      r4, #0x5b
44617d40 0070a0e1 mov      r7, r0
44617d44 0b00003a blo      #0x44617d78
44617d48 3c3400eb bl       #0x44624e40
44617d4c 000050e3 cmp      r0, #0
44617d50 0800000a beq      #0x44617d78
44617d54 252ea0e3 mov      r2, #0x250
44617d58 351e4fe2 sub      r1, pc, #0x350
44617d5c d50f4fe2 sub      r0, pc, #0x354
44617d60 07008de8 stm      sp, {r0, r1, r2}
44617d64 0030a0e3 mov      r3, #0
44617d68 0320a0e1 mov      r2, r3
44617d6c d91f4fe2 sub      r1, pc, #0x364
44617d70 d90f4fe2 sub      r0, pc, #0x364
44617d74 fa1606eb bl       #0x4479d964
44617d78 841187e0 add      r1, r7, r4, lsl #3
44617d7c 041091e5 ldr      r1, [r1, #4]
44617d80 0501a0e1 lsl      r0, r5, #2
44617d84 040080e2 add      r0, r0, #4
44617d88 010050e1 cmp      r0, r1
44617d8c 0b00009a bls      #0x44617dc0
44617d90 2a3400eb bl       #0x44624e40
44617d94 000050e3 cmp      r0, #0
44617d98 0800000a beq      #0x44617dc0
44617d9c 98219fe5 ldr      r2, [pc, #0x198]
44617da0 e61f4fe2 sub      r1, pc, #0x398
44617da4 e70f4fe2 sub      r0, pc, #0x39c
44617da8 07008de8 stm      sp, {r0, r1, r2}
44617dac 0030a0e3 mov      r3, #0
44617db0 0320a0e1 mov      r2, r3
44617db4 eb1f4fe2 sub      r1, pc, #0x3ac
44617db8 eb0f4fe2 sub      r0, pc, #0x3ac
44617dbc e81606eb bl       #0x4479d964
44617dc0 000056e3 cmp      r6, #0
44617dc4 0cd08d02 addeq    sp, sp, #0xc
44617dc8 f080bd08 popeq    {r4, r5, r6, r7, pc}
44617dcc 840197e7 ldr      r0, [r7, r4, lsl #3]
44617dd0 051190e7 ldr      r1, [r0, r5, lsl #2]
44617dd4 061081e0 add      r1, r1, r6
44617dd8 051180e7 str      r1, [r0, r5, lsl #2]
44617ddc 0400a0e1 mov      r0, r4
44617de0 0cd08de2 add      sp, sp, #0xc
44617de4 f040bde8 pop      {r4, r5, r6, r7, lr}
44617de8 0110a0e3 mov      r1, #1
44617dec e48000ea b        #0x44638184
44617df0 f0402de9 push     {r4, r5, r6, r7, lr}
44617df4 0cd04de2 sub      sp, sp, #0xc
44617df8 0070a0e1 mov      r7, r0
44617dfc 0160a0e1 mov      r6, r1
44617e00 0240a0e1 mov      r4, r2
44617e04 d98000eb bl       #0x44638170
44617e08 5b0057e3 cmp      r7, #0x5b
44617e0c 0050a0e1 mov      r5, r0
44617e10 0b00003a blo      #0x44617e44
44617e14 093400eb bl       #0x44624e40
44617e18 000050e3 cmp      r0, #0
44617e1c 0800000a beq      #0x44617e44
44617e20 272ea0e3 mov      r2, #0x270
44617e24 451f8fe2 add      r1, pc, #0x114
44617e28 110e8fe2 add      r0, pc, #0x110
44617e2c 07008de8 stm      sp, {r0, r1, r2}
44617e30 0030a0e3 mov      r3, #0
44617e34 0320a0e1 mov      r2, r3
44617e38 011c8fe2 add      r1, pc, #0x100
44617e3c 010c8fe2 add      r0, pc, #0x100
44617e40 c71606eb bl       #0x4479d964
44617e44 871185e0 add      r1, r5, r7, lsl #3
44617e48 041091e5 ldr      r1, [r1, #4]
44617e4c 0401a0e1 lsl      r0, r4, #2
44617e50 040080e2 add      r0, r0, #4
44617e54 010050e1 cmp      r0, r1
44617e58 0b00009a bls      #0x44617e8c
44617e5c f73300eb bl       #0x44624e40
44617e60 000050e3 cmp      r0, #0
44617e64 0800000a beq      #0x44617e8c
44617e68 d8209fe5 ldr      r2, [pc, #0xd8]
44617e6c cc108fe2 add      r1, pc, #0xcc
44617e70 c8008fe2 add      r0, pc, #0xc8
44617e74 07008de8 stm      sp, {r0, r1, r2}
44617e78 0030a0e3 mov      r3, #0
44617e7c 0320a0e1 mov      r2, r3
44617e80 b8108fe2 add      r1, pc, #0xb8
44617e84 b8008fe2 add      r0, pc, #0xb8
44617e88 b51606eb bl       #0x4479d964
44617e8c 5b0056e3 cmp      r6, #0x5b
44617e90 0b00003a blo      #0x44617ec4
44617e94 e93300eb bl       #0x44624e40
44617e98 000050e3 cmp      r0, #0
44617e9c 0800000a beq      #0x44617ec4
44617ea0 a4209fe5 ldr      r2, [pc, #0xa4]
44617ea4 94108fe2 add      r1, pc, #0x94
44617ea8 90008fe2 add      r0, pc, #0x90
44617eac 07008de8 stm      sp, {r0, r1, r2}
44617eb0 0030a0e3 mov      r3, #0
44617eb4 0320a0e1 mov      r2, r3
44617eb8 80108fe2 add      r1, pc, #0x80
44617ebc 80008fe2 add      r0, pc, #0x80
44617ec0 a71606eb bl       #0x4479d964
44617ec4 860185e0 add      r0, r5, r6, lsl #3
44617ec8 040090e5 ldr      r0, [r0, #4]
44617ecc 011084e2 add      r1, r4, #1
44617ed0 010050e1 cmp      r0, r1
44617ed4 0b00002a bhs      #0x44617f08
44617ed8 d83300eb bl       #0x44624e40
44617edc 000050e3 cmp      r0, #0
44617ee0 0800000a beq      #0x44617f08
44617ee4 64209fe5 ldr      r2, [pc, #0x64]
44617ee8 50108fe2 add      r1, pc, #0x50
44617eec 4c008fe2 add      r0, pc, #0x4c
44617ef0 07008de8 stm      sp, {r0, r1, r2}
44617ef4 0030a0e3 mov      r3, #0
44617ef8 0320a0e1 mov      r2, r3
44617efc 3c108fe2 add      r1, pc, #0x3c
44617f00 3c008fe2 add      r0, pc, #0x3c
44617f04 961606eb bl       #0x4479d964
44617f08 870195e7 ldr      r0, [r5, r7, lsl #3]
44617f0c 861195e7 ldr      r1, [r5, r6, lsl #3]
44617f10 040190e7 ldr      r0, [r0, r4, lsl #2]
44617f14 0410d1e7 ldrb     r1, [r1, r4]
44617f18 0cd08de2 add      sp, sp, #0xc
44617f1c f080bde8 pop      {r4, r5, r6, r7, pc}
44617f20 d9010000 ldrdeq   r0, r1, [r0], -sb
44617f24 da010000 ldrdeq   r0, r1, [r0], -sl
44617f28 ffff0000 .byte    0xff, 0xff, 0x00, 0x00
44617f2c f9010000 strdeq   r0, r1, [r0], -sb
44617f30 12020000 andeq    r0, r0, r2, lsl r2
44617f34 13020000 andeq    r0, r0, r3, lsl r2
44617f38 2f020000 andeq    r0, r0, pc, lsr #4
44617f3c 51020000 andeq    r0, r0, r1, asr r2
44617f40 00000000 andeq    r0, r0, r0
44617f44 30000000 andeq    r0, r0, r0, lsr r0
44617f48 71020000 andeq    r0, r0, r1, ror r2
44617f4c 72020000 andeq    r0, r0, r2, ror r2
44617f50 73020000 andeq    r0, r0, r3, ror r2
44617f54 f0472de9 push     {r4, r5, r6, r7, r8, sb, sl, lr}
44617f58 10d04de2 sub      sp, sp, #0x10
44617f5c 0070a0e1 mov      r7, r0
44617f60 30008de2 add      r0, sp, #0x30
44617f64 000590e8 ldm      r0, {r8, sl}
44617f68 0160a0e1 mov      r6, r1
44617f6c 0240a0e1 mov      r4, r2
44617f70 7e8000eb bl       #0x44638170
44617f74 5b0057e3 cmp      r7, #0x5b
44617f78 0050a0e1 mov      r5, r0
44617f7c 0b00003a blo      #0x44617fb0
44617f80 ae3300eb bl       #0x44624e40
44617f84 000050e3 cmp      r0, #0
44617f88 0800000a beq      #0x44617fb0
44617f8c d4249fe5 ldr      r2, [pc, #0x4d4]
44617f90 58104fe2 sub      r1, pc, #0x58
44617f94 5c004fe2 sub      r0, pc, #0x5c
44617f98 07008de8 stm      sp, {r0, r1, r2}
44617f9c 0030a0e3 mov      r3, #0
44617fa0 0320a0e1 mov      r2, r3
44617fa4 6c104fe2 sub      r1, pc, #0x6c
44617fa8 6c004fe2 sub      r0, pc, #0x6c
44617fac 6c1606eb bl       #0x4479d964
44617fb0 871185e0 add      r1, r5, r7, lsl #3
44617fb4 041091e5 ldr      r1, [r1, #4]
44617fb8 0401a0e1 lsl      r0, r4, #2
44617fbc 040080e2 add      r0, r0, #4
44617fc0 010050e1 cmp      r0, r1
44617fc4 0b00009a bls      #0x44617ff8
44617fc8 9c3300eb bl       #0x44624e40
44617fcc 000050e3 cmp      r0, #0
44617fd0 0800000a beq      #0x44617ff8
44617fd4 90249fe5 ldr      r2, [pc, #0x490]
44617fd8 a0104fe2 sub      r1, pc, #0xa0
44617fdc a4004fe2 sub      r0, pc, #0xa4
44617fe0 07008de8 stm      sp, {r0, r1, r2}
44617fe4 0030a0e3 mov      r3, #0
44617fe8 0320a0e1 mov      r2, r3
44617fec b4104fe2 sub      r1, pc, #0xb4
44617ff0 b4004fe2 sub      r0, pc, #0xb4
44617ff4 5a1606eb bl       #0x4479d964
44617ff8 5b0056e3 cmp      r6, #0x5b
44617ffc 0b00003a blo      #0x44618030
