# Reproduce KU25Q4 S1
Place official FWCL14TL_KU25Q4.efu in the directory containing these scripts.
Source SHA-256: fb8bc19af5a13bb6dba43f8971aafeb062425e030be0c761eeccbf6000c99a56
Install cryptography and unicorn with normal package/TLS verification enabled.
Run: python3 package_ku_stage1.py
It extracts the original module, builds S1, packages EFU, re-extracts it, and
executes the native tests on that final extracted module. Capstone is optional
and only needed by audit_ku_maintenance.py. No printer is accessed.
The official EFU and flash dumps are not included. build_ku_controls.py provides
the shared read-only section-validation helper; its main function is not run.
CROM codec provenance: repository LK29Q5-startup-G2-validation.zip.
