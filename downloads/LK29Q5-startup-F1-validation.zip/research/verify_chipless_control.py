"""F1 native chip-exemption regressions. No physical boot or chip emulation."""
import itertools,json,struct
from build_chipless_control import build,ROOT
from build_consumption_control import build as build_e
from verify_consumption_control import verify as verify_e
from maintenance_v3_fixture import Fixture

def snapshot(n):
 return [struct.unpack('<I',n.u.mem_read(p,4))[0] for p in (0x437cfebc,0x437cfecc,0x437cff9c,0x437ceba4)]

def flow(code,profile_flag,present,stored,fraction,mirror_fill,calibration):
 n=Fixture(code,profile_flag,present)
 for p,value in zip((0x437cfebc,0x437cfecc,0x437cff9c),(stored,(stored+17)&0xffffffff,(stored+31)&0xffffffff)):
  n.u.mem_write(p,struct.pack('<I',value))
 if calibration:
  bindings=n.literal(0x4340ae08,0x1c)
  for record,value in ((0x4e,0),(0x4f,90)):
   ptr,size=struct.unpack('<II',n.u.mem_read(bindings+record*8,8));assert size==16
   n.u.mem_write(ptr,struct.pack('<I',value))
 n.call(0x434051b4);n.call(0x43405798,0)
 assert n.call(0x43407f5c)==0
 mirror=n.literal(0x43407740,-0x140);n.u.mem_write(mirror,bytes([mirror_fill])*192)
 n.u.mem_write(0x437ceba4,struct.pack('<I',fraction));before=snapshot(n)
 n.call(0x4340e428,3)
 output=0x42001000;request=0x42002000
 n.u.mem_write(request,struct.pack('<II',500000000,0)+bytes(24))
 returns={}
 for fn,args in [(0x4340e15c,(output,)),(0x4340df98,(output,0)),(0x4340de44,(0,0)),(0x43410144,(request,)),
                 (0x43410330,(request,)),(0x43410430,(request,)),(0x4341027c,(request,0))]:
  value=n.call(fn,*args);assert value==1,(hex(fn),value)
  assert n.call(0x43407f5c)==0;returns[hex(fn)]=value
 mask=0x42003000;presence=mask+16;n.u.mem_write(mask,struct.pack('<I',1)+bytes(12))
 n.call(0x43406214,mask,presence);assert struct.unpack('<I',n.u.mem_read(presence,4))[0]==1
 n.call(0x43406330,mask,presence);n.call(0x43410748,output)
 assert n.u.mem_read(output,1)[0]==1 and n.call(0x43407f5c)==0 and n.call(0x43407ffc)==100
 assert not n.hardware_calls and before==snapshot(n)
 assert n.call(0x43406890)==before[0] and n.call(0x434068bc)==before[1]
 return {'returns':returns,'raw_state':0,'slot0_status':1,'remaining_report':100,'stored_counters_and_fraction':before,
 'capacity_after_setup':struct.unpack('<I',n.u.mem_read(n.literal(0x43406940,0x274),4))[0],
 'physical_presence_callback_calls':0,'OS_calls':n.os_calls,'copy_fixture_calls':n.utility_calls}

def main():
 code,manifest=build();e,_=build_e();regression=verify_e(code,manifest);assert regression['scenario_count']==395
 # Negative control must query the modeled absent chip and reject its absence.
 negative=Fixture(e,0,False);negative.call(0x434051b4)
 rejected=negative.call(0x4340e15c,0x42001000);assert rejected==0 and len(negative.hardware_calls)>0
 cases=[]
 for present,stored,fraction,mirror_fill,calibration,profile in itertools.product((False,True),(0,123000000,1000000000,0xffffffff),(0,999999),(0,255),(False,True),(0,1)):
  # Original E with a genuinely selected exemption profile is the positive RAM reference.
  reference=flow(e,1,present,stored,fraction,mirror_fill,calibration)
  candidate=flow(code,profile,present,stored,fraction,mirror_fill,calibration)
  assert candidate==reference
  cases.append({'modeled_chip_present':present,'primary_counter':stored,'fraction':fraction,'mirror_fill':mirror_fill,
 'explicit_calibration_fixture':calibration,'raw_profile_header_byte2':profile,'matches_original_exemption_profile':True,'result':candidate})
 cover=[]
 for value in (0,1,2):
  n=Fixture(code,0,False);n.call(0x434051b4);n.u.mem_write(n.cover,bytes([value])*3)
  n.call(0x43410748,0x42001000);status=n.u.mem_read(0x42001000,1)[0]
  assert status==int(value==0);cover.append({'cover_status_fixture':value,'slot_status':status})
 report={'module_sha256':manifest['module_sha256'],'scenario_count':395+len(cases)+len(cover)+1,
 'E_regressions':regression,'startup_profile_cases':cases,'cover_cases':cover,
 'negative_control':{'original_E_profile0_absent_return':rejected,'presence_callback_calls':len(negative.hardware_calls)},
 'native_verdict_hooks':0,'fixtures':['Single modeled bus presence callback','Bus begin/end callbacks omitted','OS delay/signaling','ROM copy utility','Synthetic profile, clock and nonvolatile cache; optional calibration record4e=0/4f=90'],
 'not_proven':['Physical F1 boot even with cartridge installed','Physical missing-chip operation','UI startup completion and full RTOS scheduling','Actual electrical bus callbacks','Profile flag official product semantics']}
 assert len(cases)==128 and report['scenario_count']==527
 (ROOT/'validation/chipless-F1-native-results.json').write_text(json.dumps(report,indent=2)+'\n')
 print('PASS',report['scenario_count'],'native cases; 128 cold profile flows; one extra code byte vs E')
if __name__=='__main__':main()
