"""Read-only, reproducible audit of the supplied P7500 SPI and EFU.

This does not claim ARM execution or generate modified firmware. Supplied
research addresses are checked against the dump, rather than assumed correct.
"""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_ROM = 'ae9b0cd5f15f1f2edcfd671c9131d9383243e1fbf9c59b0bf31dcaa04968c551'
EXPECTED_CODE = '52bff0422d872906047c36ed8abfca899934acdf3a7ec7b7edb3ab76a6003d94'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def crom_tables(rom, offset):
    require(rom[offset:offset + 6] == b'CROM\xff\xd8', 'CROM marker mismatch')
    p = offset + 10
    require(rom[p:p + 2] == b'\xff\xc4', 'Missing CROM Huffman marker')
    end = p + 2 + int.from_bytes(rom[p + 2:p + 4], 'big')
    q = p + 4
    tables = []
    while q < end:
        counts = list(rom[q + 1:q + 17])
        require(len(counts) == 16, 'Truncated Huffman counts')
        n = sum(counts)
        require(q + 17 + n <= end, 'Truncated Huffman symbols')
        tables.append({'id': hex(rom[q]), 'code_counts': counts,
                       'symbol_count': n})
        q += 17 + n
    require(q == end, 'Huffman table boundary mismatch')
    return {'offset': hex(offset), 'tables': tables,
            'next_marker_offset': hex(end),
            'next_marker': rom[end:end + 2].hex(),
            'decoded': False}


def verify_signature(key, signature, digest):
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import ec, utils
    except ImportError:
        return {'status': 'not_run', 'reason': 'cryptography unavailable'}
    try:
        pub = ec.EllipticCurvePublicNumbers(
            int.from_bytes(key[:32], 'big'),
            int.from_bytes(key[32:], 'big'), ec.SECP256R1()).public_key()
        sig = utils.encode_dss_signature(int.from_bytes(signature[:32], 'big'),
                                        int.from_bytes(signature[32:], 'big'))
        pub.verify(sig, digest, ec.ECDSA(utils.Prehashed(hashes.SHA256())))
        return {'status': 'valid', 'implementation': 'host cryptography, not ARM'}
    except InvalidSignature:
        return {'status': 'invalid', 'implementation': 'host cryptography, not ARM',
                'interpretation': 'Fails raw big-endian r||s / SHA256(body) hypothesis'}
    except ValueError as exc:
        return {'status': 'invalid_key_or_encoding', 'reason': str(exc)}


def inspect(rom_path, efu_path, module_path=None):
    rom = rom_path.read_bytes()
    require(sha(rom) == EXPECTED_ROM, 'Original merged SPI SHA-256 mismatch')
    descriptors = []
    for offset, expected in [(0x662fc, (0x6d000, 0x43f91800, 0x1000)),
                             (0x66308, (0x27b404, 0x43f99000, 0x3bc0c))]:
        src, dst, size = struct.unpack_from('<III', rom, offset)
        require((src, dst, size) == expected, 'Loader descriptor mismatch')
        require(src + size <= len(rom), 'Descriptor outside SPI')
        descriptors.append({'offset': hex(offset), 'source': hex(src),
                            'destination': hex(dst), 'size': size,
                            'copied_data_sha256': sha(rom[src:src + size])})
    key = rom[0x6d000:0x6d040]
    require(key == rom[0x7010:0x7050], 'Original public-key copies differ')
    module = {'status': 'missing', 'expected_sha256': EXPECTED_CODE}
    if module_path is not None:
        code = module_path.read_bytes()
        require(sha(code) == EXPECTED_CODE, 'Original decoded module SHA-256 mismatch')
        module.update(status='hash_verified', size=len(code), load_address='0x4409b000')
    with zipfile.ZipFile(efu_path) as archive:
        entries = archive.infolist()
        require(len(entries) == 1 and entries[0].filename == 'FW7560TL.rcx',
                'Unexpected EFU members')
        require(entries[0].file_size <= 256 * 1024 * 1024, 'RCX exceeds audit size limit')
        rcx = archive.read(entries[0])  # ZipFile verifies the member CRC.
    offset = rcx.find(b'EPSONSIGN')
    require(offset >= 0 and rcx.find(b'EPSONSIGN', offset + 1) < 0,
            'Expected one signature header')
    require(len(rcx) >= offset + 4096, 'Truncated signature header')
    header, body = rcx[offset:offset + 4096], rcx[offset + 4096:]
    declared = struct.unpack_from('<I', header, 16)[0]
    require(header[9:13] == b'LK19', 'Unexpected signature family/generation')
    require(struct.unpack_from('<H', header, 13)[0] == 100, 'Unexpected +0x0d field')
    require(declared != 0, 'Zero declared body length')
    digest = hashlib.sha256(body).digest()
    metadata = rcx[:offset].decode('ascii')
    signature = header[32:96]
    original = verify_signature(key, signature, digest)
    changed_digest = bytes([digest[0] ^ 1]) + digest[1:]
    changed_signature = bytes([signature[0] ^ 1]) + signature[1:]
    controls = {
        'original': original,
        'changed_digest': verify_signature(key, signature, changed_digest),
        'changed_signature': verify_signature(key, changed_signature, digest),
    }
    if original['status'] == 'valid':
        # Rehash an actual changed body as well as testing changed digest input.
        mutated = hashlib.sha256()
        mutated.update(bytes([body[0] ^ 1]))
        mutated.update(memoryview(body)[1:])
        controls['changed_body'] = verify_signature(key, signature, mutated.digest())
        require(all(controls[name]['status'] == 'invalid' for name in
                    ['changed_digest', 'changed_signature', 'changed_body']),
                'Signature negative control unexpectedly accepted')
    return {
        'rom_sha256': sha(rom), 'loader_descriptors': descriptors,
        'original_public_key_sha256': sha(key), 'public_key_copies_match': True,
        'crom': crom_tables(rom, 0x2d6c00), 'module': module,
        'efu': {'sha256': sha(efu_path.read_bytes()), 'rcx_sha256': sha(rcx),
                'rcx_metadata': metadata, 'signature_header_offset': hex(offset),
                'header_size_hypothesis': 4096, 'declared_body_length': declared,
                'actual_body_length': len(body), 'lengths_equal': declared == len(body),
                'body_sha256': digest.hex(),
                'signature_check_with_original_spi_key': original,
                'signature_controls': controls},
        'arm_execution': {'status': 'not_run',
                          'reason': 'CROM decoder and receiver ABI not reconstructed'},
        'firmware_modified': False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rom', type=Path, default=ROOT / 'original/merged.bin')
    parser.add_argument('--efu', type=Path, default=ROOT / 'FW7560TL_LK29Q5.efu')
    parser.add_argument('--module', type=Path)
    parser.add_argument('--native', action='store_true',
                        help='Also execute the original and latest ARM receiver suites')
    parser.add_argument('--output', type=Path,
                        default=ROOT / 'validation/efu-envelope-audit.json')
    args = parser.parse_args()
    if args.native:
        subprocess.run([sys.executable, str(ROOT / 'research/decode_crom.py')],
                       cwd=ROOT, check=True)
        from decode_crom import decode
        rcx = (ROOT / 'FW7560TL.rcx').read_bytes()
        latest, report = decode(rcx, 0x27ad53)
        require(report['sha256'] == 'a58dc0eb44390e524fd6debda23cfa5eb952c28a843b1db1cc39f75efa956726',
                'LK29Q5 module hash mismatch')
        (ROOT / 'decoded/lk29q5-crom-0027ad53.bin').write_bytes(latest)
        (ROOT / 'validation/lk29q5-decoding.json').write_text(json.dumps(report, indent=2) + '\n')
        control, control_report = decode(rcx, 0x14153)
        require(control_report['sha256'] == '82c4c34f4ed5c1dd7118dd74839b499329d732d37b467df734ed5382a25dedac',
                'LK29Q5 control module hash mismatch')
        (ROOT / 'decoded/lk29q5-crom-00014153.bin').write_bytes(control)
        (ROOT / 'validation/lk29q5-control-decoding.json').write_text(json.dumps(control_report, indent=2) + '\n')
        args.module = ROOT / 'decoded/crom-002d6c00-0.bin'
        for filename in ['probe_efu_native.py', 'probe_lk29q5_native.py',
                         'probe_maintenance_state.py', 'probe_maintenance_consumption.py',
                         'probe_maintenance_scenarios.py', 'probe_maintenance_state7_entry.py',
                         'probe_maintenance_notifications.py']:
            subprocess.run([sys.executable, str(ROOT / 'research' / filename)],
                           cwd=ROOT, check=True)
    result = inspect(args.rom, args.efu, args.module)
    if args.native:
        result['arm_execution'] = {
            'status': 'completed',
            'original_results': 'validation/efu-envelope-native-results.json',
            'latest_results': 'validation/lk29q5-native-results.json',
            'original_cases': 26, 'latest_cases': 14,
            'maintenance_helper_cases': 82,
            'maintenance_consumption_cases': 19,
            'maintenance_original_scenarios': 3,
            'maintenance_state7_entry_cases': 8,
            'maintenance_notification_cases': 3,
            'scope': 'Synthetic inputs and explicit OS/storage fixtures; not full boot or device operation',
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
