"""Audit actual C/D/E package bytes against the matching native tests."""
import hashlib,json,struct,zipfile,argparse
from audit_recovery_failure import ROOT,checksum_audit,loader_audit

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--variant',choices=('C','D','E'),default='C');variant=parser.parse_args().variant
 stem={'C':'FW7560TL_LK29Q5-startup-C-remaining-report-only','D':'FW7560TL_LK29Q5-startup-D-lifetime-control','E':'FW7560TL_LK29Q5-startup-E-zero-new-consumption'}[variant]
 path=ROOT/'experimental'/(stem+'.efu')
 with zipfile.ZipFile(path) as z:assert z.testzip() is None;rcx=z.read('FW7560TL.rcx')
 official=(ROOT/'FW7560TL.rcx').read_bytes();module=(ROOT/{'C':'experimental/maintenance-control.report-C.bin','D':'experimental/maintenance-control.lifetime-D.bin','E':'experimental/maintenance-control.consumption-E.bin'}[variant]).read_bytes()
 tests=json.loads((ROOT/{'C':'validation/remaining-report-C-native-results.json','D':'validation/lifetime-D-native-results.json','E':'validation/consumption-E-native-results.json'}[variant]).read_text())
 required={'C':87,'D':118,'E':395}[variant]
 assert hashlib.sha256(module).hexdigest()==tests['module_sha256'] and tests['scenario_count']==required
 code=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
 checksum=checksum_audit(variant+'-maintenance-control',rcx,code[0x4419e2e0-0x4409b000:0x4419e324-0x4409b000])
 start=0x14153;end=start+4+int.from_bytes(rcx[start+6:start+10],'big')
 loader=loader_audit(variant+'-maintenance-control',rcx[start:end],official[0x25bb23:0x25bb23+0xae8],module)
 assert checksum['native_checksum_return']==1 and loader['native_dma_mod48']==0 and loader['native_lz_output_exact']
 pos=rcx.index(b'EPSONSIGN')+4096;sections=[]
 while pos<len(rcx):
  header=rcx[pos:pos+4096];assert header.startswith(b'EPSON')
  meta=struct.unpack_from('<I',header,28)[0];size=struct.unpack_from('<I',header,64)[0]
  begin=pos+4096+meta;end=begin+size;assert end<=len(rcx)
  assert sum(rcx[pos+4096:begin])&65535==struct.unpack_from('<H',header,18)[0]
  assert sum(rcx[begin:end])&65535==struct.unpack_from('<H',header,54)[0]
  assert hashlib.sha1(rcx[begin:end]+hashlib.sha1(header[:14]).digest()).digest()==header[68:88]
  sections.append({'offset':hex(pos),'metadata_bytes':meta,'payload_bytes':size,'all_checks_passed':True});pos=end
 assert len(sections)==4 and pos==len(rcx)
 report={'efu_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'module_sha256':tests['module_sha256'],
 'native_cases':required,'native_payload_checksum':checksum,'native_loader':loader,'host_sections':sections,
 'baseline_user_report':{'official_after_v3_boots':True,'A_boots':True,'B_boots':True},
 'candidate':variant,'physical_candidate_boot_tested':False,'full_candidate_upper_receiver_replay_executed':False,
 'limitations':['Hardware Huffman modeled at completion boundary','No whole boot, physical CSIC, PC updater or flash execution','This is a staged maintenance experiment, not a complete virtual cartridge implementation']}
 out=ROOT/{'C':'validation/remaining-report-C-package-audit.json','D':'validation/lifetime-D-package-audit.json','E':'validation/consumption-E-package-audit.json'}[variant];out.write_text(json.dumps(report,indent=2)+'\n')
 (path.parent/(path.name+'.sha256')).write_text(report['efu_sha256']+'  '+path.name+'\n')
 print('PASS',variant,'ZIP, all four host section checks, native full payload checksum, native loader/DMA/LZ; hash',report['efu_sha256'])
if __name__=='__main__':main()
