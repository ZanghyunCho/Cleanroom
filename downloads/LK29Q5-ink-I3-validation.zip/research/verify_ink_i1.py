"""I1 boundary tests; not physical chip authenticity or printing tests."""
import json,struct
from build_ink_i1 import build,ROOT
from build_consumption_control import build as build_e
from probe_maintenance_state import Control
from verify_consumption_control import verify as verify_e
from unicorn import UC_HOOK_CODE
from unicorn.arm_const import UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_PC,UC_ARM_REG_LR

def configure(code):
    n=Control(code)
    n.u.mem_write(n.literal(0x433f6378,0x27c),bytes(8))
    return n

def ledger_case(code,slot,before,delta,secondary):
    n=configure(code);bindings=n.literal(0x4340ae08,0x1c)
    addresses=[]
    for record in (0x22,0x23,0x24,0x25,0x2f,0x30):
        ptr,size=struct.unpack('<II',n.u.mem_read(bindings+record*8,8))
        assert size=={0x22:64,0x23:16,0x24:64,0x25:16,0x2f:48,0x30:12}[record]
        if record in (0x23,0x25,0x30):
            seed=bytes((before+i)&255 for i in range(size))
        else:
            seed=b''.join(struct.pack('<I',(before+i)&0xffffffff) for i in range(size//4))
        n.u.mem_write(ptr,seed)
        addresses.append((ptr,size))
    for address,disp in ((0x4340056c,0xa0),(0x4340059c,0x74)):
        ptr=n.literal(address,disp);n.u.mem_write(ptr,b''.join(struct.pack('<I',i*31) for i in range(16)))
        addresses.append((ptr,64))
    dirty=n.literal(0x4340ae1c,0xc);n.u.mem_write(dirty,bytes(89*4))
    n.call(0x43400530 if secondary else 0x433ffe8c,slot,delta)
    return dict(data=[bytes(n.u.mem_read(p,size)).hex() for p,size in addresses],
                dirty=bytes(n.u.mem_read(dirty,89*4)).hex())

def notify(code,state,branding,remaining):
    n=configure(code);reports=0x42010000;events=[]
    state_ptr=n.literal(0x43403498,0x118)
    n.u.mem_write(state_ptr,bytes([state])*12)
    n.u.mem_write(n.literal(0x434033dc,0x1d8),bytes([branding])*12)
    n.u.mem_write(n.literal(0x43403524,0x94),bytes([remaining])*12)
    n.call(0x43403324,1)
    def hook(u,a,size,data):
        value=0
        if a==0x43408cb0:value=reports+u.reg_read(UC_ARM_REG_R0)*8
        elif a==0x43403744:value=700
        elif a==0x4360ee3c:u.mem_write(u.reg_read(UC_ARM_REG_R1),struct.pack('<I',0x42011000))
        elif a==0x43557388:events.append(u.reg_read(UC_ARM_REG_R0))
        elif a not in (0x4360f7b0,0x43458c30,0x43458e1c):return
        u.reg_write(UC_ARM_REG_R0,value);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR))
    n.u.hook_add(UC_HOOK_CODE,hook)
    n.call(0x433f3378)
    assert bytes(n.u.mem_read(state_ptr,12))==bytes([state])*12
    return bytes(n.u.mem_read(reports,96)).hex()

def verify(code,manifest):
    e,_=build_e();regression=verify_e(code,manifest)
    assert regression['scenario_count']==395
    percentages=[]
    for slot in range(12):
        for state in range(13):
            for stored in (0,1,9,10,50,100):
                n=configure(code);ptr=n.literal(0x43403498,0x118)
                n.u.mem_write(ptr+slot,bytes([state]))
                n.u.mem_write(n.literal(0x43403524,0x94)+slot,bytes([stored]))
                assert n.call(0x4340347c,slot)==100
                assert n.u.mem_read(ptr+slot,1)[0]==state
                percentages.append(dict(slot=slot,state=state,stored_percentage=stored))
    ledgers=[]
    for secondary in (False,True):
        for slot in range(12):
            for before in (0,123000000,0xffffffff):
                reference=ledger_case(e,slot,before,0,secondary)
                for delta in (0,1,1000000,0xffffffff):
                    assert ledger_case(code,slot,before,delta,secondary)==reference
                    ledgers.append(dict(secondary=secondary,slot=slot,before=before,delta=delta))
    normal=notify(e,0,0,100)
    assert notify(e,0,1,100)!=normal
    reports=[]
    for state in range(13):
        for branding in range(4):
            result=notify(code,state,branding,7)
            assert result==normal
            reports.append(dict(raw_state=state,branding_fixture=branding,report=result))
    report=dict(module_sha256=manifest['module_sha256'],scenario_count=395+len(percentages)+len(ledgers)+len(reports),
                E_regressions=regression,percentage_cases=percentages,ledger_cases=ledgers,notification_cases=reports,
                normal_reference_report=normal,
                notification_fixtures=['Per-slot output buffers','Capacity numeric fixture 700','Message allocation/transport and event sinks','Logging sinks'],
                maintenance_verdict_hooks=0,physical_tested=False,
                limits=['Report-field equivalence is not proof of every UI message being suppressed',
                        'No real chip, electrical absence, printing, ink-end or boot test',
                        'Two identified addition helpers, not all restoration/reconciliation writes',
                        'Notification normal class is a presentation result, not cryptographic authentication'])
    return report

def main():
    code,manifest=build();report=verify(code,manifest)
    (ROOT/'validation/ink-I1-native-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS I1',report['scenario_count'],'native cases')

if __name__=='__main__':main()
