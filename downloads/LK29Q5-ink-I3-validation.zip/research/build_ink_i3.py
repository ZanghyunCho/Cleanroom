"""I3: normalize branding in the second, synchronous ink-status report.

Does not modify the model/SKU, capacity, region approval or raw state getter.
"""
import hashlib,json,struct
from build_ink_i2 import build as build_i2,ROOT,BASE

def build():
    previous,manifest=build_i2();code=bytearray(previous);address=0x4340f82c
    assert struct.unpack_from('<I',previous,address-BASE)[0]==0xe1a01000
    struct.pack_into('<I',code,address-BASE,0xe3a01000)
    assert all(address-BASE<=i<address-BASE+4 for i,(a,b) in enumerate(zip(previous,code)) if a!=b)
    report=dict(label='I3-synchronous-ink-branding-report',module_sha256=hashlib.sha256(code).hexdigest(),
                I2_module_sha256=manifest['module_sha256'],patches=manifest['patches']+[
                    dict(address=hex(address),before=struct.pack('<I',0xe1a01000).hex(),
                         after=struct.pack('<I',0xe3a01000).hex(),
                         reason='Synchronous per-slot status branding word uses canonical zero, matching the I1 asynchronous report')],
                physical_tested=False,
                preserved=['T44L/SKU and volume lookup tables','Raw state and error selection',
                           'Cover status and operational flags','Separate area approval record 0x29'],
                limits=['Actual printer UI warning source remains unobserved',
                        'Report equivalence does not authenticate a physical cartridge',
                        'Does not suppress separate region, compatibility or explicit errors'])
    (ROOT/'experimental/ink-control.I3.bin').write_bytes(code)
    (ROOT/'experimental/ink-control.I3.json').write_text(json.dumps(report,indent=2)+'\n')
    return bytes(code),report

if __name__=='__main__':
    _,r=build();print(r['module_sha256'])
