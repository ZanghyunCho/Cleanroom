"""I2: treat only the non-logo approval query as already acknowledged."""
import hashlib,json,struct
from build_ink_i1 import build as build_i1,ROOT,BASE

def build():
    original,previous=build_i1();code=bytearray(original);address=0x43403cd8
    old=struct.unpack_from('<I',original,address-BASE)[0]
    assert old>>24==0xeb
    delta=old&0xffffff;delta-=0x1000000 if delta&0x800000 else 0
    assert address+8+delta*4==0x433f5fc8
    assert struct.unpack_from('<I',original,address-BASE-4)[0]==0xe3a00028
    struct.pack_into('<I',code,address-BASE,0xe3a00001)
    assert all(address-BASE<=i<address-BASE+4 for i,(a,b) in enumerate(zip(original,code)) if a!=b)
    report=dict(label='I2-specific-non-logo-approval',module_sha256=hashlib.sha256(code).hexdigest(),
                I1_module_sha256=previous['module_sha256'],patches=previous['patches']+[
                    dict(address=hex(address),before=struct.pack('<I',old).hex(),after=struct.pack('<I',0xe3a00001).hex(),
                         reason='Specific record 0x28 approval read returns acknowledged; record 0x29 and other errors unchanged')],
                semantics='Equivalent approval input at one native status decision, not generic OK/cryptographic acceptance',
                physical_tested=False,limits=['Actual printer warning suppression remains a hardware test',
                    'Explicit errors and other warning paths are not universally suppressed',
                    'Does not change actual ink presence, supply or cartridge authentication'])
    (ROOT/'experimental/ink-control.I2.bin').write_bytes(code)
    (ROOT/'experimental/ink-control.I2.json').write_text(json.dumps(report,indent=2)+'\n')
    return bytes(code),report

if __name__=='__main__':
    _,r=build();print(r['module_sha256'])
