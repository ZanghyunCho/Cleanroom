"""Package tested I1 module onto the known E+LOONA baseline."""
import hashlib,json,struct,zipfile,argparse
from pathlib import Path
from decode_crom import ROOT,decode
from encode_crom import encode
from audit_recovery_failure import loader_audit,checksum_audit

def sha(data):return hashlib.sha256(data).hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--variant',choices=('I1','I2','I3'),default='I1')
    variant=parser.parse_args().variant
    base=ROOT/'experimental/FW7560TL_LK29Q5-LOONA-E.efu'
    assert sha(base.read_bytes())=='5c6535903e9a3409868764392bf6d5a4f7140644c169dd0465d0ee2976d8aafd'
    module=(ROOT/f'experimental/ink-control.{variant}.bin').read_bytes()
    tests=json.loads((ROOT/f'validation/ink-{variant}-native-results.json').read_text())
    count={'I1':1671,'I2':9160,'I3':9784}[variant]
    assert tests['module_sha256']==sha(module) and tests['scenario_count']==count
    with zipfile.ZipFile(base) as z:
        entry=z.getinfo('FW7560TL.rcx');old=z.read(entry)
    first,limit=0x14153,0x21b553
    end=first+4+int.from_bytes(old[first+6:first+10],'big')
    assert old[end:end+2]==b'\xff\xd8'
    size=int.from_bytes(old[end+2:end+6],'big');second=old[end:end+size]
    assert old[end+size:limit]==b'\xff'*(limit-end-size)
    packed,compression=encode(module,old[first:end],positive_padding=True)
    replacement=packed+second;assert len(replacement)<=limit-first
    updated=bytearray(old);updated[first:limit]=replacement+b'\xff'*(limit-first-len(replacement))
    assert decode(updated,first)[0]==module
    sign=old.index(b'EPSONSIGN');body=sign+4096
    assert struct.unpack_from('<I',old,sign+16)[0]==len(old)-body+1
    meta=struct.unpack_from('<I',old,body+28)[0];length=struct.unpack_from('<I',old,body+64)[0]
    start=body+4096+meta;finish=start+length
    struct.pack_into('<H',updated,body+54,sum(updated[start:finish])&65535)
    updated[body+68:body+88]=hashlib.sha1(updated[start:finish]+hashlib.sha1(updated[body:body+14]).digest()).digest()
    previous=0
    for lo,hi in sorted([(first,limit),(body+54,body+56),(body+68,body+88)]):
        assert old[previous:lo]==updated[previous:lo];previous=hi
    assert old[previous:]==updated[previous:] and len(old)==len(updated)
    sections=[];pos=body
    while pos<len(updated):
        h=updated[pos:pos+4096];assert h.startswith(b'EPSON')
        m=struct.unpack_from('<I',h,28)[0];n=struct.unpack_from('<I',h,64)[0]
        lo=pos+4096+m;hi=lo+n;assert hi<=len(updated)
        assert sum(updated[pos+4096:lo])&65535==struct.unpack_from('<H',h,18)[0]
        assert sum(updated[lo:hi])&65535==struct.unpack_from('<H',h,54)[0]
        assert hashlib.sha1(updated[lo:hi]+hashlib.sha1(h[:14]).digest()).digest()==h[68:88]
        sections.append(dict(offset=hex(pos),checks_passed=True));pos=hi
    assert pos==len(updated) and len(sections)==4
    official=(ROOT/'FW7560TL.rcx').read_bytes()
    loader=loader_audit(variant+'-ink',packed,official[0x25bb23:0x25bb23+0xae8],module)
    receiver=(ROOT/'decoded/lk29q5-crom-0027ad53.bin').read_bytes()
    checksum=checksum_audit(variant+'-ink',bytes(updated),receiver[0x4419e2e0-0x4409b000:0x4419e324-0x4409b000])
    assert loader['native_lz_output_exact'] and loader['native_dma_mod48']==0 and checksum['native_checksum_return']==1
    suffix={'I1':'ink-report','I2':'ink-approval','I3':'ink-status'}[variant]
    out=ROOT/f'experimental/FW7560TL_LK29Q5-LOONA-{variant}-{suffix}.efu'
    with zipfile.ZipFile(out,'w') as z:z.writestr(entry,updated)
    with zipfile.ZipFile(out) as z:assert z.testzip() is None and z.read(entry.filename)==updated
    report=dict(artifact=out.name,efu_sha256=sha(out.read_bytes()),rcx_sha256=sha(updated),
                baseline='E+LOONA; G/G2 not included',module_sha256=sha(module),native_cases=count,
                compression=compression,native_loader=loader,native_checksum=checksum,host_sections=sections,
                original_key_signature_receiver_and_LOONA_preserved=True,
                actual_body_length=len(updated)-body,declared_body_length=len(updated)-body+1,
                modified_signature_valid=False,physical_tested=False,full_receiver_replay=False,
                scope={'I1':'I1 report/usage changes','I2':'I1 plus specific non-logo approval query',
                       'I3':'I2 plus synchronous branding report; model/capacity and other status flags preserved'}[variant],
                limits=tests.get('limits',tests.get('limitations')))
    out.with_suffix('.validation.json').write_text(json.dumps(report,indent=2)+'\n')
    Path(str(out)+'.sha256').write_text(report['efu_sha256']+'  '+out.name+'\n')
    print('PASS',variant,'package',report['efu_sha256'])

if __name__=='__main__':main()
