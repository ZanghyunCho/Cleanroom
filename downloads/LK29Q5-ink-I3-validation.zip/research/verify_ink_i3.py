"""I3 full native synchronous status builder, with synthetic per-slot RAM."""
import itertools,json,struct
from build_ink_i3 import build,ROOT
from build_ink_i2 import build as build_i2
from verify_ink_i2 import verify as verify_i2
from probe_maintenance_state import Control

def synchronous(code,state,branding,cover,mode,classification):
    n=Control(code)
    n.u.mem_write(n.literal(0x433f6378,0x27c),struct.pack('<I',mode)+bytes(4))
    ptr=n.literal(0x4340ac3c,-0x428)
    n.u.mem_write(n.literal(0x4340ac38,0x164),b'\0')
    for slot in range(12):
        n.u.mem_write(ptr+4*slot,struct.pack('<I',0x42100000+16*slot))
        n.u.mem_write(0x42100000+16*slot,bytes([0,0,0,slot%2])+bytes(12))
    raw=n.literal(0x43403498,0x118)
    brand=n.literal(0x434033dc,0x1d8)
    n.u.mem_write(raw,bytes([state])*12);n.u.mem_write(brand,bytes([branding])*12)
    n.u.mem_write(n.literal(0x43404030,-0x1d4),bytes([cover])*2)
    n.u.mem_write(n.literal(0x4340a0f8,0xf0),bytes([classification])*12)
    ret=n.call(0x4340f7b0,0x42001000)
    data=bytes(n.u.mem_read(0x42001000,144))
    assert bytes(n.u.mem_read(raw,12))==bytes([state])*12
    assert bytes(n.u.mem_read(brand,12))==bytes([branding])*12
    return ret,data

def main():
    code,manifest=build();old,_=build_i2();regression=verify_i2(code,manifest)
    assert regression['scenario_count']==9160
    cases=[]
    for state,branding,cover,mode,classification in itertools.product(range(13),range(4),(0,1),(0,1),(0,2,4)):
        original_return,before=synchronous(old,state,branding,cover,mode,classification)
        actual_return,after=synchronous(code,state,branding,cover,mode,classification)
        expected=bytearray(before)
        for slot in range(12):expected[slot*12+4:slot*12+8]=bytes(4)
        assert after==expected and actual_return==original_return
        cases.append(dict(state=state,branding=branding,cover=cover,mode=mode,classification=classification,
                          I2_report=before.hex(),I3_report=after.hex(),other_fields_and_raw_inputs_preserved=True))
    # Direct negative control: normal usable slot, branding 1 remains in I2.
    _,before=synchronous(old,0,1,0,0,0);_,after=synchronous(code,0,1,0,0,0)
    assert struct.unpack_from('<I',before,4)[0]==1 and struct.unpack_from('<I',after,4)[0]==0
    report=dict(module_sha256=manifest['module_sha256'],scenario_count=9160+len(cases),I2_regressions=regression,
                synchronous_cases=cases,slot_count_per_case=12,native_verdict_hooks=0,
                physical_tested=False,model_and_capacity_tables_changed=False,
                limits=['Actual print-time Korean UI warning source not traced on hardware',
                        'Raw physical chip branding/authentication is unchanged',
                        'Other status flags, area approval and explicit faults remain',
                        'No electrical chip or whole UI/boot/print execution'])
    assert report['scenario_count']==9784
    (ROOT/'validation/ink-I3-native-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS I3',report['scenario_count'],'cases;',len(cases),'synchronous combinations with 12 slots each')

if __name__=='__main__':main()
